---@class WorldHook
local WorldHook = {}

---@type function?(initFinishCallback: function)
local initializer = nil

---@param callback function
function WorldHook.RegisterInitializer(callback)
    initializer = callback
end

---@param initFinishCallback function
function WorldHook.StartInitializer(initFinishCallback)
    if initializer then
        initializer(initFinishCallback)
    else
        initFinishCallback()
    end
end

return WorldHook