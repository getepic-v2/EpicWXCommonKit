local json
xpcall(function()
    json = require("nextjson")
end,function(error)  end)

--向下兼容
if not json then
    json = require("json")
end
local cs_coroutine = require('common/cs_coroutine')
local waitForEndOfFrame = CS.UnityEngine.WaitForEndOfFrame()
local DispatchNextFrame = function(callback)
    cs_coroutine.start(function()
        coroutine.yield(waitForEndOfFrame)
        callback()
    end)
end




LuaGlobal = {}
LuaGlobal.IsABCFullScreenLoading = false
LuaGlobal.IsABCSmallLoading = false
LuaGlobal.IsChuangjingLoading = false
LuaGlobal.goNative = false
LuaGlobal.ShowFromNative = false
LuaGlobal.DisableResetRoom = false
LuaGlobal.GlobalShowLoading = function(fullscreen)

    if fullscreen then
        --先去掉了
        return
    end
    
    if App.IsABCZone and CourseEnv.ServicesManager:GetUIService().loadingPanel then
        if fullscreen then
            if LuaGlobal.IsABCFullScreenLoading then
                return
            end
            if LuaGlobal.goNative then
                LuaGlobal.goNative = false
                return
            end
           
            APIBridge.RequestAsync("app.buss.ABCLoading.show", {
                ["msg"] = "  "
            })
            LuaGlobal.IsABCFullScreenLoading = true
        else
            if LuaGlobal.IsABCSmallLoading == true then
                return
            end
            g_Log("loading --- 显示")
            CourseEnv.ServicesManager:GetUIService().loadingPanel:ShowLoading(true)
            LuaGlobal.IsABCSmallLoading = true
        end
        g_Log("frame -- LuaGlobal.GlobalShowLoading",fullscreen)
    else
        if LuaGlobal.IsChuangjingLoading == true then
            return
        end
        APIBridge.RequestAsync("app.buss.loading.showLoading", {})
        LuaGlobal.IsChuangjingLoading = true
    end
    

end

LuaGlobal.GlobalHideLoading = function(fullscreen)

    if fullscreen then
        --先去掉了
        return
    end

    if App.IsABCZone and CourseEnv.ServicesManager:GetUIService().loadingPanel then
        if fullscreen then
            if not LuaGlobal.IsABCFullScreenLoading then
                return
            end

            DispatchNextFrame(function()

                APIBridge.RequestAsync("app.buss.ABCLoading.hide", {})
                LuaGlobal.IsABCFullScreenLoading = false

                -- local url = "https://app.chuangjing.com/next-api/v3/mod/get-mod-info-token"
                -- APIBridge.RequestAsync('api.httpclient.request', {
                --     ["url"] = url,
                --     ["headers"] = {
                --         ["Content-Type"] = "application/json"
                --     },
                --     ["data"] = {
                --     ["planIds"] = {App.Info.liveId}
                --     }
                -- }, function(res)
                    
                --     if res ~= nil and res.responseString ~= nil and res.isSuccessed and App:IsAbcZoneMain() then
                --         local resp = res.responseString
                --         local msg = nil
                --         if type(resp) == "string" then msg = json.decode(resp) end
                --         if msg and msg.msg == "success" then
                --             --TODO
                --             g_Log("LuaGlobal 请求mod信息：",table.dump(msg.data.list[1]))
                --             local mv = tonumber(App.Info.configMap.businessField.modInfo.modVersion)
                --             local modInfo = msg.data.list[1]
                --             local modName = modInfo.packageName
                --             local modVersion = tonumber(modInfo.version)
                --             if mv and modVersion and modName == App.ModName and modVersion ~= mv then
                --                 g_Log("LuaGlobal mod版本更新 reload",mv,modVersion)
                --                 LuaGlobal.ReloadCurrentMod()
                --             end
                --         end
                --     end
                        
                -- end)
            end)
        else
            if LuaGlobal.IsABCSmallLoading == false then
                return
            end
            g_Log("loading --- 隐藏")
            CourseEnv.ServicesManager:GetUIService().loadingPanel:ShowLoading(false)
            LuaGlobal.IsABCSmallLoading = false
            if LuaGlobal.ShowFromNative then
                LuaGlobal.ShowFromNative = false
                CourseEnv.ServicesManager:GetObserverService():Fire("unity.loaded.page.show",{})
            end
        end
        g_Log("frame -- LuaGlobal.GlobalHideLoading",fullscreen)
    else
        APIBridge.RequestAsync("app.buss.loading.hideLoading", {})
        LuaGlobal.IsChuangjingLoading = false
    end
    

end

LuaGlobal.BackToABCZone = function(force,show2D)

    if LuaGlobal.IsAlertShowing and not force then
        return
    end

    if not App:IsAbcZoneMain() then
        show2D = false
    end

    LuaGlobal.IsAlertShowing = true

    if App:IsABCZoneApp() then
        local request = {
            ["planId"] = ""
        }
        if show2D == true then
            local byPassData = {
                source = "NativeLogin"
            }
            request = {
           
                ["paramDic"] = {
                    byPass = CourseEnv.ServicesManager:GetJsonService():encode(byPassData)
                }
            }
        end
        
        APIBridge.RequestAsync("app.api.jump.switch", request, nil)
    end
end

LuaGlobal.IsAlertShowing = false
LuaGlobal.ShowExitAlert = function(title)

    if LuaGlobal.IsAlertShowing then
        return
    end
    LuaGlobal.IsAlertShowing = true

    APIBridge.RequestAsync('app.ui.alert',{
        style=0,
        title="提示",
        message= "好像出了点问题，点击重进",
        button={
            {title="重试"}
        }
    }, function(msg)
        LuaGlobal.BackToABCZone(true)
    end)
end


LuaGlobal.ReloadCurrentMod = function()

    if LuaGlobal.IsAlertShowing then
        return
    end

    if not App.IsABCZone then
        return
        --只给abc加这个逻辑
    end

    --通知端上重进当前mod
    g_Log("frame -- ReloadCurrentMod")
    LuaGlobal.BackToABCZone()
end