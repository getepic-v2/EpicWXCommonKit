local class = require("middleclass")
local extends = require("gameplay/extends")
---@type Utils
local utils = require("gameplay/utils")

local log = function(str)
    if App.IsStudioClient then
        -- g_LogError(str)
    else

    end
end
local WBElement = require("mworld/worldBaseElement")
local AttackMangerElement = class("AttackMangerElement", WBElement)

local Attack_Do = "Attack_Do"
local Attack_UnDo = "Attack_UnDo"

local Attack_Result = "Attack_Result"

---@class AttackManger : ExtendedClass
local AttackManger = class("AttackManger")
function AttackManger:initialize()
    extends.Class(self)

    self.StepEnum = {
        Do = 1,
        Sync = 2,
        Result = 3,
        ResultUnique = 4
    }
    self.AttackCountMap = {}
    self.AttackUnDoMap = {} -- 每个技能取消tag最多保存10秒
    self.AttackUniqueResultMap = {} -- 每个技能的唯一结果

    self.eventEmitter = utils.EventEmitter()

end
function AttackManger:Init()
    local key = "AttackManger"
    if self.isInit == true then
        return
    end
    self.isInit = true
    xpcall(function()
        CourseEnv.ServicesManager.Gate:AddElementType(key, AttackMangerElement)
        local dict = CS.Tal.framesync.VisualProperty();
        dict:Add("type", key)
        local ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.zero, Vector3.one,
            Vector3.zero, "WorldElement_" .. key)
        self.vElement = ret

        self:SubscribeMsgKey(Attack_Do)
        self:SubscribeMsgKey(Attack_UnDo)
        self:SubscribeMsgKey(Attack_Result)
    end, function(err)
        g_LogError(err)
    end)

end

function AttackManger:OnDo(callback)
    self.eventEmitter:on("Do", callback)
end
function AttackManger:Do(param)

    local data = {
        duration = 1,
        key = "小锤",
        damage = 10,
        type = 1, -- 1 扇形
        size = {1, 30}

    }
    param.uuid = App.Uuid
    local avatar = self.avatarService.selfAvatar
    param.forward = {
        x = avatar.BodyTrans.forward.x,
        y = avatar.BodyTrans.forward.y,
        z = avatar.BodyTrans.forward.z
    }

    for k, v in pairs(data) do
        if param[k] == nil then
            g_LogError("攻击缺少属性参数:" .. k)
            return
        end
    end

    if self.AttackCountMap[param.key] == nil then
        self.AttackCountMap[param.key] = 1
    else
        self.AttackCountMap[param.key] = self.AttackCountMap[param.key] + 1
    end
    param.count = self.AttackCountMap[param.key]


    
    self:FormatExtra(param, {"forward"})
    self:SendCustomMessage(Attack_Do, param)
    self.eventEmitter:emit("Do", param, self.StepEnum.Do)

end

function AttackManger:UnDo(uuid, key, count)
    local data = {
        key = key,
        count = count,
        uuid = uuid
    }
    if count == nil then
        -- 去上一个
        data.count = self.AttackCountMap[key]
    end
    self:SendCustomMessage(Attack_UnDo, data)
end
function AttackManger:FormatExtra(value, posKeys)
    for k, v in pairs(posKeys) do
        if value[v] then
            value[v] = {
                x = tonumber(string.format("%.3f", value[v].x)),
                y = tonumber(string.format("%.3f", value[v].y)),
                z = tonumber(string.format("%.3f", value[v].z))
            }
        end
    end
end
function AttackManger:SubscribeMsgKey(key)
    self.vElement:SubscribeMsgKey(key)
end
function AttackManger:ReceiveMessage(key, value, isResume)
    -- TODO:
    if key == Attack_Do then
        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            self.eventEmitter:emit("Do", msg, self.StepEnum.Sync)
        end
    elseif key == Attack_UnDo then
        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            local uid = msg.uuid .. ";" .. msg.key .. ";" .. tostring(msg.count)
            self.AttackUnDoMap[uid] = {
                data = msg,
                frameIndex = self.frameIndex,
                endFrameIndex = self.frameIndex + 2 * 60 * App.frameNum
            }
        end
    elseif key == Attack_Result then
        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            local uid = msg.uuid .. ";" .. msg.key .. ";" .. tostring(msg.count)
            if self.AttackUnDoMap[uid] == nil then
                local uniquePlayers = {}
                for k, v in pairs(msg.players) do
                    if self.AttackUniqueResultMap[uid] == nil then
                        self.AttackUniqueResultMap[uid] = {
                            map = {},
                            frameIndex = self.frameIndex,
                            endFrameIndex = self.frameIndex + 2 * 60 * App.frameNum
                        }
                    end
                    if self.AttackUniqueResultMap[uid].map[v] then
                        -- 排除
                    else
                        self.AttackUniqueResultMap[uid].map[v] = true
                        table.insert(uniquePlayers, v)
                    end
                end
                if #uniquePlayers > 0 then
                    self.eventEmitter:emit("Do", msg, self.StepEnum.ResultUnique)
                end

                self.eventEmitter:emit("Do", msg, self.StepEnum.Result)
            else
                self.AttackUniqueResultMap[uid] = nil
            end
        end
    end
end

function AttackManger:Tick()

end
function AttackManger:UpdateFrameIndex(frameIndex)
    self.frameIndex = frameIndex
    for k, v in pairs(self.AttackUnDoMap) do
        if v.endFrameIndex < frameIndex then
            self.AttackUnDoMap[k] = nil
        end
    end
    for k, v in pairs(self.AttackUniqueResultMap) do
        if v.endFrameIndex < frameIndex then
            self.AttackUniqueResultMap[k] = nil
        end
    end
end
function AttackManger:SendCustomMessage(key, body)
    self.vElement:SendCustomMessage(key, body)
end

local AttackInstance = AttackManger:new()

---- WorldElement重载
function AttackMangerElement:initialize(worldElement)
    AttackMangerElement.super.initialize(self, worldElement)
    -- 订阅KEY消息
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function AttackMangerElement:ReceiveMessage(key, value, isResume)
    -- TODO:
    AttackInstance:ReceiveMessage(key, value, isResume)
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function AttackMangerElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function AttackMangerElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function AttackMangerElement:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function AttackMangerElement:AvatarCreated(avatar)

end
function AttackMangerElement:Tick()
    AttackInstance:Tick()
end
function AttackMangerElement:UpdateFrameIndex(frameIndex)
    AttackInstance:UpdateFrameIndex(frameIndex)
end
------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function AttackMangerElement:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function AttackMangerElement:LogicMapStartRecover()
    AttackMangerElement.super:LogicMapStartRecover()
    -- TODO
end
-- 结束恢复方法 (断线重连的时候用)
function AttackMangerElement:LogicMapEndRecover()
    AttackMangerElement.super:LogicMapEndRecover(self)
    -- TODO
end
-- 所有的组件恢复完成
function AttackMangerElement:LogicMapAllComponentRecoverComplete()
end

-- 收到Trigger事件
function AttackMangerElement:OnReceiveTriggerEvent(interfaceId)
end
-- 收到GetData事件
function AttackMangerElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end

-- 脚本释放
function AttackMangerElement:Exit()
    AttackMangerElement.super.Exit(self)
    AttackInstance:Destroy()
end
return AttackInstance
