local class = require("middleclass")
local baseManager = require("gameplay/baseManager")
---@class StatusManager : BaseManager
---@field skillManager SkillManager
local StatusManager = class("StatusManager", baseManager)
local extends = require("gameplay/extends")
local utils = require("gameplay/utils")

local StatusTryLiftKey = "StatusTryLiftKey" -- 状态，尝试举人
local StatusTryLiftFailResKey = "StatusTryLiftFailResKey" -- 举人失败消息消息
local StatusLiftResKey = "StatusLiftResKey" -- 举人状态
local StatusTryReleaseKey = "StatusTryReleaseKey" -- 释放举人状态

local StatusTryStunnedKey = "StatusTryStunnedKey" -- 状态，尝试进入眩晕
local StatusTryStunnedQuitKey = "StatusTryStunnedQuitKey" -- 状态，尝试退出眩晕
local StatusStunnedResKey = "StatusStunnedResKey" -- 眩晕状态
local StatusTryStunnedFailResKey = "StatusTryStunnedFailResKey" -- 眩晕失败消息消息

local RemovedRoleKey = "RemovedRoleKey" --- 解除并加入黑名单
---@type RoleManager
local role = require("gameplay/role")

DOTween = CS.DG.Tweening.DOTween
-- 域 （隔离作用）
StatusManager.Field = {
    lift = "lift",
    avatar = "avatar"
}
-- 域类型要和excel保持一致
-- 通用域类型
StatusManager.CommonType = {
    any = 0
}
-- 举人域类型
StatusManager.LiftType = {
    lifter = 1,
    lifted = 2,
    release = 3
}
-- avatar域 移动状态
StatusManager.AvatarMovement = {
    stunned = 4
}
function StatusManager:initialize()
    StatusManager.super.initialize(self)
    self:LoadConfig({"status"})
    self.liftList = {}
    self.remoteCallbackIdx = 1
    self.remoteCallback = {}
    self.seqMap = {}
    self.modeKeyMap = {}

    self.statusMap = {}

    self.joystickService.OnJump:connect(function(v)
        if self:IsInLiftedState(App.Uuid) then
            self:TryRelease(App.Uuid, "jump")
        end
    end)
    self.statusCallback = {}

    role:OnEnergyChanged(function(e)
        ---@type Status[]
        local status = self:GetRoleStatus(App.Uuid)

        for k, v in pairs(status) do
            local uType = v.u_type
            if uType == 1 then
                -- 能量变化

                local can = self.skillManager:Condition(v.condition, App.Uuid)
                if can == true then
                    if v.type == StatusManager.AvatarMovement.stunned then
                        self:TryStunned(App.Uuid)
                    end

                    if v.from_type == StatusManager.AvatarMovement.stunned and v.type == StatusManager.CommonType.any then
                        self:TryStunnedQuit(App.Uuid)
                    end
                end
            end
        end
    end)

    role:OnRolesHealthChanged(function(e)
        ---@type Status[]
        local status = self:GetRoleStatus(App.Uuid)

        for k, v in pairs(status) do
            local uType = v.u_type
            if uType == 2 then
                -- 血量变化
                local can = self.skillManager:Condition(v.condition, App.Uuid)
                if can == true then
                    if v.type == StatusManager.AvatarMovement.stunned then
                        self:TryStunned(App.Uuid)
                    end

                    if v.from_type == StatusManager.AvatarMovement.stunned and v.type == StatusManager.CommonType.any then
                        self:TryStunnedQuit(App.Uuid)
                    end
                end
            end
        end
    end)

    self.stunnedMap = {}
end
function StatusManager:OnGameplayInitialized()
    self.skillManager:OnDamage(function(data)
        ---@type Status[]
        for k, v in pairs(data.damagedPlayers) do
            if v == App.Uuid then
                local status = self:GetRoleStatus(App.Uuid)
                for k, v in pairs(status) do
                    local uType = v.u_type
                    if uType == 3 then
                        -- 收到伤害
                        local can = self.skillManager:Condition(v.condition, App.Uuid)
                        if can == true then
                            if v.type == StatusManager.AvatarMovement.stunned then
                                self:TryStunned(App.Uuid)
                            end

                            if v.from_type == StatusManager.AvatarMovement.stunned and v.type ==
                                StatusManager.CommonType.any then
                                self:TryStunnedQuit(App.Uuid)
                            end

                            if v.type == StatusManager.CommonType.any and v.from_type == StatusManager.CommonType.any then
                                self.skillManager:FxSequence(v.after_fx, App.Uuid)
                            end
                        end
                    end
                end
            end
        end

    end)

end
function StatusManager:RegisterMessage()
    return {StatusLiftResKey, StatusTryLiftFailResKey, StatusStunnedResKey, StatusTryStunnedFailResKey}
end

function StatusManager:OnStatusChanged(callback)
    self.eventEmitter:on("OnStatusChanged", callback)
end
function StatusManager:StatusChanged(changedList, field)
    for _, v in pairs(changedList) do
        self:ExecStatusChanged(v, field)
    end

    self.eventEmitter:emit("OnStatusChanged", changedList, field)
end
-- 按照域执行状态变化
function StatusManager:ExecStatusChanged(uid, field)
    ---@type Status[]
    local status = self:GetRoleStatus(uid)
    local curStatus = self:GetStatus(uid, field)

    for k, v in pairs(status) do

        if (curStatus[1] == v.from_type and curStatus[2] == v.type) or
            (curStatus[1] == StatusManager.CommonType.any and curStatus[2] == v.type) or
            (curStatus[1] == v.from_type and curStatus[2] == StatusManager.CommonType.any) then

            local condition = self.skillManager:Condition(v.after_fx_condition, uid)
            if condition == true then
                self.skillManager:FxSequence(v.after_fx, uid)
            end

        end

    end
end
---获取原始数据
function StatusManager:GetStatusData(id)
    return self.data.status[id]
end
-- 获取配置中制定角色的需要响应的状态列表
function StatusManager:GetRoleStatus(uid)
    local re = role:GetRole(uid)
    if re == nil then
        return {}
    end
    local roleData = re.role
    local status = roleData.status
    local statusList = {}

    if status ~= nil then
        for k, v in pairs(status) do
            statusList[v] = self:GetStatusData(v)
        end
    end

    return statusList
end
function StatusManager:ReceiveMessage(key, value, isResume)
    -- TODO:
    if key == StatusTryLiftFailResKey then
        local msg = self.jsonService:decode(value[#value])
        self:LiftFailRes(msg)
        self:ReceiveMessageRPC(msg)

    elseif key == StatusLiftResKey then
        local msg = self.jsonService:decode(value[#value])
        self:UpdateLiftStatus(msg)
        self:ReceiveMessageRPC(msg)
    elseif key == StatusStunnedResKey then
        local msg = self.jsonService:decode(value[#value])
        self:StunnedRes(msg)
        self:ReceiveMessageRPC(msg)
    elseif key == StatusTryStunnedFailResKey then
        local msg = self.jsonService:decode(value[#value])
        g_LogError("眩晕失败：" .. msg.msg)
    end

end
function StatusManager:SetStatus(uid, field, last, cur)
    if self.statusMap[uid] == nil then
        self.statusMap[uid] = {}
    end
    self.statusMap[uid][field] = {last, cur}
end
---@return number[]
function StatusManager:GetStatus(uid, field)
    local status = self.statusMap[uid][field]
    if status == nil then
        return {StatusManager.CommonType.any, StatusManager.CommonType.any}
    end
    return status
end

----------举人状态--------------
function StatusManager:TryLift(uid, callback)
    if self:IsInLifterState(uid) then
        -- 最好从ui层过滤
        return
    end
    self:SendCustomMessageRPC(StatusTryLiftKey, {
        uid = uid
    }, callback)
    self:PlayPreLiftAnim(uid)
    local seq = DOTween:Sequence()
    seq:AppendInterval(1)
    seq:AppendCallback(function()
        if self:IsInNoralState(uid) then
            self:StopAllAnim(uid)
        end
    end)
    self:AddSeq(uid, seq)

end

function StatusManager:TryRelease(uid, command, callback)
    self:SendCustomMessageRPC(StatusTryReleaseKey, {
        uid = uid,
        extra = self:GetExtra(uid),
        command = command
    }, callback)
end
function StatusManager:GetExtra(uuid)

    if uuid == nil then
        uuid = App.Uuid
    end

    local avatar = self.avatarService:GetAvatarByUUID(uuid)
    if avatar == nil then
        return nil
    end

    self.extra = {
        f = {
            x = avatar.BodyTrans.forward.x,
            y = avatar.BodyTrans.forward.y,
            z = avatar.BodyTrans.forward.z
        },
        p = {
            x = avatar.VisElement.transform.position.x,
            y = avatar.VisElement.transform.position.y,
            z = avatar.VisElement.transform.position.z
        }
    }

    self:FormatExtra(self.extra, {"f", "p"})

    return self.extra
end
function StatusManager:FormatExtra(value, posKeys)
    for k, v in pairs(posKeys) do
        if value[v] then
            value[v] = {
                x = tonumber(string.format("%.3f", value[v].x)),
                y = tonumber(string.format("%.3f", value[v].y)),
                z = tonumber(string.format("%.3f", value[v].z))
            }
        end
    end
end
function StatusManager:LiftFailRes(msg)

    if msg.uuid == App.Uuid then
        g_LogError("举人失败：" .. msg.uuid)
        g_LogError("举人失败：" .. msg.msg)
        if msg.msg == "没有有效距离目标" then
            -- 尝试查一下问题所在
            for _, v in pairs(self.avatarService:GetAllAvatar()) do
                local str = "举人失败-没有有效距离目标-" .. table.dump(v:GetModeValue())
                g_LogError(str)
            end

        end
    end
end

function StatusManager:UpdateLiftStatus(msg)
    local list = msg.list
    local uid = msg.uid
    local extra = msg.extra
    local command = msg.command

    local needRelease = {}
    local needLift = {}
    for k, v in pairs(self.liftList) do
        if list[k] == nil then
            needRelease[k] = v
        else
            if list[k].next ~= v.next then
                needRelease[k] = v
            end
        end

    end

    for k, v in pairs(list) do
        if self.liftList[k] == nil then
            needLift[k] = v
        end
    end

    self.liftList = list

    for k, v in pairs(needRelease) do

        self:PlayReleaseAnim(k, v.next, msg)

        self:SetStatus(k, StatusManager.Field.lift, StatusManager.LiftType.lifter, StatusManager.LiftType.release)
        self:SetStatus(v.next, StatusManager.Field.lift, StatusManager.LiftType.lifted, StatusManager.LiftType.release)
        local changelist = {k, v.next}
        self:StatusChanged(changelist, StatusManager.Field.lift)

        -- 举人会打断眩晕动作
        -- 这里尝试恢复状态

        local avatar_status = self:GetStatus(v.next, StatusManager.Field.avatar)

        if avatar_status[2] == StatusManager.AvatarMovement.stunned then

            if self.isInBlacklist ~= true then
                self:PlayStunned(v.next)
            end
        end

    end

    for k, v in pairs(needLift) do

        local re_lifter = role:GetRole(k)
        local re_lifted = role:GetRole(v.next)

        if re_lifter == nil or re_lifted == nil then
            if k == App.Uuid then
                self:TryRelease(k, "jump")
            end
        else
            self:PlayLiftAnim(k, v.next, msg)

            self:SetStatus(k, StatusManager.Field.lift, StatusManager.CommonType.any, StatusManager.LiftType.lifter)
            self:SetStatus(v.next, StatusManager.Field.lift, StatusManager.CommonType.any, StatusManager.LiftType.lifted)
            local changelist = {k, v.next}

            self:StatusChanged(changelist, StatusManager.Field.lift)

        end

    end

end
function StatusManager:PlayLiftAnim(lifter, lifted)
    self:AsyncGetAvatar(lifter, AvatarLoadType.PrefabLoaded, function(lifterAvatar)

        self:AsyncGetAvatar(lifted, AvatarLoadType.PrefabLoaded, function(liftedAvatar)

            if lifter ~= App.Uuid then
                self:EnterStaticMode(lifter)
            end
            if lifted ~= App.Uuid then
                self:EnterStaticMode(lifted)
            end

            self:EnterMode(lifted)

            liftedAvatar.VisElement.transform:SetParent(lifterAvatar.BodyTrans)
            liftedAvatar.characterCtrl.isMoving = false

            self:RemoveSeq(lifter)
            self:RemoveSeq(lifted)

            lifterAvatar.characterCtrl:SetBombH(false)
            liftedAvatar.characterCtrl:SetBombH(false)

            local t_lifted = liftedAvatar.VisElement.transform
            local t_lifter = lifterAvatar.VisElement.transform
            t_lifted.localRotation = Quaternion.Euler(Vector3(0, 0, 0))
            liftedAvatar.BodyTrans.transform.rotation = lifterAvatar.BodyTrans.rotation
            local height = 1.1 ---举人和被举人的高度差
            local offset = 0.5 --- 被举人间隔
            local backOffset = -0.35 --- 被举人后退距离
            local liftedBackOffset = -0.1 --- 被举人后退距离
            local finalPos = Vector3(0, height, backOffset)
            self:SetLiftIdleState(lifter)
            self:SetBeCarriedIdleState(lifted)
            t_lifted.localPosition = finalPos
            local check = function()
                local is = self:IsInLifterState(lifter)
                if is then
                    local next = self.liftList[lifter].next
                    if next == lifted and
                        (t_lifted.localPosition.x ~= finalPos.x or t_lifted.localPosition.y ~= finalPos.y or
                            t_lifted.localPosition.z ~= finalPos.z) then
                        g_LogError("举人位置不对...修正")
                        t_lifted.localPosition = finalPos
                    end
                end
            end
            self:StartCoroutine(function()
                self:YieldSeconds(1)
                check()
                self:YieldSeconds(1)
                check()
            end)

            if lifted == App.Uuid then
                self:LocalLiftedState(true)
            end
        end)
    end)
end
function StatusManager:PlayReleaseAnim(lifter, lifted, msg)

    -- 释放要分开处理
    self:AsyncGetAvatar(lifter, AvatarLoadType.PrefabLoaded, function(lifterAvatar)

        self:ExitMode(lifter)
        self:RemoveSeq(lifter)
        self:StopAllAnim(lifter)

        if lifter ~= App.Uuid then
            self:ExitStaticMode(lifter)
        end
    end)

    self:AsyncGetAvatar(lifted, AvatarLoadType.PrefabLoaded, function(liftedAvatar)

        if lifted ~= App.Uuid then
            self:ExitStaticMode(lifted)
        end
        local bodyR = liftedAvatar.BodyTrans.rotation;
        local t = liftedAvatar.VisElement.transform
        if self.oriParent == nil then
            self.oriParent = GameObject.Find("avatar").transform
        end
        t:SetParent(self.oriParent)
        t.rotation = Quaternion.Euler(Vector3(0, 0, 0))
        liftedAvatar.BodyTrans.rotation = bodyR

        self:ExitMode(lifted)

        self:RemoveSeq(lifted)

        self:StopAllAnim(lifted)
        if lifted == App.Uuid then
            self:LocalLiftedState(false)
        end

        if msg.extra ~= nil and msg.command == "throw" then
            local finalPos = self:GetFinalPos(msg)
            liftedAvatar:SetBombedWithFinalPos(finalPos, 6, nil, true)
        end
    end)
end
function StatusManager:GetFinalPos(msg)

    local extra = msg.extra -- 额外信息
    -- 第几层

    if extra == nil or extra.p == nil or extra.f == nil then
        local avatar = App:GetService("Avatar"):GetAvatarByUUID(msg.uuid);
        return avatar.VisElement.transform.position
    end

    local remotePos = Vector3(extra.p.x, extra.p.y, extra.p.z)
    local forward = Vector3(extra.f.x, extra.f.y, extra.f.z)
    local ve = Vector3.zero

    -- ve = forward * 1
    ve = forward * 2

    if msg.force then
        ve = forward * msg.force
    end

    -- 最远点和下落点根据高度计算
    local finalPos = remotePos + ve * 1.2

    finalPos = finalPos + forward
    return finalPos
end
function StatusManager:LocalLiftedState(switch)

    if self.joyHideId_lift ~= nil and switch == true then
        return
    end
    if self.joyHideId_lift == nil and switch == false then
        return
    end
    if switch == true then

        -- 隐藏遥感
        self.joyHideId_lift = self.joystickService:setHidenJoyWithID()

        self:SetGravity(self.avatarService.selfAvatar, false)

        self.uiService:HideOperationArea()
    else
        -- 各种状态恢复
        if self.joyHideId_lift then
            self.joystickService:setVisibleJoyWithID(self.joyHideId_lift)
            self.joyHideId_lift = nil
        end
        self.uiService:ShowOperationArea()
        self:SetGravity(self.avatarService.selfAvatar, true)

    end
end
function StatusManager:SetBeCarriedIdleState(uuid)
    self:AsyncGetAvatar(uuid, AvatarLoadType.PrefabLoaded, function(avatar)
        avatar:PlayBeCarriedIdle(true)
    end)
end
-- avatar进入举人状态
function StatusManager:SetLiftIdleState(uuid)

    self:AsyncGetAvatar(uuid, AvatarLoadType.PrefabLoaded, function(avatar)
        avatar:PlayCarryIdle(true)
    end)
end
-- 举起人的动画
function StatusManager:PlayCarryUp(uuid)
    self:AsyncGetAvatar(uuid, AvatarLoadType.PrefabLoaded, function(avatar)
        avatar:PlayCarryUp(function()
        end, true)
    end)
end
function StatusManager:ReceiveMessageRPC(msg)
    if msg.cb then
        local cb = msg.cb
        if self.remoteCallback[cb] then
            self.remoteCallback[cb](self)
            self.remoteCallback[cb] = nil
        end
    end
end
function StatusManager:SendCustomMessageRPC(key, data, callback)
    if callback then
        data.cb = App.Uuid .. "_" .. self.remoteCallbackIdx
        self.remoteCallback[data.cb] = callback
        self:SendCustomMessage(key, data)
        self.remoteCallbackIdx = self.remoteCallbackIdx + 1
    else
        self:SendCustomMessage(key, data)
    end
end
-- 播放举人前摇动作
function StatusManager:PlayPreLiftAnim(uuid, cb)

    self:AsyncGetAvatar(uuid, AvatarLoadType.PrefabLoaded, function(avatar)
        avatar:PlayPreCarry(true)
    end)

end
function StatusManager:StopAllAnim(uuid, force)
    self:AsyncGetAvatar(uuid, AvatarLoadType.PrefabLoaded, function(avatar)
        avatar:StopAllCarryAnimation(true)
    end)
end
function StatusManager:IsInNoralState(uuid)
    for k, v in pairs(self.liftList) do
        if v.prev == uuid or v.next == uuid then
            return false
        end
    end

    return true
end
function StatusManager:IsInLiftedState(uuid)
    for k, v in pairs(self.liftList) do
        if v.next == uuid then
            return true
        end
    end

    return false
end
function StatusManager:IsInLifterState(uuid)
    for k, v in pairs(self.liftList) do
        if k == uuid then
            return true
        end
    end
    return false
end
function StatusManager:AddSeq(uuid, seq, cb)
    self:RemoveSeq(uuid)
    self.seqMap[uuid] = {
        seq = seq,
        cb = cb
    }
end
function StatusManager:RemoveSeq(uuid)

    if self.seqMap[uuid] ~= nil and self.seqMap[uuid].seq:IsPlaying() then
        self.seqMap[uuid].seq:Kill();
        if self.seqMap[uuid].cb then
            self.seqMap[uuid].cb()
        end
        self.seqMap[uuid] = nil
    end
end
function StatusManager:SetGravity(avatar, v)
    if avatar == self.avatarService.selfAvatar then
        avatar.characterCtrl.switchGravity = v
    end
    avatar.characterCtrl.useGravity = v
end
function StatusManager:EnterMode(uuid)

    -- a进入动画模式
    local avatar = App:GetService("Avatar"):GetAvatarByUUID(uuid);
    if avatar == nil then
        return
    end
    if avatar.characterCtrl.oriIsMovingState == nil then
        avatar.characterCtrl.oriIsMovingState = avatar.characterCtrl.IsMovingState
        avatar.characterCtrl.IsMovingState = function()
            return false
        end
    end

    avatar.characterCtrl:ClearActioin()
    if self.modeKeyMap[uuid] ~= nil then
        avatar:ExitMode(self.modeKeyMap[uuid])
        self.modeKeyMap[uuid] = nil
    end
    local key = avatar:EnterMode(1)
    self.modeKeyMap[uuid] = key

    if self.avatarService.selfAvatar == avatar then
        avatar.characterCtrl.ign = true
    end

end
function StatusManager:ExitMode(uuid)
    local avatar = App:GetService("Avatar"):GetAvatarByUUID(uuid);
    if avatar == nil then
        return
    end
    if avatar.characterCtrl.oriIsMovingState ~= nil then
        avatar.characterCtrl.IsMovingState = avatar.characterCtrl.oriIsMovingState
        avatar.characterCtrl.oriIsMovingState = nil
    end

    avatar.characterCtrl:ClearActioin()
    if self.modeKeyMap[uuid] ~= nil then
        avatar:ExitMode(self.modeKeyMap[uuid])
        self.modeKeyMap[uuid] = nil
    end

    if self.avatarService.selfAvatar == avatar then
        avatar.characterCtrl.ign = false
    end

end
function StatusManager:EnterStaticMode(uuid)
    -- a进入动画模式
    local avatar = App:GetService("Avatar"):GetAvatarByUUID(uuid);
    if avatar == nil then
        return
    end
    if self.staticmodeKeyMap == nil then
        self.staticmodeKeyMap = {}
    end
    if self.staticmodeKeyMap[uuid] ~= nil then
        avatar:ExitMode(self.staticmodeKeyMap[uuid])
        self.staticmodeKeyMap[uuid] = nil
    end
    local key = avatar:EnterMode(2)
    self.staticmodeKeyMap[uuid] = key

end
function StatusManager:ExitStaticMode(uuid)
    local avatar = App:GetService("Avatar"):GetAvatarByUUID(uuid);
    if avatar == nil then
        return
    end
    if self.staticmodeKeyMap == nil then
        self.staticmodeKeyMap = {}
    end
    if self.staticmodeKeyMap[uuid] ~= nil then
        avatar:ExitMode(self.staticmodeKeyMap[uuid])
        self.staticmodeKeyMap[uuid] = nil
    end
end

-- 眩晕状态
function StatusManager:TryStunnedQuit(uid, cb)
    -- g_LogError("尝试退出眩晕状态" .. uid)
    self:SendCustomMessageRPC(StatusTryStunnedQuitKey, {
        uid = uid
    })
end
function StatusManager:TryStunned(uid, cb)
    -- g_LogError("尝试进入眩晕状态" .. uid)
    self:SendCustomMessageRPC(StatusTryStunnedKey, {
        uid = uid
    })
end
function StatusManager:StunnedRes(msg)
    local list = msg

    local needQuit = {}
    local needStunned = {}
    for k, v in pairs(self.stunnedMap) do
        if v == true and list[k] ~= true then
            table.insert(needQuit, k)
        end
    end

    for k, v in pairs(list) do
        if v == true and self.stunnedMap[k] ~= true then
            table.insert(needStunned, k)
        end
    end

    for k, v in pairs(needQuit) do
        self:SetStatus(v, StatusManager.Field.avatar, StatusManager.AvatarMovement.stunned, StatusManager.CommonType.any)
        local changelist = {v}
        self:StatusChanged(changelist, StatusManager.Field.avatar)
        self:PlayStunnedQuit(v)

    end

    for _, v in pairs(needStunned) do

        local re = role:GetRole(v)

        if re == nil then
            if v == App.Uuid then
                self:TryStunnedQuit(v)
            end
        else

            self:SetStatus(v, StatusManager.Field.avatar, StatusManager.CommonType.any,
                StatusManager.AvatarMovement.stunned)
            local changelist = {v}
            self:StatusChanged(changelist, StatusManager.Field.avatar)
            self:PlayStunned(v)
        end

    end

    self.stunnedMap = list

end
function StatusManager:PlayStunned(uid)
    if uid ~= App.Uuid then
        return
    end
    self:LocalStateStunned(true)
    self:AsyncGetAvatar(uid, AvatarLoadType.PrefabLoaded, function(avatar)
        avatar:PlayDaoDiAni(function()
            if self:IsInStatus(uid, "stunned") == 1 then
                avatar:PlayDaoDiIdelAni(function()
                end, true)
            end
        end, true)
    end)

end
function StatusManager:PlayStunnedQuit(uid)
    if uid ~= App.Uuid then
        return
    end
    self:LocalStateStunned(false)

    self:AsyncGetAvatar(uid, AvatarLoadType.PrefabLoaded, function(avatar)
        avatar:PlayStandUpAni(true)
    end)
end
function StatusManager:LocalStateStunned(switch)

    if self.joyHideId_stunned ~= nil and switch == true then
        return
    end
    if self.joyHideId_stunned == nil and switch == false then
        return
    end

    if switch == true then

        -- 隐藏遥感
        self.joyHideId_stunned = self.joystickService:setHidenJoyWithID()
        self.jumpHideId_stunned = self.joystickService:setHidenJumpWithID()

        self.uiService:HideOperationArea()

    else
        -- 各种状态恢复
        if self.joyHideId_stunned then
            self.joystickService:setVisibleJoyWithID(self.joyHideId_stunned)
            self.joyHideId_stunned = nil
        end

        if self.jumpHideId_stunned then
            self.joystickService:setVisibleJumpWithID(self.jumpHideId_stunned)
            self.jumpHideId_stunned = nil
        end

        self.uiService:ShowOperationArea()

    end
end
function StatusManager:IsInStatus(uid, key)

    if key == "lifted" then
        if self:IsInLiftedState(uid) == true then
            return 1
        else
            return 0
        end
    elseif key == "stunned" then
        if self.stunnedMap[uid] == true then
            return 1
        else
            return 0
        end
    end

    return 0
end

function StatusManager:ClearAndAddBlacklist(uid)
    if uid == nil then
        uid = App.Uuid
    end

    if uid == App.Uuid then
        self.isInBlacklist = true
    end
    self:SendCustomMessageRPC(RemovedRoleKey, {
        uid = uid
    })
end

local StatusManagerInstance = StatusManager:new()
return StatusManagerInstance
