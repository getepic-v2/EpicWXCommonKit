return
{
["幸存者-野怪1_1"] = {id="幸存者-野怪1_1",name="幸存者-野怪1_1",desc="幸存者-野怪1_1",asset_id="Asset_Monster_Go1",attack_range=1.5,dead_fx={"FX_Survival_Monster_Dead","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Crash1",},},
["幸存者-野怪1_2"] = {id="幸存者-野怪1_2",name="幸存者-野怪1_2",desc="幸存者-野怪1_2",asset_id="Asset_Monster_Go1",attack_range=1.5,dead_fx={"FX_Survival_Monster_Dead","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Crash2",},},
["幸存者-野怪1_3"] = {id="幸存者-野怪1_3",name="幸存者-野怪1_3",desc="幸存者-野怪1_3",asset_id="Asset_Monster_Go1",attack_range=1.5,dead_fx={"FX_Survival_Monster_Dead","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Crash3",},},
["幸存者-野怪1_4"] = {id="幸存者-野怪1_4",name="幸存者-野怪1_4",desc="幸存者-野怪1_4",asset_id="Asset_Monster_Go1",attack_range=1.5,dead_fx={"FX_Survival_Monster_Dead","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Crash4",},},
["幸存者-野怪2_1"] = {id="幸存者-野怪2_1",name="幸存者-野怪2_1",desc="幸存者-野怪2_1",asset_id="Asset_Monster_Go2",attack_range=5,dead_fx={"FX_Survival_Monster_Dead2","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Bomb1_1",},},
["幸存者-野怪2_2"] = {id="幸存者-野怪2_2",name="幸存者-野怪2_2",desc="幸存者-野怪2_2",asset_id="Asset_Monster_Go2",attack_range=5,dead_fx={"FX_Survival_Monster_Dead2","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Bomb1_2",},},
["幸存者-野怪2_3"] = {id="幸存者-野怪2_3",name="幸存者-野怪2_3",desc="幸存者-野怪2_3",asset_id="Asset_Monster_Go2",attack_range=5,dead_fx={"FX_Survival_Monster_Dead2","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Bomb1_3",},},
["幸存者-野怪2_4"] = {id="幸存者-野怪2_4",name="幸存者-野怪2_4",desc="幸存者-野怪2_4",asset_id="Asset_Monster_Go2",attack_range=5,dead_fx={"FX_Survival_Monster_Dead2","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Bomb1_4",},},
["幸存者-野怪3_1"] = {id="幸存者-野怪3_1",name="幸存者-野怪3_1",desc="幸存者-野怪3_1",asset_id="Asset_Monster_Go3",attack_range=7,dead_fx={"FX_Survival_Monster_Dead3","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Bomb2_1",},},
["幸存者-野怪3_2"] = {id="幸存者-野怪3_2",name="幸存者-野怪3_2",desc="幸存者-野怪3_2",asset_id="Asset_Monster_Go3",attack_range=7,dead_fx={"FX_Survival_Monster_Dead3","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Bomb2_2",},},
["幸存者-野怪3_3"] = {id="幸存者-野怪3_3",name="幸存者-野怪3_3",desc="幸存者-野怪3_3",asset_id="Asset_Monster_Go3",attack_range=7,dead_fx={"FX_Survival_Monster_Dead3","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Bomb2_3",},},
["幸存者-野怪3_4"] = {id="幸存者-野怪3_4",name="幸存者-野怪3_4",desc="幸存者-野怪3_4",asset_id="Asset_Monster_Go3",attack_range=7,dead_fx={"FX_Survival_Monster_Dead3","FX_Survival_Monster_DeadSmoke",},skills={"Survival_Monster_Bomb2_4",},},
["幸存者-野怪4"] = {id="幸存者-野怪4",name="幸存者-野怪4",desc="幸存者-野怪4",asset_id="Asset_Monster_Go4",attack_range=7,dead_fx={"FX_Survival_Monster_Dead",},skills={"Survival_Monster_Bomb2_4",},},
}