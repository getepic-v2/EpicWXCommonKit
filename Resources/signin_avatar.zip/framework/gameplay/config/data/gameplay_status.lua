return
{
["Any-Lifter"] = {id="Any-Lifter",name="",desc="",from_type=0,type=1,after_fx={"FX_Test_Change_Button_Throw","FX_Hide_Some_Skill_Buttons",},condition="",after_fx_condition="",},
["Any-Lifted"] = {id="Any-Lifted",name="",desc="",from_type=0,type=2,after_fx={"FX_Text_Hide_All_Skill_Buttons",},condition="",after_fx_condition="",},
["Lifter-Release"] = {id="Lifter-Release",name="",desc="",from_type=1,type=3,after_fx={"FX_Text_Show_All_Skill_Buttons","FX_Test_Change_Button_Lift",},condition="",after_fx_condition="",},
["Lifted-Release"] = {id="Lifted-Release",name="",desc="",from_type=2,type=3,after_fx={"FX_Text_Show_All_Skill_Buttons",},condition="",after_fx_condition="Con_Not_In_Stunned",},
["Any-Stunned"] = {id="Any-Stunned",name="",desc="",from_type=0,type=4,after_fx={"FX_Smash_Stunned_Star","FX_Text_Hide_All_Skill_Buttons",},u_type=1,condition="Con_Smash_Stunned && Con_Smash_Alive ",after_fx_condition="",},
["Stunned-Any"] = {id="Stunned-Any",name="",desc="",from_type=4,type=0,after_fx={"FX_Smash_Stunned_Star_Remove","FX_Text_Show_All_Skill_Buttons",},u_type=1,condition="Con_Smash_Stunned_Off",after_fx_condition="",},
["Any-Stunned2"] = {id="Any-Stunned2",name="",desc="",from_type=0,type=4,after_fx={"FX_Smash_Stunned_Star","FX_Text_Hide_All_Skill_Buttons",},u_type=2,condition=" !Con_Smash_Alive",after_fx_condition="",},
["OnDamage"] = {id="OnDamage",name="",desc="",from_type=0,type=0,after_fx={"FX_Survival_RealShield_Remove",},u_type=3,condition="",after_fx_condition="Con_Survival_Shield",},
["Parkour-Any-Stunned"] = {id="Parkour-Any-Stunned",name="",desc="",from_type=0,type=4,after_fx={"FX_Smash_Stunned_Star","FX_Text_Hide_All_Skill_Buttons",},condition="",after_fx_condition="",},
["Parkour-Stunned-Any"] = {id="Parkour-Stunned-Any",name="",desc="",from_type=4,type=0,after_fx={"FX_Smash_Stunned_Star_Remove","FX_Text_Show_All_Skill_Buttons",},condition="",after_fx_condition="",},
}