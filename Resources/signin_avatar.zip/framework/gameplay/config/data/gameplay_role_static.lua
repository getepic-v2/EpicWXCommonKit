return
{
["monster"] = {id="monster",name="怪物",desc="怪物",role_id="",type="",gameobject_name="传说皮肤-假面超人",},
}