return
{
["0"] = {id="0",name="探测",desc=[[躲猫猫游戏中，追击方使用技能
探测自身周围躲避者]],skill="Skill_Hide_Radar",asset_id="Asset_0",show_aim=false,},
["1"] = {id="1",name="变身",desc="躲猫猫游戏中，躲避方变成场景模型",skill="SKill_Hide_Transform",asset_id="Asset_1",show_aim=false,},
["2"] = {id="2",name="隐身",desc="躲猫猫游戏中，躲避方隐身",skill="Skill_Hide_Invisible",asset_id="Asset_2",show_aim=false,},
["3"] = {id="3",name="透视",desc="躲猫猫游戏中，躲避方透视",skill="Skill_Hide_Xray",asset_id="Asset_3",show_aim=false,},
["4"] = {id="4",name="攻击",desc="躲猫猫游戏中，追击方的攻击瞄准",skill="Skill_Hide_Attack_2",asset_id="Asset_4",show_aim=true,},
["5"] = {id="5",name="定位",desc="躲猫猫游戏中，追击方的大技能，放出指向躲避者的箭头",skill="Skill_Hide_Arrow",asset_id="Asset_5",show_aim=false,},
["6"] = {id="6",name="答题",desc="答题",skill="Skill_Answer",asset_id="Asset_6",show_aim=false,},
["7"] = {id="7",name="近战攻击",desc="近战攻击",skill="Skill_Test_Attack_Hammer",asset_id="Asset_10",show_aim=false,},
["8"] = {id="8",name="远程攻击",desc="远程攻击",skill="Skill_Test_Attack_Bomb",asset_id="Asset_11",show_aim=true,},
["9"] = {id="9",name="野蛮冲撞",desc="冲撞",skill="Skill_Test_Attack_Crash",asset_id="Asset_12",show_aim=false,},
["10"] = {id="10",name="举人",desc="举人",skill="Skill_Test_Lift",asset_id="Asset_8",show_aim=false,},
["11"] = {id="11",name="抛人",desc="抛人",skill="Skill_Test_Throw",asset_id="Asset_9",show_aim=false,},
["12"] = {id="12",name="跑酷冲刺",desc="跑酷冲刺",skill="Parkour_Blank2",asset_id="Parkour_Blank",show_aim=false,},
["13"] = {id="13",name="空占位",desc="跑酷冲刺",skill="Parkour_Blank",asset_id="Parkour_Blank",show_aim=false,},
["14"] = {id="14",name="跑酷-香蕉皮",desc="跑酷-香蕉皮",skill="Parkour_Banana",asset_id="Parkour_Banana",show_aim=false,},
["15"] = {id="15",name="跑酷-乌贼",desc="跑酷-乌贼",skill="Parkour_Inkfish",asset_id="Parkour_Inkfish",show_aim=false,},
["16"] = {id="16",name="跑酷-闪电",desc="跑酷-闪电",skill="Parkour_Lightning",asset_id="Parkour_Lightning",show_aim=false,},
["17"] = {id="17",name="跑酷冲刺-禁用",desc="跑酷冲刺",skill="Parkour_Sprint_Disable",asset_id="Parkour_Sprint_Disable",show_aim=false,},
}