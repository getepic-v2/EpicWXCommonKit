local class = require("middleclass")
---@class BaseManager : ExtendedClass
local BaseManager = class("BaseManager")
local extends = require("gameplay/extends")
local utils = require("gameplay/utils")
function BaseManager:initialize()
    extends.Class(self)
    self.eventEmitter = utils.EventEmitter()
end
function BaseManager:LoadConfig(names)
    self.data = {}
    for i, v in ipairs(names) do
        local d = utils.RequireLua("gameplay",v)
        if d then
            self.data[v] = d
        end
    end
end

return BaseManager
