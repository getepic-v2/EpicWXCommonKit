local class = require("middleclass")
local baseManager = require("gameplay/baseManager")
---@class AssetsMapManager : BaseManager
local AssetsMap = class("AssetsMap", baseManager)
local extends = require("gameplay/extends")
local utils = require("gameplay/utils")
function AssetsMap:initialize()
    extends.Class(self)
    self.assets = {}
    self.pool = {}
    self:LoadConfig({"assetmap"})
end
function AssetsMap:ConfigRegister()
    if self.data.assetmap == nil then
        return
    end

    local needHide = {}
    for k, v in pairs(self.data.assetmap) do
        local go = GameObject.Find(v.gameobject_name)
        if go then
            self:Register(v.id, go)
            table.insert(needHide, go)
        end

    end

    for _, v in pairs(needHide) do
        v:SetActive(false)
    end
    

end
--- @param id string
--- @param go GameObject  
function AssetsMap:Register(id, go)
    self.assets[id] = go
end
--- @return GameObject
function AssetsMap:GetAssetGo(id)
    return self.assets[id]
end
function AssetsMap:NewAssetGo(id)
    if self.pool[id]~=nil then
        local gos = self.pool[id]
        if #gos > 0 then
            local go = gos[1]
            table.remove(gos, 1)
            self:Postprocess(go)
            go:SetActive(true)
            return go
        end
    end

    local tmp = self.assets[id]
    if tmp == nil then
        return g_LogError("资源不存在")
    end
    local go = GameObject.Instantiate(tmp)
    go:SetActive(true)
    self:Postprocess(go)
    return go
end
function AssetsMap:DestroyGo(id,go)
    if self.pool[id] == nil then
        self.pool[id] = {}
    end
    table.insert(self.pool[id], go)
    go.transform:SetParent(nil)
    go:SetActive(false)
end
function AssetsMap:Postprocess(go)
    local trailRenderers= go:GetComponentsInChildren(typeof(CS.UnityEngine.TrailRenderer))

    for i = 0, trailRenderers.Length - 1 do
        local trailRenderer = trailRenderers[i]
        trailRenderer:Clear()
    end

    go.transform.localRotation = Quaternion.Euler(0, 0, 0);
end
local assetsMapInstance = AssetsMap:new()
return assetsMapInstance
