Color = CS.UnityEngine.Color
SceneManagement = CS.UnityEngine.SceneManagement
SceneManager = SceneManagement.SceneManager
LocalPhysicsMode = SceneManagement.LocalPhysicsMode
Physics = CS.UnityEngine.Physics
Mathf = CS.UnityEngine.Mathf
Input = CS.UnityEngine.Input
local extends = require("gameplay/extends")
local class = require("middleclass")
local utils = require("gameplay/utils")
---@class XrayEffect : ExtendedClass
local XrayEffect = class("XrayEffect")
function XrayEffect:initialize()
    extends.Class(self)
    self.eventEmitter = utils.EventEmitter()

    self.list = {}
    self:OnAvatarChildrenChanged(function(_uuid)
        self:UpdateAvatarOutline(_uuid)
    end)
end
function XrayEffect:UpdateAvatarOutline(_uuid)
    local v = self.list[_uuid]
    local avatar = self.avatarService:GetAvatarByUUID(_uuid)
    if avatar == nil then
        g_LogError("avatar 不存在" .. _uuid)
        return nil
    end

    if avatar.character == nil then
        g_LogError("avatar 不可见" .. _uuid)
        return nil
    end
    -- 名字需要单独处理一下
    local outlinable = self:GetOutline(avatar, v)
    local titleGroup = avatar.character.transform:Find("RoleCanvas")
    xpcall(function()
        self:AddRenderers(outlinable)
    end, function()

    end)

    return outlinable
end
function XrayEffect:GetOutline(avatar, value)
    local outlinable = avatar.BodyTrans.gameObject:GetComponent(typeof(CS.EPOOutline.Outlinable))

    if outlinable == nil then
        outlinable = avatar.BodyTrans.gameObject:AddComponent(typeof(CS.EPOOutline.Outlinable))

        outlinable.RenderStyle = 2;
        outlinable.FrontParameters.Enabled = false
        if self.InterlacedShader == nil then
            self.InterlacedShader = CS.UnityEngine.Resources.Load("Easy performant outline/Shaders/Fills/Interlaced");
        end

        outlinable.BackParameters.FillPass.Shader = self.InterlacedShader

        outlinable.BackParameters.Color = CS.UnityEngine.Color.green
        outlinable.BackParameters.FillPass:SetColor("_PublicColor", CS.UnityEngine.Color.green)
        outlinable.BackParameters.FillPass:SetColor("_PublicGapColor", CS.UnityEngine.Color.clear)

        outlinable.enabled = false
    end

    if value.color then
        outlinable.BackParameters.Color = value.color
        outlinable.BackParameters.FillPass:SetColor("_PublicColor", value.color)
        outlinable.BackParameters.FillPass:SetColor("_PublicGapColor", CS.UnityEngine.Color.clear)
    end
    return outlinable
end

function XrayEffect:Show(go, color, type)
    local outlinable = go:GetComponent(typeof(CS.EPOOutline.Outlinable))

    if outlinable == nil then
        outlinable = go:AddComponent(typeof(CS.EPOOutline.Outlinable))

        outlinable.RenderStyle = 2;
        outlinable.FrontParameters.Enabled = false
        if self.InterlacedShader == nil then
            self.InterlacedShader = CS.UnityEngine.Resources.Load("Easy performant outline/Shaders/Fills/Interlaced");
        end

        -- 扫描
        outlinable.BackParameters.FillPass.Shader = self.InterlacedShader
        -- 默认绿色
        outlinable.BackParameters.Color = CS.UnityEngine.Color.green
        outlinable.BackParameters.FillPass:SetColor("_PublicColor", CS.UnityEngine.Color.green)
        outlinable.BackParameters.FillPass:SetColor("_PublicGapColor", CS.UnityEngine.Color.clear)

        outlinable.enabled = false
    end

    if color then
        outlinable.BackParameters.Color = color
        outlinable.BackParameters.FillPass:SetColor("_PublicColor", color)
        outlinable.BackParameters.FillPass:SetColor("_PublicGapColor", CS.UnityEngine.Color.clear)
    end
    self:AddRenderers(outlinable, type)
    outlinable.enabled = true
end
function XrayEffect:AddRenderers(outlinable, type)
    if type == "MeshRenderer" then
        outlinable:AddAllChildRenderersToRenderingList(CS.EPOOutline.RenderersAddingMode.MeshRenderer);
    elseif type == "All" then
        outlinable:AddAllChildRenderersToRenderingList(CS.EPOOutline.RenderersAddingMode.All);
    elseif type == "SpriteRenderer" then
        outlinable:AddAllChildRenderersToRenderingList(CS.EPOOutline.RenderersAddingMode.SpriteRenderer);
    else
        outlinable:AddAllChildRenderersToRenderingList(CS.EPOOutline.RenderersAddingMode.SkinnedMeshRenderer);
    end

end
function XrayEffect:Hide(go, color)
    local outlinable = go:GetComponent(typeof(CS.EPOOutline.Outlinable))
    if outlinable then
        outlinable.enabled = false
    end
end
function XrayEffect:Set(list)
    self.list = list
    for k, v in pairs(list) do
        local avatar = self.avatarService:GetAvatarByUUID(k)

        local enable = v.enable

        if enable then
            local outlinable = self:UpdateAvatarOutline(avatar.avatarUuid)
            if outlinable then
                outlinable.enabled = true
            else
                g_LogError("outlinable is nil")
            end
        else
            local outlinable = avatar.BodyTrans.gameObject:GetComponent(typeof(CS.EPOOutline.Outlinable))
            if outlinable ~= nil then
                outlinable.enabled = false
            end
        end

    end

end

function XrayEffect:OnAvatarChildrenChanged(callback)
    self.eventEmitter:on("onAvatarTransformChanged", callback)
end
-- 有些技能需要知道avatar的解构变化，用来刷新状态，比如隐身和透视技能
-- 默认会同步
function XrayEffect:AvatarTransformChanged(uuid)
    self.eventEmitter:emit("onAvatarTransformChanged", uuid)
end
return XrayEffect
