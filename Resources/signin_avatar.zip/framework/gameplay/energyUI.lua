---
---  Author: 【彩滨滨】
---  AuthorID: 【246276】
---  CreateTime: 【2024-3-29 17:07:40】
--- 【FSync】
--- 【大乱斗】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")
---@class fsync_2f378a3a_8eab_42ad_afa4_e4e5c1e1bc38 : WorldBaseElement
local FsyncElement = class("fsync_2f378a3a-8eab-42ad-afa4-e4e5c1e1bc38", WBElement)

local Util = require(MAIN_SCRIPTS_LOC .. "common/util")
---@param worldElement CS.Tal.framesync.WorldElement
function FsyncElement:initialize(worldElement)
    FsyncElement.super.initialize(self, worldElement)
    -- 订阅KEY消息
end
function FsyncElement:setVisElement(parent, VisElement)
    self.parent = parent
    self.VisElement = VisElement
    -- 当前能量值
    self.currentEnergy = 0
    self:initService()
    self:initListener()
    self:InitView()
end

function FsyncElement:initService()
    self.commonService = App:GetService("CommonService")
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.joyService = CourseEnv.ServicesManager:GetJoystickService()
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.uiService = CourseEnv.ServicesManager:GetUIService()
end

function FsyncElement:initListener()
    -- 自己能量变化

    self.observerService:Watch("setEnergy", function(key,value)
        local data = value[0]
        if self.nengliang == nil then
            self.waitingShow  = true
            self.waitingCurrentEnergy = data.value
            return
        end
        self:SetEnergy(data.value)
    end)
    self.observerService:Watch("hideEnergyUI", function(key,value)
        if self.nengliang == nil then
            self.waitingShow  = false
            return
        end
        self.nengliang.gameObject:SetActive(false)
    end)

    self.observerService:Watch("showEnergyUI", function(key,value)
        if self.nengliang == nil then
            self.waitingShow  = true
            return
        end
        self.nengliang.gameObject:SetActive(true)
    end)

end

function FsyncElement:InitView()
    local prefabPath = "modules/" .. RESOURCE_LOC .. "/assets/energyUI/assets/Prefabs/Canvas.prefab"
    ResourceManager:LoadGameObjectWithExName(prefabPath, function(go)
        -- 等待人数
        -- 提醒关闭弹窗
        self.root = self.VisElement.gameObject
        self.rootTrans = self.root.transform

        self.rootView = GameObject.Instantiate(go).transform
        self.rootView:SetParent(self.rootTrans)
        self.rootView.localPosition = Vector3.zero
        self.rootView.localScale = Vector3.one
        self.rootView.localRotation = Quaternion.identity



        -- 能量条UI
        self.nengliang = self.rootView.transform:FindChildWithName("nengliang")
        self.nengliang.gameObject:SetActive(false)

        self.doubleEnergy = self.nengliang:FindChildWithName("doubleEnergy") -- 双倍能量图标
        self.doubleEnergy.gameObject:SetActive(false)

        self.nengliangzhi = self.nengliang:Find("EnergyTips") -- 增加能量提示
        self.nengliangzhi.gameObject:SetActive(false)
        self.nengliangzhiNum = self.nengliangzhi:Find("num").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

        self.nengliangText1 = self.nengliang:Find("text1").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.nengliangText2 = self.nengliang:Find("text2").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

        self.nengliangtiao = self.nengliang:Find("nengliangtiao")
        self.nengliangtiaoRect = self.nengliangtiao:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.nengliangtiaoFen = self.nengliang:Find("nengliangtiao-fen")
        self.nengliangtiaoRectFen = self.nengliangtiaoFen:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.nengliangtiaoAnim = self.nengliang:Find("mask/anim")
        self.nengliangtiaoAim = self.nengliang:Find("nengliangtiao/aim")
        self.nengliangtiaoAimFen = self.nengliang:Find("nengliangtiao-fen/aim")


        if self.waitingShow == true then
            self.nengliang.gameObject:SetActive(true)
            self:SetEnergy(self.waitingCurrentEnergy)
        end

    end)

end

function FsyncElement:SetEnergy(eValue)
    local energy =  eValue - self.currentEnergy
    if energy > 0 then
        self:nengliangzhiTips(energy)
    end
    local lastValue = self.currentEnergy
    self.currentEnergy = energy + self.currentEnergy
    if self.currentEnergy >= 100 then
        self.currentEnergy = 100
        -- 能量已满
        if self.energyFullAudio then
            self.audioService:PlayClipOneShot(self.energyFullAudio, function()
            end)
        end
    end
    if self.currentEnergy <= 0 then
        self.currentEnergy = 0
        -- 能量已空
    end
    local newValue = self.currentEnergy

    self.nengliangText1.text = "<color=red>" .. self.currentEnergy .. "</color>" .. "/" .. 100
    self.nengliangText2.text = "/" .. 100

    if self.currentEnergy <= 30 then
        -- 添加能量小于30时toast
        if lastValue > 30 then
            -- self.uiService.commonMenu:ShowToast("能量即将耗尽，请及时充能", 2)
        end

        self.nengliangtiao.gameObject:SetActive(false)
        self.nengliangtiaoFen.gameObject:SetActive(true)
        self.nengliangtiaoAnim:Find("light").gameObject:SetActive(false)
        self.nengliangtiaoAnim:Find("light-fen").gameObject:SetActive(true)
    else
        -- 添加回满能量提示toast
        if lastValue < 100 and newValue == 100 then
            -- self.uiService.commonMenu:ShowToast("能量已满，快去释放技能吧", 2)
        end
        self.nengliangtiao.gameObject:SetActive(true)
        self.nengliangtiaoFen.gameObject:SetActive(false)
        self.nengliangtiaoAnim:Find("light").gameObject:SetActive(true)
        self.nengliangtiaoAnim:Find("light-fen").gameObject:SetActive(false)
    end
    -- local lastValue = self.nengliangtiaoRect.sizeDelta.x
    -- local newValue = self.currentEnergy * (276 / 100)
    self.nengliangtiaoRect.sizeDelta = Vector2(self.currentEnergy * (276 / 100), self.nengliangtiaoRect.sizeDelta.y)
    self.nengliangtiaoRectFen.sizeDelta = Vector2(self.currentEnergy * (276 / 100),
        self.nengliangtiaoRectFen.sizeDelta.y)
    if self.seqEnergy then
        self.seqEnergy:Kill()
        self.seqEnergy = nil
    end

    -- if self.currentEnergy < 10 then
    --     self.nengliang:Find("mask").gameObject:SetActive(false)
    -- else
    --     self.nengliang:Find("mask").gameObject:SetActive(true)
    -- end

    if lastValue > newValue then
        -- 减少
        self.nengliangtiaoAnim.position = Vector3(self.nengliangtiaoAim.position.x, self.nengliangtiaoAnim.position.y,
            self.nengliangtiaoAnim.position.z)
    else
        -- 增加
        -- self.nengliangtiaoAnim.position = Vector3(self.nengliangtiaoAim.position.x, self.nengliangtiaoAnim.position.y, self.nengliangtiaoAnim.position.z)

        -- 延迟运动

        self.seqEnergy = DOTween:Sequence()
        self.seqEnergy:Append(self.nengliangtiaoAnim:DOMoveX(self.nengliangtiaoAim.position.x, 0.5))
    end
end

-- 能量值
function FsyncElement:nengliangzhiTips(addEnergy, callback)
    self.nengliangzhi.gameObject:SetActive(true)
    self.nengliangzhiNum.text = "+" .. addEnergy
    -- 开启协程
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(3)
        self.nengliangzhi.gameObject:SetActive(false)
        if callback then
            callback()
        end
    end)
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function FsyncElement:ReceiveMessage(key, value, isResume)

end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function FsyncElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarPrefabLoaded(avatar)
    self.selfAvatar = avatar
    -- 设置人物fov
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function FsyncElement:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function FsyncElement:LogicMapStartRecover()
    FsyncElement.super:LogicMapStartRecover()
    -- TODO
end
-- 结束恢复方法 (断线重连的时候用)
function FsyncElement:LogicMapEndRecover()
    FsyncElement.super:LogicMapEndRecover(self)
    -- TODO
end
-- 所有的组件恢复完成
function FsyncElement:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

-- 收到Trigger事件
function FsyncElement:OnReceiveTriggerEvent(interfaceId)
end
-- 收到GetData事件
function FsyncElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function FsyncElement:Exit()
    if self.cubeToastCor then
        self.cubeToastCor:Stop()
    end
    FsyncElement.super.Exit(self)
end

return FsyncElement

