local class = require("middleclass")
local extends = require("gameplay/extends")
---@type Utils
local utils = require("gameplay/utils")

local log = function(str)
    if App.IsStudioClient then
        -- g_LogError(str)
    else

    end
end
local WBElement = require("mworld/worldBaseElement")

---@class WorldBaseElementClass : ExtendedClass
local WorldBaseElementClass = class("WorldBaseElementClass")
function WorldBaseElementClass:initialize()
    extends.Class(self)
    self.eventEmitter = utils.EventEmitter()
end
function WorldBaseElementClass:Init(key, cb)
    if key == nil then
        g_LogError("缺少key")
        return
    end
    if self.isInit == true then
        return
    end
    self.isInit = true
    local that = self
    xpcall(function()
        local WBElementClass = class("WBElementClass"..key, WBElement)
        ---- WorldElement重载
        function WBElementClass:initialize(worldElement)
            WBElementClass.super.initialize(self, worldElement)
            -- 订阅KEY消息
        end

        -- 收到/恢复IRC消息
        -- @param key  订阅的消息key
        -- @param value  消息集合体
        -- @param isResume  是否为恢复消息
        function WBElementClass:ReceiveMessage(key, value, isResume)
            -- TODO:
            that:ReceiveMessage(key, value, isResume)
        end

        -- -- 发送KEY-VALUE 消息 
        -- -- @param key 自定义/协议key
        -- -- @param body  table 消息体
        -- function WBElementClass:SendCustomMessage(key, body)
        --     that:SendMessage(key, body)
        -- end

        -- 自己avatar对象创建完成
        -- @param avatar 对应自己的Fsync_avatar对象
        function WBElementClass:SelfAvatarCreated(avatar)

        end

        -- 自己avatar对象人物模型加载完成ba
        -- @param avatar 对应自己的Fsync_avatar对象
        function WBElementClass:SelfAvatarPrefabLoaded(avatar)

        end

        -- avatar对象创建完成，包含他人和自己
        -- @param avatar 对应自己的Fsync_avatar对象
        function WBElementClass:AvatarCreated(avatar)

        end
        function WBElementClass:Tick()
            that:Tick()
        end
        function WBElementClass:UpdateFrameIndex(frameIndex)
            that:UpdateFrameIndex(frameIndex)
        end

        -- 脚本释放
        function WBElementClass:Exit()
            WBElementClass.super.Exit(self)
        end

        CourseEnv.ServicesManager.Gate:AddElementType(key, WBElementClass)
        local dict = CS.Tal.framesync.VisualProperty();
        dict:Add("type", key)
        local ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.zero, Vector3.one,
            Vector3.zero, "WorldElement_" .. key)
        self.vElement = ret

        if cb then
            cb(ret)
        end
    end, function(err)
        g_LogError("WorldBaseElementClass:Init", err)
        g_LogError(err)
    end)

end

function WorldBaseElementClass:SubscribeMsgKey(key)
    self.vElement:SubscribeMsgKey(key)
end
function WorldBaseElementClass:ReceiveMessage(key, value, isResume)

end

function WorldBaseElementClass:Tick()

end
function WorldBaseElementClass:UpdateFrameIndex(frameIndex)

end
function WorldBaseElementClass:SendCustomMessage(key, body)
    self.vElement:SendMessage(key, body)
end

return WorldBaseElementClass
