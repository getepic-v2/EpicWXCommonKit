
local cs_coroutine = require "common/cs_coroutine"
---@class Extends
local Extends = {
    ---@param element WorldBaseElement
    WorldBaseElement = function(element)

        ---@class ExtendedWorldBaseElement :WorldBaseElement
        ---@field configService ConfigService
        ---@field jsonService JsonService
        ---@field httpService HttpService
        ---@field observerService ObserverService
        ---@field audioService AudioService
        ---@field uiService UIService
        ---@field avatarService AvatarService
        ---@field assetService AssetService
        ---@field joystickService JoystickService
        ---@field debugService DebugService
        ---@field configService ConfigService
        ---@field jsonService JsonService
        ---@field commonService CommonService
        ---@field configData table
        ---@field colliderService ColliderService
        ---@field transform CS.UnityEngine.Transform
        local _element = element

        _element.commonService = App:GetService("CommonService")
        _element.jsonService = CourseEnv.ServicesManager:GetJsonService()
        _element.httpService = CourseEnv.ServicesManager:GetHttpService()
        _element.observerService = CourseEnv.ServicesManager:GetObserverService()
        _element.configService = CourseEnv.ServicesManager:GetConfigService()
        _element.audioService = CourseEnv.ServicesManager:GetAudioService()
        _element.uiService = CourseEnv.ServicesManager:GetUIService()
        _element.avatarService = CourseEnv.ServicesManager:GetAvatarService()
        _element.assetService = CourseEnv.ServicesManager:GetAssetService()
        _element.joystickService = CourseEnv.ServicesManager:GetJoystickService()
        _element.debugService = CourseEnv.ServicesManager:GetDebugService()
        _element.configService = CourseEnv.ServicesManager:GetConfigService()
        _element.jsonService = CourseEnv.ServicesManager:GetJsonService()
        _element.colliderService = CourseEnv.ServicesManager:GetColliderService()

        _element.transform = element.VisElement.transform

        ---@public
        ---携程
        ---@return CS.Tal.Common.Coroutine
        function _element:StartCoroutine(...)
            return _element.commonService:StartCoroutine(...)
        end

        ---@public
        ---停止携程
        ---@param CS.Tal.Common.Coroutine
        function _element:StopCoroutineSafely(...)
            return _element.commonService:StopCoroutineSafely(...)
        end

        function _element:YieldSeconds(...)
            return _element.commonService:YieldSeconds(...)
        end

        function _element:YieldEndFrame()
            return _element.commonService:YieldEndFrame()
        end
        ---@public
        ---执行某事件
        ---@param eventKey string
        ---@vararg Object[] 任意参数
        function _element:Fire(...)
            return _element.observerService:Fire(...)
        end
        ---@public
        ---观察某事件
        ---@param eventKey string
        ---@param eventCall fun(key:string,args:Object[]):void
        ---@param watchCS boolean 是否监听CS层面的fire  
        ---@return CS.Tal.Observer.IWatcher 调用Dispose即可取消监听
        function _element:Watch(...)
            return _element.observerService:Watch(...)
        end

        -- 给按钮添加点击事件
        ---@param target GameObject
        ---@param handler function
        function _element:AddClickEventListener(go, ...)
            local btn = go:GetComponent(typeof(CS.UnityEngine.UI.Button))
            if btn then
                return _element.commonService:AddEventListener(btn, "onClick", ...)
            end
            g_LogError("不存在Button组件")
            return nil
        end
        function _element:Find(...)
            return _element.VisElement.transform:Find(...)
        end
        -- 复制节点
        ---@param target GameObject
        function _element:Instantiate(target, ...)
            return GameObject.Instantiate(target, ...)
        end

        -- 数据
        local _data = _element.configService:GetConfigTableByScript(_element.VisElement)
        -- 模型
        local _cjd = _element.configService:GetConfigJsonDataByScript(_element.VisElement).properties

        local _cd = {}

        local work = nil
        work = function(cd, data, cjd)
            local model = {}
            for k, v in pairs(cjd) do
                model[v.key] = v
            end
            for k, v in pairs(data) do
                local m = model[k]
                if m ~= nil then
                    if m.editor == "FloatInputFieldEditor" or m.editor == "IntInputFieldEditor" then
                        cd[k] = tonumber(v)
                    elseif m.editor == "NameInputFieldEditor" or m.editor == "StringInputFieldEditor" or m.editor ==
                        "TextInputFieldEditor" or m.editor == "StringInputFieldWithTitleEditor" then
                        cd[k] = v
                    elseif m.editor == "ToggleGroupEditor" or m.editor == "DropDownEditor" or m.editor ==
                        "IntSliderInputFieldEditor" or m.editor == "SingleChoiceEditor" then
                        cd[k] = tonumber(v)
                    elseif m.editor == "Vector2Editor" or m.editor == "Vector3Editor" or m.editor == "ColorPickerEditor" or
                        m.editor == "MultipleChoiceEditor" then
                        local decode = _element.jsonService:decode(v)
                        cd[k] = decode
                    elseif m.editor == "AssetSelectInConfigEditor" then
                        if m.baseInfo == "Image" then
                            local uAddress = _element.jsonService:decode(v).uAddress
                            local image = _element.assetService:GetConfigGameObjectWithUAddress(_element.VisElement,
                                uAddress)
                            cd[k] = image
                        end
                    elseif m.editor == "AssetWSpaceObConfigEditor" then
                        local configEditorInfo = _element.jsonService:decode(v)
                        local refInfo = configEditorInfo["refGoInfo"]
                        if (refInfo ~= nil) then
                            local spaceGo = _element.assetService:GetConfigGameObjectWithRefInfo(_element.VisElement,
                                refInfo)
                            cd[k] = spaceGo
                        end
                    elseif m.editor == "CustomConfigListEditor" then

                        -- 再来一遍
                        local list = {}

                        local decode = _element.jsonService:decode(v)
                        for i, v in ipairs(decode) do
                            local cd_item = {}
                            work(cd_item, v, m.children)
                            table.insert(list, cd_item)
                        end
                        _cd[k] = list

                    elseif m.editor == "CustomListAssetTextEditor" then
                    elseif m.editor == "CustomListAssetTextOptionEditor" then
                    elseif m.editor == "StringInputFieldWithTitleEditor" then

                    end
                end

            end
        end

        work(_cd, _data, _cjd)

        element.configData = _cd

    end,

    Class = function(cls)
        ---@class ExtendedClass 
        ---@field configService ConfigService
        ---@field jsonService JsonService
        ---@field httpService HttpService
        ---@field observerService ObserverService
        ---@field audioService AudioService
        ---@field uiService UIService
        ---@field avatarService AvatarService
        ---@field assetService AssetService
        ---@field joystickService JoystickService
        ---@field debugService DebugService
        ---@field configService ConfigService
        ---@field jsonService JsonService
        ---@field commonService CommonService
        ---@field configData table
        ---@field colliderService ColliderService
        ---@field transform CS.UnityEngine.Transform
        local _element = cls

        _element.commonService = App:GetService("CommonService")
        _element.jsonService = CourseEnv.ServicesManager:GetJsonService()
        _element.httpService = CourseEnv.ServicesManager:GetHttpService()
        _element.observerService = CourseEnv.ServicesManager:GetObserverService()
        _element.configService = CourseEnv.ServicesManager:GetConfigService()
        _element.audioService = CourseEnv.ServicesManager:GetAudioService()
        _element.uiService = CourseEnv.ServicesManager:GetUIService()
        _element.avatarService = CourseEnv.ServicesManager:GetAvatarService()
        _element.assetService = CourseEnv.ServicesManager:GetAssetService()
        _element.joystickService = CourseEnv.ServicesManager:GetJoystickService()
        _element.debugService = CourseEnv.ServicesManager:GetDebugService()
        _element.configService = CourseEnv.ServicesManager:GetConfigService()
        _element.jsonService = CourseEnv.ServicesManager:GetJsonService()
        _element.colliderService = CourseEnv.ServicesManager:GetColliderService()

        ---@public
        ---携程
        ---@return CS.Tal.Common.Coroutine
        function _element:StartCoroutine(...)
            return _element.commonService:StartCoroutine(...)
        end

        ---@public
        ---停止携程
        ---@param CS.Tal.Common.Coroutine
        function _element:StopCoroutineSafely(...)
            return _element.commonService:StopCoroutineSafely(...)
        end

        function _element:YieldSeconds(...)
            return _element.commonService:YieldSeconds(...)
        end

        function _element:YieldEndFrame()
            return _element.commonService:YieldEndFrame()
        end

         ---@public
        function _element:DispatchAfter(...)
            return _element.commonService:DispatchAfter(...)
        end

         ---@public
         function _element:CancelDispatch(...)
            return _element.commonService:CancelDispatch(...)
        end
    end

}
return Extends
