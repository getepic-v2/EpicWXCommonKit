local extends = require("gameplay/extends")
---@type Utils
local utils = require("gameplay/utils")
---@type FactionManager
local Faction = require("gameplay/faction")
local SkillExecKey = "SkillExecKey" -- 技能执行
local SkillSelfWaitKey = "SkillSelfWaitKey" -- 技能同步回调
local AvatarChildrenChangedKey = "AvatarChildrenChangedKey" -- avatar变化
local BulletHitAvatarKey = "BulletHitAvatarKey" -- 子弹击中
local OnSkillDamageKey = "OnSkillDamageKey" -- 技能伤害
local OnSkillDamageResKey = "OnSkillDamageResKey" -- 技能伤害结果
local BulleDestroyKey = "BulleDestroyKey" -- 子弹销毁
local BulleFireKey = "BulleFireKey" -- 子弹发射
---@type RoleManager
local role = require("gameplay/role")
---@type StatusManager
local status = require("gameplay/status")
local log = function(str)
    if App.IsStudioClient then
        -- g_LogError(str)
    else

    end
end
---@type AssetsMapManager
local assetsMap = require("gameplay/assetsMap")

---@type CommandManager
local command = require("gameplay/command")

local DamageType = {
    AOE = "aoe",
    COLLISION = "collision"
}

local class = require("middleclass")
---@class SkillManager : ExtendedClass
local SkillManager = class("SkillManager")
function SkillManager:initialize()
    extends.Class(self)
    self.data = {}
    self.fxMap = {}
    self.avatars = {}

    self.eventEmitter = utils.EventEmitter()
    self:LoadConfig()

    self.bulletMap = {}
    self.buffMap = {}

    self:OnUse(function(data, isSync)

        local uuid = data.uuid
        local skillName = data.skillName
        local skill = self:GetSkill(skillName)
        if App.Uuid == uuid and isSync == false then
            -- 消费能量
            if skill.cost ~= nil then
                role:AddEnergy(-skill.cost)
            end
        end

    end)

end
function SkillManager:RegisterMessage()
    return
        {SkillExecKey, AvatarChildrenChangedKey, OnSkillDamageResKey, BulleDestroyKey, SkillSelfWaitKey, BulleFireKey}
end
function SkillManager:LoadConfig()
    self.data = {}
    local data = {"skill", "timeline", "fx", "condition", "bullet", "buff"}

    for i, v in ipairs(data) do
        local d = utils.RequireLua("gameplay", v)
        if d then
            self.data[v] = d
        end
    end
end

function SkillManager:GetCDEntity(uuid, skillName)
    if self.cdPools == nil then
        self.cdPools = {}
    end
    if self.cdPools[uuid] == nil then
        self.cdPools[uuid] = {}
    end

    return self.cdPools[uuid][skillName]
end

---@param p1 string uuid
---@param p2 string 技能id
function SkillManager:Use(p1, p2)

    local uuid = nil
    local skillName = nil
    local extra = nil
    local isSync = false

    if type(p1) ~= "string" then
        uuid = p1.uuid
        skillName = p1.skillName
        extra = p1.extra
        isSync = p2
    else
        uuid = p1
        skillName = p2
    end
    ---@type Skill
    local skill = self.data.skill[skillName]

    if skill == nil then
        g_LogError("技能不存在:" .. skillName)
        return
    end
    local re = role:GetRole(uuid)

    if re == nil then
        return g_LogError("没有这个角色:" .. uuid)
    end

    if re.isAvatar == true then
        local avatar = re:GetAvatar()
        if avatar == nil then
            return g_LogError("没有这个avatar:" .. uuid)
        end
    end

    local condition = skill.release_condition

    local can = self:Condition(condition, uuid)
    if can == false then
        return {
            code = 1,
            msg = "技能条件不满足:" .. skillName .. "--->" .. skill.release_condition
        }
    end

    -- 这里起内部cd定时器
    if isSync == false and (uuid == App.Uuid or re.isAvatar == false) then
        local cd = skill.cd

        if cd > 0 then
            if self.cdPools == nil then
                self.cdPools = {}
            end
            if self.cdPools[uuid] == nil then
                self.cdPools[uuid] = {}
            end

            if self.cdPools[uuid][skillName] ~= nil then
                return {
                    code = 1,
                    msg = "技能cd中:" .. skillName
                }
            end
            local cdEnity = {
                time = cd
            }
            self.cdPools[uuid][skillName] = cdEnity
            cdEnity.cor = self:DispatchAfter(cd, function()
                self.cdPools[uuid][skillName] = nil
            end)
            cdEnity.TimeCor = self:StartCoroutine(function()
                while self.cdPools[uuid] ~=nil and self.cdPools[uuid][skillName] ~= nil and cdEnity.time > 0 do
                    self:YieldSeconds(0.1)
                    cdEnity.time = cdEnity.time - 0.1
                end
            end)
        end

    end

    local res = self.eventEmitter:emit("OnUse", {
        uuid = uuid,
        skillName = skillName,
        extra = extra
    }, isSync)
    local _extra = {}
    -- 这里判断重写逻辑
    for k, v in pairs(res) do
        if v == true then
            -- 存在重写逻辑
            log("存在重写逻辑:" .. skillName)
            return {
                code = 2,
                msg = "存在重写逻辑:" .. skillName
            }
        else
            if v ~= false then
                for k, v in pairs(v) do
                    _extra[k] = v
                end
            end
        end
    end

    if extra == nil then
        extra = _extra
    else
        for k, v in pairs(_extra) do
            extra[k] = v
        end
    end

    local playfx = function()
        local re = role:GetRole(uuid)

        if re == nil then
            return log("没有这个角色:" .. uuid)
        end

        if re.isAvatar then
            if isSync == true then
                if uuid == App.Uuid then
                    -- 执行过，不用在执行了
                else
                    self:PlaySkill(uuid, skillName, extra)
                end
            else
                if skill.is_synced == true and uuid == App.Uuid then
                    ---同步,收集信息
                    -- 仅自己发起的技能才会同步

                    local extra = {
                        position = self.avatarService.selfAvatar.BodyTrans.transform.position,
                        forward = self.avatarService.selfAvatar.BodyTrans.transform.forward
                    }

                    for k, v in pairs(_extra) do
                        extra[k] = v
                    end

                    self:FormatExtra(extra, {"position", "forward"})

                    self:PlaySkill(uuid, skillName, extra)

                    self:SendCustomMessage(SkillExecKey, {
                        uuid = uuid,
                        skillName = skillName,
                        extra = extra
                    })
                else
                    self:PlaySkill(uuid, skillName, extra)
                end
            end
        else
            self:PlaySkill(uuid, skillName, extra)
        end
    end

    if isSync == false then
        -- 非同步状态
        if skill.delay ~= 0 and skill.delay ~= nil then
            self:DispatchAfter(skill.delay, function()
                playfx()
            end)
        else
            playfx()
        end
    else
        playfx()
    end

    return {
        code = 0,
        msg = "技能释放成功:" .. skillName
    }

end
function SkillManager:FormatExtra(value, posKeys)
    for k, v in pairs(posKeys) do
        if value[v] then
            value[v] = {
                x = tonumber(string.format("%.3f", value[v].x)),
                y = tonumber(string.format("%.3f", value[v].y)),
                z = tonumber(string.format("%.3f", value[v].z))
            }
            if value[v].x == nil or value[v].z == nil or value[v].y == nil then
                value[v] = {
                    x = 0,
                    z = 0,
                    y = 0
                }
                g_LogError("FormatExtra坐标格式化错误,使用0")
                g_LogError(value[v].x)
                g_LogError(value[v].y)
                g_LogError(value[v].z)

            end
        end
    end
end
----- callback fun(data:{uuid:string,skillName:string,extra:table},isSync:boolean):void
function SkillManager:OnUse(callback)
    self.eventEmitter:on("OnUse", callback)
end
---@return Skill
function SkillManager:GetSkill(skillName)
    if skillName == nil or skillName == "" then
        return nil
    end
    local info = self.data.skill[skillName]
    if info == nil then
        g_LogError("技能不存在:" .. skillName)
    end

    return info
end
-- 缓存一些具有唯一性的对象
function SkillManager:AddFx(uuid, key, fxID, removeCallback, resumeCallback)

    if self:IsFxAlive(uuid, key, fxID) == true then
        -- 存在，先删了
        -- TODO 判断叠加逻辑
        log("已存在的fx，先移除:" .. key .. "," .. fxID)
        self:TryRemoveFx(uuid, key, fxID)
    end

    if self.avatars[uuid] == nil then
        self.avatars[uuid] = {}
    end

    if self.avatars[uuid][key] == nil then
        self.avatars[uuid][key] = {}
    end
    self.avatars[uuid][key][fxID] = {
        removeCallback = removeCallback,
        resumeCallback = resumeCallback
    }
end

function SkillManager:TryRemoveFx(uuid, key, buffID)
    if self:IsFxAlive(uuid, key, buffID) == true then
        if self.avatars[uuid][key][buffID].removeCallback then
            self.avatars[uuid][key][buffID].removeCallback()
        end
        self.avatars[uuid][key][buffID] = nil
    end
end
function SkillManager:GetFx(uuid, key, fxID)
    if self:IsFxAlive(uuid, key, fxID) == true then
        return self.avatars[uuid][key][fxID]
    end
    return nil
end
function SkillManager:GetFxConfig(id)
    return self.data.fx[id]
end
function SkillManager:IsFxAlive(uuid, key, id)
    if self.avatars[uuid] == nil then
        return false
    end
    if self.avatars[uuid][key] == nil then
        return false
    end
    if self.avatars[uuid][key][id] == nil then
        return false
    end
    return true
end
function SkillManager:GetBuffEntity(uid, buffID)
    if self.buffMap == nil then
        self.buffMap = {}
    end
    if self.buffMap[uid] == nil then
        self.buffMap[uid] = {}
    end

    if self.buffMap[uid][buffID] == nil then
        self.buffMap[uid][buffID] = {
            layers = {}
        }
    end
    return self.buffMap[uid][buffID]
end
function SkillManager:GetBuffLayerCount(uid, buffID)
    local buffEntity = self:GetBuffEntity(uid, buffID)
    local layersCount = 0
    for k, v in pairs(buffEntity.layers) do
        layersCount = layersCount + 1
    end
    return layersCount
end
function SkillManager:OnAvatarChildrenChanged(callback)
    self.eventEmitter:on("onAvatarTransformChanged", callback)
end
-- 有些技能需要知道avatar的解构变化，用来刷新状态，比如隐身和透视技能
-- 默认会同步
function SkillManager:AvatarTransformChanged(uuid, noSync)
    self.eventEmitter:emit("onAvatarTransformChanged", uuid)
    if noSync ~= true and uuid == App.Uuid then
        self:SendCustomMessage(AvatarChildrenChangedKey, {
            uuid = uuid
        })
    end
end
function SkillManager:OffAvatarChildrenChanged(callback)
    self.eventEmitter:off("onAvatarTransformChanged", callback)
end
---@return Bullet
function SkillManager:GetBulletFromSkill(skillName)

    ---@type Skill
    local skill = self:GetSkill(skillName)
    ---@type Timeline
    local timeline = self.data.timeline[skill.timeline]

    if timeline then
        if false then
            -- if timeline.Animation ~= nil and timeline.Animation ~= 0 then
            -- TODO 播放一个avatar动画
            -- 启动定时器，拆帧
        else
            -- 无动画，顺序执行效果
            local frames = timeline.frames
            for _, v in ipairs(frames) do
                local frame = v
                local fx = self:GetFxConfig(frame.fx)
                if fx.type == 4 then
                    -- 发射子弹
                    local bulletId = fx.param1
                    ---@type Bullet
                    local bullet = self:GetBullet(bulletId)
                    return bullet
                end
            end
        end
    else
    end
end
function SkillManager:PlaySkill(uuid, skillName, extra)
    log("技能开始:" .. skillName)

    ---@type Skill
    local skill = self:GetSkill(skillName)
    ---@type Timeline
    local timeline = self.data.timeline[skill.timeline]
    ---@type Timeline
    local selfTimeline = self.data.timeline[skill.self_timeline]

    if selfTimeline then
        local frames = selfTimeline.frames
        for _, v in ipairs(frames) do
            local frame = v
            self:PlayFX(frame.fx, uuid, nil, extra)
        end
    end

    local targets = {}
    if timeline then
        if false then
            -- if timeline.Animation ~= nil and timeline.Animation ~= 0 then
            -- TODO 播放一个avatar动画
            -- 启动定时器，拆帧
        else
            -- 无动画，顺序执行效果

            if skill.target_type == nil or skill.target_type == 0 or skill.target_type == 1 then
                table.insert(targets, uuid)
            elseif skill.target_type == 7 then
                -- 全部敌方
                local enemies = role:GetAllEnemies(uuid)
                for k, v in pairs(enemies) do
                    table.insert(targets, v.uid)
                end
                extra = nil
            elseif skill.target_type == 8 then
                -- 所有人
                local all = role:GetAllRoles()
                for k, v in pairs(all) do
                    table.insert(targets, v.uid)
                end
                extra = nil
            end

            local frames = timeline.frames

            for _, uid in pairs(targets) do
                for _, v in ipairs(frames) do
                    local frame = v
                    self:PlayFX(frame.fx, uid, nil, extra)
                end
            end

        end
    else
        g_LogError("技能时间轴不存在:" .. skill.timeline)
    end

end
function SkillManager:PlayFX(fxId, uuid, callback, extra)
    log("PlayFX:" .. fxId)
    ---@type Fx
    local fx = self:GetFxConfig(fxId)

    if fx == nil then
        g_LogError("fx配置不存在:" .. fxId)

        if callback then
            callback()
        end
        return
    end

    local re = role:GetRole(uuid)

    if re == nil then
        return log("没有这个角色:" .. uuid)
    end

    if re.isAvatar then
        local avatar = self.avatarService:GetAvatarByUUID(re.uid)
        if avatar == nil then
            g_LogError("avatar不存在" .. uuid)
            return
        end
    end
    local exec = function()
        if fx.type == 4 or fx.type == 11 then
            -- 发射子弹
            self:Bullet({
                uuid = uuid,
                fxId = fxId,
                extra = extra
            })
        elseif fx.type == 2 or fx.type == 3 then
            -- buff
            self:Buff(uuid, fx)
        elseif fx.type == 7 then
            self:Invisible(uuid, fx)
        elseif fx.type == 8 then
            self:Xray(uuid, fx)
        elseif fx.type == 10 then
            self:Command(fx.param1, uuid)
        end
    end

    exec()

    if callback then
        callback()
    end
end
function isValidStringValue(str)
    if str ~= 0 and str ~= nil and str ~= "" then

        return true
    end
    return false
end
function SkillManager:idtobool(id, uuid)
    ---@type Condition
    local con = self:GetCondition(id)
    if con == nil then
        g_LogError("不存在的表达式：" .. id)
    end
    local compare1 = nil
    local compare2 = nil
    if con.type == 1 then
        -- 与目标距离

        local dis = con.param1
        -- TODO

        compare1 = 0
        compare2 = 0
    elseif con.type == 2 then
        -- 属性检测
        -- 属性类型 health=生命值 energy=能量值
        local prop = con.param1

        local value = con.param2
        -- TODO
        compare1 = 0
        compare2 = 0

        if prop == "health" then
            compare1 = role:GetHealth(uuid)
            compare2 = value
        elseif prop == "energy" then
            compare1 = role:GetEnergy()
            compare2 = value
        elseif prop == "invincible" then
            local roleEntity = role:GetRole(uuid)
            compare1 = roleEntity.invincible
            if value == "TRUE" or value == "True" or value == "true" then
                compare2 = true
            else
                compare2 = false
            end
        end

    elseif con.type == 3 then
        -- buff层数

        local buffID = con.param1
        local layers = con.param2

        compare2 = layers
        compare1 = self:GetBuffLayerCount(uuid, buffID)
    elseif con.type == 4 then
        -- status 状态
        compare1 = status:IsInStatus(uuid, con.param1)
        compare2 = 1
    elseif con.type == 5 then
        -- 阵营类型
        compare1 = 1

        if con.param1 == "自己" then
            if uuid == App.Uuid then
                compare2 = 1
            else
                compare2 = 0
            end
        end

    else
        -- 未知类型
        compare1 = 0
        compare2 = 0
    end
    log("id表达式类型：" .. con.type)

    compare1 = tonumber(compare1)
    compare2 = tonumber(compare2)

    if con.ctype == 0 then
        log("id表达式：" .. true)

        return true
    elseif con.ctype == 1 then
        log("id表达式：" .. compare1 .. " > " .. compare2)

        return compare1 > compare2
    elseif con.ctype == 2 then
        log("id表达式：" .. compare1 .. " >= " .. compare2)
        return compare1 >= compare2

    elseif con.ctype == 3 then
        log("id表达式：" .. compare1 .. " == " .. compare2)
        return compare1 == compare2

    elseif con.ctype == 4 then
        log("id表达式：" .. compare1 .. " <= " .. compare2)
        return compare1 <= compare2

    elseif con.ctype == 5 then
        log("id表达式：" .. compare1 .. " < " .. compare2)
        return compare1 < compare2
    end

    log("id表达式：" .. "false")

    return false
end

function SkillManager:Command(id, uuid)
    command:Do(id, uuid)
end
function SkillManager:Condition(expression, uuid)
    if expression == 0 or expression == "" or expression == nil then
        -- 没有条件
        return true
    end
    if uuid == nil then
        g_LogError("uuid为空")
    end
    -- Replace ids with bool representations
    -- Assuming id is a alphanumeric sequence surrounded by operators or string boundaries
    expression = expression:gsub("([%w_]+)", function(id)
        return tostring(self:idtobool(id, uuid))
    end)

    -- Replace logical operators with Lua equivalents
    expression = expression:gsub("&&", "and"):gsub("||", "or"):gsub("!", "not ")

    log("表达式：" .. expression)
    -- Evaluate the boolean expression safely
    local func, err = load("return " .. expression)
    if not func then
        g_LogError("Invalid expression: " .. err)
    end

    return func()
end
---@param uuid string
---@param fx Fx
function SkillManager:Buff(uuid, fx)
    local buffID = fx.param1
    ---@type RoleEntity
    local roleEntity = role:GetRole(uuid)
    ---@type Buff
    local buff = self.data.buff[buffID]
    if buff == nil then
        g_LogError("buff配置不存在")
        return
    end

    local type = fx.type

    local assetID = buff.effect_asset_id
    local duration = buff.duration

    local condition = self:Condition(buff.condition, uuid)

    if condition == false then
        log("条件不满足:" .. buff.condition)
        return
    end
    log("条件满足:" .. buff.condition)

    if roleEntity.isAvatar then
        local avatar = self.avatarService:GetAvatarByUUID(uuid)
        if avatar == nil then
            g_LogError("没有这个avatar:" .. uuid)
            return
        end
    end

    if type == 2 then

        local buffEntity = self:GetBuffEntity(uuid, buffID)
        local layersCount = 0
        for k, v in pairs(buffEntity.layers) do
            layersCount = layersCount + 1
        end
        if layersCount >= buff.max_stack_layers then
            -- 超过最大层数
            if buff.max_layers_process == 0 then
                -- 不处理
                log("buff超过最大层数，跳过")
                return
            elseif buff.max_layers_process == 1 then
                -- 加时
                log("加时")
                for _, v in pairs(buffEntity.layers) do
                    if v.resumeCallback then
                        v.resumeCallback(duration)
                    end
                end
                return
            elseif buff.max_layers_process == 2 or buff.max_layers_process == 3 then
                -- 清空
                for _, v in pairs(buffEntity.layers) do
                    if v.removeCallback then
                        v.removeCallback()
                    end
                end
                if buff.max_layers_process == 2 then
                    -- 清空退出
                    return
                else
                    -- continue
                    -- 清空继续
                    layersCount = 0
                end
            else
                -- 兼容
            end
        end

        if layersCount + 1 == 1 then
            -- 第一层效果
            log("buff 第一层效果")
            self:FxSequence(buff.one_layer_effect, uuid)
        end

        if layersCount + 1 >= buff.max_stack_layers then
            -- 叠满了
            log("buff 叠满了")
            self:FxSequence(buff.full_stack_effect, uuid)
        end

        if buffEntity.used ~= true then
            buffEntity.used = true
            self:FxSequence(buff.first_layer_effect, uuid)
        end

        -- 添加标记

        local buffcallback = function()
            -- add
            local tmp = assetsMap:GetAssetGo(assetID) --  self.fxMap[assetID]
            if self.avatars[uuid] == nil then
                self.avatars[uuid] = {}
            end
            if self.avatars[uuid].buff == nil then
                self.avatars[uuid].buff = {}
            end

            if self.buffLayerCount == nil then
                self.buffLayerCount = 0
            end
            self.buffLayerCount = self.buffLayerCount + 1

            local layerKey = buffID .. "_" .. self.buffLayerCount

            log("添加buff" .. buffID)

            local go = nil

            if tmp ~= nil then
                go = assetsMap:NewAssetGo(assetID)
                go:SetActive(true)

                local targetTransform = nil
                if roleEntity.isAvatar then
                    targetTransform = roleEntity:GetAvatar().VisElement.transform
                else
                    targetTransform = roleEntity:GetTransform()
                end

                go.transform:SetParent(targetTransform)

                ---初始位置

                if buff.forward_target == nil or buff.forward_target == 1 or buff.forward_target == 0 then
                    -- 自己
                    if roleEntity.isAvatar then
                        go.transform.position = roleEntity:GetAvatar().BodyTrans.transform.position
                        go.transform.rotation = roleEntity:GetAvatar().BodyTrans.transform.rotation
                    else
                        go.transform.position = roleEntity:GetTransform().position
                        go.transform.rotation = roleEntity:GetTransform().rotation
                    end
                elseif buff.forward_target == 5 then
                    -- 最近的敌方
                    local nearest = role:GetNearestEnemy(uuid)

                    if roleEntity.isAvatar then
                        go.transform.position = roleEntity:GetAvatar().BodyTrans.transform.position

                        if nearest then
                            go.transform.rotation = Quaternion.LookRotation(
                                nearest:GetTransform().position - roleEntity:GetTransform().position)
                        else
                            go.transform.rotation = roleEntity:GetAvatar().BodyTrans.transform.rotation
                        end
                    else
                        go.transform.position = roleEntity:GetTransform().position
                        go.transform.rotation = roleEntity:GetTransform().rotation
                    end
                end

                local EffectMountPoint = buff.effect_mount_point
                if isValidStringValue(EffectMountPoint) then
                    local parent = targetTransform:FindChildWithName(EffectMountPoint)
                    go.transform:SetParent(parent)
                end

                if buff.mount_point_offset then
                    local MountPointOffset = buff.mount_point_offset
                    go.transform.position = go.transform.position + go.transform.forward * MountPointOffset.z +
                                                go.transform.up * MountPointOffset.y + go.transform.right *
                                                MountPointOffset.x
                end

                go.transform.localScale = Vector3(1, 1, 1)

                -- 检查是否是粒子，设置playOnAwake
                local particle = go:GetComponentInChildren(typeof(CS.UnityEngine.ParticleSystem))
                if particle then
                    particle:Play()
                end

                -- aim逻辑
                if buff.look_at == 5 or buff.look_at == 3 then
                    -- 最近敌方
                    local aim = go:GetComponent(typeof(CS.UnityEngine.Animations.AimConstraint))

                    if aim == nil then
                        aim = go:AddComponent(typeof(CS.UnityEngine.Animations.AimConstraint))
                    end

                    aim.aimVector = Vector3(0, 0, 1) -- z轴正方向
                    aim.upVector = Vector3(0, 1, 0) -- up轴正方向
                    aim.constraintActive = true

                    if buff.look_at_freeze_axes[1] == true then
                        aim.rotationAxis = CS.UnityEngine.Animations.Axis.X
                    end
                    if buff.look_at_freeze_axes[2] == true then
                        aim.rotationAxis = CS.UnityEngine.Animations.Axis.Y
                    end
                    if buff.look_at_freeze_axes[3] == true then
                        aim.rotationAxis = CS.UnityEngine.Animations.Axis.Z
                    end

                    -- 自己的阵营
                    local faction = Faction:GetFactionName(uuid)

                    -- 每秒更新 一次
                    self:StartCoroutine(function()
                        while go ~= nil and not go:IsNull() do
                            local minDis;
                            local minAvatar;
                            local pos = targetTransform.position
                            local avatarArray = self.avatarService:GetAllAvatar()
                            for _, a in pairs(avatarArray) do

                                if a.avatarUuid ~= uuid then
                                    local _f = Faction:GetFactionName(a.avatarUuid)
                                    -- 不同阵营

                                    if buff.look_at == 3 then
                                        -- 友方最近
                                        if _f and faction and not Faction:IsEnemy(_f, faction) then
                                            local p = a.VisElement.transform.position
                                            local dis = Vector3.Distance(pos, p)
                                            if not minDis or dis < minDis then
                                                minDis = dis
                                                minAvatar = a
                                            end
                                        end
                                    else
                                        -- 敌方最近
                                        if _f and faction and Faction:IsEnemy(_f, faction) then
                                            local p = a.VisElement.transform.position
                                            local dis = Vector3.Distance(pos, p)
                                            if not minDis or dis < minDis then
                                                minDis = dis
                                                minAvatar = a
                                            end
                                        end

                                    end
                                end

                            end
                            if minAvatar and minAvatar:IsOnline() then

                                local count = aim.sourceCount

                                if count == 1 then
                                    local _s = aim:GetSource(0)
                                    if _s.sourceTransform ~= minAvatar.VisElement.transform then
                                        local source = CS.UnityEngine.Animations.ConstraintSource()
                                        source.weight = 1
                                        source.sourceTransform = minAvatar.VisElement.transform
                                        aim:RemoveSource(0)
                                        aim:AddSource(source)
                                    end

                                else

                                    local source = CS.UnityEngine.Animations.ConstraintSource()
                                    source.weight = 1
                                    source.sourceTransform = minAvatar.VisElement.transform
                                    aim:AddSource(source)

                                end
                                if buff.look_at_offset then
                                    aim.rotationOffset = Vector3(buff.look_at_offset.x, buff.look_at_offset.y,
                                        buff.look_at_offset.z)
                                end
                            end
                            self:YieldSeconds(1)
                        end
                    end)

                end
            else
                if assetID ~= nil and assetID ~= "" then
                    g_LogError("特效不存在:" .. assetID)
                end
            end

            local life = function()
                log("buff结束:" .. buffID)
                if buffEntity.layers[layerKey] then
                    if buffEntity.layers[layerKey].removeCallback then
                        buffEntity.layers[layerKey].removeCallback()
                    end
                    -- 结束特效
                    local ended = buff.end_effect
                    if ended ~= nil and ended ~= 0 then
                        log("buff 后置")
                        self:FxSequence(ended, uuid)
                    else

                    end
                else
                    -- 提前移除，不执行结束特效
                end

            end
            local timmingCor = nil
            local cor = nil
            local startCor = function(_d)
                
                cor = self:DispatchAfter(_d, function()
                    life(_d)
                end)
            end
            startCor(duration)
            local execTimingFX = function()
                timmingCor = self:StartCoroutine(function()
                    while cor ~= nil do
                        self:YieldSeconds(buff.timing_period)
                        local re = role:GetRole(uuid)
                        if re == nil then
                            break
                        end

                        self:FxSequence(buff.timing_effect, uuid)

                    end
                end)
            end

            if #buff.timing_effect > 0 then
                if buff.timing_mod == nil or buff.timing_mod == 0 then
                    -- 生效
                    execTimingFX()
                elseif buff.timing_mod == 1 then
                    -- 仅第一层生效
                    if layersCount == 0 then
                        execTimingFX()
                    end
                elseif buff.timing_mod == 2 then
                    -- 仅触发一次
                    timmingCor = self:DispatchAfter(buff.timing_period, function()
                        local re = role:GetRole(uuid)
                        if re == nil then
                            return
                        end
                        g_LogError("一次")
                        self:FxSequence(buff.timing_effect, uuid)
                    end)
                end

            end

            local resetCor = function()
                if cor then
                    self:CancelDispatch(cor)
                    cor = nil
                    if timmingCor then
                        self:CancelDispatch(timmingCor)
                        timmingCor = nil
                    end
                end
            end

            local layer = {
                removeCallback = function()
                    buffEntity.layers[layerKey] = nil
                    resetCor()
                    life()
                    if go then
                        -- GameObject.Destroy(go)
                        assetsMap:DestroyGo(assetID, go)
                        go = nil
                    end
                end,
                resumeCallback = function(newduration)
                    if cor then
                        resetCor()
                        -- 刷新
                        startCor(newduration)
                    end
                end
            }
            buffEntity.layers[layerKey] = layer
        end

        local pre = buff.start_effect
        if pre ~= nil and pre ~= 0 then
            -- 开始特效
            log("buff 前置")
            self:FxSequence(pre, uuid, buffcallback)
        else
            buffcallback()
        end
    elseif type == 3 then
        -- remove
        log("移除指定角色的全部同名buff：" .. buffID)
        local layers = self:GetBuffEntity(uuid, buffID).layers
        for _, v in pairs(layers) do
            if v.removeCallback then
                v.removeCallback()
            end
        end
    end

end

function SkillManager:FxSequence(str, uuid, callback)

    if str == nil or str == "" then
        str = {}
    end

    local keys = str
    if type(str) == "string" then
        log("FxSequence:" .. str)
        keys = string.split(str, ",")
    else

        if #str == 0 then
            str = {}
        end
        log("FxSequence:" .. table.dump(str, nil, 3))
    end

    if keys == nil then
        keys = {}
    end

    local function execute(i)
        if i <= #keys then
            self:PlayFX(keys[i], uuid, function()
                execute(i + 1)
            end)
        else
            if callback then
                callback()
            end
        end
    end

    execute(1)
end

---@return Bullet
function SkillManager:GetBullet(id)
    return self.data.bullet[id]
end
---@return Condition
function SkillManager:GetCondition(id)
    return self.data.condition[id]
end
local current = nil
local laststartTime = nil
function measureTime(key)

    -- if key then
    --     -- 获取当前时间
    --     laststartTime = os.clock()
    --     current = key
    -- else
    --     -- 获取结束时间
    --     local endTime = os.clock()
    --     -- 计算耗时
    --     local elapsedTime = endTime - laststartTime
    --     g_LogError(current..":"..string.format("%.5f", elapsedTime))
    -- end

end

---@param fx Fx
function SkillManager:Bullet(data, isSync)
    local uuid = data.uuid
    local fxId = data.fxId
    local extra = data.extra
    ---@type RoleEntity
    local roleEntity = role:GetRole(uuid)

    if roleEntity == nil then
        return
    end


    if roleEntity.isAvatar then
        if roleEntity:GetTransform() == nil then
            return
        end
    end


    measureTime("子弹1")
    local fx = self:GetFxConfig(fxId)
    local bulletId = fx.param1
    ---@type Bullet
    local bullet = self:GetBullet(bulletId) -- self.data.bullet[bulletId]
    if bullet == nil then
        g_LogError("子弹配置不存在")
        return
    end

    local condition = self:Condition(bullet.condition, uuid)

    if condition == false then
        log("条件不满足:" .. bullet.condition)
        return
    end

    if fx.type == 11 then
        self:TryRemoveFx(uuid, "bullet", bulletId)
        return
    end

    if roleEntity.isAvatar then
        if roleEntity:GetAvatar() == nil then
            return g_LogError("没有这个avatar:" .. uuid)
        end
    end

    local bulletEvent = {
        enterCallback = nil,
        exitCallback = nil
    }

    ---@type GameObject
    local shape = nil
    local Uniqueness = bullet.uniqueness

    if self.bulletCount == nil then
        self.bulletCount = 0
    end
    self.bulletCount = self.bulletCount + 1

    local bulletNumber = self.bulletCount
    local key = bulletId .. "_" .. bulletNumber

    if self.bulletMap[uuid] == nil then
        self.bulletMap[uuid] = {}
    end
    if self.bulletMap[uuid][bulletId] == nil then
        self.bulletMap[uuid][bulletId] = {
            layers = {}
        }
    end

    local bulletEntity = self.bulletMap[uuid][bulletId]

    local max = bullet.max
    if max ~= nil and max ~= 0 then
        local count = 0
        local lastLayerKey = nil
        for k, v in pairs(bulletEntity.layers) do
            if lastLayerKey == nil then
                lastLayerKey = k
            else
                local curKey = string.split(k, "_")
                curKey = curKey[#curKey]
                local lastKey = string.split(lastLayerKey, "_")
                lastKey = lastKey[#lastKey]

                if curKey < lastKey then
                    lastLayerKey = k
                end
            end
            count = count + 1
        end
        if count >= max then

            if bullet.uniqueness == true then
                if lastLayerKey then
                    -- 加时
                    if bulletEntity.layers[lastLayerKey].resumeCallback then
                        bulletEntity.layers[lastLayerKey].resumeCallback(bullet.lifecycle)
                    end
                    return
                end
            else
                if lastLayerKey then
                    if bulletEntity.layers[lastLayerKey].removeCallback then
                        bulletEntity.layers[lastLayerKey].removeCallback()
                    end
                end
            end

        end
    end
    measureTime()

    measureTime("子弹2")

    -- 是否同步发射
    if bullet.is_sync_fire then
        if isSync == true then
            -- 覆盖数据
            bulletNumber = data.bulletNumber
            key = bulletId .. "_" .. bulletNumber
            -- contiune
        else
            if uuid == App.Uuid then
                -- 发消息
                data.bulletId = bulletId
                data.bulletNumber = bulletNumber
                self:SendCustomMessage(BulleFireKey, data)

            else
                -- waiting
            end
            log("等待同步发射")
            return
        end
    else
        -- continue
    end
    local layer = {}
    bulletEntity.layers[key] = layer

    --- 以下是子弹实例化逻辑 对象池TODO

    if bullet.emit_mode == 2 then
        -- 粒子模式
        shape = GameObject()
        self:Particle(bullet, bulletEvent, function()
            return shape
        end)
    else
        -- 物理模式
        if bullet.shape == 1 then
            -- 球状碰撞器
            shape = GameObject.CreatePrimitive(PrimitiveType.Sphere)
            -- 设置半径
            local radius = bullet.size[1]
            shape.transform.localScale = Vector3(radius, radius, radius)

        elseif bullet.shape == 2 then
            -- 立方体碰撞器
            shape = GameObject.CreatePrimitive(PrimitiveType.Cube)
            -- 设置大小
            local size = bullet.size
            shape.transform.localScale = Vector3(tonumber(size[1]), tonumber(size[2]), tonumber(size[3]))
        end

        shape:GetComponent(typeof(CS.UnityEngine.MeshRenderer)).enabled = false
        shape:GetComponent(typeof(CS.UnityEngine.Collider)).isTrigger = true

        local rb = shape:AddComponent(typeof(CS.UnityEngine.Rigidbody));
        rb.useGravity = false
        rb.isKinematic = true
    end
    if  self.BulletLayer ~=nil then
        shape.layer = self.BulletLayer
    end

    local bulletEffect = nil
    if isValidStringValue(bullet.visualeffect) then
        -- 子弹挂载的特效节点
        local tmp = assetsMap:GetAssetGo(bullet.visualeffect)
        if tmp == nil then
            g_LogError("子弹特效不存在:" .. bullet.visualeffect)
        else
            local _b = assetsMap:NewAssetGo(bullet.visualeffect)
            bulletEffect = _b
            _b.transform:SetParent(shape.transform)
            _b.transform.localRotation = Quaternion.Euler(0, 0, 0);
            _b:SetActive(false)
            _b.transform.localPosition = Vector3(0, 0, 0)
            _b:SetActive(true)

            _b.transform.localScale = Vector3(1 / shape.transform.localScale.x, 1 / shape.transform.localScale.y,
                1 / shape.transform.localScale.z)
            local colliders = _b:GetComponentsInChildren(typeof(CS.UnityEngine.Collider))
            for i = 0, colliders.Length - 1 do
                local v = colliders[i]
                v.enabled = false
            end
        end

    end
    measureTime()

    measureTime("子弹3")

    if shape == nil then
        g_LogError("不存在的碰撞器形状" .. bullet.shape)
        return
    end

    layer.bulletGO = shape

    local trackingCor = nil

    shape.name = "bullet->" .. key

    local aoeTrigger = bullet.aoe_type
    ---伤害判定
    local damageTriggerCallback = function(re)

        local data = {
            uuid = uuid,
            bulletId = bulletId,
            bulletNumber = bulletNumber,
            position = shape.transform.position,
            range = bullet.aoe_range,
            speedh = bullet.aoe_knockback_speedh
        }

        if re ~= nil then
            -- 碰撞伤害
            local player = {
                uid = re.uid
            }
            self:LocalCollisionDamage(data, {player})
        else
            -- aoe伤害
            if uuid == App.Uuid then
                -- 只有自己造成的伤害才广播伤害判定

                local hasAvatar = role:HasAvatarRole()
                if hasAvatar then
                    -- 存在avatar角色，请求remote伤害判定
                    self:Damage(data)
                end

                local hasNonAvatar = role:HasNonAvatarRole()
                if hasNonAvatar then
                    -- 存在非avatar角色，本地计算伤害
                    self:LocalAoeDamage(data)
                end

            elseif roleEntity.isAvatar == false then
                -- 非avatar角色发起的伤害，直接广播伤害
                self:LocalAoeDamage(data)
            end
        end

    end

    -- TODO 同步销毁，用来解决子弹销毁效果和击中判定效果的同步问题
    local is_sync_destory = bullet.is_sync_destory

    -- 可能得抖动动画
    local shakeDotween = nil

    -- 子弹实例销毁回调
    local _destroyCallback = function(_data)
        self.bulletSyncDestroyCallbacks[key] = nil

        local _pos = shape.transform.position
        if _data ~= nil then
            _pos = Vector3(_data.position.x, _data.position.y, _data.position.z)
        end
        self:AddEffect(_pos, shape.transform.rotation, bullet.destroy_visualeffect, bullet.destroy_visualeffect_duration)

        if bullet.destroy_sound_effect then
            self:AddEffect(_pos, shape.transform.rotation, bullet.destroy_sound_effect,
                bullet.destroy_visualeffect_duration)
        end

        if shakeDotween then
            shakeDotween:Kill()
        end
        local _shape = shape

        if bullet.is_destroy_trigger_collision_exit == true then
            -- 销毁时触发碰撞退出效果
            -- 移走，延迟一阵销毁
            _shape.transform.position = Vector3(10000, 10000, 10000)
            self:StartCoroutine(function()
                self:YieldEndFrame()
                if bulletEffect ~= nil then
                    assetsMap:DestroyGo(bullet.visualeffect, bulletEffect)
                end
                GameObject.Destroy(_shape)
            end)
        else
            -- 直接销毁
            if bulletEffect ~= nil then
                assetsMap:DestroyGo(bullet.visualeffect, bulletEffect)
            end
            GameObject.Destroy(_shape)

        end

        self.colliderService:RemoveAllColliderListener(shape)
        shape = nil

        if trackingCor then
            self:StopCoroutineSafely(trackingCor)
            trackingCor = nil
        end

        if bulletEntity.layers[key] then
            if bulletEntity.layers[key].removeCallback then
                bulletEntity.layers[key].removeCallback()
            end

            bulletEntity.layers[key] = nil
        end

        log("子弹销毁回调:" .. key)
        if bullet.destroy_effect ~= 0 then
            self:FxSequence(bullet.destroy_effect, uuid)
        end
    end

    -- 子弹销毁
    local destoryBullet = function()
        if shape then

            if aoeTrigger == 2 then
                -- 销毁时广播触发伤害
                damageTriggerCallback()
            end

            if is_sync_destory == true then
                -- 同步销毁
                local msg = {
                    uuid = uuid,
                    bulletId = bulletId,
                    bulletNumber = bulletNumber,
                    position = shape.transform.position
                }
                self:FormatExtra(msg, {"position"})
                log("。。。子弹等待同步销毁。。")
                if uuid == App.Uuid then
                    self:SendCustomMessage(BulleDestroyKey, msg)
                end

                local rb = shape:GetComponent(typeof(CS.UnityEngine.Rigidbody));
                if rb then
                    -- 
                    rb.velocity = Vector3.zero;
                    rb.isKinematic = true
                end
                -- 子弹 静止？ 特效？
                if bullet.sync_destory_waiting == 0 then
                    -- 静止

                elseif bullet.sync_destory_waiting == 1 then
                    -- 原地抖动 循环

                    if shakeDotween == nil then
                        local duration = 1
                        local strength = 0.3
                        local vibrato = 10
                        shakeDotween = shape.transform:DOShakePosition(duration, strength, vibrato):SetLoops(-1, CS.DG
                            .Tweening.LoopType.Restart);
                    end

                elseif bullet.sync_destory_waiting == 2 then
                    -- 消失
                    shape:SetActive(false)
                end

            else
                _destroyCallback()
            end

        end
    end
    measureTime()

    measureTime("子弹4")

    local cor = nil

    cor = self:DispatchAfter(bullet.lifecycle, function()
        log("子弹生命周期结束，尝试销毁")
        cor = nil
        destoryBullet()
    end)
    local stopLifeCycle = function()
        if cor then
            log("中止倒计时")
            self:CancelDispatch(cor)
            cor = nil
        end
        -- 进入兜底销毁倒计时
        if bullet.lifecycle > 0 then
            self:DispatchAfter(bullet.lifecycle, function()
                log("子弹生命周期倒兜底结束，强制销毁")
                if shape ~= nil then
                    log("子弹生命周期倒兜底结束，强制销毁")
                    _destroyCallback()
                else
                    log("子弹生命周期倒兜底结束，已被提前销毁")
                end
            end)
        end

    end
    local resetCor = function(duration)
        if cor then
            self:CancelDispatch(cor)
            cor = self:DispatchAfter(duration, function()
                log("子弹生命周期结束，尝试销毁")
                cor = nil
                destoryBullet()
            end)
        end

    end

    local destroyTag = false
    -- 满足条件，提前销毁
    local destoryImmediately = function()
        stopLifeCycle()
        if destroyTag == false then
            destroyTag = true
            destoryBullet()
        else
            log("已经提前销毁:" .. key)
        end
    end

    if self.bulletSyncDestroyCallbacks == nil then
        self.bulletSyncDestroyCallbacks = {}
    end
    -- 同步销毁回调
    self.bulletSyncDestroyCallbacks[key] = function(data)
        -- 同步销毁
        stopLifeCycle()
        log("同步销毁执行:" .. key)
        _destroyCallback(data)
    end

    local lastTarget = nil
    local exitList = {}

    local selfFaction = Faction:GetFactionName(uuid)

    bulletEvent.enterCallback = function(other)

        -- g_LogError("子弹击中--->" .. other.name)

        if shape == nil then
            return
        end
        if other.gameObject.transform:IsChildOf(shape.transform) then
            return
        end

        if self:IsBulletGO(other.gameObject) then
            return
        end

        local isValidCollision = self:IsBulletCollider(bullet.collision_detection_camp, uuid, nil, other, selfFaction)

        if isValidCollision == true then
            log("子弹击中--->" .. other.name)
            -- 有效，清空队列
            self:BulletHit({
                uuid = uuid,
                bulletId = bulletId,
                bulletNumber = bulletNumber,
                collider = other,
                bulletG = shape
            })
            if bullet.collision_detection_camp_effect and #bullet.collision_detection_camp_effect > 0 then
                local colliderRole = role:GetRoleWithGo(other)
                if colliderRole then
                    self:FxSequence(bullet.collision_detection_camp_effect, colliderRole.uid)
                end
            end

            -- 碰撞伤害
            local _re = role:GetRoleWithGo(other.gameObject)
            if bullet.collision_damage_factions and #bullet.collision_damage_factions > 0 and _re ~= nil then

                damageTriggerCallback(_re)
            end

            if aoeTrigger == 1 then
                -- 碰撞aoe伤害
                damageTriggerCallback()
            end

            lastTarget = other

            if bullet.is_self_destruct_after_collision == true then
                -- 碰撞后自毁
                -- 需要自毁的要移除碰撞监听，防止多次触发
                local colliderListener = shape:GetComponent(typeof(CS.ColliderListener))
                if colliderListener then
                    colliderListener:Clear()
                end

                if Uniqueness == true then
                    self:TryRemoveFx(uuid, "bullet", bulletId)
                else
                    destoryImmediately()
                end
            else
                -- 不自毁，注册碰撞退出事件
                if bulletEvent.exitCallback == nil then
                    bulletEvent.exitCallback = function(_other)
                        if bullet.collision_end_effect and #bullet.collision_end_effect > 0 and lastTarget == _other then
                            self:FxSequence(bullet.collision_end_effect, uuid)
                        end

                        if bullet.collision_detection_camp_end_effect and #bullet.collision_detection_camp_end_effect >
                            0 then
                            local colliderRole = role:GetRoleWithGo(_other)
                            if colliderRole then
                                self:FxSequence(bullet.collision_detection_camp_end_effect, colliderRole.uid)
                            end
                        end

                    end
                    self.colliderService:RegisterColliderExitListener(shape, bulletEvent.exitCallback)
                end
            end

            if bullet.collision_effect ~= 0 then
                self:FxSequence(bullet.collision_effect, uuid)
            end
        end

    end

    if #bullet.collision_detection_camp ~= 0 then
        -- 碰撞组大于0
        self.colliderService:RegisterColliderEnterListener(shape, bulletEvent.enterCallback)
    else
    end

    ---初始位置
    measureTime()
    measureTime("子弹5")

    if bullet.forward_target == nil or bullet.forward_target == 1 or bullet.forward_target == 0 then
        -- 自己
        if roleEntity.isAvatar then
            shape.transform.position = roleEntity:GetAvatar().BodyTrans.transform.position
            shape.transform.rotation = roleEntity:GetAvatar().BodyTrans.transform.rotation
        else
            shape.transform.position = roleEntity:GetTransform().position
            shape.transform.rotation = roleEntity:GetTransform().rotation
        end
    elseif bullet.forward_target == 5 then
        -- 最近的敌方
        local nearest = role:GetNearestEnemy(uuid)

        if roleEntity.isAvatar then
            shape.transform.position = roleEntity:GetAvatar().BodyTrans.transform.position

            if nearest then
                shape.transform.rotation = Quaternion.LookRotation(
                    nearest:GetTransform().position - roleEntity:GetTransform().position)
            else
                shape.transform.rotation = roleEntity:GetAvatar().BodyTrans.transform.rotation
            end
        else
            shape.transform.position = roleEntity:GetTransform().position
            shape.transform.rotation = roleEntity:GetTransform().rotation
        end
    end

    -- 同步返回额外数据覆盖
    if extra and extra.position then
        shape.transform.position = Vector3(extra.position.x, extra.position.y, extra.position.z)
    end
    if extra and extra.forward then
        shape.transform.rotation = Quaternion.LookRotation(Vector3(extra.forward.x, extra.forward.y, extra.forward.z),
            roleEntity:GetTransform().up);
    end

    if bullet.is_tracking == true then
        -- 追踪
        -- bodyTrans

        if bullet.tracking_target == nil or bullet.tracking_target == 0 then
            shape.transform:SetParent(roleEntity:GetTransform().parent.parent.transform)
        else

            if extra and extra.tracking_target ~= nil then
                local nearest = role:GetRole(extra.tracking_target)
                if nearest then
                    if nearest then
                        trackingCor = self:StartCoroutine(function()
                            while shape ~= nil and not shape:IsNull() do
                                local target = nearest:GetTransform().position
                                local pos = shape.transform.position
                                local dir = target - pos
                                local rot = Quaternion.LookRotation(dir)
                                shape.transform.rotation = Quaternion.Slerp(shape.transform.rotation, rot, 0.1)
                                shape.transform.position = Vector3.MoveTowards(pos, target, bullet.tracking_speed *
                                    Time.fixedDeltaTime)
                                self:YieldEndFrame()
                            end
                        end)
                    end
                end
            else
                if bullet.tracking_target == 5 then
                    -- 距离最近的地方
                    if bullet.tracking_mod == 1 then
                        -- 首次目标
                        local nearest = role:GetNearestEnemyWithFaction(uuid, selfFaction, shape,
                            bullet.tracking_distance)
                        if nearest then
                            trackingCor = self:StartCoroutine(function()
                                while shape ~= nil and not shape:IsNull() do
                                    local target = nearest:GetTransform().position
                                    local pos = shape.transform.position
                                    local dir = target - pos
                                    local rot = Quaternion.LookRotation(dir)
                                    shape.transform.rotation = Quaternion.Slerp(shape.transform.rotation, rot, 0.1)
                                    shape.transform.position =
                                        Vector3.MoveTowards(pos, target, bullet.tracking_speed * Time.fixedDeltaTime)
                                    self:YieldEndFrame()
                                end
                            end)
                        end
                    elseif bullet.tracking_mod == 2 then
                        -- 刷新目标
                        trackingCor = self:StartCoroutine(function()
                            while shape ~= nil and not shape:IsNull() do
                                local nearest = role:GetNearestEnemyWithFaction(uuid, selfFaction, shape,
                                    bullet.tracking_distance)
                                if nearest then
                                    local target = nearest:GetTransform().position
                                    local pos = shape.transform.position
                                    local dir = target - pos
                                    local rot = Quaternion.LookRotation(dir)
                                    shape.transform.rotation = Quaternion.Slerp(shape.transform.rotation, rot, 0.1)
                                    shape.transform.position =
                                        Vector3.MoveTowards(pos, target, bullet.tracking_speed * Time.fixedDeltaTime)
                                end
                                self:YieldEndFrame()
                            end
                        end)
                    elseif bullet.tracking_mod == 3 then
                        -- 等待首次目标
                        trackingCor = self:StartCoroutine(function()
                            local nearest = nil
                            while shape ~= nil and not shape:IsNull() do
                                if nearest then
                                    local target = nearest:GetTransform().position
                                    local pos = shape.transform.position
                                    local dir = target - pos
                                    local rot = Quaternion.LookRotation(dir)
                                    shape.transform.rotation = Quaternion.Slerp(shape.transform.rotation, rot, 0.1)
                                    shape.transform.position =
                                        Vector3.MoveTowards(pos, target, bullet.tracking_speed * Time.fixedDeltaTime)
                                else
                                    nearest = role:GetNearestEnemyWithFaction(uuid, selfFaction, shape,
                                        bullet.tracking_distance)
                                end
                                self:YieldEndFrame()
                            end
                        end)
                    else

                    end

                end
            end

        end

    else
        -- 计算轨迹
        local rb = shape:GetComponent(typeof(CS.UnityEngine.Rigidbody));
        rb.isKinematic = false
        -- 给初速
        if rb and not rb:IsNull() then
            rb.velocity = shape.transform.forward * bullet.speed.z + shape.transform.up * bullet.speed.y +
                              shape.transform.right * bullet.speed.x;

            if bullet.is_subject_to_gravity == true then
                rb.useGravity = true
            else
                rb.useGravity = false
            end

        end

    end

    -- 设置子弹偏移
    measureTime()
    measureTime("子弹6")

    shape.transform.position =
        shape.transform.position + shape.transform.forward * bullet.offset.z + shape.transform.up * bullet.offset.y +
            shape.transform.right * bullet.offset.x

    if bullet.offset_random then
        shape.transform.position = shape.transform.position + shape.transform.forward *
                                       math.random(-bullet.offset_random.z, bullet.offset_random.z) + shape.transform.up *
                                       math.random(-bullet.offset_random.y, bullet.offset_random.y) +
                                       shape.transform.right *
                                       math.random(-bullet.offset_random.x, bullet.offset_random.x)
    end

    if bullet.emit_forward_target == nil or bullet.emit_forward_target == 1 or bullet.emit_forward_target == 0 then

    elseif bullet.emit_forward_target == 5 then
        -- 最近的敌方
        local nearest = role:GetNearestEnemy(uuid)
        shape.transform.rotation = Quaternion.LookRotation(nearest:GetTransform().position - shape.transform.position)
    end
    -- 这里根据正方向速度，分别计算分量
    if bullet.speed_forward ~= nil and bullet.speed_forward ~= 0 then
        local sf = bullet.speed_forward -- shape.transform.forward 的速度，sf是个number
        -- 转换成世界坐标
        local ws = shape.transform.forward * sf
        local rb = shape:GetComponent(typeof(CS.UnityEngine.Rigidbody));
        rb.isKinematic = false
        -- 给初速
        if rb and not rb:IsNull() then
            -- 刚体速度叠加分量，需要在这之前确定好shape的正方向
            rb.velocity = rb.velocity + ws
        end
    end

    if Uniqueness == true then
        -- 需要释放上一个同名子弹实例
        self:AddFx(uuid, "bullet", bulletId, destoryImmediately)
    end

    layer.removeCallback = function()
        bulletEntity.layers[key] = nil
        destoryImmediately()
    end
    layer.resumeCallback = function(duration)
        resetCor(duration)
    end

    if aoeTrigger == 3 then
        -- 广播触发伤害
        damageTriggerCallback()
    end

    if bullet.start_effect and #bullet.start_effect > 0 then

        if bullet.start_effect_delay and bullet.start_effect_delay > 0 then
            self:DispatchAfter(bullet.start_effect_delay, function()
                self:FxSequence(bullet.start_effect, uuid)
            end)
        else
            self:FxSequence(bullet.start_effect, uuid)

        end
    end

    -- 发射特效
    self:AddEffect(shape.transform.position, shape.transform.rotation, bullet.emit_visualeffect,
        bullet.emit_visualeffect_duration)

end
---@param bullet Bullet
---@param event table
---@param getShape function
function SkillManager:Particle(bullet, event, getShape)
    local shape = getShape()
    shape.transform.position = Vector3(0, 0, 0)
    local targetPm = nil
    local pss = nil
    local psColliders = {}
    local destroy = function()
        -- for k, v in pairs(psColliders) do
        --     self.colliderService:RemoveAllColliderListener(v)
        --     GameObject.Destroy(v)
        -- end
        psColliders = {}
    end
    self:StartCoroutine(function()
        while true do
            if getShape() == nil then
                destroy()
                break
            end
            if targetPm == nil then
                local pms = shape:GetComponentsInChildren(typeof(CS.UnityEngine.ParticleSystem))

                -- 取第一个粒子个数大于零的粒子系统
                for i = 0, pms.Length - 1, 1 do
                    if pms[i].particleCount > 0 then
                        targetPm = pms[i]
                        break
                    end
                end
                if targetPm then

                    if pss == nil or pass.Length ~= targetPm.particleCount then
                        pss = CS.System.Array.CreateInstance(typeof(CS.UnityEngine.ParticleSystem.Particle),
                            targetPm.particleCount)
                        -- 没有实现节点池，注意不要使用数量频繁变化的粒子系统
                        for k, v in pairs(psColliders) do
                            GameObject.Destroy(v)
                        end
                        psColliders = {}
                        for i = 0, targetPm.particleCount - 1, 1 do
                            local _shape = nil
                            if bullet.shape == 1 then
                                _shape = GameObject.CreatePrimitive(PrimitiveType.Sphere)
                                local radius = bullet.size[1]
                                _shape.transform.localScale = Vector3(radius, radius, radius)

                            elseif bullet.shape == 2 then
                                _shape = GameObject.CreatePrimitive(PrimitiveType.Cube)
                                local size = bullet.size
                                _shape.transform.localScale =
                                    Vector3(tonumber(size[1]), tonumber(size[2]), tonumber(size[3]))
                            end
                            local rb = _shape:AddComponent(typeof(CS.UnityEngine.Rigidbody));
                            rb.useGravity = false
                            rb.isKinematic = true
                            table.insert(psColliders, _shape)
                            _shape.transform:SetParent(shape.transform)
                            _shape:GetComponent(typeof(CS.UnityEngine.MeshRenderer)).enabled = false
                            _shape.transform.position = targetPm.transform:TransformPoint(pss[i].position)
                            _shape:GetComponent(typeof(CS.UnityEngine.Collider)).isTrigger = true
                            self.colliderService:RegisterColliderEnterListener(_shape, function(other)
                                if event.enterCallback then
                                    event.enterCallback(other)
                                end
                            end)
                            self.colliderService:RegisterColliderExitListener(_shape, function(other)
                                if event.exitCallback then
                                    event.exitCallback(other)
                                end
                            end)
                        end
                    end
                end
            end
            if targetPm ~= nil then
                targetPm:GetParticles(pss)
                for i = 0, pss.Length - 1, 1 do
                    if bullet.simulation_space == "World" then
                        psColliders[i + 1].transform.position = pss[i].position
                    elseif bullet.simulation_space == "Local" or bullet.simulation_space == "" then
                        psColliders[i + 1].transform.position = targetPm.transform:TransformPoint(pss[i].position)
                    elseif bullet.simulation_space == "Custom" then
                        -- TODO
                        -- g_LogError("Custom空间待实现")
                        -- psColliders[i + 1].transform.position = getShape().transform:TransformPoint(pss[i].position)
                    end
                end
            end
            self:YieldEndFrame()

        end
    end)

    return shape
end

function SkillManager:AddEffect(position, rotation, assetId, duration)
    if isValidStringValue(assetId) then
        local tmp = assetsMap:GetAssetGo(assetId)
        if tmp == nil then
            return g_LogError("资源不存在" .. assetId)
        end
        local _b = assetsMap:NewAssetGo(assetId)
        _b:SetActive(true)
        _b.transform.position = position
        _b.transform.localScale = Vector3(1, 1, 1)

        _b.transform.rotation = rotation
        -- 特效销毁
        if duration ~= 0 and duration ~= nil then
            self:DispatchAfter(duration, function()
                assetsMap:DestroyGo(assetId, _b)
            end)
        else
            -- 特效自毁，或不销毁
        end
        return _b
    end
end
function SkillManager:OnBulletHit(callback)
    self.eventEmitter:on("OnBulletHit", callback)
end
function SkillManager:BulletHit(...)
    self.eventEmitter:emit("OnBulletHit", ...)
end
function SkillManager:OnDamage(callback)
    self.eventEmitter:on("OnDamage", callback)
end
-- 同步伤害
function SkillManager:Damage(data)
    log("伤害请求" .. table.dump(data))
    self:FormatExtra(data, {"position"})
    self:SendCustomMessage(OnSkillDamageKey, data)
end
-- aoe伤害回调
---@param data table
---@param damageType string  | "'aoe'" | "'collision'"
function SkillManager:DamageRes(data, damageType)
    if self.onDamageResFilter then
        self.onDamageResFilter(data)
    end
    -- 伤害结果
    local uuid = data.uuid
    local bulletId = data.bulletId
    local bullet = self:GetBullet(bulletId)
    local players = data.players
    local damage_players = {}

    if damageType == DamageType.AOE then
        -- 伤害layers
        local damageFactions = bullet.aoe_damage_factions
        for k, v in pairs(players) do

            local isValid = self:IsBulletCollider(damageFactions, uuid, v.uid)
            local can = self:Condition(bullet.aoe_condition, v.uid)

            if isValid == true and can then
                table.insert(damage_players, v.uid)
            end
        end

        -- 击退layers
        local knockbackFactions = bullet.aoe_knockback_factions
        local knockback_players = {}
        for k, v in pairs(players) do
            local isValid = self:IsBulletCollider(knockbackFactions, uuid, v.uid)
            local can = self:Condition(bullet.aoe_condition, v.uid)
            if isValid == true and can == true then
                table.insert(knockback_players, v.uid)
            end
        end

        data.knockback_players = knockback_players
        self:ExplosionAnim(data)
    elseif damageType == DamageType.COLLISION then
        local damageFactions = bullet.collision_damage_factions
        if damageFactions then
            for k, v in pairs(players) do
                local isValid = self:IsBulletCollider(damageFactions, uuid, v.uid)
                if isValid == true then
                    table.insert(damage_players, v.uid)
                end
            end
        end

    else
        g_LogError("缺少伤害类型")
    end

    -- 直接伤害
    if data.damagedPlayers ~= nil then
        for k, v in pairs(data.damagedPlayers) do
            table.insert(damage_players, v)
        end
    end

    damage_players = utils.RemoveDuplicates(damage_players)
    data.damagedPlayers = damage_players

    self:DealDamage(data, damageType)

    self.eventEmitter:emit("OnDamage", data)

end
function c_pow(base, exponent)
    local result = 1
    for i = 1, exponent do
        result = result * base
    end
    return result
end
function SkillManager:LocalCollisionDamage(value, players)
    local msg = {
        uuid = value.uuid,
        bulletId = value.bulletId,
        bulletNumber = value.bulletNumber,
        players = players
    }
    self:DamageRes(msg, DamageType.COLLISION)
end
function SkillManager:LocalAoeDamage(value)
    -- local data = {
    --     uuid = uuid,
    --     bulletId = bulletId,
    --     bulletNumber = bulletNumber,
    --     range = range,
    --     damage = damage
    -- }
    -- 爆炸aoe伤害
    local explosionMsg = {
        uuid = value.uuid,
        bulletId = value.bulletId,
        bulletNumber = value.bulletNumber
    }
    local explosionPos = value.position
    local explosion_range = value.range
    local players = {}
    local count = 0
    local colliders = Physics.OverlapSphere(explosionPos, explosion_range);
    if colliders.Length > 0 then
        for i = 0, colliders.Length - 1, 1 do
            local collider = colliders[i]
            local re = role:GetRoleWithGo(collider.gameObject)

            if re then
                local transform = re:GetTransform()
                local playerInfo = {
                    uid = re.uid
                    -- finalPos = {
                    --     x = transform.position.x,
                    --     y = transform.position.y,
                    --     z = transform.position.z
                    -- }
                }

                players[playerInfo.uid] = playerInfo
                count = count + 1
            end
        end

    end

    if count > 0 then
        explosionMsg.players = players
        -- module.sendMsg(OnSkillDamageResKey, explosionMsg)
        self:DamageRes(explosionMsg, DamageType.AOE)
    end

end

-- 校验子弹阵营类型碰撞
-- 指定阵营优先于根据uuid查询阵营
function SkillManager:IsBulletCollider(factions, selfUuid, otherUuid, collider, _selfFaction, _targetFaction)
    local isValid = false
    local colliderRole = nil
    if collider ~= nil then
        -- 实体碰撞检测
        -- TODO 这里要换成根据gameobject获取角色（avatar+静态同步角色）
        colliderRole = role:GetRoleWithGo(collider.gameObject)
        if colliderRole == nil then
            -- 按照实体碰撞，排除角色
            otherUuid = nil
            if (collider:GetComponent(typeof(CS.UnityEngine.Collider)).isTrigger == true or
                collider:GetComponent(typeof(CS.UnityEngine.Renderer)) == nil) then
                return
            end
        else
            otherUuid = colliderRole.uid
        end
    else
        -- 角色检测
        if otherUuid == nil then
            g_LogError('缺少参数otherUuid')
            return
        end
    end
    for _, faction in pairs(factions) do
        if faction == 1 or faction == 2 then
            if otherUuid ~= nil and otherUuid ~= selfUuid then
                local selfFaction = Faction:GetFactionName(selfUuid)
                if _selfFaction then
                    selfFaction = _selfFaction
                end
                local targetFaction = Faction:GetFactionName(otherUuid)
                if _targetFaction then
                    targetFaction = _targetFaction
                end
                if selfFaction ~= nil and targetFaction ~= nil then
                    local isEnemy = Faction:IsEnemy(selfFaction, targetFaction)
                    if faction == 1 then
                        -- 敌方
                        if isEnemy == true then
                            isValid = true
                        end
                    else
                        -- 我方
                        if isEnemy == false then
                            isValid = true
                        end
                    end
                end
            end

        elseif faction == 3 then
            if selfUuid == otherUuid then
                isValid = true
            end
        elseif faction == 4 then
            -- 不是角色，就是模型
            if colliderRole == nil then
                isValid = true
            end
        end
    end

    return isValid
end
--- 收到爆炸消息，展示爆炸效果，销毁道具
function SkillManager:ExplosionAnim(info)

    local bulletId = info.bulletId
    ---@type Bullet
    local bullet = self:GetBullet(bulletId)
    local players = info.players
    local knockback_players = info.knockback_players
    if players and knockback_players then
        for _, value in pairs(knockback_players) do
            local uid = value
            local finalPos = players[value].finalPos
            local avatar = CourseEnv.ServicesManager:GetAvatarService():GetAvatarByUUID(uid)
            if avatar and not avatar.Invincible  then
                avatar:SetBombedWithFinalPos(finalPos, bullet.aoe_knockback_speedv)
            end
        end
    end
end

function SkillManager:DealDamage(info, damageType)
    local from = info.uuid
    local bulletId = info.bulletId
    ---@type Bullet
    local bullet = self:GetBullet(bulletId)
    local damageValue = 0;

    if damageType == DamageType.AOE then
        damageValue = bullet.aoe_damage
    elseif damageType == DamageType.COLLISION then
        damageValue = bullet.collision_damage
    end
    local data = {
        ps = {},
        d = damageValue -- 这次伤害值
    }
    local damagedPlayers = info.damagedPlayers
    local players = info.damagedPlayers
    if players and damagedPlayers and damageValue ~= 0 then
        local needSync = false
        for _, value in pairs(damagedPlayers) do
            local uid = value
            table.insert(data.ps, uid)
            needSync = true
        end

        -- 护盾处理
        local filter = {}
        for _, v in pairs(data.ps) do
            local roleEntity = role:GetRole(v)
            if roleEntity.invincible == true or roleEntity.shield > 0 then
                if roleEntity.invincible ~= true then
                    roleEntity.shield = roleEntity.shield - 1
                else
                end
            else
                table.insert(filter, v)
            end
        end
        data.ps = filter

        if needSync == true then
            local from_role = role:GetRole(from)
            if from_role then
                if from_role.isAvatar then
                    if from == App.Uuid then
                        -- 如果是自己造成的伤害，需要自己广播，广播这个人的最大血量（用于remote初始化）和这次伤害数值（用于remote计算）
                        role:AddHealth(-data.d, data.ps,false,{
                            bulletId=bulletId,
                            form=from
                        })
                    end
                else
                    -- 非avatar角色，直接广播伤害
                    role:AddHealth(-data.d, data.ps, true)
                end
            end
        end

    end

end
---特殊技能状态
---@param uuid string
---@param fx Fx
function SkillManager:Invisible(uuid, fx)
    log("隐身:" .. fx.param1)

    local avatar = self.avatarService:GetAvatarByUUID(uuid)
    if avatar == nil then
        g_LogError("没有这个avatar:" .. uuid)
        return
    end
    local func = function()

        if fx.param1 == "1" then
            local map = {}
            local roleCanvas = avatar.BodyTrans:Find("Character/RoleCanvas")

            local rollback = function()
                -- 恢复
                log("恢复隐身材质")
                if roleCanvas then
                    roleCanvas.gameObject:SetActive(true)
                end
                for k, v in pairs(map) do

                    if not v.renderer:IsNull() then
                        v.renderer.materials = v.materials
                    end

                end
                 -- 显示传说皮肤的骨骼
                 local skeleton = avatar.BodyTrans:FindInAll("Character_Reference")
                 if skeleton then
                     skeleton.gameObject:SetActive(true)
                 end
                map = {}
            end

            local onchangeCallback = function(_uuid)
                log("更换隐身材质")

                if _uuid ~= uuid then
                    return
                end
                if #map ~= 0 then
                    -- 说明已经有缓存了，先恢复
                    rollback()
                end
                local avatar = self.avatarService:GetAvatarByUUID(uuid)
                if avatar == nil then
                    g_LogError("avatar 不存在" .. uuid)
                    return
                end
                local renderers = avatar.BodyTrans.gameObject:GetComponentsInChildren(typeof(CS.UnityEngine.Renderer))
                if roleCanvas then
                    roleCanvas.gameObject:SetActive(false)
                end
                for i = 0, renderers.Length - 1, 1 do
                    -- 过滤掉 SpriteRenderer
                    if not renderers[i].transform:IsChildOf(roleCanvas) and not renderers[i]:GetComponent(typeof(CS.UnityEngine.SpriteRenderer)) then
                        table.insert(map, {
                            renderer = renderers[i],
                            materials = renderers[i].materials
                        })
                    end
                end
                -- 同时隐藏传说皮肤的骨骼
                local skeleton = avatar.BodyTrans:FindInAll("Character_Reference")
                if skeleton then
                    skeleton.gameObject:SetActive(false)
                end

                for k, v in pairs(map) do
                    v.renderer.materials = {self.ghostM}
                end
            end

            onchangeCallback(uuid)
            self:OnAvatarChildrenChanged(onchangeCallback)
            self:AddFx(uuid, "invisible", 1, function()
                rollback()
                self:OffAvatarChildrenChanged(onchangeCallback)
            end)
        else
            self:TryRemoveFx(uuid, "invisible", 1)
        end
    end
    if self.ghostM == nil then

        if avatar ~= self.avatarService.selfAvatar then
            local assetPath = "modules/" .. RESOURCE_LOC .. "/assets/material/ghost/ghost-transparent.mat"
            ResourceManager:LoadMaterialWithExName(assetPath, function(asset)
                self.ghostM = asset
                self.ghostM:SetFloat("Vector1_ba7acd4eecbf434c8891f225829e9874", 0.2);
                func()
            end)
        else

            local assetPath = "modules/" .. RESOURCE_LOC .. "/assets/material/ghost/ghost-normal.mat"
            ResourceManager:LoadMaterialWithExName(assetPath, function(asset)
                self.ghostM = asset
                func()
            end)
        end

    else
        func()
    end

end
---@param uuid string
---@param fx Fx
function SkillManager:Xray(uuid, fx)
    log("透视:" .. fx.param1)
    local avatar = self.avatarService:GetAvatarByUUID(uuid)
    if avatar == nil then
        g_LogError("没有这个avatar:" .. uuid)
        return
    end
    -- 只有自己生效
    if avatar ~= self.avatarService.selfAvatar then
        return
    end

    if fx.param1 == "1" then
        local faction = Faction:GetFactionName(App.Uuid)
        local avatars = self.avatarService:GetAllAvatar()

        local getOutline = function(avatar)
            local outlinable = avatar.BodyTrans.gameObject:GetComponent(typeof(CS.EPOOutline.Outlinable))

            if outlinable == nil then
                outlinable = avatar.BodyTrans.gameObject:AddComponent(typeof(CS.EPOOutline.Outlinable))

                outlinable.RenderStyle = 2;
                outlinable.FrontParameters.Enabled = false
                if self.InterlacedShader == nil then
                    self.InterlacedShader = CS.UnityEngine.Resources.Load(
                        "Easy performant outline/Shaders/Fills/Interlaced");
                end

                outlinable.BackParameters.FillPass.Shader = self.InterlacedShader

                -- 这里做一个敌我双方的颜色区分
                local _f = Faction:GetFactionName(avatar.avatarUuid)

                if _f == faction then
                    outlinable.BackParameters.Color = CS.UnityEngine.Color.green
                    outlinable.BackParameters.FillPass:SetColor("_PublicColor", CS.UnityEngine.Color.green)
                    outlinable.BackParameters.FillPass:SetColor("_PublicGapColor", CS.UnityEngine.Color.clear)
                else
                    outlinable.BackParameters.Color = CS.UnityEngine.Color.red
                    outlinable.BackParameters.FillPass:SetColor("_PublicColor", CS.UnityEngine.Color.red)
                    outlinable.BackParameters.FillPass:SetColor("_PublicGapColor", CS.UnityEngine.Color.clear)
                end
                outlinable.enabled = false
            end
            return outlinable
        end

        -- 当节点发生变化时，要刷新renderingList
        local updateAvatarOutline = function(_uuid)

            local avatar = self.avatarService:GetAvatarByUUID(_uuid)
            if avatar == nil then
                g_LogError("avatar 不存在" .. _uuid)
                return nil
            end

            if avatar.character == nil then
                g_LogError("avatar 不可见" .. _uuid)
                return nil
            end
            -- 名字需要单独处理一下
            local outlinable = getOutline(avatar)
            local titleGroup = avatar.character.transform:Find("RoleCanvas")
            local pos = titleGroup.transform.localPosition
            titleGroup:SetParent(nil)

            -- 更新目标
            -- outlinable:AddAllChildRenderersToRenderingList(CS.EPOOutline.RenderersAddingMode.All);
            outlinable:AddAllChildRenderersToRenderingList(CS.EPOOutline.RenderersAddingMode.MeshRenderer | CS.EPOOutline.RenderersAddingMode.SkinnedMeshRenderer);
            -- 名字恢复
            titleGroup:SetParent(avatar.character.transform)
            titleGroup.transform.localPosition = pos
            return outlinable
        end

        local onChangedCallback = function(_uuid)
            if uuid ~= _uuid then
                return
            end
            updateAvatarOutline(_uuid)
        end

        for k, v in pairs(avatars) do
            -- if v ~= self.avatarService.selfAvatar then
            local outlinable = updateAvatarOutline(v.avatarUuid)
            if outlinable then
                outlinable.enabled = true
            else
                g_LogError("outlinable is nil")
            end
        end

        self:OnAvatarChildrenChanged(onChangedCallback)
        self:AddFx(uuid, "xray", 1, function()
            -- 恢复
            local avatars = self.avatarService:GetAllAvatar()
            for k, v in pairs(avatars) do
                local outlinable = v.BodyTrans.gameObject:GetComponent(typeof(CS.EPOOutline.Outlinable))
                if outlinable ~= nil then
                    outlinable.enabled = false
                end
            end

            self:OffAvatarChildrenChanged(onChangedCallback)
        end)

    else
        self:TryRemoveFx(uuid, "xray", 1)
    end

end

function SkillManager:ReceiveMessage(key, value, isResume)
    -- TODO:
    if key == SkillExecKey then

        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            self:AsyncGetAvatar(msg.uuid, AvatarLoadType.PrefabLoaded, function(avatar)
                self:Use({
                    uuid = msg.uuid,
                    skillName = msg.skillName,
                    extra = msg.extra
                }, true)
            end)
        end
    elseif key == AvatarChildrenChangedKey then

        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            if msg.uuid ~= App.Uuid then
                self:AsyncGetAvatar(msg.uuid, AvatarLoadType.PrefabLoaded, function(avatar)
                    self:AvatarTransformChanged(msg.uuid, true)
                end)
            end
        end

    elseif key == OnSkillDamageResKey and isResume == false then

        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            self:DamageRes(msg, DamageType.AOE)
        end
    elseif key == BulleDestroyKey then
        -- 执行销毁回调

        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            local uuid = msg.uuid
            local bulletId = msg.bulletId
            local bulletNumber = msg.bulletNumber
            local key = bulletId .. "_" .. bulletNumber
            if self.bulletSyncDestroyCallbacks and self.bulletSyncDestroyCallbacks[key] then
                self.bulletSyncDestroyCallbacks[key](msg)
                self.bulletSyncDestroyCallbacks[key] = nil
            end
        end

    elseif key == BulleFireKey then
        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            self:Bullet(msg, true)
        end
    end

end
function SkillManager:RemoveAll()

    for _, v in pairs(self.cdPools) do
        for _k, skill in pairs(v) do
            if skill.cor then
                self:StopCoroutineSafely(skill.cor)
            end
        end
    end
    self.cdPools = {}

    for _, v in pairs(self.bulletMap) do
        for _, e in pairs(v) do
            for _, event in pairs(e.layers) do
                if event.removeCallback then
                    event.removeCallback()
                end
            end
        end
    end
    self.bulletMap = {}

    for _, v in pairs(self.buffMap) do
        for _, e in pairs(v) do
            for _, event in pairs(e.layers) do
                if event.removeCallback then
                    event.removeCallback()
                end
            end
        end
    end
    self.buffMap = {}

end
function SkillManager:IsBulletGO(go)
    for _, v in pairs(self.bulletMap) do
        for _, e in pairs(v) do
            for _, v in pairs(e.layers) do
                if v.bulletGO then
                    if go.gameObject.transform:IsChildOf(v.bulletGO.transform) then
                        return true
                    end
                end

            end
        end

    end

    return false
end
local skillInstance = SkillManager:new()
return skillInstance
