local class = require("middleclass")
local bmc = require("gameplay/worldBaseElementClass")
Color = CS.UnityEngine.Color
Physics = CS.UnityEngine.Physics
Mathf = CS.UnityEngine.Mathf
Input = CS.UnityEngine.Input
local ExecuteSkill = "ExecuteSkill"
local ExecuteSkillSync = "ExecuteSkillSync"
local SkillCDSync = "SkillCDSync"
---@class ButtonManager : WorldBaseElementClass
local ButtonManager = class("ButtonManager", bmc)
function ButtonManager:initialize()
    ButtonManager.super.initialize(self)
    -- 默认显示技能CD剩余秒数，可通过SetShowSkillCDText方法修改
    self.showSkillCDText = true
    
    ButtonManager.ClickEvent = {
        Execute = "Execute",
        SyncExecute = "SyncExecute",
        Cancel = "Cancel",
        CoolingDown = "CoolingDown",
        InCoolingDown = "InCoolingDown",
        OutCoolingDown = "OutCoolingDown",
        AimDown = "AimDown",
        BuildFinish = "BuildFinish",
        CountNone = "CountNone",
        CountChanged = "CountChanged",
        Blocking = "Blocking",
        PointerUp = "PointerUp",
        PointerDown = "PointerDown",
        PreExecute = "PreExecute"
    }
end
function ButtonManager:Init()
    ButtonManager.super.Init(self, "ButtonManager", function()
        self:SubscribeMsgKey(ExecuteSkillSync)
        self:SubscribeMsgKey(SkillCDSync)
    end)

    self:StartCoroutine(function()
        while true do
            self:YieldEndFrame()
            if self.isAiming then
                if Input.touchCount > 0 then
                    local touch = Input.GetTouch(0);
                    if (touch.phase == CS.UnityEngine.TouchPhase.Ended or touch.phase ==
                        CS.UnityEngine.TouchPhase.Canceled) then
                        self:HideAimLine()
                    end
                elseif not Input.GetMouseButton(0) then
                    self:HideAimLine()
                end
            end
        end

    end)
end
function ButtonManager:ReceiveMessage(key, value, isResume)
    if key == SkillCDSync then
        local msg = self.jsonService:decode(value[#value])
        self.SyncSkillMap = msg

        -- 同步cd状态

        for k, v in pairs(msg) do

            if (self.frameIndex - v.lastFrameIndex) < (v.cd * App.frameNum) then
                -- 需要进入cd
                self:ButtonCD(k, v)
            else
            end
        end
    end

    if not isResume then

        for k, v in pairs(value) do
            local msg = self.jsonService:decode(v)
            if key == ExecuteSkillSync then
                -- 同步执行技能
                self:Click(msg.key, {
                    value = msg,
                    event = self.ClickEvent.SyncExecute
                })
            end
        end

    end
end
function ButtonManager:ButtonCD(key, value)
    if self.skillButtons then
        for _, v in pairs(self.skillButtons) do
            if v.info and v.info.key == key then
                if not v.isCoolingDown then
                    v.lastFrameIndex = value.lastFrameIndex
                    v.coolDown()
                end
            end
        end
    end
    
end
function ButtonManager:Tick()
    if self.skillButtons then
        for _, v in pairs(self.skillButtons) do
            if v.info and v.info.cd ~= 0 and v.info.cd ~= nil then
                if v.info.needSync == true then
                    if v.lastFrameIndex == nil then
                        v.lastFrameIndex = self.frameIndex
                    end
                    v.onCDUpdate((self.frameIndex - v.lastFrameIndex) / App.frameNum)
                    v.lastFrameIndex = self.frameIndex
                else
                    v.onCDUpdate(Time.deltaTime)
                end
            end
        end
    end

    if self.isAiming then
        -- self:RotateSelfAvatar()
        -- 帧模拟
        self:RotateSelfAvatar()
        self:SimulateTrajectory()
    else
        if self.ghostBall ~= nil then
            GameObject.Destroy(self.ghostBall)
            self.ghostBall = nil
        end
    end

end
function ButtonManager:UpdateFrameIndex(frameIndex)
    self.frameIndex = frameIndex
end
function ButtonManager:GetButton(idx)
    if self.skillButtons and self.skillButtons[idx] then
        return self.skillButtons[idx]
    end

    g_LogError("技能按钮未初始化:" .. idx)
    return nil
end
function ButtonManager:ChangeButton(idx, data)
    local btn = self:GetButton(idx)

    if btn then
        btn.changeButton(data)
    end

end
function ButtonManager:UpdateButton(idx, data)

    local btn = self:GetButton(idx)
    if btn then
        btn.updateButton(data)
    end

end
function ButtonManager:CoolDown(idx, cd)
    local btn = self:GetButton(idx)
    if btn then
        btn.coolDown(cd)
    end
end
function ButtonManager:Confirm(idx)
    local btn = self:GetButton(idx)
    if btn then
        btn.execute()
    end
end
function ButtonManager:Cancel(idx)
    local btn = self:GetButton(idx)
    if btn then
        btn.cancel()
    end
end
--- 设置是否显示技能CD剩余秒数
---@param show boolean true显示CD秒数(默认)，false隐藏CD秒数
function ButtonManager:SetShowSkillCDText(show)
    self.showSkillCDText = show
    g_Log("ButtonManager: 设置技能CD文字显示为 " .. tostring(show))
end

function ButtonManager:ShowSkillButtons(data, cb)
    if data then
        self:ReBuildButtons(data, cb)
    else
        self:SwitchButtons("1,1,1,1")
    end

end
function ButtonManager:SwitchButtons(info)
    if self.skillButtons == nil then
        g_LogError("技能按钮未初始化")
        return
    end

    self.buttonStatus = info

    local status = string.split(self.buttonStatus, ",")
    for k, v in pairs(status) do
        local btn = self.skillButtons[k]
        if btn then
            if v == "1" then
                self.skillButtons[k].go:SetActive(true)
            else
                self.skillButtons[k].go:SetActive(false)
            end
        end

    end
end
function ButtonManager:HideSkillButtons()
    self:SwitchButtons("0,0,0,0")

end
function ButtonManager:OnClick(cb)
    self.eventEmitter:on("Click", cb)
end
function ButtonManager:OnEvent(cb)
    self.eventEmitter:on("Click", cb)
end
function ButtonManager:Click(key, data)

    if data.event == self.ClickEvent.Execute and data.info.needSync == true then
        -- 需要同步
        self:SendCustomMessage(ExecuteSkill, {
            key = key,
            cd = data.info.cd
        })
    end

    self.eventEmitter:emit("Click", key, data)
end
function ButtonManager:OnEnergyChanged(v)
    self.Energy = v
    if self.skillButtons == nil then
        return
    end
    for k, v in pairs(self.skillButtons) do
        v.onEnergyChanged(self.Energy)
    end
end
function ButtonManager:Block(idx)
    local btn = self:GetButton(idx)
    if btn then
        btn.block()
    end
end
function ButtonManager:Unblock(idx)
    local btn = self:GetButton(idx)
    if btn then
        btn.unblock()
    end
end
function ButtonManager:ReBuildButtons(data, cb)

    if self.skillButtons ~= nil then
        for k, v in pairs(self.skillButtons) do
            GameObject.Destroy(v.go)
        end
    end
    self.skillButtons = {}

    -- 调整跳跃位置
    self.joystickService.joyPanel.jumpETCButton.anchorOffet = Vector2(78.52, 134.7)
    local jumpparent = self.joystickService.joyPanel.jumpETCButton.transform.parent

    local btn_idx = 0
    local positions = {
        [1] = Vector2(-230, 82),
        [2] = Vector2(-324, 185),
        [3] = Vector2(-293, 315),
        [4] = Vector2(-167, 370)
    }
    local assetPath = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/ui/skill/skillbutton.prefab"

    ResourceManager:LoadGameObjectWithExName(assetPath, function(asset)
        -- 技能按键列表
        for _, v in pairs(data) do

            local info = v -- 按钮信息
            btn_idx = btn_idx + 1
            local idx = btn_idx

            if info.key ~= nil then
                ---@type boolean
                local isShowAim = nil

                local isBlock = false
                local blockMask = nil
                local canUse = true
                local canActicve = true

                local isPopShow = false

                local btnImage = nil

                local btn = nil

                local cdT = nil
                local cool = nil
                local image = nil

                local popButtons = {}
                local isPopButtonEnter = false
                local whichPopButtonEnter = nil

                local upHandle = nil
                local downHandle = nil

                local needPop = false
                local HideAllPopButtons = function()
                    isPopShow = false
                    btnImage = info.sprite
                    isPopButtonEnter = false
                    whichPopButtonEnter = nil
                    -- 隐藏
                    for _, popbtn in pairs(popButtons) do
                        popbtn:SetActive(false)

                    end
                end
                local isSinglePop = false
                local poplist = {}

                local initPopButtons = function()
                    local _positions = {
                        [1] = Vector2(-161.4, -70.65),
                        [2] = Vector2(-167.2, 59.3),
                        [3] = Vector2(-93.71, 152.7)
                    }
                    popButtons = {}

                    if info.pop then
                        poplist = info.pop()
                    end
                    isPopShow = false
                    isSinglePop = true
                    if #poplist > 1 then
                        isSinglePop = false
                        local _idx = 0
                        for _, popButtonInfo in pairs(poplist) do
                            _idx = _idx + 1
                            local _id = _idx
                            local popbtn = btn.transform:Find("pop" .. _idx).gameObject
                            popbtn:SetActive(false)
                            local popbutton = btn:GetComponent(typeof(CS.UnityEngine.UI.Button))
                            -- 设置图标
                            local poprectTransform = popbtn.transform:GetComponent(typeof(CS.UnityEngine.RectTransform))
                            -- poprectTransform.sizeDelta = Vector2(50, 50)
                            if popButtonInfo.position then
                                poprectTransform.anchoredPosition = Vector2(popButtonInfo.position.x, popButtonInfo.position.y)
                            else
                                poprectTransform.anchoredPosition = _positions[_idx]
                            end
                            local popimage = popbtn:GetComponent(typeof(CS.UnityEngine.UI.Image))
                            popbtn.transform:Find("press/icon"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite =
                                popButtonInfo.sprite
                            popbtn.transform:Find("normal/icon"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite =
                                popButtonInfo.sprite

                            local press = popbtn.transform:Find("press").gameObject
                            local normal = popbtn.transform:Find("normal").gameObject
                            local _t =popbtn:GetComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
                            if _t then
                                GameObject.Destroy(_t);
                            end
                            local popbtnTrigger = popbtn:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
                            popbtnTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerEnter,
                                function(data)
                                    isPopButtonEnter = true
                                    whichPopButtonEnter = _id
                                    press:SetActive(true)
                                    normal:SetActive(false)
                                end)
                            popbtnTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerExit,
                                function(data)
                                    isPopButtonEnter = false
                                    press:SetActive(false)
                                    normal:SetActive(true)
                                end)
                            popbtnTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerClick,
                                function(data)
                                    isPopButtonEnter = true
                                    whichPopButtonEnter = _id
                                    if upHandle then
                                        upHandle()
                                    end
                                end)

                            table.insert(popButtons, popbtn)
                        end
                    end

                    btn.transform:Find("pop" .. 1).gameObject:SetActive(false)
                    btn.transform:Find("pop" .. 2).gameObject:SetActive(false)
                    btn.transform:Find("pop" .. 3).gameObject:SetActive(false)

                end

                local ShowAllPopButtons = function()
                    initPopButtons()

                    isPopShow = true
                    isPopButtonEnter = false

                    if info.popSprite then
                        btnImage = info.popSprite
                    end
                    -- 显示
                    for _, popbtn in pairs(popButtons) do
                        popbtn:SetActive(true)
                        local press = popbtn.transform:Find("press").gameObject
                        local normal = popbtn.transform:Find("normal").gameObject
                        press:SetActive(false)
                        normal:SetActive(true)

                    end
                end
                local skillButtonItem = {
                    aimCancel = false,
                    count = 0

                }

                -- 以下是能动态更新的属性，除此外的属性需要二次创建
                local updateButton = function()
                    skillButtonItem.info = info

                    local rectTransform = btn.transform:GetComponent(typeof(CS.UnityEngine.RectTransform))
                    isShowAim = info.aim
                    
                    if info.sprite then
                        btnImage.sprite = info.sprite
                    elseif info.spriteUrl then
                        self.httpService:LoadNetWorkTexture(info.spriteUrl, function(sprite)
                            btnImage.sprite = sprite
                        end)
                    end

                    if info.size then
                        rectTransform.sizeDelta = Vector2(info.size.x, info.size.y)
                    end
                    btn.gameObject:SetActive(true)

                    if info.hide then
                        btn.gameObject:SetActive(false)
                    end
                    skillButtonItem.aimCancel = false
                    skillButtonItem.onCountChanged(info.count)

                    skillButtonItem.onEnergyChanged(self.Energy)

                    btn.transform:Find("pop" .. 1).gameObject:SetActive(false)
                    btn.transform:Find("pop" .. 2).gameObject:SetActive(false)
                    btn.transform:Find("pop" .. 3).gameObject:SetActive(false)
                end
                local initButton = function()
                    if info.pop ~=nil then
                        needPop = true
                    end
                    skillButtonItem.info = info
                    local pos = positions[idx]
                    if info.position then
                        pos = info.position
                    end

                    btn = GameObject.Instantiate(asset, jumpparent)
                    if skillButtonItem.go then
                        GameObject.Destroy(skillButtonItem.go)
                    end
                    skillButtonItem.go = btn
                    -- 设置图标
                    local rectTransform = btn.transform:GetComponent(typeof(CS.UnityEngine.RectTransform))

                    cdT = btn.transform:Find("cdT"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
                    cool = btn.transform:Find("cd").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    image = btn:GetComponent(typeof(CS.UnityEngine.UI.Image))

                    blockMask = btn.transform:Find("blockMask").gameObject
                    blockMask.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).raycastTarget = false

                    rectTransform.anchoredPosition = Vector2(pos.x, pos.y)
                    btn.transform.localScale = Vector3.one * 1
                    btn:SetActive(true)
                    btnImage = btn:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    canUse = true
                    canActicve = true
                    cdT.gameObject:SetActive(false)
                    cool.fillAmount = 0;
                    image.color = Color(1, 1, 1, 1)

                    local trigger = btn:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
                    if info.aim == true or needPop then
                        trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerDown, function(data)
                            self.downScreenPostion = data.position
                            self.aimScreenPostion = data.position
                            self.draged = false
                            downHandle()
                        end)
                        trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerUp, function(data)
                            self.upScreenPostion = data.position
                            upHandle()
                        end)
                        trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.BeginDrag, function(data)
                            self.isDraging = true
                            self.canRotateSelfAvatar = true

                        end)
                        trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.EndDrag, function(data)
                            self.isDraging = false
                            self.canRotateSelfAvatar = false

                        end)
                        trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.Drag, function(data)
                            self.dragScreenPosition = data.position
                            self.aimScreenPostion = data.position
                            self.draged = true
                        end)
                        trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerClick, function(data)

                        end)
                    else
                        trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerClick, function(data)
                            upHandle()
                        end)
                    end
                    

                    -- update button
                    updateButton()

                    self:Click(info.key, {
                        event = self.ClickEvent.BuildFinish,
                        info = info
                    })

                end
                skillButtonItem.onCountChanged = function(count)
                    -- 有配置才相应
                    self:Click(info.key, {
                        event = self.ClickEvent.CountChanged,
                        info = info,
                        count = count
                    })
                    if info.count ~= nil and info.count ~= "" and info.count > 0 then
                        skillButtonItem.count = count
                        local textMesh = btn.transform:Find("count"):GetComponentInChildren(typeof(CS.TMPro
                                                                                                       .TextMeshProUGUI))

                        if count ~= nil and count ~= "" and count > 0 then
                            btn.transform:Find("count").gameObject:SetActive(true)

                            textMesh.text = count
                            if self.CountFontMt == nil then
                                local mat = CS.UnityEngine.Material(textMesh.fontSharedMaterial)
                                self.CountFontMt = mat
                                mat:SetFloat("_OutlineWidth", 0.379)
                                mat:SetColor("_OutlineColor", Color(0, 0, 0, 1))
                            end

                            textMesh.fontSharedMaterial = self.CountFontMt

                        else
                            btn.transform:Find("count").gameObject:SetActive(false)
                            btn.gameObject:SetActive(false)

                            self:Click(info.key, {
                                event = self.ClickEvent.CountNone,
                                info = info
                            })
                        end
                    else
                        btn.transform:Find("count").gameObject:SetActive(false)
                    end

                end
                skillButtonItem.block = function()
                    isBlock = true
                    blockMask:SetActive(true)
                end
                skillButtonItem.unblock = function()
                    isBlock = false
                    blockMask:SetActive(false)
                end
                skillButtonItem.onEnergyChanged = function(eg)
                    local energy = eg
                    if energy == nil then
                        energy = 0
                    end
                    if info.enable ~= false then
                        if info.cost == nil then
                            info.cost = 0
                        end

                        if energy < info.cost then
                            canActicve = false
                            image.color = Color(1, 1, 1, 0.5)
                        else
                            canActicve = true
                            if canUse then
                                image.color = Color(1, 1, 1, 1)
                            end
                        end
                    else
                        canActicve = false
                        image.color = Color(1, 1, 1, 0.5)
                    end
                end

                skillButtonItem.onCDUpdate = function(deltaTime)
                    if skillButtonItem.isCoolingDown == true then
                        skillButtonItem.isWaitingCD = false
                        if skillButtonItem.cdDuration <= 0 then
                            skillButtonItem.cdDuration = 0
                            skillButtonItem.isCoolingDown = false
                            self:Click(info.key, {
                                event = self.ClickEvent.OutCoolingDown,
                                info = info
                            })
                            return
                        end

                        if skillButtonItem.cdStarted ~= true then
                            skillButtonItem.cdStarted = true
                            -- 根据配置决定是否显示CD文字
                            if self.showSkillCDText == true then
                                cdT.gameObject:SetActive(true)
                            end
                            image.color = Color(1, 1, 1, 0.5)
                            canUse = false
                            skillButtonItem.cdDuration = skillButtonItem.info.cd
                        end

                        -- 根据配置决定是否更新CD文字内容
                        if self.showSkillCDText == true then
                            cdT.text = tostring(math.max(math.ceil(skillButtonItem.cdDuration), 0))
                        end

                        skillButtonItem.cdDuration = skillButtonItem.cdDuration - deltaTime
                        cool.fillAmount = skillButtonItem.cdDuration / skillButtonItem.info.cd
                    else

                        if skillButtonItem.info.cd ~= 0 and skillButtonItem.info.cd ~= nil then
                            skillButtonItem.cdDuration = skillButtonItem.info.cd
                        else
                            skillButtonItem.cdDuration = 0
                        end

                        if skillButtonItem.isWaitingCD == true then

                        else
                            if skillButtonItem.cdStarted == true then
                                skillButtonItem.cdStarted = false
                                canUse = true
                                cool.fillAmount = 0
                                -- 只在显示CD文字时才隐藏文字UI
                                if self.showSkillCDText == true then
                                    cdT.gameObject:SetActive(false)
                                end
                                if canActicve == true then
                                    image.color = Color(1, 1, 1, 1)
                                end
                            end
                        end

                    end

                end

                -- 如果自己的角色已经初始化，这里要初始化按钮的能量

                table.insert(self.skillButtons, skillButtonItem)

                initButton()

                -- 注册点击事件

                skillButtonItem.coolDown = function(_cd)
                    if _cd ~= nil then
                        info.cd = _cd
                        skillButtonItem.cdDuration = skillButtonItem.info.cd
                    end

                    if info.cd == 0 then
                        return
                    end


                   

                    skillButtonItem.isCoolingDown = true
                    skillButtonItem.cdStarted = false -- 重置CD状态标志
                    skillButtonItem.waitingCDStarted = false -- 重置等待CD状态标志
                    self:Click(info.key, {
                        event = self.ClickEvent.InCoolingDown,
                        info = info
                    })
                end
                skillButtonItem.cancel = function()

                    if skillButtonItem.isCoolingDown == true then
                        skillButtonItem.isCoolingDown = false
                        skillButtonItem.cdStarted = false -- 重置CD状态标志
                        self:Click(info.key, {
                            event = self.ClickEvent.OutCoolingDown,
                            info = info
                        })
                    end

                    if skillButtonItem.isWaitingCD == true then
                        skillButtonItem.isWaitingCD = false
                        skillButtonItem.waitingCDStarted = false -- 重置等待CD状态标志
                    end

                    if isShowAim then
                        if skillButtonItem.aimCancel == false then
                            skillButtonItem.aimCancel = true
                        end

                    end

                end
                skillButtonItem.changeButton = function(_info, cd)

                    if info.key == _info.key then
                        --相同的key
                        info = _info
                        updateButton()
                        return
                    end

                    skillButtonItem.cancel()
                    info = _info
                   
                    initButton()
                    -- 走一个切换冷却

                    -- 这里要判断一下这个技能的内置cd 是否大于当前cd，取一个较大的，做为冷却时间
                    -- coolDown(cd)

                end
                skillButtonItem.updateButton = function(_info)
                    info = _info
                    updateButton()
                end

                skillButtonItem.execute = function()
                    local event = {
                        event = self.ClickEvent.Execute,
                        info = info,
                        pop = nil
                    }
                    local canExec = true
                    if needPop then


                        if isSinglePop then
                            event.pop = poplist[1]
                            HideAllPopButtons()
                        else
                            if isPopButtonEnter == false then
                                local isInButton = self:IsPointInButton(self.upScreenPostion, btn)
                                if isInButton == false then
    
                                else
                                    -- keep
                                end
                                canExec = false
                            else
                                -- exec
                                event.pop = poplist[whichPopButtonEnter]
                                HideAllPopButtons()
                            end

                        end

                       
                    else

                    end

                    if canExec then
                        self:Click(info.key, event)
                        skillButtonItem.onCountChanged(skillButtonItem.count - 1)

                        if info.autoCD == false then
                            skillButtonItem.isWaitingCD = true
                            if skillButtonItem.waitingCDStarted ~= true then
                                skillButtonItem.waitingCDStarted = true
                                -- 根据配置决定是否显示CD文字
                                if self.showSkillCDText == true then
                                    cdT.gameObject:SetActive(true)
                                    cdT.text = ""
                                end
                                image.color = Color(1, 1, 1, 0.5)
                                canUse = false
                                cool.fillAmount = 1
                            end

                        else
                            skillButtonItem.coolDown()
                        end

                    end
                end

                downHandle = function()
                    self:Click(info.key, {
                        event = self.ClickEvent.PointerDown,
                        info = info
                    })
                    if isBlock then
                        self:Click(info.key, {
                            event = self.ClickEvent.Blocking,
                            info = info
                        })
                        return
                    end
                    if canUse == false then
                        self:Click(info.key, {
                            event = self.ClickEvent.CoolingDown,
                            info = info
                        })
                        return
                    end

                    if canActicve == false then
                        self:Click(info.key, {
                            event = self.ClickEvent.Cancel,
                            info = info
                        })
                        return
                    end

                    if isShowAim then
                        skillButtonItem.aimCancel = false
                        -- aim 瞄准模式
                        -- self:ShowAim(skillbutton.skill)
                        self:Click(info.key, {
                            event = self.ClickEvent.AimDown,
                            info = info
                        })

                        if info.aim_info then
                            self.aim_info = info.aim_info
                            self:ShowAimLine()
                        end
                    end
                    if needPop then
                        -- 弹出按钮
                        if isPopShow then
                            HideAllPopButtons()
                        else
                            ShowAllPopButtons()
                        end
                    end

                end

                upHandle = function()
                    self:Click(info.key, {
                        event = self.ClickEvent.PointerUp,
                        info = info
                    })
                    if isBlock then
                        self:Click(info.key, {
                            event = self.ClickEvent.Blocking,
                            info = info
                        })
                        return
                    end
                    -- 冷却中
                    if canUse == false then
                        self:Click(info.key, {
                            event = self.ClickEvent.CoolingDown,
                            info = info
                        })
                        return
                    end

                    if canActicve == false then
                        self:Click(info.key, {
                            event = self.ClickEvent.Cancel,
                            info = info
                        })
                        return
                    end

                    if isShowAim then
                        if skillButtonItem.aimCancel == true then
                            -- 取消技能
                            skillButtonItem.aimCancel = false
                            return
                        end

                        if info.aim_info then

                            if self.aimCancelActive == true then
                                self:HideAimLine()
                                return
                            end
                            self:HideAimLine()
                        end
                    end

                    self:Click(info.key, {
                        event = self.ClickEvent.PreExecute,
                        info = info
                    })

                    if info.autoExecute == false then
                        return
                    end

                    skillButtonItem.execute()

                end

                if idx == #positions then
                    -- 最后一个，设置info
                    self.buttonStatus = "1,1,1,1"
                end
            else
                -- 空位跳过
            end

        end

        if cb then
            cb()
        end
    end)

end
function ButtonManager:IsPointInButton(point, button)
    local isInside = CS.UnityEngine.RectTransformUtility.RectangleContainsScreenPoint(button:GetComponent(typeof(
        CS.UnityEngine.RectTransform)), point)
    return isInside

end
function ButtonManager:CalculateVelocity(velocity, increment)
    velocity = velocity + Physics.gravity * increment;
    return velocity;
end
function ButtonManager:SimulateTrajectory()

    local avatarTrasform = self.avatarService.selfAvatar.character.transform
    local start = avatarTrasform.position
    local bullet = self.aim_info

    start = start + avatarTrasform.forward * bullet.offset.z + avatarTrasform.up * bullet.offset.y +
                avatarTrasform.right * bullet.offset.x
    local velocity =
        avatarTrasform.forward * bullet.speed.z + avatarTrasform.up * bullet.speed.y + avatarTrasform.right *
            bullet.speed.x;
    local maxPoints = 100
    local array = {}
    local position = start

    -- TODO 根据子弹碰撞规则过滤

    for i = 1, maxPoints, 1 do
        if i ~= 1 then
            velocity = self:CalculateVelocity(velocity, Time.fixedDeltaTime);
            position = position + velocity * Time.fixedDeltaTime;
        end

        local colliders = Physics.OverlapSphere(position, bullet.size[1] * 0.5);
        local isValidCollision = false
        if colliders.Length > 0 then
            for i = 0, colliders.Length - 1, 1 do
                local collider = colliders[i]

                if self.aim_info then
                    if self.aim_info.is_collider ~= nil then
                        local isValid = self.aim_info.is_collider(collider)
                        if isValid == true then
                            isValidCollision = true
                        end
                    end
                end

            end

            if isValidCollision == true then
                table.insert(array, position)
                break
            end
        end

        table.insert(array, position)

    end
    self.aimBoom.transform.position = array[#array]
    self.aimLinerenderer.positionCount = #array
    self.aimLinerenderer:SetPositions(array)

end
function ButtonManager:ShowAimLine()

    local _showAim = function()

        if self.enabled == false then
            return
        end

        self.isAiming = true
        self.aimPanel:SetActive(true)

        if self.isCancelUIShow then
            self.aimCancel:SetActive(true)
        end

        self.aimBoom:SetActive(true)
        self.aimLine:SetActive(true)
        self.aimJoy:SetActive(true)

        self.avatarService.selfAvatar.LockRotate = true

        local pos = self:GetScreenPosition()
        self.aimJoy.transform.position = pos
        self.aimPanel.transform.position = Vector3(pos.x, pos.y + 10, pos.z)
        self.aimCenter = Vector3(pos.x, pos.y - 30, pos.z)

        -- TODO 设置球尺寸
        self.aimBoom.transform.localScale = Vector3.one * self.aim_info.aoe_range

    end
    if self.aimPanelPrepared == true then
        _showAim()
        return
    end
    if self.aimPanelPreparing == true then
        return
    end
    self.aimPanelPreparing = true

    self.aimPanelPrepared = false
    self.aimShowBlock = false

    local assetPath = "modules/" .. RESOURCE_LOC .. "/assets/gameplay/Prefabs/skillAim.prefab"
    ResourceManager:LoadGameObjectWithExName(assetPath, function(go)

        local root = GameObject.Instantiate(go)

        self.aimPanel = root.transform:Find("Canvas/aimPanel").gameObject
        self.aimPanel:SetActive(false)
        local rect = self.aimPanel:GetComponent(typeof(CS.UnityEngine.RectTransform))
        local panelImg = self.aimPanel:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.aimPanel.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        rect.sizeDelta = Vector2(150, 150)
        rect.localScale = Vector3.one
        panelImg.color = Color(1, 1, 1, 1)

        self.aimCancel = root.transform:Find("Canvas/aimCancel").gameObject
        self.aimCancel:SetActive(false)
        local rect = self.aimCancel:GetComponent(typeof(CS.UnityEngine.RectTransform))
        local cancelImage = self.aimCancel:GetComponent(typeof(CS.UnityEngine.UI.Image))

        self.aimCancel.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        -- rect.anchoredPosition = Vector2(10, 10)
        rect.sizeDelta = Vector2(100, 100)
        rect.localScale = Vector3.one

        self.aimJoy = root.transform:Find("Canvas/aimJoy").gameObject
        self.aimJoy:SetActive(false)
        self.aimJoy.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        self.aimJoy:GetComponent(typeof(CS.UnityEngine.UI.Image)).raycastTarget = false

        self.aimCancelTrigger = self.aimCancel:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
        self.aimCancelTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerEnter, function(data)
            panelImg.color = Color(1, 0, 0, 1)
            cancelImage.color = Color(1, 0, 0, 1)
            self.aimCancelActive = true
        end)
        self.aimCancelTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerExit, function(data)
            panelImg.color = Color(1, 1, 1, 1)
            cancelImage.color = Color(1, 1, 1, 1)
            self.aimCancelActive = false
        end)

        self.aimCancelActive = false

        self.aimBoom = root.transform:Find("dingweiqiu").gameObject
        self.aimBoom.transform:SetParent(nil)
        self.aimBoom.transform.localScale = Vector3.one
        self.aimBoom:SetActive(false)

        local collider = self.aimBoom:GetComponentsInChildren(typeof(CS.UnityEngine.Collider))
        for i = 0, collider.Length - 1, 1 do
            collider[i].enabled = false
        end

        self.aimLine = root.transform:Find("dingweixian").gameObject
        self.aimLinerenderer = self.aimLine:GetComponent(typeof(CS.UnityEngine.LineRenderer))
        self.aimLine.transform:SetParent(nil)
        self.aimLine.transform.localScale = Vector3.one
        self.aimLine:SetActive(false)
        self.aimLinerenderer.useWorldSpace = true
        self.aimLinerenderer.positionCount = 0

        GameObject.Destroy(root)
        -- 创建模拟
        self.aimPanelPrepared = true
        if self.aimShowBlock == false then
            _showAim()
        end

    end)

end
function ButtonManager:HideAimLine()
    if self.aimPanelPrepared == true then
        self.aimPanel:SetActive(false)
        self.aimCancel:SetActive(false)
        self.aimCancelActive = false

        self.aimPanel:GetComponent(typeof(CS.UnityEngine.UI.Image)).color = Color(1, 1, 1, 1)
        self.aimCancel:GetComponent(typeof(CS.UnityEngine.UI.Image)).color = Color(1, 1, 1, 1)

        self.aimBoom:SetActive(false)
        self.aimLine:SetActive(false)
        self.aimJoy:SetActive(false)
        self.aimLinerenderer.positionCount = 0
        self.avatarService.selfAvatar.LockRotate = false

    else
        -- 没有准备好，阻止加载回调的自动显示
        self.aimShowBlock = true
    end
    self.isAiming = false
end
function ButtonManager:GetScreenPosition()
    local pos = self.aimScreenPostion
    return Vector3(pos.x, pos.y, 0);
end
function ButtonManager:RotateSelfAvatar()
    if self.canRotateSelfAvatar ~= true then
        return
    end
    self.aimJoy.transform.position = self:GetScreenPosition()
    local start = self.aimCenter
    local endPos = self.aimJoy.transform.position
    local direction = endPos - start;

    local angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg
    local r = self.avatarService.selfAvatar.LookRotation.transform.eulerAngles.y
    angle = r - angle + 90
    self.avatarService.selfAvatar.BodyTrans.rotation = Quaternion.Euler(0, angle, 0)
end

local ButtonManagerInstance = ButtonManager:new()
return ButtonManagerInstance
