---@class Utils
local Utils = {
    ReadConfigFile = function(file, type)
        local fullPath = "";

        if App.IsStudioClass then
            if App.IsStudioClient then
                fullPath =
                    CS.Tal.EngineExtends.Scripts.StudioMobileBridge.GetFullStudioModPath() .. '/' .. App.ModName ..
                        "/config/" .. file
            else
                fullPath = CS.Tal.CourseEnv.APIBridge.APIManager.SLocalRoot .. '/' .. App.ModName .. "/config/" .. file;
            end
        end
        if type == "byte" then
            -- TODO 二进制读取
            return nil
        else
            local str = CS.System.IO.File.ReadAllText(fullPath);

            return str
        end
    end,
    RequireLua = function(mod, name)
        local rootPath = ""
        local fullPath = "";

        local schemaFile = ""

        local useFramework = false

        if App.IsStudioClient then
            schemaFile = CS.Tal.EngineExtends.Scripts.StudioMobileBridge.GetFullStudioModPath() .. '/' ..
                             App.ModName .. "/config/code/schema.lua"
        else
            schemaFile = CS.Tal.CourseEnv.APIBridge.APIManager.SLocalRoot .. '/' .. App.ModName ..
                             "/config/code/schema.lua"
        end

        -- 优先使用项目配置文件，检查schema文件，如果不存在则使用framework中的配置文件

        local schema = CS.System.IO.File.Exists(schemaFile)
        if schema == false then
            useFramework = true
        end

        if App.IsStudioClient then
            if useFramework then
                rootPath = CS.Tal.CourseEnv.APIBridge.APIManager.SLocalRoot .. '/framework/gameplay'
            else
                rootPath = CS.Tal.EngineExtends.Scripts.StudioMobileBridge.GetFullStudioModPath() .. '/' ..
                               App.ModName
            end

        else
            if useFramework then
                rootPath = CS.Tal.CourseEnv.APIBridge.APIManager.SLocalRoot .. '/framework/gameplay'
            else
                rootPath = CS.Tal.CourseEnv.APIBridge.APIManager.SLocalRoot .. '/' .. App.ModName
            end
        end

        fullPath = rootPath .. "/config/" .. "data" .. "/" .. mod .. "_" .. name .. ".lua"

        local isfileexit = CS.System.IO.File.Exists(fullPath)
        if isfileexit == false then
            g_LogError("缺少gameplay配置文件:" .. fullPath)
            return {}
        end

        local content = CS.System.IO.File.ReadAllText(fullPath);
        local code, err = load(content)
        if code and type(code) == "function" then
            local ok, func = pcall(code)
            if ok then
                if type(func) == "function" then
                    return func()
                else
                    return func
                end
            else
                print("Execution error:", func)
            end
        else
            print("Compilation error:", err)
        end

    end,
    -- 事件
    EventEmitter = function()
        local emitter = {}
        emitter._events = {}

        function emitter:on(eventName, listener)
            if self._events[eventName] == nil then
                self._events[eventName] = {listener}
            else
                table.insert(self._events[eventName], listener)
            end
        end

        function emitter:emit(eventName, ...)
            local res = {}

            local listeners = self._events[eventName]
            if listeners == nil then
                return res
            end
            for _, listener in ipairs(listeners) do
                local _res = listener(...)
                table.insert(res, _res)
            end
            return res
        end

        function emitter:once(eventName, listener)
            self:on(eventName, function(...)
                listener(...)
                self:off(eventName, listener)
            end)
        end

        function emitter:off(eventName, listenerToRemove)
            local listeners = self._events[eventName]
            if listeners == nil then
                return
            end
            for i, listener in ipairs(listeners) do
                if listener == listenerToRemove then
                    table.remove(listeners, i)
                    break
                end
            end
        end

        return emitter
    end,
    GetAvatarWithGameObject = function(go)
        local avatarService = CourseEnv.ServicesManager:GetAvatarService()
        local avatars = avatarService:GetAllAvatar()
        for k, v in pairs(avatars) do
            if v.VisElement.gameObject == go then
                return v
            end

            if go.transform:IsChildOf(v.VisElement.transform) then
                return v
            end
        end
        return nil
    end,
    RemoveDuplicates =function(array)
        local seen = {}
        local result = {}
    
        for _, value in ipairs(array) do
            if not seen[value] then
                table.insert(result, value)
                seen[value] = true
            end
        end
    
        return result
    end
}
return Utils

