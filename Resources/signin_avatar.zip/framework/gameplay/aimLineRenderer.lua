Color = CS.UnityEngine.Color
SceneManagement = CS.UnityEngine.SceneManagement
SceneManager = SceneManagement.SceneManager
LocalPhysicsMode = SceneManagement.LocalPhysicsMode
Physics = CS.UnityEngine.Physics
Mathf = CS.UnityEngine.Mathf
Input = CS.UnityEngine.Input
local extends = require("gameplay/extends")
local class = require("middleclass")
local utils = require("gameplay/utils")
---@class AimLineRenderer : ExtendedClass
local AimLineRenderer = class("AimLineRenderer")
function AimLineRenderer:initialize(btn, bullet, IsBulletCollider)
    extends.Class(self)
    self.button = btn
    self.curBullet = bullet
    self.IsBulletCollider = IsBulletCollider
    self.eventEmitter = utils.EventEmitter()
    self.isCancelUIShow = true
    self.enabled = true
    local downHandle = function()
        
    end

    local upHandle = function()
        if self.aimCancelActive == true or not self.draged then
            self:Cancel()
            return
        else
            self:HideAim()
        end

        self.eventEmitter:emit("OnAimFire", self.curBullet, self.rateY,self.firePoints)
    end

    local trigger = btn:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
    trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerDown, function(data)
        if self.enabled == false then
            return
        end

        self.eventEmitter:emit("OnStartAimFire")
        self.aimScreenPostion = data.position
        self.draged = false
        downHandle()
    end)

    trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerUp, function(data)
        if self.enabled == false then
            return
        end
        upHandle()
    end)
    trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.BeginDrag, function(data)
        if self.enabled == false then
            return
        end
        self.draged = true
        self:ShowAim()
        self.canRotateSelfAvatar = true
    end)
    trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.EndDrag, function(data)
        if self.enabled == false then
            return
        end
        self.canRotateSelfAvatar = false
    end)
    trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.Drag, function(data)
        if self.enabled == false then
            return
        end
        self.aimScreenPostion = data.position
        self.draged = true
    end)

    self.btnTrigger = trigger
end
function AimLineRenderer:Release(notDestroy)
    self.enabled = false
    self.canRotateSelfAvatar = false
    self.isAiming = false
    self.avatarService.selfAvatar.LockRotate = false

    if notDestroy ~= true then
        if self.goMap then
            for k, v in pairs(self.goMap) do
                GameObject.Destroy(v)
            end
        end
    end
end

function AimLineRenderer:OnExit()
    if self.btnTrigger then
        self.btnTrigger:ClearAll()
    end
    if self.aimCancelTrigger then
        self.aimCancelTrigger:ClearAll()
    end
end

function AimLineRenderer:SimulateTrajectory()

    local avatarTrasform = self.avatarService.selfAvatar.character.transform
    local start = avatarTrasform.position
    local degree = 0
    local rate = 1
    ---@type Bullet
    local bullet = self.curBullet
    if self.rateY then
        if self.rateY > 0 then
            degree = bullet.max_degree / 180 * self.rateY
            rate = math.tan(degree)
        else
            degree = bullet.min_degree / 180 * self.rateY
            rate = -math.tan(degree)
        end
    end

    start = start + avatarTrasform.forward * bullet.offset.z + avatarTrasform.up * bullet.offset.y +
                avatarTrasform.right * bullet.offset.x

    local velocity = avatarTrasform.forward * bullet.speed.z + avatarTrasform.up * bullet.speed.y * rate +
                         avatarTrasform.right * bullet.speed.x;
    local maxPoints = 100
    local array = {}
    local position = start

    -- TODO 根据子弹碰撞规则过滤

    for i = 1, maxPoints, 1 do
        if i ~= 1 then
            velocity = self:CalculateVelocity(velocity, 1 / 30);
            position = position + velocity * 1 / 30;
        end

        local colliders = Physics.OverlapSphere(position, bullet.size[1] * 0.5, -1, CS.UnityEngine.QueryTriggerInteraction.Ignore);
        local isValidCollision = false
        if colliders.Length > 0 then
            for i = 0, colliders.Length - 1, 1 do
                local collider = colliders[i]
                local isValid = self.IsBulletCollider(collider)
                if isValid == true then
                    isValidCollision = true
                end
            end

            if isValidCollision == true then
                table.insert(array, position)
                break
            end
        end

        table.insert(array, position)

    end
    self.aimBoom.transform.position = array[#array]
    self.aimLinerenderer.positionCount = #array
    self.aimLinerenderer:SetPositions(array)
    self.firePoints = array
end
function AimLineRenderer:ShowCancelButton()
    self.isCancelUIShow = true
end
function AimLineRenderer:HideCancelButton()
    self.isCancelUIShow = false
end
function AimLineRenderer:ShowAim()

    local _showAim = function()

        if self.enabled == false then
            return
        end

        

        self.isAiming = true
        self.aimPanel:SetActive(true)

        if self.isCancelUIShow then
            self.aimCancel:SetActive(true)
        end

        self.aimBoom:SetActive(true)
        self.aimLine:SetActive(true)
        self.aimJoy:SetActive(true)

        self.avatarService.selfAvatar.LockRotate = true

        local pos = self:GetScreenPosition()
        self.aimJoy.transform.position = pos
        self.aimPanel.transform.position = Vector3(pos.x, pos.y + 10, pos.z)
        self.aimCenter = Vector3(pos.x, pos.y - 30, pos.z)

        -- TODO 设置球尺寸
        self.aimBoom.transform.localScale = Vector3.one * self.curBullet.aoe_range

        self.eventEmitter:emit("OnAimShow", self.curBullet)
    end
    if self.aimPanelPrepared == true then
        _showAim()
        return
    end
    if self.aimPanelPreparing == true then
        return
    end
    self.aimPanelPreparing = true

    self.aimPanelPrepared = false
    self.aimShowBlock = false

    local assetPath = "modules/" .. RESOURCE_LOC .. "/assets/gameplay/Prefabs/skillAim.prefab"
    ResourceManager:LoadGameObjectWithExName(assetPath, function(go)

        local root = GameObject.Instantiate(go)
        self.goMap = {}
        self.aimPanel = root.transform:Find("Canvas/aimPanel").gameObject
        self.aimPanel:SetActive(false)
        local rect = self.aimPanel:GetComponent(typeof(CS.UnityEngine.RectTransform))
        local panelImg = self.aimPanel:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.aimPanel.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        table.insert(self.goMap, self.aimPanel)
        rect.sizeDelta = Vector2(150, 150)
        rect.localScale = Vector3.one
        panelImg.color = Color(1, 1, 1, 1)

        self.aimCancel = root.transform:Find("Canvas/aimCancel").gameObject
        self.aimCancel:SetActive(false)
        local rect = self.aimCancel:GetComponent(typeof(CS.UnityEngine.RectTransform))
        local cancelImage = self.aimCancel:GetComponent(typeof(CS.UnityEngine.UI.Image))

        self.aimCancel.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        table.insert(self.goMap, self.aimCancel)
        -- rect.anchoredPosition = Vector2(10, 10)
        rect.sizeDelta = Vector2(100, 100)
        rect.localScale = Vector3.one

        self.aimJoy = root.transform:Find("Canvas/aimJoy").gameObject
        self.aimJoy:SetActive(false)
        self.aimJoy.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        table.insert(self.goMap, self.aimJoy)
        self.aimJoy:GetComponent(typeof(CS.UnityEngine.UI.Image)).raycastTarget = false

        self.aimCancelTrigger = self.aimCancel:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
        self.aimCancelTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerEnter, function(data)
            panelImg.color = Color(1, 0, 0, 1)
            cancelImage.color = Color(1, 0, 0, 1)
            self.aimCancelActive = true
        end)
        self.aimCancelTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerExit, function(data)
            panelImg.color = Color(1, 1, 1, 1)
            cancelImage.color = Color(1, 1, 1, 1)
            self.aimCancelActive = false
        end)

        self.aimCancelActive = false

        self.aimBoom = root.transform:Find("dingweiqiu").gameObject
        self.aimBoom.transform:SetParent(nil)
        table.insert(self.goMap, self.aimBoom)

        self.aimBoom.transform.localScale = Vector3.one
        self.aimBoom:SetActive(false)

        local collider = self.aimBoom:GetComponentsInChildren(typeof(CS.UnityEngine.Collider))
        for i = 0, collider.Length - 1, 1 do
            collider[i].enabled = false
        end

        self.aimLine = root.transform:Find("dingweixian").gameObject
        self.aimLinerenderer = self.aimLine:GetComponent(typeof(CS.UnityEngine.LineRenderer))
        self.aimLine.transform:SetParent(nil)
        table.insert(self.goMap, self.aimLine)
        self.aimLine.transform.localScale = Vector3.one
        self.aimLine:SetActive(false)
        self.aimLinerenderer.useWorldSpace = true
        self.aimLinerenderer.positionCount = 0

        GameObject.Destroy(root)
        -- 创建模拟
        self.aimPanelPrepared = true
        if self.aimShowBlock == false then
            _showAim()
        end

    end)

end
function AimLineRenderer:Cancel()
    self:HideAim()
    -- 取消技能
    self.eventEmitter:emit("OnAimCancel", self.curBullet)
end
function AimLineRenderer:HideAim()
    if self.aimPanelPrepared == true then
        self.aimPanel:SetActive(false)
        self.aimCancel:SetActive(false)
        self.aimCancelActive = false

        self.aimPanel:GetComponent(typeof(CS.UnityEngine.UI.Image)).color = Color(1, 1, 1, 1)
        self.aimCancel:GetComponent(typeof(CS.UnityEngine.UI.Image)).color = Color(1, 1, 1, 1)

        self.aimBoom:SetActive(false)
        self.aimLine:SetActive(false)
        self.aimJoy:SetActive(false)
        self.aimLinerenderer.positionCount = 0
        self.avatarService.selfAvatar.LockRotate = false

    else
        -- 没有准备好，阻止加载回调的自动显示
        self.aimShowBlock = true
    end
    self.isAiming = false
    self.eventEmitter:emit("OnAimHide", self.curBullet)
end

function AimLineRenderer:Tick()

    if self.isAiming then
        self:RotateSelfAvatar()
        -- 帧模拟
        self:SimulateTrajectory()
    else
        if self.ghostBall ~= nil then
            GameObject.Destroy(self.ghostBall)
            self.ghostBall = nil
        end
    end
end
function AimLineRenderer:CalculateVelocity(velocity, increment)
    local gravityY = -15
    if self.curBullet and self.curBullet.gravity ~= nil then
        local g = tonumber(self.curBullet.gravity)
        if g ~= nil then
            gravityY = g
        end
    end
    local gravity = Vector3(0, gravityY, 0)
    velocity = velocity + gravity * increment;
    return velocity;
end
function AimLineRenderer:RotateSelfAvatar()
    if self.canRotateSelfAvatar ~= true then
        return
    end
    self.aimJoy.transform.position = self:GetScreenPosition()
    local start = self.aimCenter
    local endPos = self.aimJoy.transform.position
    local direction = endPos - start;
    self.rateY = direction.y / (750 / 5)
    self.rateY = math.min(self.rateY, 1)
    self.rateY = math.max(self.rateY, -1)

    self.rateX = direction.x / (1624 / 5)

    local angle = 180 * self.rateX
    local r = self.avatarService.selfAvatar.LookRotation.transform.eulerAngles.y
    angle = r + angle
    self.avatarService.selfAvatar.BodyTrans.rotation = Quaternion.Euler(0, angle, 0)
    self.eventEmitter:emit("OnAim", self.rateY)
end
function AimLineRenderer:GetScreenPosition()
    local pos = self.aimScreenPostion
    return Vector3(pos.x, pos.y, 0);
end

return AimLineRenderer
