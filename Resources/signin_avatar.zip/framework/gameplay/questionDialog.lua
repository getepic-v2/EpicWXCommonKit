---
---  Author: 【王德】
---  AuthorID: 【102030】
---  CreateTime: 【2024-4-8 10:04:24】
--- 【FSync】
--- 【底部答题面板】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class questionDialog : WorldBaseElement
local FsyncElement = class("questionDialog", WBElement)
local TAG = "底部答题面板"
local minWidth = 568
local sidesGap = 40
local styleIds = {
    sentence = 51,
    readBook = 52
}
---@param worldElement CS.Tal.framesync.WorldElement
function FsyncElement:initialize(worldElement)
    FsyncElement.super.initialize(self, worldElement)

end
function FsyncElement:setVisElement(parent, VisElement)
    self.parent = parent
    self.VisElement = VisElement
    -- 订阅KEY消息
    self.passScore = 60
    if not (App.IsStudioClient) then
        self.pluginJson = App.Info.plugins
        if self.pluginJson ~= nil and type(self.pluginJson) == "string" then
            -- log("开始动态资源相关配置")
            self:InitPluginInfo()
        end
    end

    local appVersion = App.Info.appVersionNumber
    if App.IsStudioClient then
        appVersion = 10809
    end
    if appVersion then
        if tonumber(appVersion) < 10810 then
            self.lowAppVersion = true
        end
    end
    self.eventId = "BottomAnswerPanel"
    self.answerIndex = 0
    self.jewel = 0
    self:InitService()
    self:InitView()

    

    -- if App.IsStudioClient then
    --     self:SendCustomMessage("activateRoom", { question_type = 1 })
    -- end
    -- self.commonService:DispatchAfter(5, function()
    --     self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", {
    --         status = 1,
    --         awardCount = 1,
    --         showAwardType = 2,
    --         callBack = function(score, isFinal, isNoSpeaking, isPass)
    --             g_Log(TAG, "score", score, isFinal, isNoSpeaking, isPass)
    --         end
    --     })
    -- end)

    -- 再来一局，学识改完0
    self.observerService:Watch("reStartGame", function()
        self.jewel = 0
        self.jewelCountTmp.text = tostring(self.jewel)
    end)
end
function FsyncElement:InitPluginInfo()
    local list = self.jsonService:decode(self.pluginJson)
    for _, v in pairs(list) do
        if v.pluginName == "ABC动态资源配置" then
            xpcall(function()
                if v.pluginVal.abc_evaluation_pass_score then
                    self.passScore = tonumber(v.pluginVal.abc_evaluation_pass_score)
                end
            end, function(err)

            end)
        end
    end
end

function FsyncElement:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()

    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

function FsyncElement:InitView()



    self.observerService:Watch("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", function(key, value)
        local data = value[0]
        if not self.isLoaded then
            --没加载完成需要暂存一下
            self.history = data
        end
    end)



    self.root = self.VisElement.gameObject
    self.rootTrans = self.root.transform

    local prefabPath = "modules/" .. RESOURCE_LOC .. "/assets/questionDialog/assets/Prefabs/Canvas.prefab"

    ResourceManager:LoadGameObjectWithExName(prefabPath, function(go)
        self.rootView = GameObject.Instantiate(go).transform
        self.rootView:SetParent(self.rootTrans)
        self.rootView.localPosition = Vector3.zero
        self.rootView.localScale = Vector3.one
        self.rootView.localRotation = Quaternion.identity

        self.panel = self.rootView.transform:Find("Canvas")
        self.sound = self.panel:FindChildWithName("Sound")
        ---@type CS.UnityEngine.UI.Button
        self.soundBtn = self.sound:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.soundBtn.enabled = false

        self.contentEn = self.panel:FindChildWithName("Content_en")
        self.contentEnRect = self.contentEn:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.contentEnRect.anchoredPosition = Vector2(0, 47)
        self.contentEnTmp = self.contentEn:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.preContent = self.contentEn:FindChildWithName("pre_content")
        self.preContentTmp = self.preContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.preContentTmp.isRightToLeftText = true
        self.preContentRect = self.preContent:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.preContentRect.anchoredPosition = Vector2(-1, -5)
        self.lastContent = self.contentEn:FindChildWithName("last_content")
        self.lastContentTmp = self.lastContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.lastContentRect = self.lastContent:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.lastContentRect.anchoredPosition = Vector2(1, -5)

        self.scrollViewCh = self.panel:FindChildWithName("ScrollView_ch")
        ---@type CS.UnityEngine.UI.ScrollRect
        self.scrollView = self.scrollViewCh:GetComponent(typeof(CS.UnityEngine.UI.ScrollRect))
        self.contentCh = self.panel:FindChildWithName("Content_ch")
        self.contentChTmp = self.contentCh:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        ---@type CS.UnityEngine.RectTransform
        self.contentChRect = self.contentCh:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.waitText = self.panel:FindChildWithName("Wait")
        self.waitTmp = self.waitText:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

        self.confirm = self.panel:FindChildWithName("Confirm")
        self.confirm.gameObject:SetActive(false)
        ---@type CS.UnityEngine.UI.Button
        self.confirmBtn = self.confirm:GetComponent(typeof(CS.UnityEngine.UI.Button))

        self.contentBg = self.panel:FindChildWithName("ContentBg")
        self.contentBgRect = self.contentBg:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.readBookBg = self.panel:FindChildWithName("ReadBookBg")
        self.zuanshi = self.readBookBg:FindChildWithName("zuanshi")
        self.zuanshiAnim = self.zuanshi:GetComponent(typeof(CS.UnityEngine.Animator))
        self.jewelCount = self.zuanshi:FindChildWithName("Text_1")
        self.jewelCountTmp = self.jewelCount:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.sentenceBg = self.panel:FindChildWithName("SentenceBg")

        self.effect = self.panel:FindChildWithName("Effect").gameObject

        self.effect:SetActive(false)

        self.scoreRoot = self.panel:FindChildWithName("huodefenshu_xiao")
        ---@type CS.UnityEngine.RectTransform
        self.scoreRootRect = self.scoreRoot:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.scoreRootRect.anchoredPosition = Vector2(0, 2)
        self.scoreRoot.gameObject:SetActive(true)
        self.greatRoot = self.scoreRoot:Find("defen/Great")
        self.greatRootRect = self.greatRoot:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.greatLevel = self.greatRoot:Find("GREAT/GREAT")
        self.greatLevelImage = self.greatLevel:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.greatLevelRect = self.greatLevel:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.greatScoreHun = self.greatRoot:FindChildWithName("bai")
        self.greatScoreHunImage = self.greatScoreHun:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.greatScoreTen = self.greatRoot:FindChildWithName("shi")
        self.greatScoreTenImage = self.greatScoreTen:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.greatScoreOne = self.greatRoot:FindChildWithName("ge")
        self.greatScoreOneImage = self.greatScoreOne:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.awardBg = self.greatRoot:FindChildWithName("AwardBg")

        self.fightingRoot = self.scoreRoot:Find("defen/Fighting")
        self.fightingLevel = self.fightingRoot:Find("Fighting/Fighting")
        self.fightingLevelImage = self.fightingLevel:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.fightingScoreTen = self.fightingRoot:FindChildWithName("shi_2")
        self.fightingScoreTenImage = self.fightingScoreTen:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.fightingScoreOne = self.fightingRoot:FindChildWithName("ge_2")
        self.fightingScoreOneImage = self.fightingScoreOne:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.fightingContent = self.fightingRoot:FindChildWithName("fightingContent")
        self.fightingContentTmp = self.fightingContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.testPass = self.panel:FindChildWithName("pass")
        self.testPassBtn = self.testPass:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.testNoPass = self.panel:FindChildWithName("noPass")
        self.testNoPassBtn = self.testNoPass:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:StartCoroutine(function()
            self.commonService:Yield(self.commonService:WaitUntil(function()
                return self.recoverComplete
            end))
            self.observerService:Fire("Bottom_Answer_Panel_Size", {
                height = self.contentBgRect.sizeDelta.y + 40 + 12
            })
        end)



        self:InitListener()

        self:InitConfig()



        

        self.panel.gameObject:SetActive()

        self.isLoaded = true

        if self.history then
            self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", self.history)
            self.history = nil
        end

    end)

end

function FsyncElement:InitConfig()
    self.audioTip = self.panel:Find("Configs/麦克风出现").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
    self.leadTip = self.panel:Find("Configs/大声跟我读").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
    self.greatClip = self.panel:Find("Configs/goodjob").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
    self.niceTryClip = self.panel:Find("Configs/nice").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
    self.yellowNumImage = {}
    self.blueNumImage = {}
    for i = 0, 9 do
        ---@type CS.UnityEngine.Sprite
        self.yellowNumImage[i] = self.panel:Find("Configs/y/"..i).gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
        ---@type CS.UnityEngine.Sprite
        self.blueNumImage[i] = self.panel:Find("Configs/b/"..i).gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    end
    self.resultImage = {}
    for i = 1, 3 do
        ---@type CS.UnityEngine.Sprite
        self.resultImage[i] = self.panel:Find("Configs/result_"..i).gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    end
end

function FsyncElement:InitListener()
    -- self.commonService:AddEventListener(self.soundBtn, "onClick", function()

    -- end)
    self.commonService:AddEventListener(self.confirmBtn, "onClick", function()
        self.confirm.gameObject:SetActive(false)
        self.effect:SetActive(false)
        if App.IsStudioClient then
            self.testPass.gameObject:SetActive(false)
            self.testNoPass.gameObject:SetActive(false)
        end
        self:stopAnswer()
    end)

    if App.IsStudioClient then
        self.commonService:AddEventListener(self.testPassBtn, "onClick", function()
            self.observerService:Fire("speech_assessment_test", {
                pass = true
            })
            self.testPass.gameObject:SetActive(false)
            self.testNoPass.gameObject:SetActive(false)
            -- self:cancelAnswer()
            -- self.effect:SetActive(false)
            -- self.confirm.gameObject:SetActive(false)
            -- local score = math.random(self.passScore, 100)
            -- if self.callBack then
            --     self.callBack(score, true, false, true)
            -- end
            -- self.contentCh.gameObject:SetActive(false)
            -- self.contentEn.gameObject:SetActive(false)
            -- self.testPass.gameObject:SetActive(false)
            -- self.testNoPass.gameObject:SetActive(false)
            -- self:showResult(score, true)

            -- self.coroutine = self.commonService:StartCoroutine(function()
            --     self.commonService:YieldSeconds(2)
            --     self.scoreRoot.gameObject:SetActive(false)
            --     self.waitText.gameObject:SetActive(true)
            --     self.commonService:YieldSeconds(0.5)
            --     self.answerIndex = self.answerIndex + 1
            --     self:startAnswer(self.callBack, self.answerIndex)
            -- end)
        end)
        self.commonService:AddEventListener(self.testNoPassBtn, "onClick", function()
            self.observerService:Fire("speech_assessment_test", {
                pass = false
            })
            self.testPass.gameObject:SetActive(false)
            self.testNoPass.gameObject:SetActive(false)
            -- self:cancelAnswer()
            -- self.effect:SetActive(false)
            -- self.confirm.gameObject:SetActive(false)
            -- self.testPass.gameObject:SetActive(false)
            -- self.testNoPass.gameObject:SetActive(false)
            -- local score = math.random(0, self.passScore - 1)
            -- if self.callBack then
            --     self.callBack(score, true, false, false)
            -- end
            -- self.contentCh.gameObject:SetActive(false)
            -- self.contentEn.gameObject:SetActive(false)
            -- self:showResult(score, false)

            -- self.coroutine = self.commonService:StartCoroutine(function()
            --     self.commonService:YieldSeconds(2)
            --     self.waitText.gameObject:SetActive(true)
            --     self.scoreRoot.gameObject:SetActive(false)
            --     self.commonService:YieldSeconds(0.5)

            --     self:startAnswer(self.callBack)
            -- end)
        end)
    end

    self.observerService:Watch("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", function(key, value)
        local data = value[0]
        local status = data.status
        if status == 1 then
            g_Log(TAG, "收到start Answer")
            APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
                open = false,
                isShow = false
            }, function()

            end)
            self.panel.gameObject:SetActive(true)
            self.scoreRoot.gameObject:SetActive(false)
            local callBack = data.callBack
            local showAwardType = data.showAwardType
            local awardCount = data.awardCount
            local reTryCount = data.reTryCount
            if not reTryCount then
                reTryCount = 1
            end
            self.callBack = callBack

            -- 默认视频展示样式 4
            local videoViewType = 4
            -- 如果调用方传入了视频展示样式，则使用调用方传入的视频展示样式
            if data.videoViewType ~= nil then
                videoViewType = data.videoViewType
            end

            local noLeadReading = false
            if data.noLeadReading ~= nil then
                noLeadReading = data.noLeadReading
            end

            -- 默认全部打开视频领读能力
            self.evaInfo = {
                showAwardType = showAwardType,
                awardCount = awardCount,
                reTryCount = reTryCount,
                isShowVideo = true,
                videoViewType = videoViewType,
                noLeadReading = noLeadReading
            }

            self.cancel = false
            self.answerIndex = self.answerIndex + 1
            self:startAnswer(callBack, self.answerIndex)
        elseif status == 2 then
            g_Log(TAG, "收到stop Answer")
            if self.coroutine then
                self.commonService:StopCoroutineSafely(self.coroutine)
                self.coroutine = nil
            end
            self.panel.gameObject:SetActive(false)
            if self.leadAudio then
                self.audioService:StopAudioSource(self.leadAudio)
                self.leadAudio = nil
            end
            if self.audioSource then
                self.audioService:StopAudioSource(self.audioSource)
                self.audioSource = nil
            end
            self.cancel = true
            self:stopAnswer() ---有回调结果返回
        else
            g_Log(TAG, "收到cancel Answer")
            if self.coroutine then
                self.commonService:StopCoroutineSafely(self.coroutine)
                self.coroutine = nil
            end
            self.panel.gameObject:SetActive(false)
            if self.leadAudio then
                self.audioService:StopAudioSource(self.leadAudio)
                self.leadAudio = nil
            end
            if self.audioSource then
                self.audioService:StopAudioSource(self.audioSource)
                self.audioSource = nil
            end
            self.cancel = true
            self:cancelAnswer()
            ---取消时候保存最后一道题目
            if self.question and (not self.question.hasPass) then
                self.lastQuestion = self.question
            end
        end
    end)
end

function FsyncElement:startAnswer(businessCallBack, answerIndex)
    g_Log(TAG, "开始答题")
    if self.answerIndex ~= answerIndex then
        return
    end
    if self.lastQuestion then
        self.question = self.lastQuestion
        self.lastQuestion = nil
        self:doAnswer(businessCallBack, answerIndex)
        return
    end
    self.observerService:Fire("EVENT_ABCZONE_QUESTION_MANATER", {
        params = {{
            qType = 51,
            qCount = 1
        }},
        callBack = function(question)
            -- local question = self.questionList[self.questionIndex]
            question = question["51"][1]
            self.question = question
            g_Log(TAG, table.dump(question))
            ---数据错误重新取题
            if not self.question.text_en or self.question.text_en == "" then
                self.answerIndex = self.answerIndex + 1
                self:startAnswer(businessCallBack, self.answerIndex)
                return
            end
            -- local randomNum = math.random(0,10)
            -- if randomNum % 2 == 0 then
            --     self.question.style = styleIds.readBook
            -- end
            self:doAnswer(businessCallBack, answerIndex)
        end
    })
end

---根据题目设置Ui
function FsyncElement:SetQuestionView()
    g_Log(TAG, "设置题目")
    self.waitText.gameObject:SetActive(false)
    self.contentEn.gameObject:SetActive(true)
    self.contentCh.gameObject:SetActive(true)
    self.contentChTmp.text = self.question.text_cn
    -- self.contentChTmp.text = "我和朋友们一起看了一场足球比赛，然后一起踢了足球"
    ---51 读句子 52 读课文
    if self.question.style == styleIds.readBook then
        self.readBookBg.gameObject:SetActive(true)
        self.sentenceBg.gameObject:SetActive(false)
        -- self.contentEnTmp.fontSize = 18
        -- self.contentEnTmp.color = CS.UnityEngine.Color(1, 1, 1, 0.4)
        local text_en = ""
        local indexArray = self.question.indexArray
        if indexArray then
            if type(indexArray) == 'string' then
                indexArray = self.jsonService:decode(indexArray)
            end
            -- if indexArray and type(indexArray) == 'table' then
            -- end
            local froStr, endStr = self:GetKeyWordTextByIndex3(self.question.display, indexArray)
            if not froStr or not endStr then
                froStr, endStr = self:GetKeyWordText1(self.question.display, self.question.text_en)
            end
            self.preContent.gameObject:SetActive(true)
            self.lastContent.gameObject:SetActive(true)
            self.preContentTmp.text = froStr
            self.lastContentTmp.text = endStr
        end
        -- if indexArray then
        --     if type(indexArray) == 'string' then
        --         indexArray = self.jsonService:decode(indexArray)
        --     end
        --     if indexArray and type(indexArray) == 'table' then
        --         text_en = self:GetKeyWordTextByIndex2(self.question.display, indexArray)
        --     end
        -- end
        -- if (not text_en) or text_en == "" and (self.question.word and self.question.word ~= "") then
        --     -- g_Log(TAG, self.question.text_en, keyWord)
        --     text_en = "<color=#00DEA9FF><size=32>" .. self.question.word .. "></size></color>"
        -- end

        text_en = "<color=#00DEA9FF><size=32>" .. self.question.text_en .. "</size></color>"
        self.contentEnTmp.text = text_en

        local width = self.contentEnTmp.preferredWidth
        width = width + sidesGap
        if width <= minWidth then
            width = minWidth
        end
        local enPreferredWidth = self.contentEnTmp.preferredWidth
        local contentPreORLastWidth = (width - enPreferredWidth) / 2
        self.preContentRect.sizeDelta = Vector2(contentPreORLastWidth, self.preContentRect.sizeDelta.y)
        self.lastContentRect.sizeDelta = Vector2(contentPreORLastWidth, self.lastContentRect.sizeDelta.y)
        self.contentBgRect.sizeDelta = Vector2(width, self.contentBgRect.sizeDelta.y)
    else
        self.readBookBg.gameObject:SetActive(false)
        self.sentenceBg.gameObject:SetActive(true)
        self.contentEnTmp.fontSize = 32
        self.contentEnTmp.color = CS.UnityEngine.Color(1, 1, 1, 1)
        local keyWord = self.question.word
        local indexArray = self.question.indexArray
        local text_en = ""
        if indexArray then
            if type(indexArray) == 'string' then
                indexArray = self.jsonService:decode(indexArray)
            end
            if indexArray and type(indexArray) == 'table' then
                text_en = self:GetKeyWordTextByIndex(self.question.text_en, indexArray)
            end
        end
        if (not text_en) or text_en == "" then
            -- g_Log(TAG, self.question.text_en, keyWord)
            text_en = self:GetKeyWordText(self.question.text_en, keyWord)
        end

        self.contentEnTmp.text = "<b>" .. text_en .. "</b>"
        self.preContent.gameObject:SetActive(false)
        self.lastContent.gameObject:SetActive(false)
        local width = self.contentEnTmp.preferredWidth
        width = width + sidesGap
        if width <= minWidth then
            width = minWidth
        end
        self.contentBgRect.sizeDelta = Vector2(width, self.contentBgRect.sizeDelta.y)

        -- 上一题是视频领读
        if self.playVideoOpen then
            self.playVideoOpen = false
            -- 清理一下视频窗口
            self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
                op = "stop"
            })
        end
    end

    if self.scrollViewTimer then
        self.commonService:StopCoroutineSafely(self.scrollViewTimer)
        self.scrollViewTimer = nil
    end
    if self.contentChTmp.preferredWidth > 500 then
        self.contentChRect.pivot = Vector2(0, 0.5)
        self.scrollView.horizontalNormalizedPosition = 0
        local pos = -0.1
        ---使用ScrollView实现跑马灯
        self.scrollViewTimer = self.commonService:StartCoroutine(function()
            while true do
                self.scrollView.horizontalNormalizedPosition = pos
                -- if pos == 0 or pos == 1 then
                --     self.commonService:YieldSeconds(0.5)
                -- else
                self.commonService:YieldEndFrame()
                -- end
                pos = pos + 0.015
                if pos > 1 then
                    self.commonService:YieldSeconds(0.8)
                    pos = -0.1
                end
            end
        end)
    else
        self.contentChRect.pivot = Vector2(0.5, 0.5)
    end
    -- if width < self.contentChTmp.preferredWidth then
    --     width = self.contentChTmp.preferredWidth
    -- end

    self.sound.gameObject:SetActive(true)
end

function FsyncElement:doAnswer(businessCallBack, answerIndex)
    self:SetQuestionView()
    self.leadAudio = self.audioService:PlayClipOneShot(self.leadTip, function()
        if self.cancel then
            return
        end
        if self.answerIndex ~= answerIndex then
            return
        end
        self:playFirstSound(function()
            if self.answerIndex ~= answerIndex then
                g_Log(TAG, "index 错误 return")
                return
            end
            if App.IsStudioClient then
                self.audioService:PlayClipOneShot(self.audioTip)
                self.effect:SetActive(true)
                if self.lowAppVersion then
                    self.confirm.gameObject:SetActive(true)
                end
                self.testPass.gameObject:SetActive(true)
                self.testNoPass.gameObject:SetActive(true)
            end
            local showAwardType = self.evaInfo.showAwardType
            if (not showAwardType) or showAwardType == 2 or showAwardType == 11 then
                ---读课文
                if self.question.style == styleIds.readBook then
                    showAwardType = 14
                end
            end
            local petExp = 1
            local params = {
                action = "start",
                serviceType = "evaAndRect",
                showMicView = false,
                preserveType = showAwardType,
                awardCount = self.evaInfo.awardCount,
                questionId = self.question.id,
                questionStyle = self.question.style,
                text_cn = self.question.text_cn,
                text_en = self.question.text_en,
                passBy = self.question.passBy,
                countdown = 10,
                passScore = self.passScore,
                showResult = false,
                reTryCount = self.evaInfo.reTryCount,
                showAwardType = showAwardType,
                needInterception = true, -- 开启高分截停
                petExp = petExp,
                noChangeChat = true,
                callBack = function(score, isFinal, isNoSpeaking)
                    g_Log(TAG, "score = " .. tostring(score) .. " isFinal = " .. tostring(isFinal))
                    local isPass = score >= self.passScore
                    if isPass then
                        self.question.hasPass = true
                    end
                    -- score = 60
                    local isReadBook = self.question.style == styleIds.readBook
                    if businessCallBack then
                        businessCallBack(score, isFinal, isNoSpeaking, isPass, isReadBook)
                    end
                    ---用于切换下一题
                    self.observerService:Fire("change_next_question", {
                        score = score,
                        isFinal = isFinal,
                        isNoSpeaking = isNoSpeaking,
                        isPass = isPass,
                        isReadBook = isReadBook
                    })
                    if self.lowAppVersion then
                        self.confirm.gameObject:SetActive(false)
                    end
                    self.effect:SetActive(false)
                    -- g_Log(TAG, "评测结束")
                    self.contentCh.gameObject:SetActive(false)
                    self.contentEn.gameObject:SetActive(false)
                    self:showResult(score, isPass)
                    g_Log(TAG, "开始等待结果页显示")
                    -- g_Log(TAG, "评测结束")
                    local resultDelay = 2
                    if isPass and self.question.style == styleIds.readBook then
                        resultDelay = 2.5
                    end
                    self.coroutine = self.commonService:StartCoroutine(function()
                        self.commonService:YieldSeconds(resultDelay)
                        g_Log(TAG, "开始等待结果页显示完成")
                        self.scoreRoot.gameObject:SetActive(false)
                        if not isFinal then
                            if App.IsStudioClient then
                                self.contentCh.gameObject:SetActive(true)
                                self.contentEn.gameObject:SetActive(true)
                                self.audioService:PlayClipOneShot(self.audioTip)
                                self.effect:SetActive(true)
                                if self.lowAppVersion then
                                    self.confirm.gameObject:SetActive(true)
                                end
                                self.testPass.gameObject:SetActive(true)
                                self.testNoPass.gameObject:SetActive(true)
                            end
                        else
                            if self.scrollViewTimer then
                                self.commonService:StopCoroutineSafely(self.scrollViewTimer)
                                self.scrollViewTimer = nil
                            end
                            self.waitText.gameObject:SetActive(true)
                            self.commonService:YieldSeconds(0.5)
                            g_Log(TAG, "评测结束,自动开始下一题")
                            self.answerIndex = self.answerIndex + 1
                            self:startAnswer(businessCallBack, self.answerIndex)
                        end
                    end)
                end,
                stepCallBack = function(step)
                    if step == 1 then
                        self.contentCh.gameObject:SetActive(true)
                        self.contentEn.gameObject:SetActive(true)
                        CS.UnityEngine.AudioListener.volume = 1
                        self.commonService:RegisterIntervalSingleTimer(0,"_setVoiceAnim",function ()
                            CS.UnityEngine.AudioListener.volume = 1
                        end,true)
                        self.audioService:PlayClipOneShot(self.audioTip, function()
                            CS.UnityEngine.AudioListener.volume = 0
                            self.commonService:UnregisterIntervalSingleTimer(0,"_setVoiceAnim")
                        end)
                        if self.lowAppVersion then
                            self.confirm.gameObject:SetActive(true)
                        end
                        self.effect:SetActive(true)
                    else
                        if self.lowAppVersion then
                            self.confirm.gameObject:SetActive(false)
                        end
                        self.effect:SetActive(false)
                    end
                end
            }
            for k, v in pairs(self.evaInfo) do
                params[k] = v
            end
            self.speechAssessmentBusiness:StartAssessment(params, params.callBack)
            -- self.observerService:Fire(EVENT_EVALUATION_AND_RECOGNITION_SERVICE, params)
        end)
    end)
end

-- 检测视频领读是否可用
function FsyncElement:CanPlayVideoGuide()
    -- 是否开启外教领读
    local isShowVideo = self.evaInfo.isShowVideo
    local videoViewType = self.evaInfo.videoViewType or 1
    -- 播放引导视频是否可用
    local PlayVideo = false
    -- 播放视频功能是否可用 --版本、是否是测试环境
    local canUse = false
    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
        op = "Available",
        callback = function(use)
            canUse = use
        end
    })
    local videoUrl = self.question.video
    if isShowVideo and videoUrl and videoUrl ~= "" and canUse then
        PlayVideo = true
    end

    return PlayVideo, videoViewType
end

function FsyncElement:playFirstSound(callBack)
    local noLeadReading = self.evaInfo.noLeadReading
    if noLeadReading then
        g_Log(TAG, "不播放引导音")
        callBack()
        return
    end
    local audio = self.question.audio
    local PlayVideo, videoViewType = self:CanPlayVideoGuide()

    if PlayVideo then
        self.isPlaying = true
        self.playVideoOpen = true
        self.effect:SetActive(false)
        self.sound.gameObject:SetActive(true)
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
            op = "PlayVideo",
            viewType = videoViewType,
            question = self.question,
            callback = function(res)
                self.isPlaying = false
                self.sound.gameObject:SetActive(false)
                if self.outTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                    self.outTimeCoroutine = nil
                end
                -- 异常上报
                if res and res.status == "error" then
                    self:_reportData("外教引导视频播放失败", {
                        url = audio,
                        text_en = self.question.text_en,
                        id = self.question.id
                    }, "1")
                end
                callBack()
            end
        })
        -- 超时兜底
        if self.outTimeCoroutine then
            self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
            self.outTimeCoroutine = nil
        end
        self.outTimeCoroutine = self.commonService:StartCoroutine(function()
            self.commonService:YieldSeconds(10)
            if self.isPlaying then
                self.isPlaying = false
                self:_reportData("播放音频超时", {
                    url = audio,
                    text_en = self.question.text_en,
                    id = self.question.id
                }, "1")
                callBack()
            end
        end)
    else
        self.isPlaying = true
        local audioClip = self.question.audioClip
        ---兜底
        if self.outTimeCoroutine then
            self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
            self.outTimeCoroutine = nil
        end
        self.outTimeCoroutine = self.commonService:StartCoroutine(function()
            self.commonService:YieldSeconds(10)
            if self.isPlaying then
                self.isPlaying = false
                if self.audioSource then
                    self.audioService:StopAudioSource(self.audioSource)
                end
                self.sound.gameObject:SetActive(false)
                -- self.soundAnim:SetBool("play", false)
                self:_reportData("播放音频超时", {
                    url = audio,
                    text_en = self.question.text_en,
                    id = self.question.id
                }, "1")
                if self.cancel then
                    return
                end
                g_Log(TAG, "触发了播放兜底")
                callBack()
            end
        end)

        if audioClip then
            self.effect:SetActive(false)
            -- self.soundAnim:SetBool("play", true)
            self.sound.gameObject:SetActive(true)
            self.audioSource = self.audioService:PlayClipOneShot(audioClip, function()
                g_Log(TAG, "播放成功")
                if self.outTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                    self.outTimeCoroutine = nil
                end
                if not self.isPlaying then
                    return
                end
                self.isPlaying = false
                self.sound.gameObject:SetActive(false)
                -- self.soundAnim:SetBool("play", false)
                if self.cancel then
                    return
                end
                callBack()
            end)
        else
            self.audioService:GetMp3AudioFromGetUrl(audio, function()
                self.isPlaying = false
                if self.outTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                    self.outTimeCoroutine = nil
                end
                if self.cancel then
                    return
                end
                self.sound.gameObject:SetActive(false)
                g_Log(TAG, "下载失败，直接回调")
                callBack()
                self:_reportData("下载音频失败", {
                    url = audio,
                    text_en = self.question.text_en,
                    id = self.question.id
                }, "0")
            end, function(clip)
                if self.outTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                    self.outTimeCoroutine = nil
                end
                g_Log(TAG, "下载成功，准备播放")
                self.question.audioClip = clip
                self:playFirstSound(callBack)
            end)
        end
    end
end

function FsyncElement:showResult(score, isPass)
    if isPass then
        self.greatRoot.gameObject:SetActive(true)
        self.fightingRoot.gameObject:SetActive(false)
        if score >= 100 then
            self.greatLevelImage.sprite = self.resultImage[1]
            self.greatLevelRect.sizeDelta = Vector2(164, 40) / 0.28
        elseif score >= 90 then
            self.greatLevelImage.sprite = self.resultImage[2]
            self.greatLevelRect.sizeDelta = Vector2(196, 40) / 0.28
        else
            self.greatLevelImage.sprite = self.resultImage[3]
            self.greatLevelRect.sizeDelta = Vector2(148, 40) / 0.28
        end
        if self.question.style == styleIds.sentence then
            self.greatRootRect.anchoredPosition = Vector2(0, 0)
            self.awardBg.gameObject:SetActive(false)
        elseif self.question.style == styleIds.readBook then
            self.awardBg.gameObject:SetActive(true)
            self.greatRootRect.anchoredPosition = Vector2(0, 81)
        end
        self.audioService:PlayClipOneShot(self.greatClip)

        if self.question.style == styleIds.readBook then
            self.jewel = self.jewel + 1
            self.commonService:StartCoroutine(function()
                self.commonService:YieldSeconds(1.5)
                self.zuanshiAnim:SetTrigger("Add")
                self.commonService:YieldSeconds(0.4)
                self.jewelCountTmp.text = tostring(self.jewel)
            end)
        end
    else
        self.fightingRoot.gameObject:SetActive(true)
        self.greatRoot.gameObject:SetActive(false)
        self.audioService:PlayClipOneShot(self.niceTryClip)
        if self.question.style == styleIds.readBook then
            self.fightingContentTmp.text = "未达标不能获得能量和学识哦～"
        else
            self.fightingContentTmp.text = "未达标不能获得能量哦～"
        end
    end
    -- self.contentBgRect.sizeDelta = Vector2(minWidth, self.contentBgRect.sizeDelta.y)
    self:setScore(score, isPass)
    self.scoreRoot.gameObject:SetActive(true)
end

function FsyncElement:setScore(score, isPass)
    local hun = 0
    local ten = 0
    local one = 0
    local hunShow = false
    local tenShow = true
    if score >= 100 then
        hun = 1
        ten = 0
        one = 0
        hunShow = true
    else
        hun = 0
        ten = math.floor(score / 10)
        one = score % 10
        if ten == 0 then
            tenShow = false
        end
    end
    if isPass then
        if hunShow then
            self.greatScoreHun.gameObject:SetActive(true)
            self.greatScoreTen.gameObject:SetActive(true)
            self.greatScoreOne.gameObject:SetActive(true)
            self.greatScoreHunImage.sprite = self.yellowNumImage[hun]
            self.greatScoreTenImage.sprite = self.yellowNumImage[ten]
            self.greatScoreOneImage.sprite = self.yellowNumImage[one]
            -- self.greatScoreHunImage:SetNativeSize()
            -- self.greatScoreTenImage:SetNativeSize()
            -- self.greatScoreOneImage:SetNativeSize()
        elseif tenShow then
            self.greatScoreHun.gameObject:SetActive(false)
            self.greatScoreTen.gameObject:SetActive(true)
            self.greatScoreOne.gameObject:SetActive(true)
            self.greatScoreTenImage.sprite = self.yellowNumImage[ten]
            self.greatScoreOneImage.sprite = self.yellowNumImage[one]
            -- self.greatScoreTenImage:SetNativeSize()
            -- self.greatScoreOneImage:SetNativeSize()
        else
            self.greatScoreHun.gameObject:SetActive(false)
            self.greatScoreTen.gameObject:SetActive(false)
            self.greatScoreOne.gameObject:SetActive(true)
            self.greatScoreOneImage.sprite = self.yellowNumImage[one]
            -- self.greatScoreOneImage:SetNativeSize()
        end
    else
        if tenShow then
            self.fightingScoreTen.gameObject:SetActive(true)
            self.fightingScoreOne.gameObject:SetActive(true)
            self.fightingScoreTenImage.sprite = self.blueNumImage[ten]
            self.fightingScoreOneImage.sprite = self.blueNumImage[one]
            -- self.fightingScoreTenImage:SetNativeSize()
            -- self.fightingScoreOneImage:SetNativeSize()
        else
            self.fightingScoreTen.gameObject:SetActive(false)
            self.fightingScoreOne.gameObject:SetActive(true)
            self.fightingScoreOneImage.sprite = self.blueNumImage[one]
            -- self.fightingScoreOneImage:SetNativeSize()
        end
    end
end

function FsyncElement:cancelAnswer()
    -- 取消视频领读UI
    if self.outTimeCoroutine then
        self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
        self.outTimeCoroutine = nil
    end
    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
        op = "stop"
    })
    self.speechAssessmentBusiness:CancelAssessment()
end

function FsyncElement:stopAnswer()
    if self.outTimeCoroutine then
        self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
        self.outTimeCoroutine = nil
    end
    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
        op = "stop"
    })
    self.speechAssessmentBusiness:StopAssessment()
end

function FsyncElement:GetKeyWordTextByIndex(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return text
    end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                elseif lastIndex then
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#00DEA9>" .. middleStr .. "</color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return text
end

function FsyncElement:GetKeyWordTextByIndex2(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return text
    end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                elseif lastIndex then
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            frontStr = "<color=#FFFFFF66>" .. frontStr .. "</color>"
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#00DEA9FF><size=32>" .. middleStr .. "</size></color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                endStr = "<color=#FFFFFF66>" .. endStr .. "</color>"
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return text
end

function FsyncElement:GetKeyWordTextByIndex3(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return nil, nil
    end
    if not index[1] then
        return nil, nil
    end
    local index1 = index[1]

    local startIndex = index1[1]
    local endIndex = index1[2]
    local frontStr = ""

    if startIndex > 0 then
        frontStr = string.sub(text, 1, startIndex)
    end

    --- 对frontStr 反转
    local frontStrReverse = string.reverse(frontStr)
    local endStr = ""
    if endIndex + 2 <= #text then
        endStr = string.sub(text, endIndex + 2, #text)
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return frontStrReverse, endStr
end

-- 处理对应重点单词文字
function FsyncElement:GetKeyWordText(text, word)
    if not text and not word then
        return ""
    end
    if not word or word == "" then
        return text
    end
    if not text or text == "" then
        return ""
    end
    for keyWord in string.gmatch(word, "%w+") do
        local keyWordLower = keyWord:lower()
        local lowerText = text:lower()
        local startIndex, endIndex = string.find(lowerText, keyWordLower)
        if startIndex and endIndex then
            -- local key = string.sub(text, startIndex, endIndex)
            -- g_Log(TAG, "使用关键词高亮显示"..keyWord)
            text = text:gsub('(%f[%a]' .. keyWord .. '[%p]*%f[^%a])', "<color=#00DEA9>" .. keyWord .. "</color>")
        end
    end
    -- 替换所有出现的关键词
    return text
end

function FsyncElement:GetKeyWordText1(text, word)
    if not text and not word then
        return "", ""
    end
    if not word or word == "" then
        return "", ""
    end
    if not text or text == "" then
        return "", ""
    end
    local startIndex, endIndex = string.find(text, word)
    local frontStr = ""
    local endStr = ""
    if startIndex and startIndex > 1 then
        frontStr = string.sub(text, 1, startIndex - 1)
    end
    local frontStrReverse = string.reverse(frontStr)
    if endIndex and endIndex + 1 <= #text then
        endStr = string.sub(text, endIndex + 1, #text)
    end
    -- 替换所有出现的关键词
    return frontStrReverse, endStr
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function FsyncElement:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function FsyncElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function FsyncElement:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function FsyncElement:LogicMapStartRecover()
    FsyncElement.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function FsyncElement:LogicMapEndRecover()
    FsyncElement.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function FsyncElement:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

-- 收到Trigger事件
function FsyncElement:OnReceiveTriggerEvent(interfaceId)
end

-- 收到GetData事件
function FsyncElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

function FsyncElement:_reportData(label, value, action)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(self.eventId, "64007", "Special-Interaction",
            label, action, value)
    end
end

-- 脚本释放
function FsyncElement:Exit()
    FsyncElement.super.Exit(self)
end

return FsyncElement
