local class = require("middleclass")
local baseManager = require("gameplay/baseManager")
---@class CommandManager : BaseManager
local CommandManager = class("CommandManager", baseManager)
local extends = require("gameplay/extends")
local utils = require("gameplay/utils")
---@type RoleManager
local role = require("gameplay/role")

---@type StatusManager
local status = require("gameplay/status")


---@type AssetsMapManager 
local assetsMap = require("gameplay/assetsMap")
function CommandManager:initialize()
    CommandManager.super.initialize(self)
    self:LoadConfig({"command"})
end
function CommandManager:Do(id, uid)

    -- if uid ~= App.Uuid then
    --     return
    -- end
    ---@type Command
    local command = self:GetCommand(id)

    if command == nil then
        return g_LogError("不存在的命令" .. id)
    end

    local condition = command.condition

    local can = role.skillManager:Condition(condition, uid)
    if can == false then
        return
    end

    if uid == App.Uuid then
        if command.type == 1 then
            -- 切换技能按钮
            local param = command.param
            role:ChangeSkillButton(param)
        elseif command.type == 2 then
            -- 显示toast
        elseif command.type == 3 then
            -- 开关技能按钮
            role:SwitchButtons(command.param["button_idxs"])
        elseif command.type == 4 then
            -- 举人
            status:TryLift(App.Uuid)
        elseif command.type == 5 then
            -- 释放举人
            status:TryRelease(App.Uuid, command.param["release_command"])
        elseif command.type == 6 then
            -- 眩晕
            status:TryStunned(App.Uuid)
        elseif command.type == 7 then
            -- 解除眩晕
            status:TryStunnedQuit(App.Uuid)
        elseif command.type == 14 then
            -- 相机遮罩 
            local asset = assetsMap:GetAssetGo(command.param["id"])
            if asset == nil then
                return
            end
    
            local duration = tonumber(command.param["duration"])
    
            self:StartCoroutine(function ()
                --show
    
                local camera = CS.UnityEngine.Camera.main
                local sp = GameObject("camera-mask")
                sp.transform:SetParent(camera.transform)
                local pos =string.split(command.param["pos"], ',')
                sp.transform.localPosition = Vector3(tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]))
                local scale = string.split(command.param["scale"], ',')
                sp.transform.localScale = Vector3(tonumber(scale[1]), tonumber(scale[2]), tonumber(scale[3]))
                sp.transform.localRotation = Quaternion.identity
    
                local render = sp:AddComponent(typeof(CS.UnityEngine.SpriteRenderer))
                render.sprite = asset:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
                render.sortingOrder = 10
                self:YieldSeconds(duration)
                --hide
                GameObject.Destroy(sp)
    
            end)
        end
    else

    end

    if command.type == 8 then
        -- 加血
        local roleEntity = role:GetRole(uid)
        role:AddHealth(tonumber(command.param["value"]), {uid})

    elseif command.type == 9 then
        -- 加速
        local roleEntity = role:GetRole(uid)
        if roleEntity.isAvatar == false then
            local go = roleEntity.go
            go:GetComponentInChildren(typeof(CS.UnityEngine.AI.NavMeshAgent)).speed =
                roleEntity.role.initial_speed * tonumber(command.param["value"])
            local speed = go:GetComponentInChildren(typeof(CS.UnityEngine.AI.NavMeshAgent)).speed
        else
            -- TODO
        end

    elseif command.type == 10 then
        -- 护盾

        local roleEntity = role:GetRole(uid)
        roleEntity.shield = tonumber(command.param["value"])
    elseif command.type == 11 then
        self.eventEmitter:emit("OnDo", command.param["key"], command.param["value"])
    elseif command.type == 12 then
        -- 护盾

        local roleEntity = role:GetRole(uid)
        roleEntity.shield = roleEntity.shield + tonumber(command.param["value"])
    elseif command.type == 13 then

        -- 无敌状态
        local roleEntity = role:GetRole(uid)
        -- true 无敌 false 可以被攻击

        local isInvincible = false
        if command.param["value"] == "true" or command.param["value"] == "True" or command.param["value"] == "TRUE"  then
            isInvincible = true
        else
            isInvincible = false
        end
        roleEntity.invincible = isInvincible
    
    end

end

function CommandManager:GetCommand(id)
    return self.data.command[id]
end

function CommandManager:OnDo(callback)
    self.eventEmitter:on("OnDo", callback)
end

local CommandManagerInstance = CommandManager:new()
return CommandManagerInstance
