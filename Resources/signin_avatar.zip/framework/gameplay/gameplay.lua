local class = require("middleclass")
---@class Gameplay
local Gameplay = class("Gameplay")
---@type FactionManager
local Faction = require("gameplay/faction")
---@type SkillManager
local Skill = require("gameplay/skill")
---@type Extends
local extends = require("gameplay/extends")
---@type Utils
local utils = require("gameplay/utils")
---@type RoleManager
local Role = require("gameplay/role")

---@type AssetsMapManager
local AssetsMap = require("gameplay/assetsMap")

local Status = require("gameplay/status")
local WBElement = require("mworld/worldBaseElement")
local GameplayElement = class("GameplayElement", WBElement)
Physics = CS.UnityEngine.Physics

function Gameplay:initialize()
    extends.Class(self)

    self.eventEmitter = utils.EventEmitter()
    self.skill = Skill;
    self.faction = Faction;
    self.role = Role;
    self.role.skillManager = self.skill
    self.status = Status;
    self.status.skillManager = self.skill
    self.mods = {}


    local modMap = {self.skill,self.faction,self.role,self.status}

    for k, v in pairs(modMap) do
        if v.OnGameplayInitialized then
            v:OnGameplayInitialized()
        end
    end
    

end

function Gameplay:Destroy()
    self.eventEmitter = nil
    self.skill = nil;
    self.faction = nil;
    self.role = nil;
    self.gameplayElement = nil
end

---@type Gameplay
local GameplayInstance = Gameplay:new()
---注册element
function Gameplay:Init()
    local key = "Gameplay"
    if self.isInit == true then
        return
    end
    self.isInit = true
    xpcall(function()
        CourseEnv.ServicesManager.Gate:AddElementType(key, GameplayElement)
        local dict = CS.Tal.framesync.VisualProperty();
        dict:Add("type", key)
        local ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.zero, Vector3.one,
            Vector3.zero, "WorldElement_" .. key)
        self.gameplayElement = ret
    end, function(err)
        g_LogError(err)
    end)


    -- 拓展类对象
    -- 注册消息key

    local that = self
    self.mods = {Skill, Faction, Role,Status}
    for k, v in pairs(self.mods) do
        function v:SendCustomMessage(...)
            return that.gameplayElement:SendCustomMessage(...)
        end
        function v:AsyncGetAvatar(...)
            return that.gameplayElement:AsyncGetAvatar(...)
        end

        if v.RegisterMessage then
            local keys = v:RegisterMessage()
            for _k, _v in pairs(keys) do
                self.gameplayElement:SubscribeMsgKey(_v)
            end
        end
    end

    AssetsMap:ConfigRegister()
    self.eventEmitter:emit("OnInit")
end
function Gameplay:OnInit(cb)
    self.eventEmitter:on("OnInit", cb)
end

function Gameplay:ReceiveMessage(key, value, isResume)
    -- TODO:
    for k, v in pairs(self.mods) do
        if v.ReceiveMessage then
            v:ReceiveMessage(key, value, isResume)
        end
    end

end

function Gameplay:Tick()
    for k, v in pairs(self.mods) do
        if v.Tick then
            v:Tick()
        end
    end
end
function Gameplay:UpdateFrameIndex(frameIndex)
    for k, v in pairs(self.mods) do
        if v.UpdateFrameIndex then
            v:UpdateFrameIndex(frameIndex)
        end
    end
end
----------------------------------------GameplayElement----------------------------------------

function GameplayElement:initialize(worldElement)
    GameplayElement.super.initialize(self, worldElement)
    -- 订阅KEY消息
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function GameplayElement:ReceiveMessage(key, value, isResume)
    -- TODO:
    GameplayInstance:ReceiveMessage(key, value, isResume)
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function GameplayElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function GameplayElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function GameplayElement:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function GameplayElement:AvatarCreated(avatar)

end
function GameplayElement:Tick()
    GameplayInstance:Tick()
end
function GameplayElement:UpdateFrameIndex(frameIndex)
    GameplayInstance:UpdateFrameIndex(frameIndex)
end
------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function GameplayElement:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function GameplayElement:LogicMapStartRecover()
    GameplayElement.super:LogicMapStartRecover()
    -- TODO
end
-- 结束恢复方法 (断线重连的时候用)
function GameplayElement:LogicMapEndRecover()
    GameplayElement.super:LogicMapEndRecover(self)
    -- TODO
end
-- 所有的组件恢复完成
function GameplayElement:LogicMapAllComponentRecoverComplete()
end

-- 收到Trigger事件
function GameplayElement:OnReceiveTriggerEvent(interfaceId)
end
-- 收到GetData事件
function GameplayElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end

-- 脚本释放
function GameplayElement:Exit()
    GameplayElement.super.Exit(self)
    GameplayInstance:Destroy()
end
return GameplayInstance
