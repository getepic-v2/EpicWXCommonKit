local class = require("middleclass")
---@class FactionManager : ExtendedClass
local Faction = class("FactionManager")
local extends = require("gameplay/extends")
local utils = require("gameplay/utils")
function Faction:initialize()
    extends.Class(self)
    self.factions = {}
    self.config = {}
    self.eventEmitter = utils.EventEmitter()
    self:LoadConfig()
    self.registerHistory = {}
end
function Faction:LoadConfig()
    self.data = {}
    local data = {"faction"}

    for i, v in ipairs(data) do
        local d = utils.RequireLua("gameplay", v)
        if d then
            self.data[v] = d
        end
    end
end
function Faction:Register(name, uuid, force)
    if self.registerHistory[uuid] ~= nil and force ~= true then
        g_LogError("历史已经注册过了,二次注册需要设置force参数:" .. uuid .. "--force:" ..
                       tostring(force))
        return
    end
    if self.factions[name] == nil then
        if name ~= nil then
            g_LogError("没有这个阵营:" .. name)
        else
            g_LogError("没有这个阵营 nil")
        end
        return
    end

    if self:GetFactionName(uuid) ~= nil then
        g_LogError("已经注册过了")
        return
    end

    self.registerHistory[uuid] = {
        faction = name,
        time = os.time()
    }
    -- g_LogError("注册阵营-->"..name)
    self.factions[name].roles[uuid] = {}
end
function Faction:Unregister(uuid)
    local faction = self:GetFactionName(uuid)
    if faction == nil then
        return
    end
    self.factions[faction].roles[uuid] = nil
end

function Faction:Get(name)
    return self.factions[name]
end
function Faction:GetFactionName(uuid)
    for k, v in pairs(self.factions) do
        if v.roles[uuid] ~= nil then
            return k
        end
    end
    return nil
end

function Faction:IsEnemy(faction1, faction2)

    -- 一方敌对，认为另一方也敌对
    local enemies = self.factions[faction1].enemies
    for k, v in pairs(enemies) do
        if v == faction2 then
            return true
        end
    end

    local enemies = self.factions[faction2].enemies
    for k, v in pairs(enemies) do
        if v == faction1 then
            return true
        end
    end

    return false
end
function Faction:OnMatched(cb)
    self.eventEmitter:on("OnMatched", cb)
end
function Faction:Matched(data)

    -- 初始化阵营信息
    for k, v in pairs(self.data.faction) do
        local item = {
            name = v.id, -- 阵营名称
            roles = {}, -- 阵营成员
            enemies = {} -- 敌对阵营
        }
        item.enemies = v.enemies

        if self.factions[v.id] == nil then
            self.factions[v.id] = item
        end
    end

    for k, v in pairs(data) do
        for _k, _v in pairs(v) do
            self:Register(k, _v)
        end
    end
    self.eventEmitter:emit("OnMatched", data)
end
function Faction:OnAvatarOffline(cb)
    self.eventEmitter:on("OnAvatarOffline", cb)
end
function Faction:AvatarOffline(uuid)
    self.eventEmitter:emit("OnAvatarOffline", uuid)
end

local factionInstance = Faction:new()
return factionInstance
