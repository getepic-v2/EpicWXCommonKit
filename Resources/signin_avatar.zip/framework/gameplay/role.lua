local class = require("middleclass")
local baseManager = require("gameplay/baseManager")
---@class RoleManager : BaseManager
---@field role :RoleEntity
---@field roleEntities table<string,RoleEntity>
---@field skillManager SkillManager
---@field Energy number
local RoleManager = class("RoleManager", baseManager)
---@type Extends
local extends = require("gameplay/extends")
---@type Utils
local utils = require("gameplay/utils")
---@type AssetsMapManager
local assetsMap = require("gameplay/assetsMap")
---@type FactionManager
local faction = require("gameplay/faction")
Color = CS.UnityEngine.Color
SceneManagement = CS.UnityEngine.SceneManagement
SceneManager = SceneManagement.SceneManager
LocalPhysicsMode = SceneManagement.LocalPhysicsMode
Physics = CS.UnityEngine.Physics
Mathf = CS.UnityEngine.Mathf
Input = CS.UnityEngine.Input

local AddHealthKey = "AddHealthKey" -- 添加血量消息
local RoleHealthChangedResKey = "RoleHealthChangedResKey" -- 角色生命值变化
local SetHealthKey = "SetHealthKey" -- 设置血量消息

---@class RoleEntity :ExtendedClass
---@field isAvatar boolean
---@field uid string
---@field role Role -- 角色定义数据
---@field health number --血量
---@field go GameObject -- 非avatar角色对象
---@field shield number --护盾
---@field invincible boolean --无敌
local RoleEntity = class("RoleEntity")
function RoleEntity:initialize()
    extends.Class(self)
    self.roleEntities = {}
end
function RoleEntity:GetAvatar()
    if self.isAvatar then
        local avatar = self.avatarService:GetAvatarByUUID(self.uid)
        if avatar == nil then
            return nil
        end

        return avatar

    else
        return nil
    end
end
function RoleEntity:GetTransform()
    if self.isAvatar then
        local avatar = self:GetAvatar()
        if avatar and avatar:IsOnline() and avatar.character then
            return avatar.character.transform
        end

        return nil
    else
        return self.go.transform
    end
end

function RoleManager:initialize()

    RoleManager.super.initialize(self)

    self:OnEnergyChanged(function(eg)
        if self.skillButtons == nil then
            return
        end
        for k, v in pairs(self.skillButtons) do
            v.onEnergyChanged(eg)
        end
    end)

    self:OnRolesHealthChanged(function(data)
        for k, v in pairs(data) do
            local re = self:GetRole(k)
            if re then
                local v = re.health
                if v == 0 and re.isAvatar == false then
                    ---@type AI
                    local ai = self:GetAI(re.role.ai)
                    if ai then
                        self.skillManager:FxSequence(ai.dead_fx, re.uid)
                    end
                end
            end
        end
    end)

    self:LoadConfig({"role", "skill_button", "role_static", "ai"})

    self:StartCoroutine(function()
        while true do
            self:YieldEndFrame()
            if self.isAiming then
                if Input.touchCount > 0 then
                    local touch = Input.GetTouch(0);
                    if (touch.phase == CS.UnityEngine.TouchPhase.Ended or touch.phase ==
                        CS.UnityEngine.TouchPhase.Canceled) then
                        self:HideAim()
                    end
                elseif not Input.GetMouseButton(0) then
                    self:HideAim()
                end
            end
        end

    end)
end
function RoleManager:GetRoleInfo(roleID)
    return self.data.role[roleID]
end
function RoleManager:GetAI(id)
    return self.data.ai[id]
end
---@return AI
function RoleManager:GetAIWithRoleID(roleID)
    ---@type Role
    local roleInfo = self:GetRoleInfo(roleID)
    ---@type AI
    local ai = self:GetAI(roleInfo.ai)
    return ai
end
function RoleManager:RegisterMessage()
    return {RoleHealthChangedResKey}
end

-- 根据阵容创建角色
function RoleManager:CreateRoleEntity(uid, faction, isAvatar, go)
    uid = tostring(uid)

    local re = self:GetRole(uid)
    if re ~= nil then
        g_LogError("角色已经存在:" .. uid)
        return re
    end
    local roleInfo = self:GetRoleByFaction(faction)
    ---@type RoleEntity
    local re = self:initializeRole(uid, isAvatar, go, roleInfo)

    return re
end
-- 根据id创建角色
function RoleManager:CreateRoleEntityWithId(uid, roleId, isAvatar, go)
    uid = tostring(uid)

    local re = self:GetRole(uid)
    if re ~= nil then
        g_LogError("角色已经存在:" .. uid)
        return re
    end
    local roleInfo = self.data.role[roleId]
    if roleInfo == nil then
        return g_LogError("非法的roleid:" .. roleId)
    end

    ---@type RoleEntity
    local re = self:initializeRole(uid, isAvatar, go, roleInfo)
    return re
end
function RoleManager:initializeRole(uid, isAvatar, go, roleInfo)
    ---@type RoleEntity
    local re = RoleEntity:new()
    self.roleEntities[uid] = re
    re.isAvatar = isAvatar
    re.uid = uid

    re.role = roleInfo
    re.health = re.role.initial_health
    re.shield = 0
    re.invincible = false

    if re.isAvatar == false and go == nil then
        ---@type AI
        local ai = self:GetAI(roleInfo.ai)
        if ai then
            local asset = assetsMap:GetAssetGo(ai.asset_id)
            if asset then
                go = GameObject.Instantiate(asset)
                go:SetActive(true)
            end
        end
    end

    re.go = go

    if re.isAvatar == false and go then
        local nm = go:GetComponentInChildren(typeof(CS.UnityEngine.AI.NavMeshAgent))
        if nm and re.role.initial_speed ~= 0 then
            nm.speed = re.role.initial_speed
        end
    end
    return re
end
function RoleManager:RemoveRoleEntity(uid)

    if uid == App.Uuid then
        self:HideSkillButtons()
    end
    self.eventEmitter:emit("OnRoleRemove", uid)
    self.roleEntities[uid] = nil

end
function RoleManager:OnRemoveRoleEntity(cb)
    self.eventEmitter:on("OnRoleRemove", cb)
end
---@return RoleEntity
function RoleManager:GetRole(uid)
    if self.roleEntities == nil then
        self.roleEntities = {}
    end
    local re = self.roleEntities[uid]
    return re
end
---@param role RoleEntity
function RoleManager:InitSelfRole(role)
    self.role = role
    -- 尝试注册状态的监听

    self:SetEnergy(role.role.initial_energy, role.role.max_energy)
end
-- 初始化角色并自定义能量
function RoleManager:InitSelfRoleWithEnergy(role, energy,maxEnergy)
    self.role = role
    self:SetEnergy(energy, maxEnergy)
end

function RoleManager:GetRoleByFaction(factionName)
    if factionName == nil then
        g_LogError("没有这个阵营的角色: nil")
        return
    end

    for k, v in pairs(self.data.role) do
        if v.faction == factionName then
            return v
        end
    end

    g_LogError("没有这个阵营的角色: " .. factionName)
    return nil
end

function RoleManager:GetSkillButton(id)
    return self.data["skill_button"][id]
end
function RoleManager:ReBuildButtons(cb)

    if self.skillButtons ~= nil then
        for k, v in pairs(self.skillButtons) do
            GameObject.Destroy(v.go)
        end
    end
    self.skillButtons = {}

    self.joystickService.joyPanel.jumpETCButton.anchorOffet = Vector2(78.52, 134.7)
    local jumpparent = self.joystickService.joyPanel.jumpETCButton.transform.parent

    local idx = 0
    local positions = {
        [1] = Vector2(-230, 82),
        [2] = Vector2(-324, 185),
        [3] = Vector2(-293, 315),
        [4] = Vector2(-167, 370)
    }
    local assetPath = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/ui/skill/skillbutton.prefab"

    ResourceManager:LoadGameObjectWithExName(assetPath, function(asset)
        -- 技能按键列表
        for k, v in pairs(self.role.role.skills) do

            -- 轮转技能按钮
            ---@type SkillButton
            local skillbutton = self:GetSkillButton(v) -- 初始化第一个
            ---@type Skill
            local skillData = nil
            ---@type boolean
            local isShowAim = false
            idx = idx + 1
            local pos = positions[idx]

            local coolDuration = nil

            local canUse = true
            local canActicve = true

            local btn = GameObject.Instantiate(asset, jumpparent)
            btn:SetActive(false)
            local button = btn:GetComponent(typeof(CS.UnityEngine.UI.Button))
            -- 设置图标
            local rectTransform = btn.transform:GetComponent(typeof(CS.UnityEngine.RectTransform))
            rectTransform.anchoredPosition = pos
            btn.transform.localScale = Vector3.one * 1
            local cdT = btn.transform:Find("cdT"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
            local cool = btn.transform:Find("cd").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
            local image = btn:GetComponent(typeof(CS.UnityEngine.UI.Image))

            local initButton = function()
                skillData = self.skillManager:GetSkill(skillbutton.skill)
                if skillData == nil then
                    g_LogError("没有这个技能数据:" .. skillbutton.skill)
                    return
                end
                btn:SetActive(true)
                isShowAim = skillbutton.show_aim
                local ago = assetsMap:GetAssetGo(skillbutton.asset_id)
                local icon = ago:GetComponentInChildren(typeof(CS.UnityEngine.UI.Image)).sprite
                btn:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite = icon
                coolDuration = skillData.cd
                canUse = true
                canActicve = true

                cdT.gameObject:SetActive(false)
                cool.fillAmount = 0;
                image.color = Color(1, 1, 1, 1)
            end
            initButton()

            -- 注册点击事件

            local trigger = btn:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))



            for i = 1, 3, 1 do
                if btn.transform:Find("pop" .. i) then
                    btn.transform:Find("pop" .. i).gameObject:SetActive(false)
                end
            end
            


            local skillButtonItem = {}

            local c1 = nil
            local c2 = nil

            local collDown = function(duration)
                -- 按钮冷却

                if duration == 0 then

                    return
                end
                cdT.gameObject:SetActive(true)
                image.color = Color(1, 1, 1, 0.5)
                canUse = false
                c1 = self:StartCoroutine(function()
                    cool.fillAmount = 1;
                    local time = 0

                    while time <= duration do
                        time = time + Time.deltaTime
                        cool.fillAmount = (duration - time) / duration
                        self:YieldEndFrame()
                    end
                    canUse = true
                    cdT.gameObject:SetActive(false)

                    if canActicve == true then
                        image.color = Color(1, 1, 1, 1)
                    end
                end)

                c2 = self:StartCoroutine(function()
                    local second = duration
                    while second > 0 do
                        cdT.text = tostring(math.max(math.floor(second), 0))
                        self:YieldSeconds(1)
                        second = second - 1
                    end
                end)
            end

            local cancelCoolDown = function()
                if c1 then
                    self:StopCoroutineSafely(c1)
                end
                if c2 then
                    self:StopCoroutineSafely(c2)
                end
            end

            local downHandle = function()

                if canUse == false then
                    return
                end

                if canActicve == false then
                    self:EnergyNotEnough()
                    return
                end

                if isShowAim then
                    -- aim 瞄准模式
                    self:ShowAim(skillbutton.skill)
                end

            end

            local upHandle = function()

                -- 冷却中
                if canUse == false then
                    return
                end

                if canActicve == false then
                    if isShowAim then
                        if self.isAiming ~= true then
                            -- 没有瞄准
                            self:EnergyNotEnough()
                            return
                        end
                    else
                        -- 没有瞄准
                        self:EnergyNotEnough()
                        return
                    end
                    -- 是瞄准按钮且在瞄准中，放行
                end

                if isShowAim then
                    if self.aimCancelActive == true then
                        self:HideAim()
                        -- 取消技能
                        return
                    else
                        self:HideAim()
                    end
                end
                local res = self.skillManager:Use(App.Uuid, skillData.id)
                if res and (res.code == 0 or res.code == 2) then
                    collDown(coolDuration)
                end

            end

            if isShowAim == true then
                trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerDown, function(data)
                    self.aimScreenPostion = data.position
                    downHandle()
                end)

                trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerUp, function(data)
                    upHandle()
                end)
                trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.BeginDrag, function(data)
                    self.canRotateSelfAvatar = true
                end)
                trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.EndDrag, function(data)
                    self.canRotateSelfAvatar = false
                end)
                trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.Drag, function(data)
                    self.aimScreenPostion = data.position
                end)

            else
                trigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerClick, function(data)
                    upHandle()
                end)
            end

            skillButtonItem.go = btn
            skillButtonItem.cancel = cancelCoolDown

            skillButtonItem.onEnergyChanged = function(eg)
                if eg < skillData.cost then
                    canActicve = false
                    image.color = Color(1, 1, 1, 0.5)
                else
                    canActicve = true
                    if canUse then
                        image.color = Color(1, 1, 1, 1)
                    end
                end

            end

            -- 如果自己的角色已经初始化，这里要初始化按钮的能量
            if self.role ~= nil then
                skillButtonItem.onEnergyChanged(self.Energy)
            end

            skillButtonItem.changeButton = function(id, cd)
                skillButtonItem.cancel()
                skillbutton = self:GetSkillButton(id)
                initButton()
                -- 走一个切换冷却

                -- 这里要判断一下这个技能的内置cd 是否大于当前cd，取一个较大的，做为冷却时间

                local skillInnerCdEntity = self.skillManager:GetCDEntity(App.Uuid, skillbutton.skill)
                if skillInnerCdEntity ~= nil then
                    -- cd中
                    if skillInnerCdEntity.time > cd then
                        collDown(skillInnerCdEntity.time)
                    else
                        collDown(cd)
                    end
                else
                    collDown(cd)
                end

            end
            table.insert(self.skillButtons, skillButtonItem)

            if idx == #positions then
                -- 最后一个，设置info
                self.buttonStatus = "1,1,1,1"
            end
        end

        if cb then
            cb()
        end
    end)

end
function RoleManager:ShowSkillButtons(rebuild, cb)
    if self.skillButtons == nil or rebuild == true then
        self:ReBuildButtons(cb)
    else
        self:SwitchButtons("1,1,1,1")
    end

end
function RoleManager:HideSkillButtons()
    self:SwitchButtons("0,0,0,0")

end

function RoleManager:Tick()
    if self.isAiming then
        -- 帧模拟
        self:SimulateTrajectory()
        self:RotateSelfAvatar()
    else
        if self.ghostBall ~= nil then
            GameObject.Destroy(self.ghostBall)
            self.ghostBall = nil
        end
    end
end
function RoleManager:CalculateVelocity(velocity, increment)
    velocity = velocity + Physics.gravity * increment;
    return velocity;
end
function RoleManager:GetRoleWithGo(go)
    for k, v in pairs(self.roleEntities) do
        if v.isAvatar then
            local avatar = v:GetAvatar()
            if avatar then
                if avatar.VisElement.gameObject == go then
                    return v
                end
                if go.transform:IsChildOf(avatar.VisElement.transform) then
                    return v
                end
            end

        else
            if go.transform:IsChildOf(v:GetTransform()) then
                return v
            end
        end
    end

    return nil
end
function RoleManager:RotateSelfAvatar()
    if self.canRotateSelfAvatar ~= true then
        return
    end
    self.aimJoy.transform.position = self:GetScreenPosition()
    local start = self.aimCenter
    local endPos = self.aimJoy.transform.position
    local direction = endPos - start;

    local angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg
    local r = self.avatarService.selfAvatar.LookRotation.transform.eulerAngles.y
    angle = r - angle + 90
    self.avatarService.selfAvatar.BodyTrans.rotation = Quaternion.Euler(0, angle, 0)
end
function RoleManager:SimulateTrajectory()

    local avatarTrasform = self.avatarService.selfAvatar.character.transform
    local start = avatarTrasform.position

    ---@type Bullet
    local bullet = self.curBullet
    start = start + avatarTrasform.forward * bullet.offset.z + avatarTrasform.up * bullet.offset.y +
                avatarTrasform.right * bullet.offset.x
    local velocity =
        avatarTrasform.forward * bullet.speed.z + avatarTrasform.up * bullet.speed.y + avatarTrasform.right *
            bullet.speed.x;
    local maxPoints = 100
    local array = {}
    local position = start

    -- TODO 根据子弹碰撞规则过滤

    for i = 1, maxPoints, 1 do
        if i ~= 1 then
            velocity = self:CalculateVelocity(velocity, Time.fixedDeltaTime);
            position = position + velocity * Time.fixedDeltaTime;
        end

        local colliders = Physics.OverlapSphere(position, bullet.size[1] * 0.5);
        local isValidCollision = false
        if colliders.Length > 0 then
            for i = 0, colliders.Length - 1, 1 do
                local collider = colliders[i]
                local isValid = self.skillManager:IsBulletCollider(bullet.collision_detection_camp, App.Uuid, nil,
                    collider)
                if isValid == true then
                    isValidCollision = true
                end
            end

            if isValidCollision == true then
                table.insert(array, position)
                break
            end
        end

        table.insert(array, position)

    end
    self.aimBoom.transform.position = array[#array]
    self.aimLinerenderer.positionCount = #array
    self.aimLinerenderer:SetPositions(array)

end
function RoleManager:HideAim()
    if self.aimPanelPrepared == true then
        self.aimPanel:SetActive(false)
        self.aimCancel:SetActive(false)
        self.aimCancelActive = false

        self.aimPanel:GetComponent(typeof(CS.UnityEngine.UI.Image)).color = Color(1, 1, 1, 1)
        self.aimCancel:GetComponent(typeof(CS.UnityEngine.UI.Image)).color = Color(1, 1, 1, 1)

        self.aimBoom:SetActive(false)
        self.aimLine:SetActive(false)
        self.aimJoy:SetActive(false)
        self.aimLinerenderer.positionCount = 0
        self.avatarService.selfAvatar.LockRotate = false

    else
        -- 没有准备好，阻止加载回调的自动显示
        self.aimShowBlock = true
    end
    self.isAiming = false
    self.eventEmitter:emit("OnAimHide", self.curBullet)
end
function RoleManager:OnAimHide(callback)
    self.eventEmitter:on("OnAimHide", callback)
end
function RoleManager:OnAimShow(callback)
    self.eventEmitter:on("OnAimShow", callback)
end
function RoleManager:ShowAim(skillData)

    local _showAim = function()
        self.isAiming = true
        self.aimPanel:SetActive(true)
        self.aimCancel:SetActive(true)

        self.aimBoom:SetActive(true)
        self.aimLine:SetActive(true)
        self.aimJoy:SetActive(true)

        self.avatarService.selfAvatar.LockRotate = true

        local pos = self:GetScreenPosition()
        self.aimJoy.transform.position = pos
        self.aimPanel.transform.position = Vector3(pos.x, pos.y + 10, pos.z)
        self.aimCenter = Vector3(pos.x, pos.y - 30, pos.z)

        self.curBullet = self.skillManager:GetBulletFromSkill(skillData)
        -- TODO 设置球尺寸
        self.aimBoom.transform.localScale = Vector3.one * self.curBullet.aoe_range

        self.eventEmitter:emit("OnAimShow", self.curBullet)
    end
    if self.aimPanelPrepared == true then
        _showAim()
        return
    end
    if self.aimPanelPreparing == true then
        return
    end
    self.aimPanelPreparing = true

    self.aimPanelPrepared = false
    self.aimShowBlock = false

    local assetPath = "modules/" .. RESOURCE_LOC .. "/assets/gameplay/Prefabs/skillAim.prefab"
    ResourceManager:LoadGameObjectWithExName(assetPath, function(go)

        local root = GameObject.Instantiate(go)

        self.aimPanel = root.transform:Find("Canvas/aimPanel").gameObject
        self.aimPanel:SetActive(false)
        local rect = self.aimPanel:GetComponent(typeof(CS.UnityEngine.RectTransform))
        local panelImg = self.aimPanel:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.aimPanel.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        rect.sizeDelta = Vector2(150, 150)
        rect.localScale = Vector3.one
        panelImg.color = Color(1, 1, 1, 1)

        self.aimCancel = root.transform:Find("Canvas/aimCancel").gameObject
        self.aimCancel:SetActive(false)
        local rect = self.aimCancel:GetComponent(typeof(CS.UnityEngine.RectTransform))
        local cancelImage = self.aimCancel:GetComponent(typeof(CS.UnityEngine.UI.Image))

        self.aimCancel.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        -- rect.anchoredPosition = Vector2(10, 10)
        rect.sizeDelta = Vector2(100, 100)
        rect.localScale = Vector3.one

        self.aimJoy = root.transform:Find("Canvas/aimJoy").gameObject
        self.aimJoy:SetActive(false)
        self.aimJoy.transform:SetParent(CS.Com.Tal.Unity.UI.UIManager.S.BaseCanvas.transform)
        self.aimJoy:GetComponent(typeof(CS.UnityEngine.UI.Image)).raycastTarget = false

        self.aimCancelTrigger = self.aimCancel:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
        self.aimCancelTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerEnter, function(data)
            panelImg.color = Color(1, 0, 0, 1)
            cancelImage.color = Color(1, 0, 0, 1)
            self.aimCancelActive = true
        end)
        self.aimCancelTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerExit, function(data)
            panelImg.color = Color(1, 1, 1, 1)
            cancelImage.color = Color(1, 1, 1, 1)
            self.aimCancelActive = false
        end)

        self.aimCancelActive = false

        self.aimBoom = root.transform:Find("dingweiqiu").gameObject
        self.aimBoom.transform:SetParent(nil)
        self.aimBoom.transform.localScale = Vector3.one
        self.aimBoom:SetActive(false)

        local collider = self.aimBoom:GetComponentsInChildren(typeof(CS.UnityEngine.Collider))
        for i = 0, collider.Length - 1, 1 do
            collider[i].enabled = false
        end

        self.aimLine = root.transform:Find("dingweixian").gameObject
        self.aimLinerenderer = self.aimLine:GetComponent(typeof(CS.UnityEngine.LineRenderer))
        self.aimLine.transform:SetParent(nil)
        self.aimLine.transform.localScale = Vector3.one
        self.aimLine:SetActive(false)
        self.aimLinerenderer.useWorldSpace = true
        self.aimLinerenderer.positionCount = 0

        GameObject.Destroy(root)
        -- 创建模拟
        self.aimPanelPrepared = true
        if self.aimShowBlock == false then
            _showAim()
        end

    end)

end
function RoleManager:GetScreenPosition()
    local pos = self.aimScreenPostion
    return Vector3(pos.x, pos.y, 0);
end

function RoleManager:GetEnergy()
    return self.Energy
end
function RoleManager:SetEnergy(value, max)
    if max ~= nil then
        self.MaxEmergy = max;
    end
    self.Energy = math.max(0, value)
    self.Energy = math.min(self.Energy, self.MaxEmergy)
    self.eventEmitter:emit("onEnergyChanged", self.Energy)
end
function RoleManager:AddEnergy(value)
    if value == 0 then
        return
    end
    if self.Energy == nil then
        return
    end
    self:SetEnergy(self.Energy + value)
end
-- 自己能量变化，能量是本地数据
function RoleManager:OnEnergyChanged(callback)
    self.eventEmitter:on("onEnergyChanged", callback)
end

function RoleManager:GetHealth(uuid)
    local role = self:GetRole(uuid)
    if role == nil then
        g_LogError("没有这个角色:" .. uuid)
        return 0
    end
    return role.health
end
function RoleManager:SetHealth(uuid, health)
    local role = self:GetRole(uuid)
    if role == nil then
        return
    end
    role.health = health

    if role.isAvatar == true then
        self:SendCustomMessage(SetHealthKey, {
            uid = uuid,
            v = {
                h = health,
                i_h = role.role.initial_health,
                m_h = role.role.max_health
            }
        })
    else
        self:LocalSetHealth({
            uid = uuid,
            v = {
                h = health,
                i_h = role.role.initial_health,
                m_h = role.role.max_health
            }
        })
    end

end
function RoleManager:AddHealth(value, list, isLocal, extra)

    if isLocal ~= true then
        -- avatar造成的混合伤害
        local data = {
            add = value,
            ps = {},
            extra = extra
        }
        local localData = {
            add = value,
            ps = {}
        }
        for _, v in pairs(list) do
            local roleEntity = self:GetRole(v)
            if roleEntity then
                local _d = {
                    uid = v,
                    v = {
                        i_h = roleEntity.role.initial_health,
                        m_h = roleEntity.role.max_health
                    }
                }
                if roleEntity.isAvatar then
                    table.insert(data.ps, _d)
                else
                    table.insert(localData.ps, _d)
                end
            end

        end
        if #data.ps > 0 then
            self:SendCustomMessage(AddHealthKey, data)
        end
        if #localData.ps > 0 then
            self:LocalAddHealth(localData)
        end
    else
        -- 非avatar造成的伤害

        local localData = {
            add = value,
            ps = {}
        }
        for _, v in pairs(list) do
            local roleEntity = self:GetRole(v)
            if roleEntity then
                local _d = {
                    uid = v,
                    v = {
                        i_h = roleEntity.role.initial_health,
                        m_h = roleEntity.role.max_health
                    }
                }
                table.insert(localData.ps, _d)
            end

        end

        if #localData.ps > 0 then
            self:LocalAddHealth(localData)
        end
    end

end
function RoleManager:LocalAddHealth(data)
    local add = data.add

    if add == 0 or add == nil then
        return
    end
    local changedList = {}
    for _, v in pairs(data.ps) do
        local roleEntity = self:GetRole(v.uid)
        local value = roleEntity.health + add
        if value > roleEntity.role.max_health then
            value = roleEntity.role.max_health
        end
        if value < 0 then
            value = 0
        end
        changedList[v.uid] = value
    end

    self:RolesHealthChanged(changedList)
end
function RoleManager:LocalSetHealth(data)
    -- local data = {
    --     uid = uuid,
    --     v = {
    --         h = health,
    --         i_h = role.role.initial_health,
    --         m_h = role.role.max_health
    --     }
    -- }

    local roleEntity = self:GetRole(data.uid)
    local changedList = {}
    local value = data.v.h
    if value > roleEntity.role.max_health then
        value = roleEntity.role.max_health
    end
    if value < 0 then
        value = 0
    end
    changedList[data.uid] = value
    self:RolesHealthChanged(changedList)
end
function RoleManager:OnRolesHealthChanged(callback)
    self.eventEmitter:on("OnRolesHealthChanged", callback)
end
function RoleManager:RolesHealthChanged(data)

    for k, v in pairs(data) do
        local re = self:GetRole(k)
        if re then
            re.health = v
        end
    end
    self.eventEmitter:emit("OnRolesHealthChanged", data)
end

function RoleManager:SwitchButtons(info)
    if self.skillButtons == nil then
        g_LogError("技能按钮未初始化")
        return
    end

    self.buttonStatus = info

    local status = string.split(self.buttonStatus, ",")
    for k, v in pairs(status) do
        local btn = self.skillButtons[k]
        if btn then
            if v == "1" then
                self.skillButtons[k].go:SetActive(true)
            else
                self.skillButtons[k].go:SetActive(false)
            end
        end

    end
end
function RoleManager:ChangeSkillButton(info)

    local cd = tonumber(info.cd)
    local idx = tonumber(info.idx)
    local id = info.id

    if self.skillButtons[idx] == nil then
        g_LogError("按钮不存在.." .. id)
        return
    end
    self.skillButtons[idx].changeButton(id, cd)
end

function RoleManager:OnEnergyNotEnough(callback)
    self.eventEmitter:on("OnEnergyNotEnough", callback)
end
function RoleManager:EnergyNotEnough(callback)
    self.eventEmitter:emit("OnEnergyNotEnough")
end
function RoleManager:ReceiveMessage(key, value, isResume)
    -- TODO:
    if key == RoleHealthChangedResKey then
        -- 全量血量表
        local msg = self.jsonService:decode(value[#value])
        -- role:
        self:RolesHealthChanged(msg)
    end

end

function RoleManager:HasAvatarRole()
    local has = false
    for k, v in pairs(self.roleEntities) do
        if v.isAvatar == true then
            has = true
            break
        end
    end

    return has
end
function RoleManager:HasNonAvatarRole()
    local has = false
    for k, v in pairs(self.roleEntities) do
        if v.isAvatar == false then
            has = true
            break
        end
    end
    return has
end
function RoleManager:GetNearestEnemy(uid, dis)
    local re = self:GetRole(uid)
    if re == nil then
        g_LogError("没有这个角色:" .. uid)
        return
    end
    local selfFaction = re.role.faction
    local enemies = self:GetAllEnemies(uid)

    local minDis = 999
    if dis ~= nil and dis > 0 then
        minDis = dis
    end
    local target = nil
    for k, v in pairs(enemies) do
        local dis = Vector3.Distance(re:GetTransform().position, v:GetTransform().position)
        if dis < minDis then
            minDis = dis
            target = v
        end
    end

    return target
end
function RoleManager:GetNearestEnemyWithFaction(selfUid, selfFaction, selfGo, dis)
    local enemies = self:GetAllEnemiesWithFaction(selfFaction)

    local minDis = 999
    if dis ~= nil and dis > 0 then
        minDis = dis
    end
    local target = nil
    for k, v in pairs(enemies) do
        if v.uid ~= selfUid and v:GetTransform() ~= nil then
            local dis = Vector3.Distance(selfGo.transform.position, v:GetTransform().position)
            if dis < minDis then
                minDis = dis
                target = v
            end
        end
    end

    return target

end
---@return RoleEntity[]
function RoleManager:GetAllEnemies(uid)
    local re = self:GetRole(uid)
    if re == nil then
        g_LogError("没有这个角色:" .. uid)
        return
    end
    local selfFaction = re.role.faction
    local _enemies = self:GetAllEnemiesWithFaction(selfFaction)

    local enemies = {}
    for k, v in pairs(_enemies) do
        if v.uid ~= uid then
            table.insert(enemies, v)
        end
    end
    return enemies
end
---@return RoleEntity[]
function RoleManager:GetAllEnemiesWithFaction(factionName)
    local selfFaction = factionName
    local enemies = {}
    for k, v in pairs(self.roleEntities) do
        local _re = self:GetRole(k)
        local targetFaction = _re.role.faction
        local isEnemy = faction:IsEnemy(selfFaction, targetFaction)
        if isEnemy then
            table.insert(enemies, _re)
        end
    end

    return enemies
end
---@return RoleEntity[]
function RoleManager:GetAllFriendsWithFaction(factionName)
    local selfFaction = factionName
    local _roles = {}
    for k, v in pairs(self.roleEntities) do
        local _re = self:GetRole(k)
        local targetFaction = _re.role.faction
        local isEnemy = faction:IsEnemy(selfFaction, targetFaction)
        if not isEnemy then
            table.insert(_roles, _re)
        end
    end

    return _roles
end
function RoleManager:GetAllRoles()
    if self.roleEntities == nil then
        self.roleEntities = {}
    end
    return self.roleEntities
end

---@return RoleEntity[]
function RoleManager:GetAllFriends(uid)
    local re = self:GetRole(uid)
    if re == nil then
        g_LogError("没有这个角色:" .. uid)
        return
    end
    local selfFaction = re.role.faction
    local _enemies = self:GetAllFriendsWithFaction(selfFaction)

    local enemies = {}
    for k, v in pairs(_enemies) do
        if v.uid ~= uid then
            table.insert(enemies, v)
        end
    end
    return enemies
end
local RoleInstance = RoleManager:new()
return RoleInstance
