local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class ScreenshotHelper : WorldBaseElement
local ScreenshotHelper = class("ScreenshotHelper", WBElement)

function ScreenshotHelper:initialize(worldElement)
    ScreenshotHelper.super.initialize(self, worldElement)
    self.canScrrenshot = false
    --是否为ABCZone
    self.isABC = App.modPlatformId == MOD_PLATFORM.ABCZone
    if not self.isABC then
        g_Log("非ABCZone平台，暂不支持系统截图")
        return
    end

    self.isFinishNewbieTask = false
    self.isOpenAddiction = false

    self:AddNativeBridges()
    self:AddEventListeners()


    --- 当前是否为 ABCZone 主场景
    local canJumpSchool = App:IsAbcZoneMain()
    g_Log("【系统截图Helper】收到 app.buss.friend.canJumpSchool：",canJumpSchool)
    APIBridge.RequestAsync("app.buss.friend.canJumpSchool", {
        enable = canJumpSchool
    })

    g_Log("【系统截图Helper】收到 unity.buss.friend.canScrrenshot:",self:CanScrrenshot())
    APIBridge.RequestAsync("app.buss.friend.canScrrenshot", self:BuildRequestParams())
end

function ScreenshotHelper:AddNativeBridges()
    --- 收到跳转校园通知
    APIBridge.CreateService("unity.buss.friend.jumpAddSchool", {}, function(res)
        g_Log("【系统截图Helper】收到 unity.buss.friend.jumpAddSchool")
        self:ShowJoinSchoolPanel()
    end)
    --- 是否可以跳转校园
    APIBridge.CreateService("app.buss.friend.canJumpSchool", {}, function(res)
        --- 当前是否为 ABCZone 主场景
        local canJumpSchool = App:IsAbcZoneMain()
        g_Log("【系统截图Helper】收到 app.buss.friend.canJumpSchool：",canJumpSchool)
        APIBridge.RequestAsync("app.buss.friend.canJumpSchool", {
            enable = canJumpSchool
        })
    end)
    --- 收到是否可以截图
    APIBridge.CreateService("app.buss.friend.canScrrenshot", {}, function(res)
        g_Log("【系统截图Helper】收到 unity.buss.friend.canScrrenshot:",self:CanScrrenshot())
        APIBridge.RequestAsync("app.buss.friend.canScrrenshot", self:BuildRequestParams())
    end)
end

---构造Request参数
function ScreenshotHelper:BuildRequestParams()
    if App:IsAbcZoneMain() then
        return {
            enable = self:CanScrrenshot()
        }
    else
        return {
            enable = self:CanScrrenshot(),
            mapType = HOME_CONFIG_INFO and HOME_CONFIG_INFO.MapType or "",
            mapId = HOME_CONFIG_INFO and HOME_CONFIG_INFO.MapId or "",
            userId = App.Info.userId or "",
            unionId = App.Properties.UnionId or ""
        }
    end
end

function ScreenshotHelper:ShowJoinSchoolPanel()
    self.observerService:Fire("EVENT_NEED_SHOW_JOIN_SCHOOL_PANEL")
    ---检测是否可以打开H5校园主页
    self.observerService:Fire("ABCZONE_CHECK_SUPPORT_H5_CIRCLE_OF_FRIENDS", {
        checkCallback = function(canOpenH5School)
            self.canOpenH5School = canOpenH5School
            -- 不支持打开H5校园主页，则打开Unity校园主页
            if not canOpenH5School then
                --- 第一步需要隐藏下 聊天区
                self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = false })
                self.observerService:Fire("EVENT_SCHOOL_TOURNAMENT_OPNE_JOIN_PANEL", {
                    schoolSimpleData = {
                        isFrom3D = false
                    },
                    openType = "green",
                    isNewSchoolEnter = true,
                    fromPage = "0",
                    from = "join_school_screenshot",
                    saveCallback = function()
                        --- 第二步 需要打开聊天区
                        self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = true })
                    end
                })
            else
                -- 支持打开H5校园主页，则打开H5校园主页
                local source = 1004004
                self.observerService:Fire("ABCZONE_OPEN_H5_SCHOOL", {
                    source = source,
                    webDidOpenCallback = function()
                        g_Log("H5-打开校园加入页面")
                        --屏蔽聊天区
                        self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = false })
                    end,
                    webDidCloseCallback = function()
                        g_Log("H5-关闭校园加入页面....webDidCloseCallback")
                        --开启聊天区
                        self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = true })
                    end,
                })
            end
        end
    })
end

function ScreenshotHelper:CanScrrenshot()
    if App:IsAbcZoneMain() then
        ---完成新手引导 且 眼保健操未开启
        return self.isFinishNewbieTask and not self.isOpenAddiction
    end
    -- 眼保健操未开启
    return not self.isOpenAddiction
end

function ScreenshotHelper:AddEventListeners()
    ---监听新手引导完成状态
    self.observerService:Watch("EVENT_NEWBIE_TASK_ALL_COMPLETE", function(key, value)
        self.isFinishNewbieTask = true
        g_Log("【系统截图Helper】收到 EVENT_NEWBIE_TASK_ALL_COMPLETE")
        APIBridge.RequestAsync("app.buss.friend.canScrrenshot", self:BuildRequestParams())
    end)
    ---监听眼保健操状态
    self.isOpenAddiction = false
    self.observerService:Watch("ANTI_ADDICTION_STATE_BROADCAST", function(key, value)
        local data = value[0]
        if data then
            self.isOpenAddiction = data.open
            g_Log("【系统截图Helper】收到 ANTI_ADDICTION_STATE_BROADCAST")
            APIBridge.RequestAsync("app.buss.friend.canScrrenshot", self:BuildRequestParams())
        end
    end)

    --- 唤起Native截图分享
    self.observerService:Watch("EVENT_SCREENSHOT_SHARE", function(key, value)
        APIBridge.RequestAsync("app.api.screenshot.start", {})
    end)

end

function ScreenshotHelper:isHome()
    return App:IsHome()
end

function ScreenshotHelper:isMap()
    return HOME_CONFIG_INFO and HOME_CONFIG_INFO.MapType and HOME_CONFIG_INFO.MapId
end


return ScreenshotHelper
