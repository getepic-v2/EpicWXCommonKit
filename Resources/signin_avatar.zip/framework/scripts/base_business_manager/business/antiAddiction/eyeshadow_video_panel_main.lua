---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-5-13 15:34:40】
--- 【FSync】
--- 【护眼视频播放UI】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

if CS.System.IO ~= nil then
    ---@type CS.System.IO.File
    File = CS.System.IO.File
else
    File = CS.XLua.CustomExtensions.CustomSystemFile
end

---@type CS.UnityEngine.Sprite
local Sprite = CS.UnityEngine.Sprite
---@type CS.UnityEngine.Screen
local Screen = CS.UnityEngine.Screen
---@type CS.UnityEngine.Rect
local Rect = CS.UnityEngine.Rect
local Texture2D = CS.UnityEngine.Texture2D
---@type CS.UnityEngine.TextureFormat
local TextureFormat = CS.UnityEngine.TextureFormat
---@type CS.UnityEngine.RenderTexture
local RenderTexture = CS.UnityEngine.RenderTexture


--管控验证UI面板
local control_verification_panel = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/control_verification_panel")

--本地存储视频播放进度的key
local LOCAL_VIDEO_PROGRESS_KEY_MAIN = "LOCAL_VIDEO_PROGRESS_KEY_MAIN"

local eyeshadow_video_panel_main = class("eyeshadow_video_panel_main")

function eyeshadow_video_panel_main:Print(...)
    g_Log("【防沉迷护眼视频播放UI-Main】", ...)
end

function eyeshadow_video_panel_main:initialize(uipanel, callback)
    self.UIRoot = uipanel
    self.LoadCompleted = callback
    self:InitService()
    self:InitUI()

    -- 视频总时长
    self.vidoetotalTime = 160
    --总奖励最大值
    self.maxReward = 160
    --奖励间隔
    self.rewardInterval = 1
    if App.modPlatform == MOD_PLATFORM.Math then
        self.maxReward = 53
        self.rewardInterval = 3
    end
    --当前视频进度
    self.curPer = 0
    --上次保存的视频播放时间
    self.lastTime = 0
    --上一次播放进度
    self.lastProgress = 0
    --有效的奖励时间
    self.validTime = 0
    --是否正在播放
    self.playing = false
    --是否暂停
    self.isPause = false
    --是否播放完成
    self.playFinsih = false
    --是否触发兜底方案
    self.isReveal = false
    self.videoUrl = "https://static0.xesimg.com/next-studio-pub/app/1719370970162/vJ7dnFL60HX9ii6bukut.mp4"
    if not (App.IsStudioClient) then
        self.pluginJson = App.Info.plugins
        if self.pluginJson ~= nil and type(self.pluginJson) == "string" then
            -- log("开始动态资源相关配置")
            self:InitPluginInfo()
        end
    end
    --检测进度计数
    self.checkProgressCount = 0
    --视频是否下载完成
    self.isDownload = false
    -- 下载眼保健操视频
    self:DownloadVideo()

    --回调tb
    self.callFunTb = {}
end

function eyeshadow_video_panel_main:InitPluginInfo()
    local list = self.jsonService:decode(self.pluginJson)
    for _, v in pairs(list) do
        if v.pluginName == "ABC防沉迷场次配置" then
            xpcall(function()
                if v.pluginVal.videoURL then
                    self:Print("防沉迷眼保健操视频url", v.pluginVal.videoURL)
                    self.videoUrl = v.pluginVal.videoURL
                end
            end, function(err)

            end)
        end
    end
end

--下载存储眼保健操视频文件
function eyeshadow_video_panel_main:DownloadVideo()
    local md5 = CS.Com.Tal.Unity.Core.Utility.Md5Tools.ProcessMd5(self.videoUrl)
    local savePath = CS.UnityEngine.Application.persistentDataPath .. string.format("/%s.mp4", md5)
    if File.Exists(savePath) then
        self:Print("视频准备完成")
        self.isDownload = true
        self.videoPlayer.source = CS.UnityEngine.Video.VideoSource.Url
        self.videoPlayer.url = savePath
        return
    end
    local successCallback = function(data)
        self:Print("下载成功")
        File.WriteAllBytes(savePath, data)
        self:Print("savePath->", savePath)
        self.isDownload = true
        self.videoPlayer.source = CS.UnityEngine.Video.VideoSource.Url
        self.videoPlayer.url = savePath
    end
    local errorCallback = function(data)
        self:Print("下载失败")
    end

    --延迟下载视频--进入场景25分钟后开始下载视频防止一些用户进入场景后退出浪费流量
    self.commonService:DispatchAfter(60 * 25, function()
        self:Print("开始下载视频")
        self.httpService:GetByteRequest(self.videoUrl, {}, successCallback, errorCallback)
    end)
end

function eyeshadow_video_panel_main:InitUI()
    self.UIRoot.localPosition = Vector3.zero
    self.UIRoot.localScale = Vector3.one
    self.UIRoot.localRotation = Quaternion.identity
    local canvas = self.UIRoot:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
    canvas.sortingOrder = 10000
    self.UIRoot.gameObject:SetActive(false)
    self:InitUIComponent()

    if self.LoadCompleted then
        self.LoadCompleted()
    end
end

--初始化UI组件
function eyeshadow_video_panel_main:InitUIComponent()
    --获取视频播放控制组件
    self.videoImage = self.UIRoot:Find("diban/videoImage")
    self.videoImage.gameObject:SetActive(false)
    self.videoPlayer = self.videoImage:GetComponentInChildren(typeof(CS.UnityEngine.Video.VideoPlayer))
    self.RawImage = self.UIRoot:Find("diban/videoImage/RawImage")
    --完成背景
    self.completbg = self.UIRoot:Find("diban/bg").gameObject
    --完成奖励数量
    self.completbgNum = self.completbg.transform:Find("countLab").gameObject:GetComponent(typeof(CS.TMPro
        .TextMeshProUGUI))
    self.completbg.gameObject:SetActive(false)
    --任务完成音频
    self.rwwcAudio = self.UIRoot:Find("diban/rwwcAudio").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource))
    -- 关闭提示音频
    self.guanbiAudio = self.UIRoot:Find("guanbiAudio").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource))
    --获取进度条组件
    self.progressSlider = self.UIRoot:Find("Slider"):GetComponent(typeof(CS.UnityEngine.UI.Slider))
    --发光特效
    self.lightEffect = self.UIRoot:Find("Slider/Fill Area/Fill/texiao").gameObject
    self.lightEffect.gameObject:SetActive(false)

    --获取宝箱节点
    self.boxNode = self.UIRoot:Find("Slider/box").gameObject
    --获取宝箱动画
    self.boxAni = self.boxNode:GetComponent(typeof(CS.UnityEngine.Animator))

    self.SlideRt = self.UIRoot:Find("Slider").gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
    -- 钻石标识
    -- self.diamondAni = self.UIRoot:Find("Slider/zhuazuanshi").gameObject
    --获取倒计时、进度文字节点和资源
    --倒计时
    self.timeNode = self.UIRoot:Find("timeNode").gameObject
    self.timeNum1 = self.timeNode.transform:Find("timeNums/num1").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.timeNum2 = self.timeNode.transform:Find("timeNums/num2").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.timeNum3 = self.timeNode.transform:Find("timeNums/num3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.timeNum4 = self.timeNode.transform:Find("timeNums/num4").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))

    self.timeNumImages = {}
    local resNode1 = self.UIRoot:Find("resNode1")
    for i = 0, 9 do
        local sprite = resNode1:Find(i).gameObject:GetComponent(typeof(CS.UnityEngine.SpriteRenderer)).sprite
        self.timeNumImages[i] = sprite
    end

    --左侧数字
    self.perNode = self.UIRoot:Find("Slider/perNode").gameObject
    self.leftNum_ge = self.perNode.transform:Find("ge").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.leftNum_shi = self.perNode.transform:Find("shi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.leftNum_bai = self.perNode.transform:Find("bai").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.leftNumImages = {}
    local resNode2 = self.UIRoot:Find("resNode2")
    for i = 0, 9 do
        local sprite = resNode2:Find(i).gameObject:GetComponent(typeof(CS.UnityEngine.SpriteRenderer)).sprite
        self.leftNumImages[i] = sprite
    end

    --右侧数字
    self.rightNum_ge = self.perNode.transform:Find("t_ge").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.rightNum_shi = self.perNode.transform:Find("t_shi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.rightNum_bai = self.perNode.transform:Find("t_bai").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.rightNumImages = {}
    local resNode3 = self.UIRoot:Find("resNode3")
    for i = 0, 9 do
        local sprite = resNode3:Find(i).gameObject:GetComponent(typeof(CS.UnityEngine.SpriteRenderer)).sprite
        self.rightNumImages[i] = sprite
    end

    --兜底图片
    self.revealImage = self.UIRoot:Find("diban/revealImage").gameObject
    self.revealAudioSource = self.revealImage:GetComponent(typeof(CS.UnityEngine.AudioSource))

    --获取关闭按钮
    self.btn_close = self.UIRoot:Find("closeBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.btn_close, "onClick", function()
        --用户点击右上退出按钮 数据埋点
        if not App.IsStudioClient then
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_Exit", "888888",
                "continuous_Exit",
                "用户点击右上退出按钮", "0", {})
        end


        local completeCall = function(close)
            if close then
                --验证通过没有奖励
                self:VideoPlayFinish(0)
            else
                if not self.isReveal then
                    CS.UnityEngine.AudioListener.volume = 0
                end
                self:Resume()
            end
        end

        --暂停视频播放
        self:Pause()
        --播放提示音
        self.guanbiAudio:Play()
        if not self.control_verification_panel then
            self.control_verification_panel = control_verification_panel:new(self.UIRoot.parent.transform, completeCall,
                true)
        else
            self.control_verification_panel:Show(completeCall, true)
        end
    end)


    --监听app切入后台
    self.pauseFunction = function(pause)
        if pause then
            self:Print("用户进入后台")
        else
            self:Print("用户进入前台")
            if self.playing then
                --判断回来的时候视频是否播放完成
                if not self.isPause then --如果在暂停状态且后台保持原状
                    local progress, validTime, lastTimestamp = self:GetLocalVideoProgress()
                    local curTimestamp = os.time()
                    local addTime = curTimestamp - lastTimestamp
                    local addPer = addTime / self.vidoetotalTime

                    --用户进入时间 数据埋点
                    if not App.IsStudioClient then
                        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_Breakstart", "888888",
                            "continuous_Breakstart",
                            "用户进入时间", curTimestamp, {})
                    end

                    --用户退出了多少时间 数据埋点
                    if not App.IsStudioClient then
                        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_Breakleave", "888888",
                            "continuous_Breakleave",
                            "用户退出了多少时间", addTime, {})
                    end

                    if progress + addPer >= 0.99 then
                        --视频按照播放完毕计算
                        self:Print("切回后台时视频已经播放完毕->", validTime)
                        self:Print("切回后台时视频已经播放完毕-lastTimestamp->", lastTimestamp)
                        self:Print("切回后台时视频已经播放完毕-curTimestamp->", curTimestamp)
                        self:VideoPlayFinish(validTime, true)
                    else
                        --视频进度快进
                        local curPer = progress + addPer
                        local videoTime = self.vidoetotalTime * curPer
                        self.validTime = validTime
                        self.lastTime = videoTime

                        self:Print("切回后台时视频跳转到当前时间进度-1>", videoTime)
                        if self.isReveal then
                            --兜底模式
                            self.revealAudioSource.time = videoTime
                        else
                            --清理回调
                            self:ClearCallBack()
                            self.videoImage.gameObject:SetActive(false)
                            App:GetService("CommonService"):DispatchNextFrame(function()
                                self.videoImage.gameObject:SetActive(true)
                                --添加准备完成回调
                                local PrepareCall = function(source)
                                    --视频跳转到当前时间进度
                                    self.videoPlayer:Play()
                                    self.videoPlayer.time = videoTime
                                    self:Print("切回后台时视频跳转到当前时间进度-3>", self.videoPlayer.time)
                                end
                                --视频跳转准备工作
                                self.videoPlayer:prepareCompleted('+', PrepareCall)
                                table.insert(self.callFunTb, PrepareCall)
                                self.videoPlayer:Prepare()
                            end)
                        end
                        self:Print("切回后台时视频跳转到当前时间进度-2>", videoTime)
                    end
                end
            end
        end
    end

    self.commonService:DispatchAfter(1, function()
        if self.gate.worldController.World.OnApplicationPauseAction == nil then
            self.gate.worldController.World.OnApplicationPauseAction = self.pauseFunction
        else
            self.gate.worldController.World.OnApplicationPauseAction = self.gate.worldController.World
                .OnApplicationPauseAction + self.pauseFunction
        end
    end)
end

--获取本地存储的视频播放进度
function eyeshadow_video_panel_main:GetLocalVideoProgress()
    local progress, validTime, timestamp, isRevealValue = 0, 0, os.time(), 0
    if CS.UnityEngine.PlayerPrefs.HasKey(LOCAL_VIDEO_PROGRESS_KEY_MAIN .. App.Info.userId) then
        local progressStr = CS.UnityEngine.PlayerPrefs.GetString(LOCAL_VIDEO_PROGRESS_KEY_MAIN .. App.Info.userId)
        local progressArr = string.split(progressStr, ",")
        progress = tonumber(progressArr[1])
        validTime = tonumber(progressArr[2])
        timestamp = tonumber(progressArr[3])
        isRevealValue = tonumber(progressArr[4])
    end
    return progress, validTime, timestamp, isRevealValue
end

--本地存储视频播放进度
function eyeshadow_video_panel_main:SaveLocalVideoProgress()
    local isRevealValue = self.isReveal and 1 or 0
    local progressStr = self.curPer .. "," .. self.validTime .. "," .. os.time() .. "," .. isRevealValue
    CS.UnityEngine.PlayerPrefs.SetString(LOCAL_VIDEO_PROGRESS_KEY_MAIN .. App.Info.userId, progressStr)
    CS.UnityEngine.PlayerPrefs.Save()
end

--清空本地存储进度
function eyeshadow_video_panel_main:ClearLocalVideoProgress()
    CS.UnityEngine.PlayerPrefs.DeleteKey(LOCAL_VIDEO_PROGRESS_KEY_MAIN .. App.Info.userId)
    CS.UnityEngine.PlayerPrefs.Save()
end

--展示护眼提示
function eyeshadow_video_panel_main:Show(callback, isToDayToClaim)
    --打开眼保健操休息页上报 数据埋点
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_Startbreak_main", "888888",
            "continuous_Startbreak_main",
            "打开眼保健操休息页上报", "0", {})
    end

    --播放视频
    self.playing = true
    --检测进度计数
    self.checkProgressCount = 0
    self.lastTime = 0
    ---关uinity环境音
    CS.UnityEngine.AudioListener.volume = 0

    --完成回调
    self.CompleteCallback = callback

    self.UIRoot.gameObject:SetActive(true)

    --今日如果已经领取过奖励不显示盒子动效
    self.boxNode.gameObject:SetActive(not isToDayToClaim)
    self.perNode.gameObject:SetActive(not isToDayToClaim)
    self.completbgNum.gameObject:SetActive(not isToDayToClaim)
    self.completbg.transform:Find("Image (2)").gameObject:SetActive(not isToDayToClaim)
    self.SlideRt.anchoredPosition = isToDayToClaim and Vector2(791, -279.7) or Vector2(627.9, -279.7)
    --设置右侧数字
    if App.modPlatform == MOD_PLATFORM.Math then
        self.rightNum_ge.sprite = self.rightNumImages[3]
        self.rightNum_shi.sprite = self.rightNumImages[5]
        self.rightNum_bai.sprite = self.rightNumImages[0]
    else
        self.rightNum_ge.sprite = self.rightNumImages[0]
        self.rightNum_shi.sprite = self.rightNumImages[6]
        self.rightNum_bai.sprite = self.rightNumImages[1]
    end


    self.boxAni.enabled = true

    self.boxAni:SetBool("add", false)
    self.boxAni:SetBool("over", false)
    self.boxAni:Play("zhishifeiru", -1, 0)
    self.boxAni:SetBool("add", true)

    self.boxAni.speed = 1

    --播放视频
    local progress, validTime, timestamp, isRevealValue = self:GetLocalVideoProgress()
    self:Print("获取本地历史进度", progress, validTime, timestamp, isRevealValue)

    --极差机型或者视频没有准备好启动音频模式
    if App.IsUltraLowDevice or (not self.isDownload) then
        isRevealValue = 1
        self:Print("视频没有准备好启动音频模式")
    end

    --获取本地历史进度
    local videoTime = self.vidoetotalTime * progress
    self.validTime = validTime
    self.lastTime = videoTime

    self.progressSlider.value = progress
    self:UpdateCheeseProgress()

    self.completbg.gameObject:SetActive(false)

    if isRevealValue == 1 then
        self.revealImage.gameObject:SetActive(true)
        self.videoImage.gameObject:SetActive(false)
        self.revealAudioSource:Play()
        self.revealAudioSource.time = videoTime
        CS.UnityEngine.AudioListener.volume = 1
        self.isReveal = true
    else
        --显示视频播放节点
        self.videoImage.gameObject:SetActive(true)
        self.RawImage.gameObject:SetActive(false)
        self.revealImage.gameObject:SetActive(false)

        self:ClearCallBack()
        --添加准备完成回调
        local PrepareCall = function(source)
            self.RawImage.gameObject:SetActive(true)
            --从零开始播放视频
            if not self.isPause then
                self.videoPlayer:Play()
            end
            self.videoPlayer.time = videoTime
            self:Print("self.prepareCompleted->", self.videoPlayer.clip)
        end
        --视频跳转准备工作
        self.videoPlayer:Prepare()
        self.videoPlayer:prepareCompleted('+', PrepareCall)
        table.insert(self.callFunTb, PrepareCall)
    end
end

--清理回调
function eyeshadow_video_panel_main:ClearCallBack()
    for _, PrepareCall in pairs(self.callFunTb) do
        self.videoPlayer:prepareCompleted('-', PrepareCall)
    end
    self.callFunTb = {}
end

--暂停
function eyeshadow_video_panel_main:Pause()
    self.videoPlayer:Pause()
    if self.isReveal then
        self.revealAudioSource:Pause()
    end
    self.boxAni.speed = 0
    self.isPause = true
end

--继续
function eyeshadow_video_panel_main:Resume()
    self.videoPlayer:Play()
    if self.isReveal then
        self.revealAudioSource:Play()
    end
    self.boxAni.speed = 1
    self.isPause = false
end

--更新芝士获取进度UI
function eyeshadow_video_panel_main:UpdateCheeseProgress()
    local num_bai, num_shi, num_ge = self:extractDigits(self.validTime)

    self.leftNum_bai.gameObject:SetActive(self.validTime >= 100)
    self.leftNum_shi.gameObject:SetActive(self.validTime >= 10)

    self.leftNum_ge.sprite = self.leftNumImages[num_ge]
    self.leftNum_shi.sprite = self.leftNumImages[num_shi]
    self.leftNum_bai.sprite = self.leftNumImages[num_bai]
end

--设置明信片中的照片
---@param sprite CS.UnityEngine.Sprite
function eyeshadow_video_panel_main:SetFuzzyBgImageSprite(sprite)
    local image = self.fuzzyBg:GetComponent(typeof(CS.UnityEngine.UI.Image))
    if not IsNull(image.sprite) then
        CS.UnityEngine.Object.Destroy(image.sprite)
    end
    image.sprite = sprite
end

--通过 Texture2D 创建Sprite
---@param texture CS.UnityEngine.Texture2D
function eyeshadow_video_panel_main:TextureToSprite(texture)
    return Sprite.Create(texture, Rect(0, 0, texture.width, texture.height), Vector2(0.5, 0.5))
end

--更新视频播放时间进度UI
function eyeshadow_video_panel_main:UpdateVideoTime()
    local curTime = self.videoPlayer.time
    local totalTime = self.vidoetotalTime
    if self.isReveal then
        curTime = self.revealAudioSource.time
    end

    if not self.isReveal and not self.isPause then
        if curTime == self.lastProgress then
            self.checkProgressCount = self.checkProgressCount + 1
        else
            self.checkProgressCount = 0
        end
        if self.checkProgressCount > 100 then
            self.checkProgressCount = 0
            self:Print("视频播放进度异常")

            --上报眼保健操视频播放异常 数据埋点
            if not App.IsStudioClient then
                NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("AbnormalPlayOfTheRyeExerciseVideo",
                    "888888",
                    "AbnormalPlayOfTheRyeExerciseVideo",
                    "眼保健操视频播放异常", "0", {})
            end

            self.isReveal = true
            self.videoImage.gameObject:SetActive(false)
            self.revealImage.gameObject:SetActive(true)
            self.revealAudioSource:Play()
            self.revealAudioSource.time = curTime
            CS.UnityEngine.AudioListener.volume = 1
        end
    end
    --记录上一次播放进度
    self.lastProgress = curTime

    self.curPer = curTime / totalTime
    self.progressSlider.value = math.max(0.04, self.curPer)
    self.lightEffect.gameObject:SetActive(self.progressSlider.value > 0.16)
    local subTime = self.vidoetotalTime - curTime
    local num1, num2, num3, num4 = self:GetFormatNumber(math.max(math.ceil(subTime), 0))
    self.timeNum1.sprite = self.timeNumImages[num1]
    self.timeNum2.sprite = self.timeNumImages[num2]
    self.timeNum3.sprite = self.timeNumImages[num3]
    self.timeNum4.sprite = self.timeNumImages[num4]

    --每一秒更新一次保存本地一次
    if math.floor(curTime - self.lastTime) >= self.rewardInterval then
        self.lastTime = self.lastTime + self.rewardInterval
        self.validTime = math.min(self.validTime + 1, self.maxReward)
        --更新芝士获取进度
        self:UpdateCheeseProgress()
        --保存进度
        self:SaveLocalVideoProgress()
    end

    if curTime >= totalTime then
        if self.playFinsih then
            return
        end
        self.playFinsih = true
        self.boxAni:SetBool("add", false)
        self.boxAni:SetBool("over", true)
        if self.validTime >= 155 then
            self.validTime = 160
        end
        self:VideoPlayFinish(self.validTime, true)
    end
end

--视频播放完成
function eyeshadow_video_panel_main:VideoPlayFinish(validTime, needOpenGame)
    --视频播放节点
    self.videoImage.gameObject:SetActive(false)
    --隐藏兜底资源
    self.revealImage.gameObject:SetActive(false)
    self.boxAni:SetBool("add", false)
    self.boxAni:SetBool("over", false)


    self.playing = false
    self.playFinsih = false
    self.isReveal = false
    ---放开uinity环境音
    CS.UnityEngine.AudioListener.volume = 1
    self.isPause = false

    --发放奖励
    if validTime > 0 then
        self:Print("视频UI关闭奖励:", validTime)
        self.observerService:Fire("EVENT_MAIN_SCENE_ADD_REWARD", {
            reward = validTime,
            callBack = function()
                self:Print("调用服务端接口添加芝士成功->", validTime)
            end
        })
    end

    --清空本地存储进度
    self:ClearLocalVideoProgress()
    if self.CompleteCallback then
        self.CompleteCallback(validTime)
    end

    --播放兜底音频
    if needOpenGame then
        self.rwwcAudio.gameObject:SetActive(true)
        self.rwwcAudio:Play()
        self.completbg.gameObject:SetActive(true)
        self.completbgNum.text = "已获得" .. validTime

        self.commonService:DispatchAfter(3, function()
            self.rwwcAudio.gameObject:SetActive(false)
            self.UIRoot.gameObject:SetActive(false)
            --游戏开始
            self.observerService:Fire("EVENT_GAME_START_GOLD_MINER", {})
        end)
    else
        self.UIRoot.gameObject:SetActive(false)
    end
end

--tick
function eyeshadow_video_panel_main:Tick()
    if self.playing and not self.playFinsih and not self.isPause then
        self:UpdateVideoTime()
    end
end

--获取数字的个位、十位、百位
function eyeshadow_video_panel_main:extractDigits(num)
    -- 获取个位
    local units = num % 10

    -- 获取十位
    local tens = (num // 10) % 10

    -- 获取百位
    local hundreds = (num // 100) % 10

    return hundreds, tens, units
end

--获取时间数字格式
function eyeshadow_video_panel_main:GetFormatNumber(t_seconds)
    local num1, num2, num3, num4 = 0, 0, 0, 0

    if t_seconds <= 0 then
        num1 = 0
        num2 = 0
        num3 = 0
        num4 = 0
    else
        local minutes = math.floor((t_seconds % 3600) / 60)
        local seconds = t_seconds % 60
        num1 = math.floor(minutes / 10)
        num2 = minutes % 10
        num3 = math.floor(seconds / 10)
        num4 = seconds % 10
    end
    return num1, num2, num3, num4
end

function eyeshadow_video_panel_main:InitService()
    ---@type CommonService
    self.commonService            = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService              = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService              = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService          = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService            = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService             = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService                = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService            = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService             = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService          = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService             = CourseEnv.ServicesManager:GetDebugService()
    self.gate                     = CourseEnv.ServicesManager.Gate
    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

function eyeshadow_video_panel_main:Exit()
    self:ClearCallBack()
end

return eyeshadow_video_panel_main
