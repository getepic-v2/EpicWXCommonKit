---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-5-13 15:34:40】
--- 【FSync】
--- 【累计一小时提示H5】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/antiAddiction/"
local UIPrefabPath = ResourcePathRoot .. "assets/Prefabs/CumulativePromptPanel.prefab"
local audioPathRoot = ResourcePathRoot .. "audio/"
local TAG = "【累计一小时提示H5】"
local cumulative_prompt_panel = class("cumulative_prompt_panel")

function cumulative_prompt_panel:initialize(root, callback)
    self.root = root
    self.LoadCompleted = callback
    self.loadingCompleted = false
    self:InitService()
    self:InitUI()
end

function cumulative_prompt_panel:InitUI()
    ResourceManager:LoadGameObjectWithExName(UIPrefabPath, function(go)
        self.UIRoot = GameObject.Instantiate(go).transform
        self.UIRoot:SetParent(self.root.transform)
        self.UIRoot.localPosition = Vector3.zero
        self.UIRoot.localScale = Vector3.one
        self.UIRoot.localRotation = Quaternion.identity
        local canvas = self.UIRoot:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
        canvas.sortingOrder = 10002

        self.UIRoot.gameObject:SetActive(false)
        if self.LoadCompleted then
            self.LoadCompleted()
        end
        self.loadingCompleted = true
    end)
end

--展示累计一小时提示H5UI
function cumulative_prompt_panel:Show(url, callback)
    self.UIRoot.gameObject:SetActive(true)

    self.callback = callback

    ---关闭uinity环境音
    CS.UnityEngine.AudioListener.volume = 0

    local param = {}
    --- 全屏H5
    local normalizedPosition = { 0, 0, 1, 1 }
    param = {
        url = url,
        normalizedPosition = normalizedPosition,
        show_close_btn = false,
        clear_cache = false
    }

    self.openH5Ids = self.h5Service:OpenH5OnRoom(param, function(res)
        if res.event == "closeH5PageEvent" then
            g_Log(TAG, "h5调用关闭")

            self.UIRoot.gameObject:SetActive(false)
            self.openH5Ids = nil
        end
    end)
end

function cumulative_prompt_panel:Hide()
    self.UIRoot.gameObject:SetActive(false)
    if self.callback then
        self.callback()
    end

    ---关闭uinity环境音
    CS.UnityEngine.AudioListener.volume = 1

    if self.openH5Ids then
        self.h5Service:CloseH5OnRoom(self.openH5Ids)
        self.openH5Ids = nil
    end
    --恢复聊天区
    self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = true })
end

function cumulative_prompt_panel:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()

    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()

    ---@type H5Service
    self.h5Service = CourseEnv.ServicesManager:GetH5Service()
end

return cumulative_prompt_panel
