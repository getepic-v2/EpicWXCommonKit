---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-5-13 15:34:40】
--- 【FSync】
--- 【管控验证UI】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/antiAddiction/"
local UIPrefabPath = ResourcePathRoot .. "assets/Prefabs/VerifyPanel.prefab"
local audioPathRoot = ResourcePathRoot .. "audio/"

local control_verification_panel = class("control_verification_panel")

function control_verification_panel:initialize(root, callback, notPalyGuide)
    self.root = root
    self.CompleteCallback = callback
    self.loadingCompleted = false
    self.numMap = {}
    local items = { "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖" }
    for i = 1, #items do
        self.numMap[items[i]] = i
    end
    self:InitService()
    self:InitUI(notPalyGuide)

    self.isShow = false
end

function control_verification_panel:InitUI(notPalyGuide)
    ResourceManager:LoadGameObjectWithExName(UIPrefabPath, function(go)
        self.UIRoot = GameObject.Instantiate(go).transform
        self.UIRoot:SetParent(self.root.transform)
        self.UIRoot.localPosition = Vector3.zero
        self.UIRoot.localScale = Vector3.one
        self.UIRoot.localRotation = Quaternion.identity
        local canvas = self.UIRoot:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
        canvas.sortingOrder = 10001

        self.UIRoot.gameObject:SetActive(false)

        self.BtnPanel = self.UIRoot:Find("BtnPanel").gameObject
        self.tempItem = self.UIRoot:Find("tempBtn").gameObject
        self.timuLab = self.UIRoot:Find("timuLab").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.guideAudio = self.UIRoot:Find("Audio Source")
        self.guideAudio.gameObject:SetActive(false)
        self:InitUIComponent()

        self:Show(self.CompleteCallback, notPalyGuide)

        self.loadingCompleted = true
    end)

    --初始化提示音频
    --正确反馈音
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "正确反馈.mp3", function(audioclip)
        self.correctAudio = audioclip
    end)

    --错误反馈应
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "错误反馈.mp3", function(audioclip)
        self.errorAudio = audioclip
    end)
end

--初始化UI组件
function control_verification_panel:InitUIComponent()
    self.btn_close = self.UIRoot:Find("closeBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.btn_close, "onClick", function()
        self.isShow = false
        --输入密码点击关闭 数据埋点
        if not App.IsStudioClient then
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("control_verification_panel", "888888",
                "control_verification_panel",
                "输入密码点击关闭", "2", {})
        end
        self.UIRoot.gameObject:SetActive(false)
        if self.CompleteCallback then
            self.CompleteCallback(false)
        end
    end)
end

--展示护眼提示
function control_verification_panel:Show(callback, notPalyGuide)
    self.isShow = true
    ---放开uinity环境音
    CS.UnityEngine.AudioListener.volume = 1
    self.CompleteCallback = callback
    self.UIRoot.gameObject:SetActive(true)
    --播放引导动画
    self:ResetVerifyPanel(callback)
    --是否播放引导音频
    self.guideAudio.gameObject:SetActive(not notPalyGuide)
end

--强制关闭
function control_verification_panel:ForceClose()
    self.isShow = false
    self.UIRoot.gameObject:SetActive(false)
end

--重置验证题目
function control_verification_panel:ResetVerifyPanel(callback)
    local len = 3

    math.randomseed(os.time())

    local items = { "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖" }
    for i = #items, 2, -1 do
        local j = math.random(i)
        items[i], items[j] = items[j], items[i]
    end

    local resultIndexs = self:getRandomElements({ 1, 2, 3, 4, 5, 6, 7, 8, 9 }, len)

    self.resultItmes = {}
    for i = 1, #resultIndexs do
        self.resultItmes[i] = items[resultIndexs[i]]
    end

    local resultString = table.concat(self.resultItmes, ", ")

    self.timuLab.text = resultString

    for i = 0, self.BtnPanel.transform.childCount - 1 do
        CS.UnityEngine.Object.Destroy(self.BtnPanel.transform:GetChild(i).gameObject)
    end

    for i = 1, #items do
        local item = CS.UnityEngine.Object.Instantiate(self.tempItem, self.BtnPanel.transform)
        item.gameObject:SetActive(true)
        item.transform:Find("numLab"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI)).text = self.numMap[items[i]]
        self.commonService:AddEventListener(item:GetComponent(typeof(CS.UnityEngine.UI.Button)), "onClick", function()
            self:OnItemClick(item, items[i], callback)
        end)
    end
end

function control_verification_panel:OnItemClick(item, text, callback)
    if self.resultItmes[1] == text then
        self.audioService:PlayClipOneShot(self.correctAudio)
        table.remove(self.resultItmes, 1)
        item:GetComponent(typeof(CS.UnityEngine.UI.Button)).interactable = false
        item.transform:Find("rightImage").gameObject:SetActive(true)

        if #self.resultItmes == 0 then
            self.UIRoot.gameObject:SetActive(false)
            if callback then
                g_Log("验证解锁成功")
                --用户输入密码退出成功 数据埋点
                if not App.IsStudioClient then
                    NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("control_verification_panel", "888888",
                        "control_verification_panel",
                        "用户输入密码退出成功", "0", {})
                end
                callback(true)
            end
        end
    else
        --密码输入失败 数据埋点
        if not App.IsStudioClient then
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("control_verification_panel", "888888",
                "control_verification_panel",
                "密码输入失败", "1", {})
        end

        self.audioService:PlayClipOneShot(self.errorAudio)
        for i = 0, self.BtnPanel.transform.childCount - 1 do
            self.BtnPanel.transform:GetChild(i):GetComponent(typeof(CS.UnityEngine.UI.Button)).interactable = false
        end
        item.transform:Find("errorImage").gameObject:SetActive(true)
        --toast提示
        CourseEnv.ServicesManager:GetUIService().commonMenu:ShowToast("验证失败，请重试", 2)
        --延迟一秒后重置
        self.commonService:DispatchAfter(2, function()
            self:ResetVerifyPanel(callback)
        end)
    end
end

function control_verification_panel:getRandomElements(arr, count)
    local len = #arr
    if len < count then
        error("Array does not have enough elements.")
        return nil
    end

    local tempIndices = {}
    for i = 1, len do
        tempIndices[i] = i
    end

    local result = {}

    for i = 1, count do
        local index = math.random(1, #tempIndices)    -- 随机选择一个索引
        table.insert(result, arr[tempIndices[index]]) -- 将对应的元素添加到结果列表中
        table.remove(tempIndices, index)              -- 移除已选的索引，保证不会重复选择同一个元素
    end

    return result
end

function control_verification_panel:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()

    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

return control_verification_panel
