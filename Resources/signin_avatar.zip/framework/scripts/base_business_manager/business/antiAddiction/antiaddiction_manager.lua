---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-5-13 15:34:40】
--- 【FSync】
--- 【防沉迷管理】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

-----------------------------------连续在线时长---------------------------
--护眼开始UI面板
local eyeshadow_start_panel = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/eyeshadow_start_panel")
--护眼视频UI面板
local eyeshadow_video_panel = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/eyeshadow_video_panel")
--护眼奖励UI面板
local eyeshadow_reward_panel = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/eyeshadow_reward_panel")
---------------------------------眼保健操主场景版本-------------------------
--护眼视频UI面板主场景启动UI
local eyeshadow_start_panel_main = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/eyeshadow_start_panel_main")
--护眼视频UI面板主场景版本
local eyeshadow_video_panel_main = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/eyeshadow_video_panel_main")
--护眼视频主场景黄金矿工小游戏
local reward_game_goldminer = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/reward_game_goldminer")
------------------------------------累计时长---------------------------
--一小时限制UI面板
local cumulative_prompt_panel = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/cumulative_prompt_panel")
--一小时限制解除UI面板
local control_relieve_panel = require(MAIN_SCRIPTS_LOC ..
    "base_business_manager/business/antiAddiction/control_relieve_panel")

--状态枚举
local ENUM_STATE = {
    NONE = 0,
    START = 1,             --护眼开始
    VIDEO = 2,             --护眼视频
    REWARD = 3,            --护眼奖励
    VERIFICATION = 4,      --护眼验证
    CUMULATIVE_PROMPT = 5, --累计时长提示
    RELIEVE = 6            --解除累计时长限制UI
}

--冲突管理
local EVENT_BUSINESS_CONFLICT_ANTI_ADDICTION = "EVENT_BUSINESS_CONFLICT_ANTI_ADDICTION"
--奖励领取标识本地KEY
local LOCAL_ANTIADDICTION_AWARD_KEY = "LOCAL_ANTIADDICTION_AWARD_KEY"
--眼保健操UI非主场景110601 素材id:117586
local uAddress = "930301730864778/assets/Prefabs/VideoPanel.prefab"
--眼保健操UI主场景110601 素材id:117587
local uAddress_main = "930301730864778/assets/Prefabs/VideoPanel_Main.prefab"
--主场景眼保健操开始UI061901 素材id:109186
local uAddress_main_start = "878611718784415/assets/Prefabs/Canvas.prefab"
--黄金矿工游戏UI061902 素材id:109224
local uAddress_game_gold_miner = "878881718795801/assets/Prefabs/Canvas.prefab"
--芝士机器人
local uAddress_cheese_robot = "876951718104664/assets/Prefabs/c_ABC_zhishijiqiren_idle.prefab"

---@class AntiAddictionManager : WorldBaseElement
local AntiAddictionManager = class("AntiAddictionManager", WBElement)

function AntiAddictionManager:Print(...)
    g_Log("【防沉迷管理】", ...)
end

---@param worldElement CS.Tal.framesync.WorldElement
function AntiAddictionManager:initialize(worldElement)
    AntiAddictionManager.super.initialize(self, worldElement)
    self.domain = "https://app.chuangjing.com/abc-api"
    self.root = self.VisElement.gameObject

    --场次id
    self.liveId = App.Info.liveId
    self.appVersion = App.Info.appVersionNumber
    --是否是AbcZone主场景
    self.isAbcZone = App:IsAbcZoneMain()
    if self.isAbcZone then
        self:RegisterDownloadUaddress(uAddress_main)
        self:RegisterDownloadUaddress(uAddress_main_start)
        self:RegisterDownloadUaddress(uAddress_cheese_robot)
        self:RegisterDownloadUaddress(uAddress_game_gold_miner)
    else
        self:RegisterDownloadUaddress(uAddress)
    end
    --眼保健操功能开放场次id
    self.openPlanIds = {}
    --未加微用户一小时持续在线时长限制
    self.NoVOpenPlanIds = {}
    --初始化插件平台配置项
    if not (App.IsStudioClient) then
        self.pluginJson = App.Info.plugins
        if self.pluginJson ~= nil and type(self.pluginJson) == "string" then
            -- log("开始动态资源相关配置")
            self:InitPluginInfo()
        end
    end

    self:Print("self.liveId", self.liveId)

    --检测防沉迷眼保健操功能是否开启
    self.isOpen = table.indexof(self.openPlanIds, tonumber(self.liveId))
    --添加特殊渠道制定app版本关闭眼保健操功能
    if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.Android then
        APIBridge.RequestAsync("app.api.channel", {}, function(res)
            self:Print("app.api.channel 渠道-->", table.dump(res or {}))
            if res.channel == "readboy" then
                local appVersion = App.Info.appVersionNumber
                if appVersion then
                    if tonumber(appVersion) < 10915 then
                        self:Print("读书郎设备app版本低于10915强制关闭眼保健操功能")
                        self.isOpen = false
                    end
                end
            end
        end)
    end

    --检测防沉迷未加微用户持续在线功能是否开启
    self.isNoVOpen = table.indexof(self.NoVOpenPlanIds, tonumber(self.liveId))

    self:Print("初始化完成-1", self.isOpen)
    self:Print("初始化完成-2", self.isNoVOpen)

    self.state = ENUM_STATE.NONE
    --是否需要显示护眼提示
    self.needShowReachLimit = false
    --一小时限制UI是否显示
    self.cumulativePanelShow = false
    -- 一小时限制h5 url
    self.control_h5 = ""
    --新手引导是否完成
    self.isNewbieFinish = false
    --所有UI是否加载完成
    self.uiLoaded = false
    self.loadCount = 0
    self:InitService()
    self:InitUI()
    self:InitListener()



    --test
    -- local tsetFun
    -- tsetFun = function()
    --     self.commonService:DispatchAfter(6, function()
    --         self.eyeshadow_start_panel_main:Show(function()
    --             self.eyeshadow_video_panel_main:Show(function(arards)
    --                 --清空本地状态
    --                 if arards ~= 0 then
    --                     self:RewardCheese(arards, 3, function()
    --                         --todo 刷新芝士
    --                     end)
    --                     self.eyeshadow_reward_panel:Show(arards, function()

    --                     end)
    --                 end

    --                 -- tsetFun()
    --             end, true)
    --         end)
    --         self:Print("开始游戏->")
    -- self.observerService:Fire("EVENT_GAME_START_GOLD_MINER", {})
    --     end)
    -- end
    -- tsetFun()
end

--初始化UI
function AntiAddictionManager:InitUI()
    local addLoadCount = function()
        self.loadCount = self.loadCount + 1
        if self.loadCount == 5 then
            self.uiLoaded = true
            self:Print("初始化UI-完成->")
        end
    end

    if self.isAbcZone then --加载出场景眼保健操相关UI
        --主场景眼保健操启动页
        self:LoadRemoteUaddress(uAddress_main_start, function(success, prefab)
            if success and prefab then
                local startPanel = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
                self.eyeshadow_start_panel_main = eyeshadow_start_panel_main:new(startPanel)
                --加载机器人模型
                self:LoadRemoteUaddress(uAddress_cheese_robot, function(success, prefab)
                    if success and prefab then
                        local robot = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform)
                        self.eyeshadow_start_panel_main:SetRobotModel(robot, addLoadCount)
                    end
                end)
            end
        end)
        --加载主场景版本眼保健操视频UI
        self:LoadRemoteUaddress(uAddress_main, function(success, prefab)
            if success and prefab then
                local videoPanel_main = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
                self.eyeshadow_video_panel_main = eyeshadow_video_panel_main:new(videoPanel_main, addLoadCount)
            end
        end)
        --黄金矿工奖励小游戏
        self:LoadRemoteUaddress(uAddress_game_gold_miner, function(success, prefab)
            if success and prefab then
                local gamePanel = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
                self.reward_game_goldminer = reward_game_goldminer:new(gamePanel, addLoadCount)
            end
        end)
    else
        --眼保健操启动页
        self.eyeshadow_start_panel = eyeshadow_start_panel:new(self.root, addLoadCount)
        --加载眼保健操视频UI
        self:LoadRemoteUaddress(uAddress, function(success, prefab)
            if success and prefab then
                local videoPanel = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
                self.eyeshadow_video_panel = eyeshadow_video_panel:new(videoPanel, addLoadCount)
            end
        end)
        --芝士奖励弹窗
        self.eyeshadow_reward_panel = eyeshadow_reward_panel:new(self.root, addLoadCount)
    end

    --未加微一小时累积限制弹窗
    self.cumulative_prompt_panel = cumulative_prompt_panel:new(self.root, addLoadCount)
    --一小时限制解除弹窗
    self.control_relieve_panel = control_relieve_panel:new(self.root, addLoadCount)
end

function AntiAddictionManager:InitPluginInfo()
    local list = self.jsonService:decode(self.pluginJson)

    -- self:Print("list->", table.dump(list))

    for _, v in pairs(list) do
        if v.pluginName == "ABC防沉迷场次配置" then
            xpcall(function()
                if v.pluginVal.planIds then
                    self:Print("防沉迷眼保健操开启场次id", v.pluginVal.planIds)
                    local planIds = string.split(v.pluginVal.planIds, ',')
                    for _, id in pairs(planIds) do
                        table.insert(self.openPlanIds, tonumber(id))
                    end
                end

                if v.pluginVal.Parental_control_planIds then
                    self:Print("防沉迷未加微用户持续在线限制开启场次id", v.pluginVal.Parental_control_planIds)
                    local planIds = string.split(v.pluginVal.Parental_control_planIds, ',')
                    for _, id in pairs(planIds) do
                        table.insert(self.NoVOpenPlanIds, tonumber(id))
                    end
                end
            end, function(err)

            end)
        end
    end
end

function AntiAddictionManager:InitService()
    ---@type CommonService
    self.commonService            = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService              = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService              = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService          = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService            = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService             = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService                = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService            = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService             = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService          = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService             = CourseEnv.ServicesManager:GetDebugService()

    self.gate                     = CourseEnv.ServicesManager.Gate
    self.businessConflictService  = CourseEnv.ServicesManager:GetBusinessConflictService()
    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

--暂停or恢复视频领读和预读相关
function AntiAddictionManager:PauseOrResumeVideo(pause)
    if pause then
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", { op = "PauseOrHide" })
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", { op = "Pause" })
    else
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", { op = "ResumeOrShow" })
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", { op = "Resume" })
    end
end

function AntiAddictionManager:conflictManager(open)
    if open then
        self.observerService:Fire("ABCZONE_HOME_2D_SHOW_OR_HIDE", { show = false })
        self.businessConflictService:DidOpenBusiness(EVENT_BUSINESS_CONFLICT_ANTI_ADDICTION)
    else
        self.businessConflictService:DidCloseBusiness(EVENT_BUSINESS_CONFLICT_ANTI_ADDICTION)
        --添加一个眼保健操防沉迷功能结束回调
        self.observerService:Fire("ABCZONE_ANTI_ADDICTION_CLOSED", { close = true })
    end
    --广播眼保健操防沉迷状态
    self.observerService:Fire("ANTI_ADDICTION_STATE_BROADCAST", { open = open })
    self:PauseOrResumeVideo(open)
end

function AntiAddictionManager:InitListener()
    --监听特殊互动结束

    --冲突管理
    self.businessConflictService:Register("EVENT_BUSINESS_CONFLICT_ANTI_ADDICTION",
        function(status, block, extract, from)
            for i, v in ipairs(block) do
                if v == "ON_OFF" then

                elseif v == "UI" then

                end
            end
        end)

    --获取连续在线时长限制状态
    self.observerService:Watch("EVENT_GET_ANTI_ADDICTION_CONTINUOUS_STATE", function(event, value)
        local data = value[0]
        local callBack = data.callBack
        if callBack and type(callBack) == "function" then
            self:GetParentalControlStatus(function(msg)
                if msg then
                    callBack(msg.event_type == 1)
                end
            end)
        end
    end)

    --家长管控消息推送 --获取累计一小时在线家长管控状态
    self.observerService:Watch("PUSH_PARENTAL_CONTROL_CONTINUE", function(event, value)
        local data = value[0]
        if type(data) == 'table' then
            self:Print("收到推送消息" .. table.dump(data))
            if data.control_type == 1 then
                self.control_h5 = data.control_h5

                self.commonService:DispatchAfter(1, function()
                    self:CheckShowParentalControl()
                end)
            elseif data.control_type == 2 then
                --关闭已经展示的限制H5UI
                if self.cumulativePanelShow then
                    self.cumulativePanelShow = false
                    self.cumulative_prompt_panel:Hide()
                    -- 展示解除限制UI
                    self.control_relieve_panel:Show(function()

                    end)
                    --处理眼保健操检测
                    self:CheckShowEyeShadowVideo()
                end
            end
        end
    end)

    --监听场景切换
    self.observerService:Watch("unity.api.page.show", function()
        self.needRefresh = true
    end)

    --新手引导
    self.observerService:Watch("EVENT_NEWBIE_TASK_ALL_COMPLETE", function(event, value)
        local data = value[0]
        self.isNewbieFinish = true
        if not self.selfAvatarLoaded then
            --UI可能还没加载完
            return
        end
        self:CheckContinueOrReachLimitState()
    end)

    --持续在线时长监听
    APIBridge.CreateService("unity.user.usagetime.reachLimit", {}, function(res)
        if res then
            local reachLimit = res.reachLimit
            if not reachLimit then
                g_LogError("unity.user.usagetime.reachLimit error: reachLimit = nil")
                return
            end
            --是否到达持续在线限制
            self.reachLimit = reachLimit
            self:Print("端通知到达连续在线时长限制->", self.reachLimit)
            if self.reachLimit == 1 then
                self.needShowReachLimit = true

                self:CheckReachLimitShow(true)
            end
        else
            g_LogError("unity.user.usagetime.reachLimit error: res = nil")
        end
    end)

    --监听用户主动触发防沉迷检测
    self.observerService:Watch("ACTIVITE_TRIGGERING_ANTI_ADDICTION_CHECK", function(event, value)
        local data = value[0]
        self:Print("用户主动触发防沉迷检测")
        self:CheckContinueOrReachLimitState()
    end)

    --监听世界boss活动状态
    self.observerService:Watch("ABC_ZONE_WORLD_UPDATA_PLAYER_DATA", function(key, value)
        local data = value and value[0]
        if data and data.uuid then
            if data.uuid == App.Uuid then
                if not data.IAT then
                    --用户退出世界boss战斗
                    --检测一下在线状态
                    self:CheckContinueOrReachLimitState()
                end
            end
        end
    end)

    --用户退出宠物pvp或pve
    self.observerService:Watch("ABC_ZONE_WORLD_BOSS_CHECK_PLAYER_JOIN_ACTIVITE", function(key, value)
        local data = value and value[0]
        self:CheckContinueOrReachLimitState()
    end)

    --监听矿工游戏添加学识
    self.observerService:Watch("EVENT_GAME_GOLD_MINER_ADD_REWARD", function(key, value)
        local data = value and value[0]
        if data and data.reward then
            self:RewardCheese(data.reward, 6, function()
                --刷新芝士
                self.observerService:Fire("ABC_ZONE_UPDATE_LEARN_KNOW_EVENT_KEY")
                if data.callBack and type(data.callBack) == "function" then
                    data.callBack()
                end
            end)
        end
    end)

    --监听矿工游戏添加芝士
    self.observerService:Watch("EVENT_MAIN_SCENE_ADD_REWARD", function(key, value)
        local data = value and value[0]
        if data and data.reward then
            self:RewardCheese(data.reward, 3, function(data)
                --判断奖励是否发放成功--每日只可以领取一次
                if data and data.add_val ~= 0 then
                    --刷新芝士
                    self.observerService:Fire("ABC_ZONE_UPDATE_LEARN_KNOW_EVENT_KEY")
                end
                --标记当日领取状态
                self:SetToDayIsToClaim()

                if data.callBack and type(data.callBack) == "function" then
                    data.callBack()
                end
            end)
        end
    end)

    --监听app切入后台
    self.pauseFunction = function(pause)
        if pause then
            self:Print("用户进入后台")
        else
            self:Print("用户进入前台")
            self:CheckContinueOrReachLimitState()
        end
    end

    self.commonService:DispatchAfter(1, function()
        if self.gate.worldController.World.OnApplicationPauseAction == nil then
            self.gate.worldController.World.OnApplicationPauseAction = self.pauseFunction
        else
            self.gate.worldController.World.OnApplicationPauseAction = self.gate.worldController.World
                .OnApplicationPauseAction + self.pauseFunction
        end
    end)
end

--主动监测连续和持续在线时长限制
function AntiAddictionManager:CheckContinueOrReachLimitState(reachLimitCall)
    --UI没有加载完成
    if not self.uiLoaded then
        self:Print("self.uiLoaded->", self.uiLoaded)
        return
    end
    --获取是否到达连续在线时长限制
    self:GetReachLimit(function(showReachLimit)
        if showReachLimit then
            self:Print("到达连续在线时长限制")
            self.needShowReachLimit = true
            self:CheckReachLimitShow()
        end
        if reachLimitCall and type(reachLimitCall) == "function" then
            reachLimitCall()
        end
    end)

    --获取是否到达持续在线时长限制
    if self.isNoVOpen then
        self:GetParentalControlStatus(function(data)
            if data then
                self:Print("获取是否到达累计在线时长限制->", table.dump(data))
                if data.event_type == 1 then
                    self.control_h5 = data.desc
                    self:CheckShowParentalControl()
                elseif data.event_type == 2 then
                    --关闭已经展示的限制H5UI
                    if self.cumulativePanelShow then
                        self.cumulativePanelShow = false
                        self.cumulative_prompt_panel:Hide()
                        --处理眼保健操检测
                        self:CheckShowEyeShadowVideo()
                    end
                end
            end
        end)
    end
end

--一小时限制解除时，检测是否展示护眼视频
function AntiAddictionManager:CheckShowEyeShadowVideo()
    if not self.uiLoaded then
        self:Print("self.uiLoaded-CheckShowEyeShadowVideo>", self.uiLoaded)
        return
    end
    --冲突管理业务打开
    self:conflictManager(false)

    --处理连续和持续UI同时弹出的冲突
    if self.eyeshadow_video_panel and self.eyeshadow_video_panel.playing then
        if self.eyeshadow_video_panel.isPause then
            self.eyeshadow_video_panel:Resume()
            local control_verification_panel = self.eyeshadow_video_panel.control_verification_panel
            if control_verification_panel and control_verification_panel.isShow then
                control_verification_panel:ForceClose()
            end
        end
    end

    if self.eyeshadow_video_panel_main and self.eyeshadow_video_panel_main.playing then
        if self.eyeshadow_video_panel_main.isPause then
            self.eyeshadow_video_panel_main:Resume()
            local control_verification_panel = self.eyeshadow_video_panel_main.control_verification_panel
            if control_verification_panel and control_verification_panel.isShow then
                control_verification_panel:ForceClose()
            end
        end
    end

    --重新检测一下是否要播眼保健操
    self:GetReachLimit(function(showReachLimit)
        if showReachLimit then
            self:Print("到达连续在线时长限制")
            self.needShowReachLimit = true
            self:CheckReachLimitShow()
        end
    end)
end

--检测用户是否处于宠物pvp或pve状态
function AntiAddictionManager:CheckPlayerPetPvpOrPveState()
    local pet_pvp = 0
    self.observerService:Fire("PET_SYSTEM_GET_PVP_BATTLE_STATE",
        {
            uuid = App.Uuid,
            callBack = function(state)
                if state then
                    pet_pvp = state
                end
            end
        })

    --检测用户是否在pve战斗中
    local pet_pve = 0
    self.observerService:Fire("PET_SYSTEM_GET_PVE_BATTLE_STATE",
        {
            uuid = App.Uuid,
            callBack = function(state)
                if state then
                    pet_pve = state
                    -- self:Print("被邀请人pet_pve->", pet_pve)
                end
            end
        })

    --用户处于对战中状态重置计时
    if tonumber(pet_pvp) == 1 or tonumber(pet_pve) == 1 then
        return false
    end
    return true
end

--业务逻辑宠物pvp、pve、世界bos、、、状态判断
function AntiAddictionManager:CheckOtherBusinessState()
    --如果是abczone主场景额外检测一些互动的状态是否可用
    if self.isAbcZone then
        self:Print("新手引导-1>", self.isNewbieFinish)
        if not self.isNewbieFinish then
            self:Print("用户未完成新手引导、不弹出防沉迷")
            return true
        end

        --检测用户是否处于宠物pvp或pve状态
        if not self:CheckPlayerPetPvpOrPveState() then
            self:Print("否处于宠物pvp或pve状态、不弹出防沉迷")
            return true
        end

        --世界boss
        local playerData = nil
        self.observerService:Fire("ABC_ZONE_WORLD_GET_ACTIVITE_PLAYER_DATA",
            {
                uid = App.Info.userId,
                callBack = function(data)
                    playerData = data
                end
            })

        if playerData and playerData.IAT then
            self:Print("处于世界Boss活动、不弹出防沉迷")
            return true
        end
    end

    --判定用户是否在不可打断状态
    local block = false
    self.observerService:Fire("EVENT_CHECK_ANTI_ADDICTION_CAN_USE", {
        callBack = function(canUse)
            block = not canUse
        end
    })
    self:Print("用户在不可打断状态、不触发防沉迷", block)
    return block
end

--获取当日是否获得过奖励 --检测当日是否已领取过奖励
function AntiAddictionManager:GetToDayIsToClaim()
    --查看当天是否已经领取过奖励
    local toDayKey = os.date("%Y-%m-%d", os.time())
    if CS.UnityEngine.PlayerPrefs.HasKey(LOCAL_ANTIADDICTION_AWARD_KEY .. App.Info.userId) then
        local awardKey = CS.UnityEngine.PlayerPrefs.GetString(LOCAL_ANTIADDICTION_AWARD_KEY .. App.Info.userId)
        if toDayKey == awardKey then
            return true
        end
    end
    return false
end

--设置当天已领取过奖励状态
function AntiAddictionManager:SetToDayIsToClaim()
    local toDayKey = os.date("%Y-%m-%d", os.time())
    CS.UnityEngine.PlayerPrefs.SetString(LOCAL_ANTIADDICTION_AWARD_KEY .. App.Info.userId, toDayKey)
end

--检测是否弹出连续在线时长限制
function AntiAddictionManager:CheckReachLimitShow()
    --功能是否打开
    if not self.isOpen then
        return
    end

    if not self.uiLoaded then
        self:Print("self.uiLoaded-CheckReachLimitShow>", self.uiLoaded)
        return
    end

    --判断是否满足弹出条件 、各种特殊互动
    if self:CheckOtherBusinessState() then
        return
    end

    self:Print("CheckReachLimitShow-1>")

    --是否继续上次的进度
    local progress, validTime, lastTimestamp = 0, 0, 0
    if self.isAbcZone then
        progress, validTime, lastTimestamp = self.eyeshadow_video_panel_main:GetLocalVideoProgress()
    else
        progress, validTime, lastTimestamp = self.eyeshadow_video_panel:GetLocalVideoProgress()
    end

    self:Print("CheckReachLimitShow-2>")
    if self.state ~= ENUM_STATE.NONE then
        return
    end

    --一小时限制弹出时,不弹出护眼视频
    if self.cumulativePanelShow then
        self:Print("一小时限制弹出时,不弹出护眼视频->")
        return
    end

    self:Print("CheckReachLimitShow-3>")

    --冲突管理业务打开
    self:conflictManager(true)

    self:Print("CheckReachLimitShow-4>")

    --非主场景视频播放流程
    local showVideoPanel = function()
        self.state = ENUM_STATE.VIDEO
        self.eyeshadow_video_panel:Show(function(arards)
            self:Print("RewardCheese-call>")
            --清空本地状态
            if arards ~= 0 then
                self:RewardCheese(arards, 3, function(data)
                    if data and data.add_val ~= 0 then
                        --刷新芝士
                        self.observerService:Fire("ABC_ZONE_UPDATE_LEARN_KNOW_EVENT_KEY")
                        self.eyeshadow_reward_panel:Show(arards, function()

                        end)
                        self.eyeshadow_video_panel:ClearLocalVideoProgress()
                        --标记当日领取状态
                        self:SetToDayIsToClaim()
                    end
                end)
            end

            --恢复聊天区
            self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = true })

            --清空端上连续状态
            self:Print("清空端上连续状态")
            self.state = ENUM_STATE.NONE
            self:RelieveReachLimit()

            --冲突管理业务关闭
            self:conflictManager(false)
        end, self:GetToDayIsToClaim())

        --在一小h5弹窗打开时停止播放眼保健操
        if self.cumulativePanelShow then
            if self.eyeshadow_video_panel and self.eyeshadow_video_panel.playing then
                self.eyeshadow_video_panel:Pause()
            end
            if self.eyeshadow_video_panel_main and self.eyeshadow_video_panel_main.playing then
                self.eyeshadow_video_panel_main:Pause()
            end
        end
    end

    --主场景视频播放流程
    local showMainVideoPanel = function()
        if self.state == ENUM_STATE.VIDEO then
            return
        end
        self.state = ENUM_STATE.VIDEO
        self.eyeshadow_video_panel_main:Show(function(arards)
            self:Print("RewardCheese-call>")
            --清空端上连续状态
            self:Print("清空端上连续状态")
            self.state = ENUM_STATE.NONE
            self:RelieveReachLimit()
            --恢复聊天区
            self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = true })
            --冲突管理业务关闭
            self:conflictManager(false)
        end, self:GetToDayIsToClaim())

        --在一小h5弹窗打开时停止播放眼保健操
        if self.cumulativePanelShow then
            if self.eyeshadow_video_panel_main and self.eyeshadow_video_panel_main.playing then
                self.eyeshadow_video_panel_main:Pause()
            end
        end
    end

    --隐藏聊天区
    self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = false })

    self:Print("CheckReachLimitShow-5>")

    if progress == 0 then
        self.state = ENUM_STATE.START
        if self.isAbcZone then
            self.eyeshadow_start_panel_main:Show(showMainVideoPanel)
        else
            if self:GetToDayIsToClaim() then
                showVideoPanel()
            else
                self.eyeshadow_start_panel:Show(showVideoPanel)
            end
        end
    else
        if self.isAbcZone then
            showMainVideoPanel()
        else
            showVideoPanel()
        end
    end
end

--检测是否展示累计在线弹窗
function AntiAddictionManager:CheckShowParentalControl()
    --功能是否打开
    if not self.isNoVOpen then
        return
    end

    --UI没有加载完成
    if not self.uiLoaded then
        return
    end

    --判断是否满足弹出条件 、各种特殊互动
    if self:CheckOtherBusinessState() then
        return
    end

    if not self.cumulativePanelShow then
        if self.cumulative_prompt_panel and self.cumulative_prompt_panel.loadingCompleted then
            self.cumulativePanelShow = true
            --隐藏聊天区
            self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = false })

            self.cumulative_prompt_panel:Show(self.control_h5, function()
                self:Print("累计时长提示关闭")
            end)
            --冲突管理业务打开
            self:conflictManager(true)

            --如果打开这个H5页面弹窗时，眼保健操也在播放，需要暂停、关闭时需要恢复
            if self.eyeshadow_video_panel and self.eyeshadow_video_panel.playing then
                self.eyeshadow_video_panel:Pause()
            end
            if self.eyeshadow_video_panel_main and self.eyeshadow_video_panel_main.playing then
                self.eyeshadow_video_panel_main:Pause()
            end
        end
    end
end

--获取是否到达持续在线时长限制
function AntiAddictionManager:GetReachLimit(callBack)
    APIBridge.RequestAsync("app.user.usagetime.reachLimit", {}, function(res)
        if res then
            local reachLimit = res.reachLimit
            if not reachLimit then
                g_LogError("app.user.usagetime.reachLimit error: reachLimit = nil")
                callBack(false)
                return
            end
            --是否到达持续在线限制
            self.reachLimit = reachLimit
            self:Print("获取是否到达持续在线时长限制->", self.reachLimit)
            callBack(self.reachLimit == 1)
        else
            g_LogError("unity.user.usagetime.reachLimit error: res = nil")
        end
    end)
end

--解除连续在线时长限制
function AntiAddictionManager:RelieveReachLimit()
    APIBridge.RequestAsync("app.user.usagetime.reset", {}, function(res)
        self:Print("解除连续在线时长限制")
    end)
end

--奖励芝士或者学识
function AntiAddictionManager:RewardCheese(rewards, add_type, callBack, is_yesterday)
    local url = self.domain .. "/v3/user/cheese/add"
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041/v3/user/cheese/add"
    end

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                if msg.data then
                    callBack(msg.data)
                end
            end
        end
    end

    local fail = function(err)
        if not err then
            err = ""
        end
        if type(err) == "table" then
            err = table.dump(err)
        end
        callBack(nil)
    end

    -- 上报用户调用添加奖励接口
    if not App.IsStudioClient then
        local action = {}
        action["type"] = add_type
        action["value"] = rewards
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_User_get_rewards",
            "888888",
            "continuous_User_get_rewards",
            "用户退出时间", action, {})
    end

    self:_HttpRequestExtend(url,
        { business_id = 900, add_type = add_type, add_val = rewards, is_yesterday = is_yesterday }, success,
        fail)
end

--获取累计一小时在线家长管控状态
function AntiAddictionManager:GetParentalControlStatus(callBack)
    local url = self.domain .. "/v3/parent-control/check-in-control-unity"
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041/v3/parent-control/check-in-control-unity"
    end

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                if msg.data then
                    callBack(msg.data)
                end
            end
        end
    end

    local fail = function(err)
        if not err then
            err = ""
        end
        if type(err) == "table" then
            err = table.dump(err)
        end
        callBack(nil)
    end
    self:_HttpRequest(url, {}, success, fail)
end

--http请求
function AntiAddictionManager:_HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

function AntiAddictionManager:_HttpRequestExtend(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        local timestamp = os.time()
        local md5Str = string.format("adc_u:%d_t:%s_dwmw", App.Info.userId, timestamp)
        local sign = CS.Com.Tal.Unity.Core.Utility.Md5Tools.ProcessMd5(md5Str)

        g_Log("sign", md5Str .. ":" .. sign)

        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json",
                ["req_time"] = tostring(timestamp),
                ["sign"] = sign

            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function AntiAddictionManager:ReceiveMessage(key, value, isResume)

end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function AntiAddictionManager:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function AntiAddictionManager:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function AntiAddictionManager:SelfAvatarPrefabLoaded(avatar)
    --自己的人物模型加载完成
    self.selfAvatarLoaded = true
    --没有开启功能的场次不发放奖励
    if self.isOpen then
        self.commonService:StartCoroutine(function()
            coroutine.yield(self.commonService:WaitUntil(function()
                return self.uiLoaded and self.allComponentRecover
            end))

            self:Print("CheckContinueOrReachLimitState->")
            self:CheckContinueOrReachLimitState(function()
                if not self.isAbcZone then --非主场景模式
                    local progress, validTime, lastTimestamp = self.eyeshadow_video_panel:GetLocalVideoProgress()
                    --如果重新进入游戏，且上次有未完成的护眼视频 -- 清空本地状态--发放上次未发放的奖励
                    self:Print("CheckContinueOrReachLimitState3", progress, self.needShowReachLimit)
                    if progress ~= 0 and not self.needShowReachLimit then
                        self:Print("补发本地记录奖励->", validTime)
                        if validTime ~= 0 then
                            self:RewardCheese(validTime, 3, function(data)
                                --判断奖励是否发放成功--每日只可以领取一次
                                if data and data.add_val ~= 0 then
                                    --展示奖励弹窗
                                    self.eyeshadow_reward_panel:Show(validTime, function()

                                    end)
                                    --刷新芝士
                                    self.observerService:Fire("ABC_ZONE_UPDATE_LEARN_KNOW_EVENT_KEY")
                                end
                                --标记当日领取状态
                                self:SetToDayIsToClaim()
                                --清空本地状态
                                self.eyeshadow_video_panel:ClearLocalVideoProgress()
                            end, true)
                        end

                        local curTimestamp = os.time()
                        local addTime = curTimestamp - lastTimestamp
                        --用户退出了多少时间 数据埋点
                        if not App.IsStudioClient then
                            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_Breakleave",
                                "888888",
                                "continuous_Breakleave",
                                "用户退出时间", addTime, {})
                        end
                    end
                else
                    local progress, validTime, lastTimestamp = self.eyeshadow_video_panel_main:GetLocalVideoProgress()
                    if progress ~= 0 and not self.needShowReachLimit then
                        self:Print("补发本地记录奖励->", validTime)
                        if validTime ~= 0 then
                            self:RewardCheese(validTime, 3, function(data)
                                --标记当日领取状态
                                self:SetToDayIsToClaim()
                                --判断奖励是否发放成功--每日只可以领取一次
                                if data and data.add_val ~= 0 then
                                    --刷新芝士
                                    self.observerService:Fire("ABC_ZONE_UPDATE_LEARN_KNOW_EVENT_KEY")
                                end
                            end, true)
                        end
                        --清空本地状态
                        self.eyeshadow_video_panel_main:ClearLocalVideoProgress()

                        local curTimestamp = os.time()
                        local addTime = curTimestamp - lastTimestamp
                        --用户退出了多少时间 数据埋点
                        if not App.IsStudioClient then
                            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_Breakleave",
                                "888888",
                                "continuous_Breakleave",
                                "用户退出时间", addTime, {})
                        end
                    end
                end
            end)
        end)
    end
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function AntiAddictionManager:AvatarCreated(avatar)
end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function AntiAddictionManager:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function AntiAddictionManager:LogicMapStartRecover()
    AntiAddictionManager.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function AntiAddictionManager:LogicMapEndRecover()
    AntiAddictionManager.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function AntiAddictionManager:LogicMapAllComponentRecoverComplete()
    self.allComponentRecover = true
end

-- 收到Trigger事件
function AntiAddictionManager:OnReceiveTriggerEvent(interfaceId)

end

-- 收到GetData事件
function AntiAddictionManager:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------
function AntiAddictionManager:Tick()
    if self.eyeshadow_video_panel then
        self.eyeshadow_video_panel:Tick()
    end
    if self.eyeshadow_video_panel_main then
        self.eyeshadow_video_panel_main:Tick()
    end
    if self.reward_game_goldminer then
        self.reward_game_goldminer:Tick()
    end
end

-- 脚本释放
function AntiAddictionManager:Exit()
    AntiAddictionManager.super.Exit(self)
    if self.eyeshadow_video_panel then
        self.eyeshadow_video_panel:Exit()
    end
    if self.eyeshadow_video_panel_main then
        self.eyeshadow_video_panel_main:Exit()
    end
    if self.reward_game_goldminer then
        self.reward_game_goldminer:Exit()
    end
end

return AntiAddictionManager
