---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-5-13 15:34:40】
--- 【FSync】
--- 【管控解除提示UI】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/antiAddiction/"
local UIPrefabPath = ResourcePathRoot .. "assets/Prefabs/UnlockPanel.prefab"
local audioPathRoot = ResourcePathRoot .. "audio/"

local control_relieve_panel = class("control_relieve_panel")

function control_relieve_panel:initialize(root, callback)
    self.root = root
    self.LoadCompleted = callback
    self:InitService()
    self:InitUI()
end

function control_relieve_panel:InitUI()
    ResourceManager:LoadGameObjectWithExName(UIPrefabPath, function(go)
        self.UIRoot = GameObject.Instantiate(go).transform
        self.UIRoot:SetParent(self.root.transform)
        self.UIRoot.localPosition = Vector3.zero
        self.UIRoot.localScale = Vector3.one
        self.UIRoot.localRotation = Quaternion.identity
        local canvas = self.UIRoot:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
        canvas.sortingOrder = 10002

        self.jixuBtn = self.UIRoot:Find("jixuBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.jixuBtn, "onClick", function()
            self.UIRoot.gameObject:SetActive(false)
            if self.callback then
                self.callback()
            end
        end)

        self.UIRoot.gameObject:SetActive(false)

        if self.LoadCompleted then
            self.LoadCompleted()
        end
    end)
end

--展示护眼提示
function control_relieve_panel:Show(callback)
    self.UIRoot.gameObject:SetActive(true)
    self.callback = callback
    self.titleLab = self.UIRoot:Find("titleLab").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

    self.titleLab.text = App.Properties.AvatarName .. " 小朋友"

    --在触发1小时限制后用户解除了限制 数据埋点
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("limitedtime_Relieve", "888888",
            "limitedtime_Relieve",
            "在触发1小时限制后用户解除了限制", "0", {})
    end
end

function control_relieve_panel:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()

    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

return control_relieve_panel
