---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-5-13 15:34:40】
--- 【FSync】
--- 【护眼奖励UI】
---

local class                  = require("middleclass")
local WBElement              = require("mworld/worldBaseElement")

local ResourcePathRoot       = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/antiAddiction/"
local UIPrefabPath           = ResourcePathRoot .. "assets/Prefabs/TipPanel2.prefab"
local audioPathRoot          = ResourcePathRoot .. "audio/"

local eyeshadow_reward_panel = class("eyeshadow_reward_panel ")

function eyeshadow_reward_panel:initialize(root, callback)
    self.root = root
    self.LoadCompleted = callback
    self:InitService()
    self:InitUI()
end

function eyeshadow_reward_panel:InitUI()
    ResourceManager:LoadGameObjectWithExName(UIPrefabPath, function(go)
        self.UIRoot = GameObject.Instantiate(go).transform
        self.UIRoot:SetParent(self.root.transform)
        self.UIRoot.localPosition = Vector3.zero
        self.UIRoot.localScale = Vector3.one
        self.UIRoot.localRotation = Quaternion.identity
        local canvas = self.UIRoot:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
        canvas.sortingOrder = 10000

        self.UIRoot.gameObject:SetActive(false)

        self.jixuBtn = self.UIRoot:Find("jixuBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.jixuBtn, "onClick", function()
            --用户点击继续学习按钮 数据埋点
            if not App.IsStudioClient then
                NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_Receiveclick", "888888",
                    "continuous_Receiveclick",
                    "用户点击继续学习按钮", self.awards, {})
            end

            self.UIRoot.gameObject:SetActive(false)
            if self.callback then
                self.callback()
            end
        end)

        self.tipText = self.UIRoot:Find("tipText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

        self.numText = self.UIRoot:Find("zhishiNode/Image/numText").gameObject:GetComponent(typeof(CS.TMPro
            .TextMeshProUGUI))

        if self.LoadCompleted then
            self.LoadCompleted()
        end
    end)

    --加载音频
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "rewardAudio.mp3", function(audioclip)
        self.rewardAudio = audioclip
    end)
end

--展示护眼提示
function eyeshadow_reward_panel:Show(awards, callback)
    self.UIRoot.gameObject:SetActive(true)
    self.callback = callback
    self.tipText.text = string.format("你做了%d秒的眼保健操，获得了%d个知识币奖励", awards, awards)
    if App.modPlatform == MOD_PLATFORM.Math then
        self.tipText.text = string.format("你做了%d秒的眼保健操，获得了%d个贝壳奖励", awards * 3, awards)
    end

    self.numText.text = tostring(awards)
    self.awards = awards

    self.audioService:PlayClipOneShot(self.rewardAudio, function() end)
end

function eyeshadow_reward_panel:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()

    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

return eyeshadow_reward_panel
