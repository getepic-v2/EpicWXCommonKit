---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-5-13 15:34:40】
--- 【FSync】
--- 【护眼开始UI】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local eyeshadow_start_panel_main = class("eyeshadow_start_panel_main")

function eyeshadow_start_panel_main:Print(...)
    g_Log("【防沉迷开场main】", ...)
end

function eyeshadow_start_panel_main:initialize(root, callback)
    self.UIRoot = root
    self.LoadCompleted = callback
    self:InitService()
    self:InitUI()
end

--设置robot模型资源
function eyeshadow_start_panel_main:SetRobotModel(model, loadCallback)
    self.robotModel = model
    self.robotModel.gameObject:SetActive(false)
    if loadCallback then
        loadCallback()
    end
end

--初始化UI
function eyeshadow_start_panel_main:InitUI()
    local canvas = self.UIRoot:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
    canvas.sortingOrder = 10000
    self.UIRoot.gameObject:SetActive(false)

    --开局标题
    self.tipNode = self.UIRoot:Find("tipNode").gameObject
    self.daojishi = self.tipNode.transform:Find("daojishi").gameObject

    --对话框
    self.dialogPanel = self.UIRoot:Find("dialogPanel").gameObject
    --音频按钮
    self.audioBtn = self.UIRoot:Find("dialogPanel/di/laba/btn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    --音频按钮动画
    self.audioBtnAni = self.UIRoot:Find("dialogPanel/di/laba/btnAni").gameObject

    self.commonService:AddEventListener(self.audioBtn, "onClick", function()
        self.audioBtn.gameObject:SetActive(false)
        self.audioBtnAni:SetActive(true)
        self.pangbaiAudio:Play()
        local seq = DOTween:Sequence()
        seq:AppendInterval(5.2)
        seq:AppendCallback(function()
            self.audioBtnAni:SetActive(false)
            self.audioBtn.gameObject:SetActive(true)
        end)
    end)
    --旁白音频
    self.pangbaiAudio = self.UIRoot:Find("dialogPanel/di/pangbaiAudio").gameObject:GetComponent(typeof(typeof(CS
        .UnityEngine.AudioSource)))
    --关闭按钮
    self.closeBtn = self.UIRoot:Find("dialogPanel/di/closeBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.closeBtn, "onClick", function()
        self.robotModel.gameObject:SetActive(false)
        self.UIRoot.gameObject:SetActive(false)
        if self.CompletedCall then
            self.CompletedCall()
            self.CompletedCall = nil
        end
        if self.delaySeq then
            self.delaySeq:Kill()
            self.delaySeq = nil
        end
    end)

    if self.LoadCompleted then
        self.LoadCompleted()
    end
end

--展示护眼提示
function eyeshadow_start_panel_main:Show(callback)
    self.CompletedCall = callback
    self.UIRoot.gameObject:SetActive(true)
    --展示tip
    self.dialogPanel:SetActive(false)
    self.tipNode:SetActive(true)
    self.daojishi:SetActive(true)
    local seq = DOTween:Sequence()
    seq:AppendInterval(3)
    seq:AppendCallback(function()
        self.tipNode:SetActive(false)
        self.daojishi:SetActive(false)
    end):OnComplete(function()
        self:Print("倒计时播放结束")
        --展示机器人
        self:PlayRobotAni(function()
            self:ShowDialog()
        end)
    end)
end

function eyeshadow_start_panel_main:PlayRobotAni(completeCallback)
    local avatar = self.avatarService:GetAvatarByUUID(App.Uuid)
    local target = avatar.BodyTrans.transform
    local targetPos = target.position
    local startPos = targetPos + target:TransformDirection(Vector3(0, 3.5, 5.5))
    self.robotModel.transform.position = startPos
    self.robotModel.gameObject:SetActive(true)
    local endPos = targetPos + target:TransformDirection(Vector3(0, 1, 3))

    local anim = self.robotModel.gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
    anim:SetBool("shuohua", true)

    --todo 停止摇杆
    self:ActivateJoystick(false)
    self.robotModel.transform:LookAt(endPos)
    self.robotModel.transform:DOMove(endPos, 1):OnComplete(function()
        --使物体垂直于地面
        self.robotModel.transform.rotation = Quaternion.Euler(0, self.robotModel.transform.eulerAngles.y,
            self.robotModel.transform.eulerAngles.z)
        self:Print("移动到了目标位置")
        local seq = DOTween:Sequence()
        seq:AppendInterval(0.5)
        seq:AppendCallback(function()
            self:ActivateJoystick(true)
            if completeCallback and type(completeCallback) == "function" then
                completeCallback()
            end
            if seq then
                seq:Kill()
            end
        end)
    end)
end

--屏蔽摇杆
function eyeshadow_start_panel_main:ActivateJoystick(active)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:WaitUntil(function()
            return self.joystickService:IsReady() == true and self.avatarPrefabLoaded
        end))

        self.joystickService.joyPanel.bLockCamera = not active
        --设置摇杆按钮静态图显隐
        local staticJoy = self.joystickService.joyPanel.staticJoy

        if staticJoy then
            self.commonService:DispatchAfter(1, function()
                staticJoy.gameObject:SetActive(active)
            end)
        end

        if active then
            self.joystickService:setVisibleJoyWithID(self.joyId)
            self.joystickService:setVisibleJumpWithID(self.jumpId)
        else
            --隐藏摇杆和跳跃按钮
            self.joyId = self.joystickService:setHidenJoyWithID()
            --隐藏摇杆占位静态图片
            self.jumpId = self.joystickService:setHidenJumpWithID()
        end
    end)
end

--显示对话框
function eyeshadow_start_panel_main:ShowDialog()
    self.dialogPanel:SetActive(true)
    self.tipNode:SetActive(false)

    self.pangbaiAudio.gameObject:SetActive(true)
    self.audioBtn.gameObject:SetActive(false)
    self.audioBtnAni:SetActive(true)
    self.pangbaiAudio:Play()
    local seq = DOTween:Sequence()
    seq:AppendInterval(5.2)
    seq:AppendCallback(function()
        self.audioBtnAni:SetActive(false)
        self.audioBtn.gameObject:SetActive(true)
        self.robotModel.gameObject:SetActive(false)
        self.UIRoot.gameObject:SetActive(false)
        if self.CompletedCall then
            self.CompletedCall()
            self.CompletedCall = nil
        end
        if self.delaySeq then
            self.delaySeq:Kill()
            self.delaySeq = nil
        end
    end)
    self.delaySeq = seq
end

function eyeshadow_start_panel_main:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()

    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

return eyeshadow_start_panel_main
