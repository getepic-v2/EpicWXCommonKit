---
---  Author: 【吕清林】
---  AuthorID: 【283869】
---  CreateTime: 【2024-6-11 13:51:22】
--- 【FSync】
--- 【黄金矿工小游戏】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")
require("common/tableutil")
local Mathf = CS.UnityEngine.Mathf
local Color = CS.UnityEngine.Color


--摇摆方向枚举
local RotaDirEnum = {
    Left = 2,
    Right = 3,
}

--碰撞体类型
local ColliderType = {
    None = 0,
    Box = 1,
    Circle = 2,
}

--物品类型
local ItemType = {
    Hook = 0, --钩子
    Gold = 1,
    Stone = 2,
}

--游戏状态
local GameState = {
    None = 0,
    Start = 1,
    Playing = 2,
    End = 3,
    Settlement = 4 --结算
}

--游戏局时-单位秒
local GAME_COUNTDOWNTIME = 30
--可抓取次数
local GAME_PLAYCOUNT = 3
--道具配置
--被沟中后的分数
--被沟中后回收钩子的速度
--被沟中后的偏移显示位置
local PropConfig = {
    ['stone1'] = {
        Score = 0,
        ColliderType = ColliderType.Circle,
        Radius = 24.5,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(50, 50),
        Rotation = 0,
        BackSpeed = 250,
        HitOffset = Vector3(-4, -35, 0)
    },
    ['stone2'] = {
        Score = 0,
        ColliderType = ColliderType.Circle,
        Radius = 36,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(72, 72),
        Rotation = 0,
        BackSpeed = 230,
        HitOffset = Vector3(9.5, -53.8, 0)
    },
    ['stone3'] = {
        Score = 0,
        ColliderType = ColliderType.Circle,
        Radius = 40,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(80, 80),
        Rotation = 0,
        BackSpeed = 210,
        HitOffset = Vector3(-7.4, -55.4, 0)
    },
    ['stone4'] = {
        Score = 0,
        ColliderType = ColliderType.Circle,
        Radius = 46,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(92, 92),
        Rotation = 0,
        BackSpeed = 190,
        HitOffset = Vector3(6.3, -63.3, 0)
    },
    ['diamond1'] = {
        Score = 1,
        ColliderType = ColliderType.Circle,
        Radius = 27,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(54, 54),
        Rotation = 0,
        BackSpeed = 320,
        HitOffset = Vector3(0, -44.3, 0)
    },
    ['diamond2'] = {
        Score = 2,
        ColliderType = ColliderType.Circle,
        Radius = 38,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(76, 76),
        Rotation = 0,
        BackSpeed = 260,
        HitOffset = Vector3(4.3, -59.8, 0)
    },
    ['diamond3'] = {
        Score = 2,
        ColliderType = ColliderType.Circle,
        Radius = 38,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(76, 76),
        Rotation = 0,
        BackSpeed = 260,
        HitOffset = Vector3(-4.3, -59.8, 0)
    },
    ['diamond4'] = {
        Score = 4,
        ColliderType = ColliderType.Circle,
        Radius = 52,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(104, 104),
        Rotation = 0,
        BackSpeed = 200,
        HitOffset = Vector3(9.6, -71, 0)
    },
    ['diamond5'] = {
        Score = 4,
        ColliderType = ColliderType.Circle,
        Radius = 52,
        Offset = Vector3(0, 0, 0),
        Size = Vector2(104, 104),
        Rotation = 0,
        BackSpeed = 200,
        HitOffset = Vector3(-6, -71, 0)
    },

}

local PropGuid = 0
--道具类
---@class Item
local Prop = class("Prop")

function Prop:Print(...)
    g_Log("【道具】", ...)
end

function Prop:initialize(rt, data)
    self.rt = rt                              --CS.UnityEngine.RectTransform
    self.name = data.Name                     --配置名称
    self.propType = data.ItemType             --物品类型
    self.score = data.Score or 0              --分数
    self.colliderType = data.ColliderType     --碰撞类型
    self.radius = data.Radius                 --边缘半径 针对圆形碰撞体生效
    self.offset = data.Offset or Vector3.zero --偏移量
    self.size = data.Size                     --物品尺寸
    self.rotation = data.Rotation or 0        --旋转角度(弧度)
    self.backSpeed = data.BackSpeed
    self.hitOffset = data.HitOffset
    self.active = true               --是否激活
    self.guid = PropGuid             --道具唯一id
    PropGuid = PropGuid + 1
    self.prop = self.rt:Find("prop") --被抓取时的内容
end

--抓捕命中
function Prop:Capture()
    return self.prop
end

--抓捕完成
function Prop:CaptureComplete()
    self.prop.gameObject:SetActive(false)
end

--判断是否相等
function Prop:__eq(other)
    return self.guid == other.guid
end

--检测碰撞 --圆与圆
function Prop:CheckCircleOrCircleCollision(oneself, other)
    local distance = Vector3.Distance(oneself.rt.position + oneself.offset, other.rt.position + other.offset)
    return distance <= (oneself.radius + other.radius)
end

--检测碰撞 --轨道检测
function Prop:CheckTrackCollision(oneself, other, startP)
    local point = other.rt.position
    local lineStart = startP
    local lineEnd = oneself.rt.position
    local distance = self:PointToLineDistance(point, lineEnd, lineStart)
    return distance <= (oneself.radius + other.radius)
end

--计算点到线段的最短距离
function Prop:PointToLineDistance(point, lineStart, lineEnd)
    local ab = lineStart - point
    local ac = lineEnd - point
    local bc = lineEnd - lineStart
    local t = Vector3.Dot(ab, bc) / Vector3.Dot(bc, bc)
    if t < 0 then
        return ab.magnitude
    elseif t > 1 then
        return ac.magnitude
    end

    local projection = lineStart + (t * bc)
    return (point - projection).magnitude;
end

--检测碰撞 --矩形与矩形
function Prop:CheckBoxOrBosCollision(oneself, other)
    local x1 = oneself.rt.position.x - oneself.size.x / 2
    local x2 = oneself.rt.position.x + oneself.size.x / 2
    local y1 = oneself.rt.position.y - oneself.size.y / 2
    local y2 = oneself.rt.position.y + oneself.size.y / 2
    local x3 = other.rt.position.x - other.size.x / 2
    local x4 = other.rt.position.x + other.size.x / 2
    local y3 = other.rt.position.y - other.size.y / 2
    local y4 = other.rt.position.y + other.size.y / 2
    return x1 < x4 and x2 > x3 and y1 < y4 and y2 > y3
end

--检测碰撞 --圆与矩形
function Prop:CheckCircleOrBoxCollision(circle, rect)
    local cosR = math.cos(-rect.rotation)
    local sinR = math.sin(-rect.rotation)

    local rotatedCircleX = cosR * (circle.rt.position.x - rect.rt.position.x) -
        sinR * (circle.rt.position.y - rect.rt.position.y) + rect.rt.position.x
    local rotatedCircleY = sinR * (circle.rt.position.x - rect.rt.position.x) +
        cosR * (circle.rt.position.y - rect.rt.position.y) + rect.rt.position.y

    -- 找到最近点，并计算到圆心的距离。
    local nearestX = math.max(rect.rt.position.x - rect.size.x / 2,
        math.min(rotatedCircleX, rect.rt.position.x + rect.size.x / 2))
    local nearestY = math.max(rect.rt.position.y - rect.size.y / 2,
        math.min(rotatedCircleY, rect.rt.position.y + rect.size.y / 2))

    local deltaX = rotatedCircleX - nearestX;
    local deltaY = rotatedCircleY - nearestY;

    return (deltaX ^ 2 + deltaY ^ 2) < (circle.radius ^ 2)
end

--黄金矿工游戏
local EVENT_BUSINESS_CONFLICT_GOLD_MINER = "EVENT_BUSINESS_CONFLICT_GOLD_MINER"
--引导记录key
local FirstGuideKey                      = "GOLDMINER_FIRST_GUIDE"

---@class fsync_4ebcd8ae_caac_4a34_a441_04584a414c08 : WorldBaseElement
local reward_game_goldminer              = class("reward_game_goldminer")

function reward_game_goldminer:Print(...)
    g_Log("【防沉迷-黄金矿工小游戏】", ...)
end

---@param worldElement CS.Tal.framesync.WorldElement
function reward_game_goldminer:initialize(uipanel, callback)
    self.rootCanvas = uipanel
    self.LoadCompletedCall = callback
    self:InitService()
    --游戏当前剩余时间
    self.currentTime = GAME_COUNTDOWNTIME
    --游戏剩余抓取次数
    self.currentCount = GAME_PLAYCOUNT
    --当前摆动方向
    self.nowDir = RotaDirEnum.Left
    --游戏得分
    self.score = 0
    --摆动速度
    self.rotaSpeed = 50
    --绳子最小长度
    self.minLineLen = 94
    --发射中
    self.isFire = false
    --出钩子速度
    self.fireSpeed = 550
    --回收中
    self.isBack = false
    --回收钩子的初始速度
    self.baseBackSpeed = 500
    --回收钩子速度
    self.backSpeed = 500
    --当前发射点
    self.firePoint = nil
    --当前抓取到的物体
    self.catchProp = nil
    --游戏状态
    self.gameState = GameState.None
    --是否暂停
    self.isPause = false
    --是否
    --奖励道具
    self.rewardsProp = {}
    --计算屏幕道具可以随机区域
    --石头区域
    self.stonePropArea = {
        min_x = 0,
        max_x = Screen.width,
        min_y = 0,
        max_y = Screen.height * 3 / 5
    }
    --钻石区域
    self.diamondPropArea = {
        min_x = 0,
        max_x = Screen.width,
        min_y = 0,
        max_y = Screen.height * 1.5 / 5
    }
    self:Print("self.propArea->", table.dump(self.stonePropArea))
    --是否展示新手引导
    self.isShowGuide = false
    --加载完成
    self.loadComplete = false
    --初始化UI
    self:InitUI()
    --初始化监听
    self:InitListener()
end

--初始化UI
function reward_game_goldminer:InitUI()
    self.rootCanvas.gameObject:SetActive(false)
    self.rootCanvas.gameObject:GetComponent(typeof(CS.UnityEngine.Canvas)).sortingOrder = 10000
    --绳子
    self.line = self.rootCanvas:Find("gamePanel/robot_right_arm/line").gameObject:GetComponent(typeof(CS
        .UnityEngine
        .RectTransform))
    --起点
    self.startPoint = self.rootCanvas:Find("gamePanel/robot_right_arm/startPoint").gameObject:GetComponent(
        typeof(
            CS
            .UnityEngine
            .RectTransform))
    --终点
    self.targetPoint = self.rootCanvas:Find("gamePanel/robot_right_arm/targetPoint").gameObject:GetComponent(
        typeof(CS
            .UnityEngine
            .RectTransform))

    --机器人动画节点
    self.robotAni = self.rootCanvas:Find("gamePanel/robot").gameObject:GetComponent(typeof(CS.UnityEngine
        .Animator))
    --目标箭头
    self.targetArrow = self.targetPoint.transform:Find("gouzi").gameObject:GetComponent(typeof(CS
        .UnityEngine
        .RectTransform))
    self.targetArrow.localPosition = Vector3(0, -8.4, 0)
    --钩子闭合状态
    self.hookImagehe = self.targetPoint.transform:Find("gouzihe").gameObject
    --钩子打开状态
    self.hookImagekai = self.targetPoint.transform:Find("gouzikai").gameObject
    --道具摆放层
    self.propLayer = self.rootCanvas:Find("gamePanel/propLayer").gameObject:GetComponent(typeof(CS.UnityEngine
        .RectTransform))

    --获取倒计时m资源
    --倒计时
    self.timeNode = self.rootCanvas:Find("gamePanel/timeNode").gameObject
    self.timeNum1 = self.timeNode.transform:Find("timeNums/num1").gameObject:GetComponent(typeof(CS
        .UnityEngine
        .UI.Image))
    self.timeNum2 = self.timeNode.transform:Find("timeNums/num2").gameObject:GetComponent(typeof(CS.UnityEngine
        .UI.Image))
    self.timeNum3 = self.timeNode.transform:Find("timeNums/num3").gameObject:GetComponent(typeof(CS.UnityEngine
        .UI.Image))
    self.timeNum4 = self.timeNode.transform:Find("timeNums/num4").gameObject:GetComponent(typeof(CS.UnityEngine
        .UI.Image))


    --倒计时图片资源
    self.timeNumImages = {}
    local resNode1 = self.rootCanvas:Find("gamePanel/resNode1")
    for i = 0, 9 do
        local sprite = resNode1:Find(i).gameObject:GetComponent(typeof(CS.UnityEngine.SpriteRenderer)).sprite
        self.timeNumImages[i] = sprite
    end

    --获取计数资源
    --得分提示
    self.addTip = self.rootCanvas:Find("gamePanel/addTip").gameObject
    self.addTipGroup = self.addTip:GetComponent(typeof(CS.UnityEngine.CanvasGroup))

    self.addNum_ge = self.addTip.transform:Find("num_ge").gameObject:GetComponent(typeof(CS.UnityEngine
        .UI.Image))
    self.addNum_shi = self.addTip.transform:Find("num_shi").gameObject:GetComponent(typeof(CS.UnityEngine
        .UI.Image))

    --获得总量
    self.leftTop = self.rootCanvas:Find("gamePanel/leftTop").gameObject
    self.countNum_ge = self.leftTop.transform:Find("num_ge").gameObject:GetComponent(typeof(CS.UnityEngine
        .UI.Image))
    self.countNum_shi = self.leftTop.transform:Find("num_shi").gameObject:GetComponent(typeof(CS.UnityEngine
        .UI.Image))
    self.countNum_bai = self.leftTop.transform:Find("num_bai").gameObject:GetComponent(typeof(CS.UnityEngine
        .UI.Image))

    self.countNumImages = {}
    local resNode2 = self.rootCanvas:Find("gamePanel/resNode2")
    for i = 0, 9 do
        local sprite = resNode2:Find(i).gameObject:GetComponent(typeof(CS.UnityEngine.SpriteRenderer)).sprite
        self.countNumImages[i] = sprite
    end

    --引导资源节点
    self.guideNode = self.rootCanvas:Find("gamePanel/guide").gameObject

    --退出按钮
    self.exitBtn = self.rootCanvas:Find("gamePanel/exitBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI
        .Button))
    App:GetService("CommonService"):AddEventListener(self.exitBtn, "onClick", function()
        --退出游戏
        self.isPause = true
        self.topPanel.gameObject:SetActive(true)
    end)

    --钩子
    self.hook = Prop:new(self.targetArrow, {
        Name = "钩子",
        ItemType = ItemType.Hook,
        ColliderType = ColliderType.Circle,
        Rotation = 0,
        Radius = 25
    })

    --地面UI添加点击事件
    self.ground = self.rootCanvas:Find("gamePanel/dadi").gameObject
    self.btnTrigger = self.ground.gameObject:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
    self.btnTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerClick, function(data)
        if self.gameState ~= GameState.Playing then
            return
        end
        if self.isFire then
            return
        end
        if self.isBack then
            return
        end
        self:Print("点击发射钩子")
        self.isFire = true
        --播放发射钩子音频
        self:PlayAudio(self.fireAudio, 3.5)
        self.firePoint = self.targetPoint.position
        self:CheckOrCloseGuid()
    end)

    --音效
    self.audioNode = self.rootCanvas:Find("gamePanel/audioNode").gameObject
    self.bgmAudio = self.audioNode.transform:Find("bgm").gameObject:GetComponent(typeof(CS.UnityEngine
        .AudioSource))
    self.fireAudio = self.audioNode.transform:Find("fire").gameObject:GetComponent(typeof(CS.UnityEngine
        .AudioSource))
    self.backAudio = self.audioNode.transform:Find("back").gameObject:GetComponent(typeof(CS.UnityEngine
        .AudioSource))
    self.successAudio = self.audioNode.transform:Find("success").gameObject:GetComponent(typeof(CS.UnityEngine
        .AudioSource))
    self.stoneAudio = self.audioNode.transform:Find("stone").gameObject:GetComponent(typeof(CS.UnityEngine
        .AudioSource))
    self.diamondAudio = self.audioNode.transform:Find("diamond").gameObject:GetComponent(typeof(CS.UnityEngine
        .AudioSource))

    --结算UI
    self.settlePanel = self.rootCanvas:Find("settlePanel").gameObject
    self.countText = self.settlePanel.transform:Find("bg/countText").gameObject:GetComponent(typeof(CS.TMPro
        .TextMeshProUGUI))

    --二次确认弹窗
    self.topPanel = self.rootCanvas:Find("topPanel").gameObject
    --取消按钮
    self.cancelBtn = self.topPanel.transform:Find("bg/cancelBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI
        .Button))
    --确认按钮
    self.verifyBtn = self.topPanel.transform:Find("bg/verifyBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI
        .Button))


    --取消按钮点击
    App:GetService("CommonService"):AddEventListener(self.cancelBtn, "onClick", function()
        --退出游戏
        self.isPause = false
        self.topPanel.gameObject:SetActive(false)
    end)


    --确认按钮点击
    App:GetService("CommonService"):AddEventListener(self.verifyBtn, "onClick", function()
        self.topPanel.gameObject:SetActive(false)
        --退出游戏
        self:Settlement()
    end)


    self:Print("初始化完成")
    --加载完成
    self.loadComplete = true
    if self.LoadCompletedCall then
        self.LoadCompletedCall()
    end
end

--冲突管理
function reward_game_goldminer:conflictManager(open)
    if open then
        --隐藏聊天区
        self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = false })
        self.businessConflictService:DidOpenBusiness(EVENT_BUSINESS_CONFLICT_GOLD_MINER)
    else
        --隐藏聊天区
        self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = true })
        self.businessConflictService:DidCloseBusiness(EVENT_BUSINESS_CONFLICT_GOLD_MINER)
    end
end

--用户第一次玩展示引导
function reward_game_goldminer:ShowFirstGuide()
    local status = CS.UnityEngine.PlayerPrefs.GetString(FirstGuideKey .. App.Info.userId, "0")
    if status == "1" then
        return
    end
    self.isShowGuide = true
    self.guideNode.gameObject:SetActive(true)
end

--检测关闭引导
function reward_game_goldminer:CheckOrCloseGuid()
    if self.isShowGuide then
        self.isShowGuide = false
        self.guideNode.gameObject:SetActive(false)
        CS.UnityEngine.PlayerPrefs.SetString(FirstGuideKey .. App.Info.userId, "1")
        CS.UnityEngine.PlayerPrefs.Save()
    end
end

--初始化监听
function reward_game_goldminer:InitListener()
    --开始游戏
    self.observerService:Watch("EVENT_GAME_START_GOLD_MINER", function(event, value)
        if not self.loadComplete then
            self:Print("UI未加载完成")
            return
        end
        if self.gameState == GameState.Playing then
            return
        end
        --冲突管理
        self:conflictManager(true)
        --显示UI
        self.rootCanvas.gameObject:SetActive(true)
        self.topPanel.gameObject:SetActive(false)
        self.settlePanel.gameObject:SetActive(false)
        --重置游戏组件
        self:ResetGameComponent()
        --第一次游戏展示新手引导提示
        self:ShowFirstGuide()
        --开始游戏
        self.gameState = GameState.Playing

        if not App.IsStudioClient then
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_gold_miner_show", "888888",
                "continuous_gold_miner_show",
                "黄金矿工曝光", "0", {})
        end
    end)
end

--重置游戏元素
function reward_game_goldminer:ResetGameComponent()
    self.isFire = false
    self.isBack = false
    self.isPause = false
    self.score = 0
    --重置回收速度
    self.backSpeed = self.baseBackSpeed
    --重置游戏当前剩余时间
    self.currentTime = GAME_COUNTDOWNTIME
    --重置游戏剩余抓取次数
    self.currentCount = GAME_PLAYCOUNT
    --设置绳子最短长度
    self.targetPoint.localPosition = self.startPoint.localPosition + Vector3(0, -self.minLineLen, 0)
    self.targetPoint.localRotation = Quaternion.Euler(0, 0, 0)
    --更新绳子状态
    self:UpdateLine()
    --初始化道具
    self:InitProp()
    --隐藏得分UI
    self.addTip:SetActive(false)
    --更新得分
    self:UpdateScore(self.score)
end

--游戏结算
function reward_game_goldminer:Settlement()
    self.gameState = GameState.Settlement
    --todo 展示结算UI
    self:Print("结算")

    self.settlePanel.gameObject:SetActive(true)
    self.countText.text = self.score
    --显示结算UI
    self.commonService:DispatchAfter(3, function()
        self.settlePanel.gameObject:SetActive(false)
        self:ExitGame()
    end)
end

--退出游戏
function reward_game_goldminer:ExitGame()
    self.gameState = GameState.End
    self.isPause = false
    --清空正在抓取的道具
    if self.catchProp then
        self.catchProp:CaptureComplete()
        self.catchProp = nil
    end
    --隐藏UI
    self.rootCanvas.gameObject:SetActive(false)
    self:ClearAllRewardsProp()
    self:conflictManager(false)
    self:Print("退出游戏")
end

--清空所有奖励道具
function reward_game_goldminer:ClearAllRewardsProp()
    for _, prop in pairs(self.rewardsProp) do
        prop.active = false
        GameObject.Destroy(prop.rt.gameObject)
    end
    self.rewardsProp = {}
end

--初始化道具
function reward_game_goldminer:InitProp()
    self:Print("InitProp-1>")

    self:ClearAllRewardsProp()

    local propRoot = self.rootCanvas:Find("gamePanel/Props").gameObject

    local stoneNames = { "stone1", "stone2", "stone3", "stone4", "stone1", "stone2" }
    local diamondNames = { "diamond1", "diamond2", "diamond3", "diamond4", "diamond5", "diamond1", "diamond2", "diamond3" }

    --初始化石头
    for _, name in pairs(stoneNames) do
        local count = 1
        for i = 1, count do
            local config = PropConfig[name]
            local pos = self:GetRandomPosition(self.stonePropArea)
            local obj = GameObject.Instantiate(propRoot.transform:Find(name).gameObject, self.propLayer)
            obj.transform.position = pos

            -- self:Print("pos-1>", pos)

            local prop = Prop:new(obj:GetComponent(typeof(CS.UnityEngine.RectTransform)), {
                Name = name,
                ItemType = ItemType.Stone,
                ColliderType = ColliderType.Circle,
                Size = config.Size,
                Rotation = config.Rotation,
                Radius = config.Radius,
                Offset = config.Offset,
                BackSpeed = config.BackSpeed,
                HitOffset = config.HitOffset
            })

            obj:SetActive(true)
            table.insert(self.rewardsProp, prop)
        end
    end

    --初始化钻石
    for _, name in pairs(diamondNames) do
        local count = 1 --math.random(1, 2)
        for i = 1, count do
            local config = PropConfig[name]
            local pos = self:GetRandomPosition(self.diamondPropArea)
            local obj = GameObject.Instantiate(propRoot.transform:Find(name).gameObject, self.propLayer)
            obj.transform.position = pos

            -- self:Print("pos-1>", pos)

            local prop = Prop:new(obj:GetComponent(typeof(CS.UnityEngine.RectTransform)), {
                Name = name,
                ItemType = ItemType.Gold,
                Score = config.Score,
                ColliderType = ColliderType.Circle,
                Size = config.Size,
                Rotation = config.Rotation,
                Radius = config.Radius,
                Offset = config.Offset,
                BackSpeed = config.BackSpeed,
                HitOffset = config.HitOffset
            })

            obj:SetActive(true)
            table.insert(self.rewardsProp, prop)
        end
    end

    self:Print("InitProp-2>")
end

--播放音效
function reward_game_goldminer:PlayAudio(audio, delayTime)
    audio.gameObject:SetActive(true)
    if audio then
        audio:Play()
    end
    local seq = DOTween:Sequence()
    seq:AppendInterval(delayTime)
    seq:AppendCallback(function()
        audio.gameObject:SetActive(false)
    end)
end

function reward_game_goldminer:GetRandomPosition(propArea, maxAttempts)
    maxAttempts = maxAttempts or 100 -- 设置默认的最大尝试次数
    local attempts = 0
    local newPos = nil
    while attempts < maxAttempts do
        local x = math.random(math.floor(propArea.min_x), math.floor(propArea.max_x))
        local y = math.random(math.floor(propArea.min_y), math.floor(propArea.max_y))
        newPos = Vector3(x, y, 0)

        if not self:CheckOverlap(newPos) then
            return newPos -- 如果新位置没有重叠，则返回该位置
        end

        attempts = attempts + 1
    end

    -- 达到最大尝试次数后还没找到合适的位置，处理失败情况（可以返回nil、默认值或抛出错误）
    self:Print("GetRandomPosition->达到最大尝试次数后还没找到合适的位置")
    return newPos -- 或者返回一个默认值/错误处理
end

--检测位置是否可用
function reward_game_goldminer:CheckOverlap(pos)
    for _, prop in pairs(self.rewardsProp) do
        if prop.active then
            if Vector3.Distance(prop.rt.position, pos) < (prop.radius * 4) then
                return true
            end
        end
    end
    return false
end

--开始摇摆
function reward_game_goldminer:PlayRatate()
    local rightAngle = Vector3.Angle(self.targetPoint.up, Vector3.right)
    if self.nowDir == RotaDirEnum.Left then
        if rightAngle < 165 then
            self.targetPoint:RotateAround(self.startPoint.position, Vector3.forward, self.rotaSpeed * Time.deltaTime)
        else
            self.nowDir = RotaDirEnum.Right
        end
    else
        if rightAngle > 15 then
            self.targetPoint:RotateAround(self.startPoint.position, Vector3.forward,
                -self.rotaSpeed * Time.deltaTime)
        else
            self.nowDir = RotaDirEnum.Left
        end
    end
end

--更新绳子状态
function reward_game_goldminer:UpdateLine()
    local lineLen = Vector3.Distance(self.startPoint.localPosition, self.targetPoint.localPosition)
    self.line.sizeDelta = Vector2(lineLen, 8)
    local direction = self.startPoint.localPosition - self.targetPoint.localPosition
    local right = Vector3.Cross(Vector3.up, direction).normalized
    local up = Vector3.Cross(direction, right).normalized
    self.line.rotation = Quaternion.LookRotation(right, up)
end

--获取时间数字格式
function reward_game_goldminer:GetFormatNumber(t_seconds)
    local num1, num2, num3, num4 = 0, 0, 0, 0
    if t_seconds <= 0 then
        num1 = 0
        num2 = 0
        num3 = 0
        num4 = 0
    else
        local minutes = math.floor((t_seconds % 3600) / 60)
        local seconds = t_seconds % 60
        num1 = math.floor(minutes / 10)
        num2 = minutes % 10
        num3 = math.floor(seconds / 10)
        num4 = math.floor(seconds % 10)
    end
    return num1, num2, num3, num4
end

--更新游戏倒计时
function reward_game_goldminer:UpdateGameCountDownTime()
    if self.currentTime > 0 then
        self.currentTime = self.currentTime - Time.deltaTime
        local num1, num2, num3, num4 = self:GetFormatNumber(self.currentTime)

        self.timeNum1.sprite = self.timeNumImages[num1]
        self.timeNum2.sprite = self.timeNumImages[num2]
        self.timeNum3.sprite = self.timeNumImages[num3]
        self.timeNum4.sprite = self.timeNumImages[num4]
    else
        self:Settlement()
    end
end

--显示得分提示
function reward_game_goldminer:ShowAddTip(score)
    self.addTip:SetActive(true)

    --todo作淡出动画
    local seq = DOTween:Sequence()
    seq:AppendInterval(1.5)
    seq:AppendCallback(function()
        self.addTip:SetActive(false)
    end)

    --播放获取成功音频
    self:PlayAudio(self.successAudio, 1.5)

    local num1, num2 = 0, 0
    num2 = math.floor(score % 100 / 10)
    num1 = math.floor(score % 10)
    self.addNum_ge.sprite = self.countNumImages[num1]
    self.addNum_shi.sprite = self.countNumImages[num2]
    self.addNum_shi.gameObject:SetActive(num2 > 0)
end

--加分
function reward_game_goldminer:AddScore(score)
    self.observerService:Fire("EVENT_GAME_GOLD_MINER_ADD_REWARD", {
        reward = score,
        callBack = function()
            self:Print("调用服务端接口添加学识成功->", score)
        end
    })
    self.score = self.score + score
    self:ShowAddTip(score)
    self:UpdateScore(self.score)
end

--更新得分
function reward_game_goldminer:UpdateScore(score)
    local num1, num2, num3 = 0, 0, 0
    num1 = math.floor(score / 100)
    num2 = math.floor(score % 100 / 10)
    num3 = math.floor(score % 10)

    self.countNum_ge.sprite = self.countNumImages[num3]
    self.countNum_shi.sprite = self.countNumImages[num2]
    self.countNum_bai.sprite = self.countNumImages[num1]
    self.countNum_shi.gameObject:SetActive(num2 > 0 or num1 > 0)
    self.countNum_bai.gameObject:SetActive(num1 > 0)
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function reward_game_goldminer:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function reward_game_goldminer:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function reward_game_goldminer:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function reward_game_goldminer:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function reward_game_goldminer:AvatarCreated(avatar)

end

--初始化
function reward_game_goldminer:InitService()
    ---@type Gate
    self.gate                     = CourseEnv.ServicesManager.Gate
    ---@type ObserverService
    self.BusEventService          = CourseEnv.ServicesManager:GetObserverService()
    self.observerService          = self.BusEventService
    ---@type AvatarService
    self.avatarService            = CourseEnv.ServicesManager:GetAvatarService()
    ---@type CommonService
    self.commonService            = App:GetService("CommonService")
    ---@type ConfigService
    self.configService            = CourseEnv.ServicesManager:GetConfigService()
    ---@type DebugService
    self.debugService             = CourseEnv.ServicesManager:GetDebugService()
    ---@type HttpService
    self.httpService              = CourseEnv.ServicesManager:GetHttpService()
    ---@type AssetService
    self.assetService             = CourseEnv.ServicesManager:GetAssetService()
    ---@type UIService
    self.UIService                = App:GetService("UIService")
    ---@type JsonService
    self.jsonService              = CourseEnv.ServicesManager:GetJsonService()
    ---@type AudioService
    self.audioService             = CourseEnv.ServicesManager:GetAudioService()
    ---@type JoystickService
    self.joystickService          = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DecorateService
    self.decorateService          = CourseEnv.ServicesManager:GetDecorateService()
    ---@type LightService
    self.lightService             = CourseEnv.ServicesManager:GetLightService()

    self.businessConflictService  = CourseEnv.ServicesManager:GetBusinessConflictService()
    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function reward_game_goldminer:LogicMapIsAsyncRecorver()
    return false
end

--开始恢复方法（断线重连的时候用）
function reward_game_goldminer:LogicMapStartRecover()
    reward_game_goldminer.super:LogicMapStartRecover()
    --TODO
end

--结束恢复方法 (断线重连的时候用)
function reward_game_goldminer:LogicMapEndRecover()
    reward_game_goldminer.super:LogicMapEndRecover(self)
    --TODO
end

--所有的组件恢复完成
function reward_game_goldminer:LogicMapAllComponentRecoverComplete()
end

--收到Trigger事件
function reward_game_goldminer:OnReceiveTriggerEvent(interfaceId)
end

--收到GetData事件
function reward_game_goldminer:OnReceiveGetDataEvent(interfaceId)
    return nil
end

--播放出钩子
function reward_game_goldminer:PlayMoveForward()
    self.targetPoint.position = self.targetPoint.position + self.targetPoint.up * -1 * self.fireSpeed * Time.deltaTime
end

--播放回收钩子
function reward_game_goldminer:PlayMoveBack()
    self.targetPoint.position = self.targetPoint.position + self.targetPoint.up * self.backSpeed * Time.deltaTime
    if self.targetPoint.position.y >= self.firePoint.y then
        self.isBack = false
        self.targetPoint.position = self.firePoint

        if self.catchProp then
            --重置回收速度
            self.backSpeed = self.baseBackSpeed
            --加分
            if self.catchProp.score > 0 then
                self.robotAni:SetTrigger("success")
                self:AddScore(self.catchProp.score)
            else
                self.robotAni:SetTrigger("fail")
            end
            self.catchProp:CaptureComplete()
            self.catchProp = nil
        end
    end
end

--碰撞检测
function reward_game_goldminer:OnTriggerEnter(other)
    if ItemType.Stone == other.propType or ItemType.Gold == other.propType then
        self:Print("抓取物品")
        --停止当前捕获道具检测
        other.active = false
        self.catchProp = other

        --返回
        self.isFire = false
        self.isBack = true
        --播放回收钩子音频
        self.fireAudio.gameObject:SetActive(false)
        self:PlayAudio(self.backAudio, 3.5)

        --设置回收速度
        self.backSpeed = other.backSpeed

        if ItemType.Stone == other.propType then
            --播放石头音频
            self:PlayAudio(self.stoneAudio, 1.5)
        elseif ItemType.Stone == other.propType then
            --播放钻石音频
            self:PlayAudio(self.diamondAudio, 1.5)
        end

        self.robotAni:SetTrigger("success")
        --设置
        local prop = other:Capture()
        prop:SetParent(self.targetPoint)
        prop.position = self.targetPoint:TransformPoint(Vector3.zero + other.hitOffset)
        prop.rotation = self.targetPoint.rotation
    end
end

--碰撞检测
function reward_game_goldminer:CollisionDetection()
    --检测钩子与边界碰撞
    if self.hook.rt.position.y <= 0 or self.hook.rt.position.x <= 0 or self.hook.rt.position.x >= Screen.width then
        self.isFire = false
        self.isBack = true
        --播放回收钩子音频
        self.robotAni:SetTrigger("fail")
        self.fireAudio.gameObject:SetActive(false)
        self:PlayAudio(self.backAudio, 3.5)
        --设置回收速度
        self.backSpeed = self.fireSpeed * 1.3
        return
    end

    --检测钩子与道具碰撞
    for _, prop in pairs(self.rewardsProp) do
        if prop.active then
            if prop.colliderType == ColliderType.Circle then
                if self.hook:CheckTrackCollision(self.hook, prop, self.startPoint.position) then
                    self:OnTriggerEnter(prop)
                    break
                end
            elseif prop.colliderType == ColliderType.Box then
                if self.hook:CheckCircleOrBoxCollision(self.hook, prop) then
                    self:OnTriggerEnter(prop)
                    break
                end
            end
        end
    end
end

--绘制圆形
function reward_game_goldminer:DrawDebugCircle(center, radius, color)
    local segments = 360 --定义圆的分段数
    local angle = 0
    local prevPos = center +
        Vector3(0, Mathf.Sin(Mathf.Deg2Rad * angle) * radius, Mathf.Cos(Mathf.Deg2Rad * angle) * radius)
    for i = 1, segments do
        angle = angle + (360 / segments)
        local newPos = center +
            Vector3(0, Mathf.Sin(Mathf.Deg2Rad * angle) * radius, Mathf.Cos(Mathf.Deg2Rad * angle) * radius);
        Debug.DrawLine(prevPos, newPos, color)
        prevPos = newPos;
    end
end

------------------------蓝图组件相应方法End---------------------------------------------
function reward_game_goldminer:Tick()
    if not self.loadComplete then
        return
    end
    if self.gameState ~= GameState.Playing then
        return
    end

    if self.isPause then
        return
    end

    --更新游戏倒计时
    self:UpdateGameCountDownTime()
    --更新钩子
    self.hookImagehe:SetActive(not self.isFire)
    self.hookImagekai:SetActive(self.isFire)
    if self.isFire then
        --物体碰撞检测
        self:CollisionDetection()
        self:PlayMoveForward()
    elseif self.isBack then
        self:PlayMoveBack()
    else
        self:PlayRatate()
    end
    --更新绳子
    self:UpdateLine()

    -- --testdebug 绘制钩子碰撞区域
    -- self:DrawDebugCircle(self.hook.rt.position, self.hook.radius, Color.red)

    -- for _, prop in pairs(self.rewardsProp) do
    --     if prop.active then
    --         --testdebug 绘制道具碰撞区域
    --         if prop.colliderType == ColliderType.Circle then
    --             self:DrawDebugCircle(prop.rt.position + prop.offset, prop.radius, Color.green)
    --         end
    --     end
    -- end
end

-- 脚本释放
function reward_game_goldminer:Exit()
    if self.btnTrigger then
        self.btnTrigger:ClearAll()
    end
end

return reward_game_goldminer
