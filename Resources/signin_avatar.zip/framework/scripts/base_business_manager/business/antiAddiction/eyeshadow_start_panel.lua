---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-5-13 15:34:40】
--- 【FSync】
--- 【护眼开始UI】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/antiAddiction/"
local UIPrefabPath = ResourcePathRoot .. "assets/Prefabs/TipPanel1.prefab"
local audioPathRoot = ResourcePathRoot .. "audio/"

local eyeshadow_start_panel = class("eyeshadow_start_panel")

function eyeshadow_start_panel:initialize(root, callback)
    self.root = root
    self.LoadCompleted = callback
    self:InitService()
    self:InitUI()
end

function eyeshadow_start_panel:InitUI()
    ResourceManager:LoadGameObjectWithExName(UIPrefabPath, function(go)
        self.UIRoot = GameObject.Instantiate(go).transform
        self.UIRoot:SetParent(self.root.transform)
        self.UIRoot.localPosition = Vector3.zero
        self.UIRoot.localScale = Vector3.one
        self.UIRoot.localRotation = Quaternion.identity
        local canvas = self.UIRoot:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
        canvas.sortingOrder = 10000

        self.CountdownNode = self.UIRoot:Find("CountdownNode").gameObject
        self.tipImage = self.UIRoot:Find("tipImage").gameObject

        self.CountdownNode:SetActive(false)

        local tipText = self.tipImage.transform:Find("Text (TMP)"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        if App.modPlatform == MOD_PLATFORM.Math then
            tipText.text = "保护眼睛得贝壳！每做3秒就能得到1个贝壳哦～"
        else
            tipText.text = "保护眼睛得知识！每做1秒就能得1个知识币哦～"
        end

        self.UIRoot.gameObject:SetActive(false)

        if self.LoadCompleted then
            self.LoadCompleted()
        end
    end)

    if App.modPlatform == MOD_PLATFORM.Math then
        --加载音频
        ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "startAudio_math.mp3", function(audioclip)
            self.startAudio = audioclip
        end)
    else
        --加载音频
        ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "startAudio.mp3", function(audioclip)
            self.startAudio = audioclip
        end)
    end
end

--展示护眼提示
function eyeshadow_start_panel:Show(callback)
    self.UIRoot.gameObject:SetActive(true)
    self.tipImage:SetActive(true)
    self.CountdownNode:SetActive(false)

    self.audioService:PlayClipOneShot(self.startAudio, function()
        self.CountdownNode:SetActive(true)
        self.tipImage:SetActive(false)
        --播放倒计时动画
        self.commonService:DispatchAfter(4, function()
            self.UIRoot.gameObject:SetActive(false)
            self.CountdownNode:SetActive(false)
            if callback then
                callback()
            end
        end)
    end)



    --触发30分钟休息的倒计时弹窗 数据埋点
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("continuous_Taskrelease", "888888",
            "continuous_Taskrelease",
            "触发30分钟休息的倒计时弹窗", "0", {})
    end
end

function eyeshadow_start_panel:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()

    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

return eyeshadow_start_panel
