---
---  Author: 【吕清林】
---  AuthorID: 【283869】
---  CreateTime: 【2024-10-24 11:33:45】
--- 【FSync】
--- 【外教视频播放UI102402】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")
-- 视频领读UI110801  素材编号：117877
local uAddress_UI = "987751743415102/assets/Prefabs/video_canvas.prefab"
-- 视图类型枚举
local ViewTypeEnum = {
    LEFT_T = 1, -- 左上
    LEFT_B = 2, -- 左下
    RIGHT_T = 3, -- 右上
    RIGHT_B = 4, -- 右下
    RIGHT_T_T = 5, -- 右上带图文动画的
    CENTER = 6 -- 中间
}

---@class QuestionPanel : WorldBaseElement
local QuestionVideoPanel = class("QuestionVideoPanel", WBElement)

function QuestionVideoPanel:Print(...)
    g_Log("【外教视频播放UI】:", ...)
end

---@param worldElement CS.Tal.framesync.WorldElement
function QuestionVideoPanel:initialize(worldElement)
    QuestionVideoPanel.super.initialize(self, worldElement)
    self.lastRewardCount = -1

    self:InitService()

    -- 测试视频地址
    self.videoUrl = "https://static0.xesimg.com/next-studio-pub/app/1729838477017/6zQsJaNUe1LWSdQT5YEI.mp4"
    -- 当前展示的视图索引
    self.curViewIndex = 0
    -- 当前预报的题目索引
    self.curPreQuestionIndex = 1
    -- 预报视频关闭
    self.isForecastClose = false
    -- 视频窗口打开
    self.isVideoShow = false
    -- 视频已经被隐藏
    self.isPauseHide = false
    -- 预读是否暂停
    self.isPausePreseed = false
    -- 是否开启视频预播模式
    self.isPreseedMode = false
    -- 是否开始答题
    self.isStartAnswer = false
    -- 功能是否打开
    self.isOpen = true
    -- UI视图适配是否合理
    self.uiViewIsReasonable = true
    -- UI配置加载完成
    self.uiConfigloadComplete = false
    -- 加一个全局功能开关
    self:InitPluginInfo()
    self:InitView()
    self:InitListener()
end

function QuestionVideoPanel:InitPluginInfo()
    if not (App.IsStudioClient) then
        self.pluginJson = App.Info.plugins
        if self.pluginJson ~= nil and type(self.pluginJson) == "string" then
            local list = self.jsonService:decode(self.pluginJson)
            -- self:Print("list->", table.dump(list))
            for _, v in pairs(list) do
                if v.pluginName == "视频领读配置" then
                    xpcall(function()
                        if v.pluginVal.videoGuide_open then
                            local openValue = tonumber(v.pluginVal.videoGuide_open)
                            self.isOpen = openValue == 1
                            self:Print("视频领读配置开关->", self.isOpen)
                        end
                    end, function(err)

                    end)
                end
            end
        end
    end
end

function QuestionVideoPanel:InitView()
    -- 默认占位图
    local cover = "https://static0.xesimg.com/next-studio-pub/abc_zone/spell/image/video_default_01.png"
    -- 顶部文字
    -- local mask = "https://static0.xesimg.com/next-studio-pub/app/1729849299058/Dis5KvR6S6RMwAo5hjHh.png"
    local mask = "https://static0.xesimg.com/next-studio-pub/app/1743137988717/JGcih5Mj4HM4PFG8dcJn.png"
    -- 视图配置参数
    self.viewConfig = {}
    self.viewConfig[ViewTypeEnum.LEFT_T] = {
        nodeName = "leftViewB",
        cover = cover,
        mask = mask,
        isCircle = false
    }
    self.viewConfig[ViewTypeEnum.LEFT_B] = {
        nodeName = "leftViewS",
        cover = cover,
        mask = mask,
        isCircle = false
    }
    self.viewConfig[ViewTypeEnum.RIGHT_T] = {
        nodeName = "rightViewS",
        cover = cover,
        mask = mask,
        isCircle = false,
        radius = 0.01
    }
    self.viewConfig[ViewTypeEnum.RIGHT_B] = {
        nodeName = "rightViewB",
        cover = cover,
        mask = mask,
        isCircle = false
    }
    self.viewConfig[ViewTypeEnum.RIGHT_T_T] = {
        nodeName = "leftVideoViewT",
        cover = cover,
        -- mask = mask,
        isCircle = true
    }
    self.viewConfig[ViewTypeEnum.CENTER] = {
        nodeName = "centreView",
        cover = cover,
        -- mask = mask,
        isCircle = true
    }

    -- 加载下一题音频
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/paokumiji/"
    local beginAudiopath = ResourcePathRoot .. "arts/audios/listenPlease.mp3"
    ResourceManager:LoadAudioClipWithExName(beginAudiopath, function(audioclip)
        self.pleaseListenAudio = audioclip
    end)

    self:LoadRemoteUaddress(uAddress_UI, function(success, prefab)
        if success and prefab then
            local uiPanel = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
            self.uiRoot = uiPanel

            self.viewImages = {}
            for i, viewConfig in ipairs(self.viewConfig) do
                local viewRect = self.VisElement.transform:FindChildWithName(viewConfig.nodeName):GetComponent(typeof(
                    CS.UnityEngine.RectTransform))
                local viewImage = self.VisElement.transform:FindChildWithName(viewConfig.nodeName):GetComponent(typeof(
                    CS.UnityEngine.UI.Image))
                self.viewConfig[i].normalizedPosition = self:GetViewRect(viewRect)
                self.viewImages[i] = viewImage
            end

            -- 右侧题板
            self.leftViewT = self.VisElement.transform:FindChildWithName("leftViewT").gameObject
            self.transTitleIcon = self.leftViewT.transform:Find("titleIcon")
            -- 英文文本
            self.leftViewEText = self.leftViewT.transform:Find("enTxtLab")
                :GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
            -- 中文文本
            self.leftViewZText = self.leftViewT.transform:Find("cnTxtLab")
                :GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
            -- 音波特效
            -- 音波占位图
            self.videoEffectLImage = self.leftViewT.transform:Find("yinbo_left").gameObject
            self.videoEffectRImage = self.leftViewT.transform:Find("yinbo_right").gameObject
            self.videoEffect = self.VisElement.transform:FindChildWithName("yinbo").gameObject

            -- 右侧文本题板
            self.leftViewW = self.VisElement.transform:FindChildWithName("leftViewW").gameObject
            self.fromDetailTmp = self.leftViewW.transform:Find("content/fromText"):GetComponent(typeof(CS.TMPro
                                                                                                           .TextMeshProUGUI))
            self.dialogContentTmp = self.leftViewW.transform:Find("content/contentText"):GetComponent(typeof(CS.TMPro
                                                                                                                 .TextMeshProUGUI))
            self.fromDetailTmp.text = ""
            self.backgroundLayout =
                self.leftViewW.gameObject:GetComponent(typeof(CS.UnityEngine.UI.VerticalLayoutGroup))
            self.contentLayout = self.leftViewW.transform:Find("content"):GetComponent(typeof(CS.UnityEngine.UI
                                                                                                  .VerticalLayoutGroup))
            self.mijiBG = self.leftViewW.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
            self.mijiBGImage = self.leftViewW.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
            self.mijikewenImage = self.leftViewW.transform:Find("kewen"):GetComponent(typeof(CS.UnityEngine.UI.Image))
                                      .sprite

            self.uiConfigloadComplete = true
        end
    end)

    local url = "https://static0.xesimg.com/next-fe/uploadStaticFile/guojiabin0/assets/textures/kyd_1.png"
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.httpService:LoadNetWorkTexture(url, function(sprite)
        if not sprite then
            g_LogError("跑酷秘籍" .. url .. "加载失败")
            return
        end
        g_Log("跑酷秘籍" .. url .. "加载完成")
        self.mijikewenImage2 = sprite
    end)
end

function QuestionVideoPanel:InitListener()
    -- 测试场景使用
    self.observerService:Watch("TEST_WAIJIAO_BRIDGE", function(key, args)
        local data = args and args[0]
        local op = data and data.op
        if op == "play" then
            self.curViewIndex = 1
            local question = {}
            question.video = self.videoUrl
            self:PlayVideo(question, function(res)
                self:Print("play video res:", table.dump(res))
            end)
        elseif op == "pause" then
            self:PauseVideo()
        elseif op == "stop" then
            self:StopVideo()
        elseif op == "show" then
            self:ShowVideoView()
        elseif op == "hide" then
            self:HideVideoView()
        elseif op == "start" then
            local config = self.viewConfig[1]
            -- self:ShowViewImageByIndex(1)
            self:InitVideoView(config)
        elseif op == "resume" then
            self:ResumeVideo()
        end
    end)

    self.observerService:Watch("on_change_last_reward_count", function(key, params)
        local data = params[0]
        if data then
            self.lastRewardCount = data.count or -1
        end
    end)

    -- 视频领读相关
    self.observerService:Watch("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", function(key, args)
        local data = args and args[0]
        local op = data and data.op
        local viewType = data and data.viewType
        if op == "PlayVideo" then
            local callback = data and data.callback
            local question = data and data.question
            local viewType = data and data.viewType
            if self.curViewIndex ~= viewType then
                local config = self.viewConfig[viewType]
                self.curViewIndex = viewType
                self:InitVideoView(config)
            end
            if not self.isPauseHide then
                self:ShowVideoView()
            end
            self:PlayVideo(question, callback)
        elseif op == "pause" then
            self:PauseVideo()
        elseif op == "resume" then
            self:ResumeVideo()
        elseif op == "stop" then
            self:StopVideo()
        elseif op == "show" then
            self:ShowVideoView()
        elseif op == "hide" then
            self:HideVideoView()
        elseif op == "InitView" then
            self:HideVideoView()
            local config = self.viewConfig[viewType]
            self.curViewIndex = viewType
            self:InitVideoView(config)
        elseif op == "Available" then -- 视频播放功能是否可用
            local callback = data and data.callback
            if callback then
                callback(self:IsAvailable())
            end
        elseif op == "PauseOrHide" then
            -- self:PauseVideo()
            self.isPauseHide = true
            self:HideVideoView()
        elseif op == "ResumeOrShow" then
            -- self:ResumeVideo()
            self.isPauseHide = false
            self:ShowVideoView()
        end
    end)

    -- 视频预读相关
    self.observerService:Watch("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", function(key, args)
        local data = args and args[0]
        local op = data and data.op
        if op == "Start" then -- 开始预播
            self:Print("开启预播")
            self.isForecastClose = false
            self.isPreseedMode = true
            self.isStartAnswer = false
            local question = self:GetForecastQuestion()
            if self.uiRoot then
                self:RefreshForecastView(question)
                self:PlayQuestionForecast(question)
            else
                self:Print("开启预播时，UI还未初始化完成")
            end
        elseif op == "StartAnswer" then -- 开始答题
            self:Print("开始答题")
            if self.isForecastClose then
                self:Print("预播视频已关闭")
                return
            end
            self.isStartAnswer = true
            if self.uiRoot then
                self.leftViewT.gameObject:SetActive(false)
                self.leftViewW.gameObject:SetActive(false)
            end
            self:StopCurForecastPlay()
            -- 停止音频播放
        elseif op == "PlayNextQuestion" then -- 播放下一题
            if self.isForecastClose then
                self:Print("预播视频已关闭")
                return
            end
            self.isStartAnswer = false
            self.curPreQuestionIndex = self.curPreQuestionIndex + 1
            local question = self:GetForecastQuestion()
            self:Print("PlayNextQuestion", question)
            self:RefreshForecastView(question)
            self:PlayQuestionForecast(question)
        elseif op == "Pause" then -- 暂停
            if not self.isPreseedMode then
                return
            end
            self.isPausePreseed = true
            if self.leftViewT then
                self.leftViewT.gameObject:SetActive(false)
                self.leftViewW.gameObject:SetActive(false)
            end
            self:StopCurForecastPlay()
            self:Print("Pause")
        elseif op == "Resume" then -- 恢复
            if self.isForecastClose then
                self:Print("预播视频已关闭")
                return
            end
            if not self.isPreseedMode then
                return
            end
            self.isPausePreseed = false

            -- 答题中不恢复
            if self.isStartAnswer then
                return
            end
            local question = self:GetForecastQuestion()
            if self.uiRoot then
                self:RefreshForecastView(question)
                self:PlayQuestionForecast(question)
            end
            self:Print("Resume")
        elseif op == "Stop" then -- 关闭
            self:Print("Stop")
            self.isForecastClose = true
            self:StopCurForecastPlay()
            self:StopVideo()
            self.isPausePreseed = false
            if self.uiRoot then
                self.leftViewT.gameObject:SetActive(false)
                self.leftViewW.gameObject:SetActive(false)
            end
        end
    end)

    self.observerService:Watch("EVENT_BUSINESS_QUESTION_FROM_INFO", function(key, value)
        local data = value[0]
        self.bookName = data.bookName
        self.bookLevel = data.bookLevel
        if self.fromDetailTmp then
            self.fromDetailTmp.text = "<b>" .. "来源：" .. self.bookName .. "<br>" .. self.bookLevel .. "</b>"
        end
    end)
end

-- 检测视频领读是否可用
function QuestionVideoPanel:CanPlayQuestionForecast(question)
    -- 播放引导视频是否可用
    local PlayVideo = false
    -- 播放视频功能是否可用 --版本、是否是测试环境
    local canUse = self:IsAvailable()
    local videoUrl = question.video
    if videoUrl and videoUrl ~= "" and canUse then
        PlayVideo = true
    end
    return PlayVideo, 5
end

function QuestionVideoPanel:GetKeyWordTextByIndex(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return text
    end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                else
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#FAE105>" .. middleStr .. "</color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return text
end

-- 处理对应重点单词文字
function QuestionVideoPanel:GetKeyWordText(text, word)
    if not text and not word then
        return ""
    end
    if not word or word == "" then
        return text
    end
    for keyWord in string.gmatch(word, "%w+") do
        local keyWordLower = keyWord:lower()
        local lowerText = text:lower()
        local startIndex, endIndex = string.find(lowerText, keyWordLower)
        if startIndex and endIndex then
            -- local key = string.sub(text, startIndex, endIndex)
            -- g_Log(TAG, "使用关键词高亮显示"..keyWord)
            text = text:gsub('(%f[%a]' .. keyWord .. '[%p]*%f[^%a])', "<color=#FAE105>" .. keyWord .. "</color>")
        end
    end
    -- 替换所有出现的关键词
    return text
end

-- 刷新预告视图
function QuestionVideoPanel:RefreshForecastView(question)
    if question then
        local PlayVideo = self:CanPlayQuestionForecast(question)
        if PlayVideo then
            local style_id = question.style_id -- 51:句子 52:读书
            local text = ""
            local cn_text = ""
            if style_id == 51 then
                text = question.text_en
                cn_text = question.text_cn
                self.transTitleIcon.gameObject:SetActive(false)
            elseif style_id == 52 then
                text = question.word or question.display
                cn_text = question.text_cn
                self.transTitleIcon.gameObject:SetActive(self.lastRewardCount > 0)
            end

            -- 英文文本
            self.leftViewEText.text = text
            -- 中文文本
            self.leftViewZText.text = cn_text
            self.leftViewT.gameObject:SetActive(true)
        else
            -- 显示UI
            self.leftViewW.gameObject:SetActive(true)
            self.mijiBG.sprite = question.style_id == 52 and self.mijikewenImage or self.mijiBGImage
            local readBook = question.style_id == 52
            if readBook then
                self.transTitleIcon.gameObject:SetActive(self.lastRewardCount > 0)
                if self.lastRewardCount <= 0 then
                    if self.mijikewenImage2 then
                        self.mijiBG.sprite = self.mijikewenImage2
                    else
                        g_LogError("跑酷秘籍 mijikewenImage2 为空")
                    end
                else
                    self.mijiBG.sprite = self.mijikewenImage
                end
            else
                self.mijiBG.sprite = self.mijiBGImage
            end
            local keyWord = question.word
            local indexArray = question.indexArray
            local text_en = ""
            local text = question.text_en
            if indexArray then
                if type(indexArray) == 'string' then
                    indexArray = self.jsonService:decode(indexArray)
                end
                if indexArray and type(indexArray) == 'table' then
                    text_en = self:GetKeyWordTextByIndex(text, indexArray)
                end
            end
            if (not text_en) or text_en == "" then
                -- g_Log(TAG, self.question.text_en, keyWord)
                text_en = self:GetKeyWordText(text, keyWord)
            end

            self.dialogContentTmp.text = "<b>" .. tostring(text_en) .. "</b><br><size=20><color=#cccccc>" ..
                                             tostring(question.text_cn) .. "</color></size>"
            if question.level_name and self.bookName then
                self.fromDetailTmp.text = "<b>" .. "来源：" .. self.bookName .. "<br>" .. question.level_name ..
                                              "</b>"
            end
            if self.backgroundLayout and self.contentLayout then
                self.contentLayout.childAlignment = 0
                self.commonService:DispatchNextFrame(function()
                    self.contentLayout.childAlignment = 1
                    self.backgroundLayout.childAlignment = 1
                    self.commonService:DispatchNextFrame(function()
                        self.backgroundLayout.childAlignment = 0
                    end)
                end)
            end
        end
    end
end

-- 播放音波特效
function QuestionVideoPanel:PlayVideoEffect(play)
    if self.videoEffect then
        self.videoEffectLImage:SetActive(not play)
        self.videoEffectRImage:SetActive(not play)
        self.videoEffect:SetActive(play)
    end
end

-- 播放题目预告
function QuestionVideoPanel:PlayQuestionForecast(question)
    if self.isForecastClose then
        self:Print("预播视频已关闭")
        return
    end
    -- self:Print("PlayQuestionForecast")
    if question then
        -- 是否可以使用视频播放模式
        local PlayVideo, videoViewType = self:CanPlayQuestionForecast(question)
        if PlayVideo then
            self:PlayVideoEffect(true)
            self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
                op = "PlayVideo",
                viewType = videoViewType,
                question = question,
                callback = function(res)
                    -- self:Print("播放完成-循环播放")
                    self:PlayVideoEffect(false)
                    if self.seq then
                        self.seq:Kill()
                        self.seq = nil
                    end
                    if self.isPausePreseed then
                        return
                    end
                    self.seq = DOTween:Sequence()
                    self.seq:AppendInterval(3)
                    self.seq:AppendCallback(function()
                        self:PlayQuestionForecast(question)
                    end)
                end
            })
        else
            local audio = ""
            if question.style_id == 51 or question.style_id == 52 then
                audio = question.audio
            else
                if question.stem then
                    audio = question.stem.audio
                end
            end
            if audio == "" then
                return
            end

            self:StopCurForecastPlay()

            local audioClip = question.audioClip
            if audioClip then
                if self.isPausePreseed then
                    return
                end
                self.firstAudioSource = self.audioService:PlayClipOneShot(self.pleaseListenAudio, function()
                    -- 播放下一题
                    if self.isPausePreseed then
                        return
                    end
                    self.questionAudioSource = self.audioService:PlayClipOneShot(audioClip, function()
                        if self.seq then
                            self.seq:Kill()
                            self.seq = nil
                        end
                        -- 播放完成重新播放
                        if self.isPausePreseed then
                            return
                        end
                        self.seq = DOTween:Sequence()
                        self.seq:AppendInterval(3)
                        self.seq:AppendCallback(function()
                            -- self:Print("questionAudioSource")
                            self:PlayQuestionForecast(question)
                        end)
                    end)
                end)
            else
                self.audioService:GetMp3AudioFromGetUrl(audio, function()
                    self:Print("音频下载失败重试播放")
                    if self.isPausePreseed then
                        return
                    end
                    self:PlayQuestionForecast(question)
                end, function(clip)
                    question.audioClip = clip
                    -- self:Print("GetMp3AudioFromGetUrl")
                    if self.isPausePreseed then
                        return
                    end
                    self:PlayQuestionForecast(question)
                end)
            end
        end
    end
end

-- 停止当前正在播放的音频和视频
function QuestionVideoPanel:StopCurForecastPlay()
    self:StopVideo()
    -- 停止前面正在播放的音频
    if self.questionAudioSource then
        self.audioService:StopAudioSource(self.questionAudioSource)
        self.questionAudioSource = nil
    end

    if self.firstAudioSource then
        self.audioService:StopAudioSource(self.firstAudioSource)
        self.firstAudioSource = nil
    end

    if self.seq then
        self.seq:Kill()
        self.seq = nil
    end
end

-- 获取要预告的题目
function QuestionVideoPanel:GetForecastQuestion()
    local question = nil
    self.observerService:Fire("EVENT_ABCZONE_GET_FORECAST_QUESTION", {
        questionIndex = self.curPreQuestionIndex,
        callback = function(q)
            question = q
        end
    })
    return question
end

-- 功能是否可用
function QuestionVideoPanel:IsAvailable()
    -- todo 判断功能是否可用 .APP版本
    if App.IsStudioClient then
        return false
    end
    if not self.isOpen then
        return false
    end

    local appVersion = App.Info.appVersionNumber
    if appVersion then
        if tonumber(appVersion) >= 11702 then
            return true
        else
            return false
        end
    end

    -- 极差机型关闭视频领读
    if App.IsUltraLowDevice then
        return false
    end

    if not self.uiViewIsReasonable then
        -- 上报视频领读UI尺寸适配异常 数据埋点
        if not App.IsStudioClient then
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("Video_lead_reading_not_reasonable", "888888",
                "Video_lead_reading_not_reasonable", "视频领读UI尺寸适配异常", "0", {})
        end
        return false
    end

    return true
end

-- 测试代码
function QuestionVideoPanel:ShowViewImageByIndex(index)
    for i, viewImage in ipairs(self.viewImages) do
        viewImage.color = i == index and CS.UnityEngine.Color.red or CS.UnityEngine.Color.white
    end
end

function QuestionVideoPanel:InitService()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.commonService = App:GetService("CommonService")
end

function QuestionVideoPanel:GetViewRect(rectTransform)
    -- self:Print("rectTransform:", rectTransform)

    local size = Vector2.Scale(rectTransform.rect.size, Vector2(rectTransform.lossyScale.x, rectTransform.lossyScale.y));
    local rect = {
        x = rectTransform.position.x,
        y = CS.UnityEngine.Screen.height - rectTransform.position.y,
        width = size.x,
        height = size.y,
        screen_width = CS.UnityEngine.Screen.width,
        screen_height = CS.UnityEngine.Screen.height
    }
    rect.x = rect.x - (rectTransform.pivot.x * size.x)
    rect.y = rect.y - ((1.0 - rectTransform.pivot.y) * size.y)
    local r_x = rect.x / rect.screen_width
    local r_y = rect.y / rect.screen_height
    local width = rect.width / rect.screen_width
    local height = rect.height / rect.screen_height
    local isReasonable = width < 0.5 and height < 0.5
    if not isReasonable then
        self.uiViewIsReasonable = false
    end
    return {r_x, r_y, width, height}
end

-- 初始化视频视图
function QuestionVideoPanel:InitVideoView(config)
    -- self:Print("InitVideoView", table.dump(config.normalizedPosition))
    local initView = function()
        local radius = config.radius or 0.02
        if config.isCircle then
            radius = config.normalizedPosition[3] / 2
        end
        APIBridge.RequestAsync("app.api.video.show", {
            op = 'start',
            cover = config.cover or "",
            mask = config.mask or "",
            area = "all",
            normalizedPosition = config.normalizedPosition or {0, 0, 0, 0},
            scallMode = "aspectFill",
            cornerRadius = radius,
            borderWidth = 5,
            borderColor = "#FFFFFFFF",
            showCloseBtn = false
        })
    end
    if self.uiConfigloadComplete then
        initView()
    else
        self.commonService:StartCoroutine(function()
            coroutine.yield(self.commonService:WaitUntil(function()
                return self.uiConfigloadComplete
            end))
            initView()
        end)
    end
end

-- 显示视频视图
function QuestionVideoPanel:ShowVideoView()
    self:Print("ShowVideoView")
    self.isVideoShow = true
    -- local config = self.viewConfig[self.curViewIndex]
    -- local cover = config.cover or ""
    APIBridge.RequestAsync("app.api.video.show", {
        op = 'show'
    })
end

-- 隐藏视频视图
function QuestionVideoPanel:HideVideoView()
    self:Print("HideVideoView")
    self.isVideoShow = false
    APIBridge.RequestAsync("app.api.video.show", {
        op = 'hide'
    })
end

-- 暂停视频播放
function QuestionVideoPanel:PauseVideo()
    self:Print("PauseVideo")
    APIBridge.RequestAsync("app.api.video.show", {
        op = 'pause'
    })
end

-- 恢复视频播放
function QuestionVideoPanel:ResumeVideo()
    self:Print("ResumeVideo")
    APIBridge.RequestAsync("app.api.video.show", {
        op = 'resume'
    })
end

-- 播放视频
function QuestionVideoPanel:PlayVideo(question, callback)
    -- if question then
    --     self:Print("question", table.dump(question))
    -- end

    self.isVideoShow = true
    local videoUrl = question and question.video
    local config = self.viewConfig[self.curViewIndex]
    -- 安卓特殊处理一下播放时初始化一下
    if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.Android then
        self:InitVideoView(config)
        if self.isPauseHide then
            self:HideVideoView()
        end
    end
    -- self:Print("PlayVideo", videoUrl)
    APIBridge.RequestAsync("app.api.video.show", {
        op = 'play',
        cover = config.cover or "",
        url = videoUrl
    }, function(res)
        if res then

        end
        if callback then
            callback(res)
        end
    end)
end

-- 停止视频播放
function QuestionVideoPanel:StopVideo()
    -- self:Print("StopVideo")
    self.isVideoShow = false
    self.curViewIndex = 0
    APIBridge.RequestAsync("app.api.video.show", {
        op = 'stop'
    })
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function QuestionVideoPanel:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function QuestionVideoPanel:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionVideoPanel:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionVideoPanel:SelfAvatarPrefabLoaded(avatar)
    -- self.observerService:Fire("EVENT_ABCZONE_GET_ALL_QUESTION", {
    --     callback = function(questions)
    --         self:Print("EVENT_ABCZONE_GET_ALL_QUESTION", table.dump(questions))
    --     end
    -- })
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionVideoPanel:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function QuestionVideoPanel:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function QuestionVideoPanel:LogicMapStartRecover()
    QuestionVideoPanel.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function QuestionVideoPanel:LogicMapEndRecover()
    QuestionVideoPanel.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function QuestionVideoPanel:LogicMapAllComponentRecoverComplete()
end

-- 收到Trigger事件
function QuestionVideoPanel:OnReceiveTriggerEvent(interfaceId)
end

-- 收到GetData事件
function QuestionVideoPanel:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function QuestionVideoPanel:Exit()
    if self.isVideoShow then
        self:StopVideo()
    end
    QuestionVideoPanel.super.Exit(self)
end

return QuestionVideoPanel
