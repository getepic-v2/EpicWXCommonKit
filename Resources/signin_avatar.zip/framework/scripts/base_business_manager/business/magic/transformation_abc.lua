local class = require("middleclass")
local TransformationEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/transformation_effect")

-- Configuration specific to TransformationABC
local CONFIG = {
    uaddress = "1041481753771052/assets/Prefabs/female_student_new.prefab"
}

local user_data = {
    stat = 1,
    code = 0,
    msg = "success",
    data = {
        user_id = 1090003232,
        nick_name = "56110081",
        avatar = "https://static0.xesimg.com/next-app/avatar/avatar8.png",
        defend_phone = "",
        dress_info = {
            list = {{
                id = 25,
                name = "",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1729504492293-65.png",
                package = {
                    ios = "",
                    android = "",
                    ios_high = "",
                    android_high = "",
                    package_id = 0,
                    asset_name = "",
                    body_part_type = 0,
                    u_address = "",
                    u_address_high = "",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1729504492293-65.png",
                    sketch_url = "https://static0-test.xesimg.com/next-scm/resource/source-1691148459533-94.png",
                    decorate_type = 4,
                    cut_type = 0,
                    is_default = 1,
                    ios_md5 = "",
                    ios_high_md5 = "",
                    android_md5 = "",
                    android_high_md5 = "",
                    material_id = 0,
                    effect_video = "",
                    texture_url = "https://static0-test.xesimg.com/next-scm/resource/source-1704363471641-67.png",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    share_pic = "",
                    legend_button_pic = "",
                    idle_name = "",
                    idle_desc = "",
                    idle_img = "",
                    idle_bg = ""
                },
                level = 10,
                user_id = 1090003232,
                type = 4,
                idle_status = 0
            }, {
                id = 29,
                name = "",
                pic = "https://static0-test.xesimg.com/next-scm/resource/source-1704798979177-70.png",
                package = {
                    ios = "",
                    android = "",
                    ios_high = "",
                    android_high = "",
                    package_id = 0,
                    asset_name = "",
                    body_part_type = 0,
                    u_address = "",
                    u_address_high = "",
                    cover_url = "https://static0-test.xesimg.com/next-scm/resource/source-1704798979177-70.png",
                    sketch_url = "https://static0-test.xesimg.com/next-scm/resource/source-1691148641446-14.png",
                    decorate_type = 5,
                    cut_type = 0,
                    is_default = 1,
                    ios_md5 = "",
                    ios_high_md5 = "",
                    android_md5 = "",
                    android_high_md5 = "",
                    material_id = 0,
                    effect_video = "",
                    texture_url = "https://static0-test.xesimg.com/next-scm/resource/source-1704699985995-81.png",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    share_pic = "",
                    legend_button_pic = "",
                    idle_name = "",
                    idle_desc = "",
                    idle_img = "",
                    idle_bg = ""
                },
                level = 10,
                user_id = 1090003232,
                type = 5,
                idle_status = 0
            }, {
                id = 543,
                name = "小清新格子裙",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1695278695033-36.png",
                package = {
                    ios = "https://static0.xesimg.com/next-studio-pub/ios_bundle/790961694678293.zip",
                    android = "https://static0.xesimg.com/next-studio-pub/android_bundle/790961694678293.zip",
                    ios_high = "https://static0.xesimg.com/next-studio-pub/ios_bundle/790961694678293.zip",
                    android_high = "https://static0.xesimg.com/next-studio-pub/android_bundle/790961694678293.zip",
                    package_id = 79096,
                    asset_name = "小清新格子裙",
                    body_part_type = 10,
                    u_address = "790961694678293/assets/Prefabs/putong_04_rig (1).prefab",
                    u_address_high = "790961694678293/assets/Prefabs/putong_04_rig (1).prefab",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1695278695033-36.png",
                    sketch_url = "https://static0.xesimg.com/wx-mobile-fe/下装.png",
                    decorate_type = 3,
                    cut_type = 5,
                    is_default = 0,
                    ios_md5 = "863ddb805b44fe0c07aa92ec7c324ee9",
                    ios_high_md5 = "863ddb805b44fe0c07aa92ec7c324ee9",
                    android_md5 = "6617460378d01db18f13d904ec2114c1",
                    android_high_md5 = "6617460378d01db18f13d904ec2114c1",
                    material_id = 93414,
                    effect_video = "",
                    texture_url = "",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    share_pic = "",
                    legend_button_pic = "",
                    idle_name = "",
                    idle_desc = "",
                    idle_img = "",
                    idle_bg = ""
                },
                level = 20,
                user_id = 1090003232,
                type = 3,
                idle_status = 0
            }, {
                id = 809,
                name = "奶奶灰",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1700136584715-47.png",
                package = {
                    ios = "https://static0.xesimg.com/next-studio-pub/ios_bundle/809031698920392.zip",
                    android = "https://static0.xesimg.com/next-studio-pub/android_bundle/809031698920392.zip",
                    ios_high = "https://static0.xesimg.com/next-studio-pub/ios_bundle/809031698920392.zip",
                    android_high = "https://static0.xesimg.com/next-studio-pub/android_bundle/809031698920392.zip",
                    package_id = 80903,
                    asset_name = "奶奶灰",
                    body_part_type = 7,
                    u_address = "809031698920392/assets/Prefabs/C_Hair_01.prefab",
                    u_address_high = "809031698920392/assets/Prefabs/C_Hair_01.prefab",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1700136584715-47.png",
                    sketch_url = "https://static0.xesimg.com/wx-mobile-fe/头部.png",
                    decorate_type = 1,
                    cut_type = -1,
                    is_default = 0,
                    ios_md5 = "8b08d632bbd891bfea43204444684906",
                    ios_high_md5 = "8b08d632bbd891bfea43204444684906",
                    android_md5 = "834f7184b5a4ec4d4bd34816fddd51d6",
                    android_high_md5 = "834f7184b5a4ec4d4bd34816fddd51d6",
                    material_id = 96493,
                    effect_video = "",
                    texture_url = "",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    share_pic = "",
                    legend_button_pic = "",
                    idle_name = "",
                    idle_desc = "",
                    idle_img = "",
                    idle_bg = ""
                },
                level = 20,
                user_id = 1090003232,
                type = 1,
                idle_status = 0
            }, {
                id = 810,
                name = "万圣节南瓜上装",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1700391365828-78.png",
                package = {
                    ios = "https://static0.xesimg.com/next-studio-pub/ios_bundle/814881700449806.zip",
                    android = "https://static0.xesimg.com/next-studio-pub/android_bundle/814881700449806.zip",
                    ios_high = "https://static0.xesimg.com/next-studio-pub/ios_bundle/814881700449806.zip",
                    android_high = "https://static0.xesimg.com/next-studio-pub/android_bundle/814881700449806.zip",
                    package_id = 81488,
                    asset_name = "万圣节南瓜上装",
                    body_part_type = 4,
                    u_address = "814881700449806/assets/Prefabs/nanguatou_01_rig.prefab",
                    u_address_high = "814881700449806/assets/Prefabs/nanguatou_01_rig.prefab",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1700391365828-78.png",
                    sketch_url = "https://static0.xesimg.com/wx-mobile-fe/上衣.png",
                    decorate_type = 2,
                    cut_type = 1,
                    is_default = 0,
                    ios_md5 = "5ed2068b708de78698c65d1162ed1e58",
                    ios_high_md5 = "5ed2068b708de78698c65d1162ed1e58",
                    android_md5 = "3ca24186146fba15a03e42eb06334ba3",
                    android_high_md5 = "3ca24186146fba15a03e42eb06334ba3",
                    material_id = 97760,
                    effect_video = "",
                    texture_url = "",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    share_pic = "",
                    legend_button_pic = "",
                    idle_name = "",
                    idle_desc = "",
                    idle_img = "",
                    idle_bg = ""
                },
                level = 20,
                user_id = 1090003232,
                type = 2,
                idle_status = 0
            }},
            has_dress = false
        },
        continue_study_day = 0,
        total_continue_study_day = 0,
        cheese_cnt = 3640,
        power_cnt = 69746,
        pet_level = 1,
        cur_season_level = 3,
        cur_season_section_num = "4",
        cur_season_score = 0,
        history_season_level = 1,
        history_season_section = "3",
        history_season_score = 4,
        fashion_level = 1110,
        has_friend = false,
        school_name = "",
        school_id = 0,
        prosperity = 776,
        is_vip = false,
        vip_status = 0,
        svip_status = 0,
        identity = 0,
        union_id = "1y2p0ij32dvep",
        cur_study_level = 1,
        cur_study_sub_level = 3,
        unread_moment_count = 0,
        recent_moment_time = 0
    },
    traceId = "60099d744ae8b0a8"
}

local user_data_vip = {
    stat = 1,
    code = 0,
    msg = "success",
    data = {
        user_id = 1090003232,
        nick_name = "56110081",
        avatar = "https://static0.xesimg.com/next-app/avatar/avatar8.png",
        defend_phone = "",
        dress_info = {
            list = {
                {
                    id = 25,
                    name = "",
                    pic = "https://static0.xesimg.com/next-scm/resource/source-1729504492293-65.png",
                    package = {
                        ios = "",
                        android = "",
                        ios_high = "",
                        android_high = "",
                        package_id = 0,
                        asset_name = "",
                        body_part_type = 0,
                        u_address = "",
                        u_address_high = "",
                        cover_url = "https://static0.xesimg.com/next-scm/resource/source-1729504492293-65.png",
                        sketch_url = "https://static0-test.xesimg.com/next-scm/resource/source-1691148459533-94.png",
                        decorate_type = 4,
                        cut_type = 0,
                        is_default = 1,
                        ios_md5 = "",
                        ios_high_md5 = "",
                        android_md5 = "",
                        android_high_md5 = "",
                        material_id = 0,
                        effect_video = "",
                        texture_url = "https://static0-test.xesimg.com/next-scm/resource/source-1704363471641-67.png",
                        effect_start_pic = "",
                        effect_end_pic = "",
                        preview_video = "",
                        share_pic = "",
                        legend_button_pic = "",
                        idle_name = "",
                        idle_desc = "",
                        idle_img = "",
                        idle_bg = ""
                    },
                    level = 10,
                    user_id = 1090003232,
                    type = 4,
                    idle_status = 0
                },
                {
                    id = 29,
                    name = "",
                    pic = "https://static0-test.xesimg.com/next-scm/resource/source-1704798979177-70.png",
                    package = {
                        ios = "",
                        android = "",
                        ios_high = "",
                        android_high = "",
                        package_id = 0,
                        asset_name = "",
                        body_part_type = 0,
                        u_address = "",
                        u_address_high = "",
                        cover_url = "https://static0-test.xesimg.com/next-scm/resource/source-1704798979177-70.png",
                        sketch_url = "https://static0-test.xesimg.com/next-scm/resource/source-1691148641446-14.png",
                        decorate_type = 5,
                        cut_type = 0,
                        is_default = 1,
                        ios_md5 = "",
                        ios_high_md5 = "",
                        android_md5 = "",
                        android_high_md5 = "",
                        material_id = 0,
                        effect_video = "",
                        texture_url = "https://static0-test.xesimg.com/next-scm/resource/source-1704699985995-81.png",
                        effect_start_pic = "",
                        effect_end_pic = "",
                        preview_video = "",
                        share_pic = "",
                        legend_button_pic = "",
                        idle_name = "",
                        idle_desc = "",
                        idle_img = "",
                        idle_bg = ""
                    },
                    level = 10,
                    user_id = 1090003232,
                    type = 5,
                    idle_status = 0
                },
                {
                    id = 11129,
                    name = "无双吕布",
                    pic = "https://static0.xesimg.com/next-scm/resource/source-1736735569172-88.png",
                    package = {
                        ios = "https://static0.xesimg.com/next-studio-pub/ios_bundle/964051736755647.zip",
                        android = "https://static0.xesimg.com/next-studio-pub/android_bundle/964051736755647.zip",
                        ios_high = "https://static0.xesimg.com/next-studio-pub/ios_bundle/964051736755647.zip",
                        android_high = "https://static0.xesimg.com/next-studio-pub/android_bundle/964051736755647.zip",
                        package_id = 96405,
                        asset_name = "无双吕布",
                        body_part_type = 0,
                        u_address = "964051736755647/assets/Prefabs/M_LvBu@anim_idle.prefab",
                        u_address_high = "964051736755647/assets/Prefabs/M_LvBu@anim_idle.prefab",
                        cover_url = "https://static0.xesimg.com/next-scm/resource/source-1736735569172-88.png",
                        sketch_url = "",
                        decorate_type = 7,
                        cut_type = 0,
                        is_default = 0,
                        ios_md5 = "3b168de1c18314aa0147686808841d2b",
                        ios_high_md5 = "3b168de1c18314aa0147686808841d2b",
                        android_md5 = "211b9ce0fe1c2cb936eaea34f726d241",
                        android_high_md5 = "211b9ce0fe1c2cb936eaea34f726d241",
                        material_id = 124008,
                        effect_video = "https://static0.xesimg.com/next-scm/scene/source-1737016431157-91.mp4",
                        texture_url = "",
                        effect_start_pic = "",
                        effect_end_pic = "",
                        preview_video = "",
                        share_pic = "",
                        legend_button_pic = "",
                        idle_name = "",
                        idle_desc = "",
                        idle_img = "",
                        idle_bg = ""
                    },
                    level = 40,
                    user_id = 1090003232,
                    type = 7,
                    idle_status = 0
                }
            },
            has_dress = false
        },
        continue_study_day = 0,
        total_continue_study_day = 0,
        cheese_cnt = 3640,
        power_cnt = 69746,
        pet_level = 1,
        cur_season_level = 3,
        cur_season_section_num = "4",
        cur_season_score = 0,
        history_season_level = 1,
        history_season_section = "3",
        history_season_score = 4,
        fashion_level = 1110,
        has_friend = false,
        school_name = "",
        school_id = 0,
        prosperity = 776,
        is_vip = false,
        vip_status = 0,
        svip_status = 0,
        identity = 0,
        union_id = "1y2p0ij32dvep",
        cur_study_level = 1,
        cur_study_sub_level = 3,
        unread_moment_count = 0,
        recent_moment_time = 0
    },
    traceId = "959b4a89f79e1144"
}

---@class TransformationABC : TransformationEffect 
local TransformationABC = class("TransformationABC", TransformationEffect)

function TransformationABC:initialize(magicManager)
    TransformationABC.super.initialize(self, magicManager)
    
    -- Register and load the specific prefab for ABC transformation
    self.magicManager:RegisterDownloadUaddress(CONFIG.uaddress)
    self.magicManager:LoadRemoteUaddress(CONFIG.uaddress, function(success, prefab)
        if success then
            self.prefab = prefab
        end
    end)
end

-- Override to provide config
function TransformationABC:getConfig()
    return CONFIG
end

-- Override to provide test data
function TransformationABC:getTestUserData()
    -- Check if we should use VIP data
    if self:shouldUseVIPData() then
        return user_data_vip
    else
        return user_data
    end
end

-- Determine whether to use VIP data
function TransformationABC:shouldUseVIPData()
    -- You can implement your own logic here
    -- For example, check a global variable, user property, or random selection
    
    -- Option 1: Check if VIP mode is enabled globally
    if _G.USE_VIP_TEST_DATA then
        return true
    end
    
    -- Option 2: Random selection for testing (50% chance)
    -- return math.random() > 0.5
    
    -- Option 3: Check specific avatar property
    -- local avatar = self.magicManager.avatarService.selfAvatar
    -- if avatar and avatar.is_vip then
    --     return true
    -- end
    
    -- Default to normal data
    return false
end

-- Override to provide subject for ABC
function TransformationABC:getSubject()
    return "english"
end



-- Override find part mesh for ABC-specific behavior
function TransformationABC:FindPartMesh(skeletonBase, partName)
    -- ABC looks for part directly first, then in Geometry
    local basePartMesh = skeletonBase:Find(partName)
    if not basePartMesh then
        basePartMesh = skeletonBase:Find("Geometry/" .. partName)
    end
    return basePartMesh
end

-- Override share skeleton method for ABC-specific behavior
function TransformationABC:ShareSkeletonForVirtualAvatar(skinMeshRd, skeletonBase, bodyPartType, oldSkinMeshRd, oldMeshGo)
    local boneRoot = skeletonBase.transform:Find("Character_Hips") or skeletonBase.transform:Find("Character_Hip")
    
    if bodyPartType == 7 then -- Hair
        boneRoot = skeletonBase.transform:Find("Character_Spine2")
    end
    
    local skinMeshRootBone = oldMeshGo.transform
    skinMeshRd.bones = oldSkinMeshRd.bones
    skinMeshRd.rootBone = skinMeshRootBone
    self:Print("bone sharing complete")
end

return TransformationABC