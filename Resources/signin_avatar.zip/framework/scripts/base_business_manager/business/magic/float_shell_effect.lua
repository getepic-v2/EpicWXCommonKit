local class                 = require("middleclass")
local BaseMagicEffect       = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local Util                  = require(MAIN_SCRIPTS_LOC .. "common/util")

local uAddress              = "971411739254544/assets/Prefabs/Canvas.prefab"
--出场特效
local uAddressShowEffect    = "990561743673101/assets/Prefabs/Vfx_bianshen_shanguang.prefab"
--贝壳
local uAddressShell         = "990831743993614/assets/Prefabs/M_beike_anim.prefab"

local AVATAR_STATUS         = {
    NORMAL = 0,
    MAGIC = 1,
}

---@class FloatShellMagicEffect : BaseMagicEffect --浮空贝壳
local FloatShellMagicEffect = class("FloatShellMagicEffect", BaseMagicEffect)

function FloatShellMagicEffect:initialize(magicManager)
    FloatShellMagicEffect.super.initialize(self, magicManager)
    -- 初始化特效资源

    self.magicManager:RegisterDownloadUaddress(uAddress)
    self.magicManager:RegisterDownloadUaddress(uAddressShowEffect)
    self.magicManager:LoadRemoteUaddress(uAddressShowEffect, function(success, prefabs)
        if success then
            self.FloatShellShowEffect = prefabs
        end
    end)

    self.magicManager:RegisterDownloadUaddress(uAddressShell)
    self.magicManager:LoadRemoteUaddress(uAddressShell, function(success, prefabs)
        if success then
            self.FloatShellEffect = prefabs
        end
    end)
end

--展示贝壳
function FloatShellMagicEffect:ShowShell(avatar, callback)
    if Util:IsNil(avatar.shellmount) then
        avatar.shellmount = CS.UnityEngine.Object.Instantiate(self.FloatShellEffect, avatar.Body.transform).transform
        avatar.shellmount.transform.localPosition = Vector3(0, 0, 0)
        avatar.shellmount.transform.localScale = Vector3.one
        avatar.shellmount.transform.localRotation = Quaternion.identity
        avatar.shellmount.gameObject:SetActive(true)
    else
        avatar.shellmount.transform.localPosition = Vector3(0, 0, 0)
        avatar.shellmount.gameObject:SetActive(true)
    end
    if avatar.palyShowShellSeq then
        avatar.palyShowShellSeq:Kill()
        avatar.palyShowShellSeq = nil
    end
    local seq = DOTween:Sequence()
    seq:AppendInterval(1)
    seq:AppendCallback(function()
        callback(avatar.shellmount)
        avatar.palyShowShellSeq = nil
    end)
    avatar.palyShowShellSeq = seq
end

--隐藏贝壳
function FloatShellMagicEffect:HideShell(avatar)
    if Util:IsNil(avatar.shellmount) then
        return
    end
    avatar.shellmount.gameObject:SetActive(false)
    if avatar.palyShowShellSeq then
        avatar.palyShowShellSeq:Kill()
        avatar.palyShowShellSeq = nil
    end
end

--隐藏瞬移动画
function FloatShellMagicEffect:HideShellMoveAnimation(avatar)
    if Util:IsNil(avatar.shellmountEffect) then
        return
    end
    avatar.shellmountEffect.gameObject:SetActive(false)

    if avatar.palyShellMoveAnimationSeq then
        avatar.palyShellMoveAnimationSeq:Kill()
        avatar.palyShellMoveAnimationSeq = nil
    end
end

--播放瞬移动化
function FloatShellMagicEffect:PlayShellMoveAnimation(avatar, callback)
    if Util:IsNil(avatar.shellmountEffect) then
        avatar.shellmountEffect = CS.UnityEngine.Object.Instantiate(self.FloatShellShowEffect,
            avatar.VisElement.transform).transform
        avatar.shellmountEffect.transform.localPosition = Vector3(0, 0, 0)
        avatar.shellmountEffect.transform.localScale = Vector3.one
        avatar.shellmountEffect.transform.localRotation = Quaternion.identity
        avatar.shellmountEffect.gameObject:SetActive(true)
    else
        avatar.shellmountEffect.transform.localPosition = Vector3(0, 0, 0)
        avatar.shellmountEffect.gameObject:SetActive(true)
    end
   
    if avatar.palyShellMoveAnimationSeq then
        avatar.palyShellMoveAnimationSeq:Kill()
        avatar.palyShellMoveAnimationSeq = nil
    end
    local seq = DOTween:Sequence()
    seq:AppendInterval(1)
    seq:AppendCallback(function()
        callback(avatar.shellmountEffect)
        avatar.palyShellMoveAnimationSeq = nil
    end)
    avatar.palyShellMoveAnimationSeq = seq
end

function FloatShellMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        if data.uuid == App.Uuid then
            --停止宠物跟随并且隐藏宠物
            self.magicManager.observerService:Fire("PETSYSTEM_SET_PET_FOLLOW_STATE", {
                follow = false, hide = true
            })
            -- --加载显示控制UI
            self:DisableJump()
            self:DisableMove()
            self.posY = avatar.VisElement.transform.position.y
            self.maxHeigh = magicInfo.max_height or 10
            --贝壳坐骑
        end

        --人物消失
        local character = avatar:GetCharacter()

        if not character then
            self:Print("Error: not character")
            return
        end
        character.gameObject:SetActive(false)
        --播放贝壳瞬移动画
        self:PlayShellMoveAnimation(avatar, function(shellEffect)
            --显示贝壳
            self:ShowShell(avatar, function(shell)
                --贝壳绑定
                character.gameObject:SetActive(true)
                character.transform.localPosition = Vector3(0, 0.05, 0.5)
                shell.transform.localPosition = Vector3(0, 0, 0)
                avatar.characterCtrl.switchGravity = false
                -- avatar.moveState = AVATAR_ENUM.MOVE_TYPE.DIVE
                avatar.isUseFlyMode = true
                if magicInfo.gravityRate then
                    avatar:SetGravityFactor(magicInfo.gravityRate)
                end
                if magicInfo.speedRate then
                    avatar:SetMoveSpeedFactor(magicInfo.speedRate)
                end
                if data.uuid == App.Uuid then
                    --设置动画层
                    avatar:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_ride", nil, true)
                    self:ShowControlUI()
                    self:RecoverMove()
                    avatar.verticalFlag = 0
                    avatar:_Move(nil)
                    if self.updateDownId then
                        self.magicManager.commonService:UnregisterGlobalTimer(self.updateDownId)
                        self.updateDownId = nil
                    end
                    if self.updateUpId then
                        self.magicManager.commonService:UnregisterGlobalTimer(self.updateUpId)
                        self.updateUpId = nil
                    end
                end
            end)
        end)
    end
end

function FloatShellMagicEffect:onEnd(data, avatar)
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end

    local magicInfo = data.magic
    if data.uuid == App.Uuid then
        self.magicManager.observerService:Fire("PETSYSTEM_SET_PET_FOLLOW_STATE", { follow = true })
        avatar:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "stop_ride", nil, true)
        --加载显示控制UI
        self:HideControlUI()
        self:RecoverMove()
        self:RecoverJump()
    end
    local character = avatar:GetCharacter()
    if Util:IsNil(character) then
        self:Print("Error: not character")
        return
    end
    character.gameObject:SetActive(true)
    character.transform.localPosition = Vector3.zero
    self:HideShellMoveAnimation(avatar)
    self:HideShell(avatar)
    avatar.characterCtrl.switchGravity = true
    -- avatar.moveState = AVATAR_ENUM.MOVE_TYPE.WALK
    avatar.isUseFlyMode = false
    avatar:SetGravityFactor(1)
    avatar:SetMoveSpeedFactor(1)
end

--隐藏控制UI
function FloatShellMagicEffect:HideControlUI()
    if self.controlPanel and self.controlPanel.gameObject.activeSelf == true then
        self.controlPanel.gameObject:SetActive(false)
    end
end

--加载UI
function FloatShellMagicEffect:ShowControlUI()
    if self.controlPanel and self.controlPanel.gameObject.activeSelf == false then
        self.controlPanel.gameObject:SetActive(true)
    elseif self.controlPanel and self.controlPanel.gameObject.activeSelf == true then
        return
    else
        self.magicManager:LoadRemoteUaddress(uAddress, function(success, prefab)
            if success then
                self.controlPanel = CS.UnityEngine.Object.Instantiate(prefab, self.magicManager.VisElement.transform)
                .transform
                self.contentCanvas = self.controlPanel:GetComponent(typeof(CS.UnityEngine.Canvas))
                self.contentCanvas.sortingOrder = 200
                self:InitControlView()
                self:InitControlEvent()
            end
        end, true)
    end
end

--加载节点
function FloatShellMagicEffect:InitControlView(...)
    self.upButton = self.controlPanel:Find("上"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.downButton = self.controlPanel:Find("下"):GetComponent(typeof(CS.UnityEngine.UI.Button))
end

--注册控制按钮事件
function FloatShellMagicEffect:InitControlEvent(...)
    self.avatar = self.magicManager.myAvatar

    self.holdUpBtnTrigger = self.upButton.gameObject:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
    --按下向上监听
    self.holdUpBtnTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerDown,
        function(data)
            if self.updateUpId then
                self.magicManager.commonService:UnregisterGlobalTimer(self.updateUpId)
                self.updateUpId = nil
            end
            self.updateUpId = self.magicManager.commonService:RegisterGlobalTimer(0.02, function()
                if self.avatar.VisElement.transform.position.y >= self.posY + self.maxHeigh then
                    self.avatar.verticalFlag = 0
                    self.avatar:_Move(nil)
                    return
                end
                self.avatar:_SwimUp()
            end)
        end)

    --抬起向上监听
    self.holdUpBtnTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerUp,
        function(data)
            self.avatar.verticalFlag = 0
            self.avatar:_Move(nil)
            if self.updateUpId then
                self.magicManager.commonService:UnregisterGlobalTimer(self.updateUpId)
                self.updateUpId = nil
            end
        end)




    self.holdDownBtnTrigger = self.downButton.gameObject:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))

    --按下向下监听
    self.holdDownBtnTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerDown,
        function(data)
            if self.isMove then
                self.avatar:_SwimDown()
            else
                if self.updateDownId then
                    self.magicManager.commonService:UnregisterGlobalTimer(self.updateDownId)
                    self.updateDownId = nil
                end
                self.updateDownId = self.magicManager.commonService:RegisterGlobalTimer(0.02, function()
                    self.avatar:_SwimDown()
                end)
            end
        end)

    --抬起向下监听
    self.holdDownBtnTrigger:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.PointerUp,
        function(data)
            self.avatar.verticalFlag = 0
            self.avatar:_Move(nil)
            if self.updateDownId then
                self.magicManager.commonService:UnregisterGlobalTimer(self.updateDownId)
                self.updateDownId = nil
            end
        end)
end

--禁用摇杆等移动
function FloatShellMagicEffect:DisableJump(...)
    self.jumpId = self.magicManager.joystickService:setHidenJumpWithID()
end

function FloatShellMagicEffect:DisableMove(...)
    self.joyId = self.magicManager.joystickService:setGrayJoyWithID()
end

--恢复摇杆等移动
function FloatShellMagicEffect:RecoverJump(...)
    if self.jumpId then
        self.magicManager.joystickService:setVisibleJumpWithID(self.jumpId)
        self.jumpId = nil
    end
end

function FloatShellMagicEffect:RecoverMove(...)
    if self.joyId then
        self.magicManager.joystickService:setGrayVisibleJoyWithID(self.joyId)
        self.joyId = nil
    end
end

function FloatShellMagicEffect:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

function FloatShellMagicEffect:Exit()
    FloatShellMagicEffect.super.Exit(self)

    if self.holdUpBtnTrigger then
        self.holdUpBtnTrigger:ClearAll()
    end
    if self.holdDownBtnTrigger then
        self.holdDownBtnTrigger:ClearAll()
    end
end

return FloatShellMagicEffect
