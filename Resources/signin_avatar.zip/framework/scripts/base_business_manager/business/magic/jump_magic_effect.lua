local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local Util                        = require(MAIN_SCRIPTS_LOC .. "common/util")

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

---森林之力
---开始特效
local jumpStartEffectUAddress     = "972321739516879/assets/Prefabs/VFX_jinglingzhili.prefab"
local jumpStartAudioURL           = "https://static0.xesimg.com/next-studio-pub/app/1739440042255/ohnv0bFUvpkYVGIO6oQK.mp3"
---拖尾特效
local moveTailEffectUAddress      = "971281739239766/assets/Prefabs/VFX_STAR.prefab"
--头顶特效
local headTopEffectUAddress       = "972321739516879/assets/Prefabs/vfx_hua.prefab"


---@class JumpMagicEffect : BaseMagicEffect --道具魔法特效 --平衡车
local JumpMagicEffect = class("JumpMagicEffect", BaseMagicEffect)

function JumpMagicEffect:initialize(magicManager)
    JumpMagicEffect.super.initialize(self, magicManager)
    -- 初始化大变身特效资源
     -- 森林之力2个特效
    -- self.jumpStartEffectGo = nil
    self.magicManager:RegisterDownloadUaddress(jumpStartEffectUAddress)
    self.magicManager:LoadRemoteUaddress(jumpStartEffectUAddress, function(success, prefabs)
        if success then
            self.jumpStartEffect = prefabs
            local audioSource = self.jumpStartEffect:AddComponent(typeof(CS.UnityEngine.AudioSource))
            audioSource.spatialBlend = 1                                     -- Set to 3D audio
            audioSource.rolloffMode = CS.UnityEngine.AudioRolloffMode.Linear -- Linear falloff
            audioSource.minDistance = 1
            audioSource.maxDistance = 10                                     -- 10 meter falloff
            audioSource.playOnAwake = true
            self.magicManager.audioService:GetMp3AudioFromGetUrl(
                jumpStartAudioURL, function(error)

                end, function(audioClip)
                    audioSource.clip = audioClip
                end)
        end
    end)
    -- self.moveTailEffectGo = nil
    self.magicManager:RegisterDownloadUaddress(moveTailEffectUAddress)
    self.magicManager:LoadRemoteUaddress(moveTailEffectUAddress, function(success, prefabs)
        if success then
            self.moveTailEffect = prefabs
        end
    end)

    self.magicManager:RegisterDownloadUaddress(headTopEffectUAddress)
    self.magicManager:LoadRemoteUaddress(headTopEffectUAddress, function(success, prefabs)
        if success then
            self.headTopEffect = prefabs
        end
    end)
end

function JumpMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现变大效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        --执行开始动效动效
        self:showOpenJumpEffect(avatar, function()
            --添加甩尾
            -- g_Log("gyz  加甩尾特效")
            self:showMoveTailEffect(avatar, true)
            --添加头顶 特效
            self.magicManager.commonService:DispatchNextFrame(function()
                self:showTopHeadEffect(avatar, true)
            end)
        end)
        --启用二段跳
        avatar.characterCtrl.enableJumpTwice = true
    end
end

---开启技能后的特效
function JumpMagicEffect:showOpenJumpEffect(avatar, finishCallBack)
    if not self.jumpStartEffect then
        return
    end
    if not avatar then
        return
    end
    if Util.IsNil(avatar.jumpStartEffectGo) then
        avatar.jumpStartEffectGo = GameObject.Instantiate(self.jumpStartEffect)
    end

    if avatar.jumpStartEffectGo then
        avatar.jumpStartEffectGo.transform:SetParent(avatar.Body.transform, false)
        avatar.jumpStartEffectGo.transform.localPosition = CS.UnityEngine.Vector3.zero
        avatar.jumpStartEffectGo.transform.localRotation = CS.UnityEngine.Quaternion.identity
        avatar.jumpStartEffectGo.transform.localScale = CS.UnityEngine.Vector3.one
        avatar.jumpStartEffectGo:SetActive(true)
        self.magicManager.commonService:DispatchAfter(1, function()
            avatar.jumpStartEffectGo:SetActive(false)
            if finishCallBack then
                finishCallBack()
            end
        end)
    end
end


---甩尾特效
function JumpMagicEffect:showMoveTailEffect(avatar, isShow)

     self:Print("onEnd-1")
    if not self.moveTailEffect then
        return
    end
    if not avatar then
        return
    end
         self:Print("onEnd-2")
    if isShow then ---开启
        if Util.IsNil(avatar.moveTailEffectGo) then
            avatar.moveTailEffectGo = GameObject.Instantiate(self.moveTailEffect)
        end
        if avatar.moveTailEffectGo then
            avatar.moveTailEffectGo.transform:SetParent(avatar.Body.transform, false)
            avatar.moveTailEffectGo.transform.localPosition = Vector3(0, 0.7, 0)
            avatar.moveTailEffectGo.transform.localRotation = CS.UnityEngine.Quaternion.identity
            avatar.moveTailEffectGo.transform.localScale = CS.UnityEngine.Vector3.one
            avatar.moveTailEffectGo:SetActive(true)
        end
    else
        if avatar.moveTailEffectGo then
            avatar.moveTailEffectGo:SetActive(false)
        end
    end
end


function JumpMagicEffect:showTopHeadEffect(avatar, isShow)
    if not self.headTopEffect then
        return
    end
    if not avatar then
        return
    end
    if isShow then ---开启
        if Util.IsNil(avatar.headTopEffectGo) then
            avatar.headTopEffectGo = GameObject.Instantiate(self.headTopEffect)
        end
        if avatar.headTopEffectGo then
            avatar.headTopEffectGo.transform:SetParent(avatar.Body.transform, false)
            avatar.headTopEffectGo.transform.localPosition = Vector3(0, 1.8, 0)
            avatar.headTopEffectGo.transform.localRotation = CS.UnityEngine.Quaternion.identity
            avatar.headTopEffectGo.transform.localScale = CS.UnityEngine.Vector3.one
            avatar.headTopEffectGo:SetActive(true)
        end
    else
        ---关闭
        if avatar.headTopEffectGo then
            avatar.headTopEffectGo:SetActive(false)
        end
    end
end

function JumpMagicEffect:onEnd(data, avatar) 
   if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end
    self:showMoveTailEffect(avatar, false)
    self.magicManager.commonService:DispatchNextFrame(function()
        self:showTopHeadEffect(avatar, false)
    end)
    avatar.characterCtrl.enableJumpTwice = false
end

return JumpMagicEffect