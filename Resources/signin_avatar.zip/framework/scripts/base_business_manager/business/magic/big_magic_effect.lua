local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local bigEffectUAddress           = "903101725610744/assets/Prefabs/vfx_bianda.prefab"

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

---@class BigMagicEffect : BaseMagicEffect --大大大魔法
local BigMagicEffect = class("BigMagicEffect", BaseMagicEffect)

function BigMagicEffect:initialize(magicManager)
    BigMagicEffect.super.initialize(self, magicManager)
    -- 初始化大变身特效资源
    self.magicManager:RegisterDownloadUaddress(bigEffectUAddress)
    self.magicManager:LoadRemoteUaddress(bigEffectUAddress, function(success, prefabs)
        if success then
            self.bigEffect = prefabs
            local audioSource = self.bigEffect:AddComponent(typeof(CS.UnityEngine.AudioSource))
            audioSource.spatialBlend = 1                                     -- Set to 3D audio
            audioSource.rolloffMode = CS.UnityEngine.AudioRolloffMode.Linear -- Linear falloff
            audioSource.minDistance = 1
            audioSource.maxDistance = 10                                     -- 10 meter falloff
            audioSource.playOnAwake = true
            self.magicManager.audioService:GetMp3AudioFromGetUrl(
                "https://static0.xesimg.com/next-studio-pub/app/1730794230488/S8rfQpr663yNzpKwckU8.mp3", function(error)

                end, function(audioClip)
                    audioSource.clip = audioClip
                end)
        end
    end)
end

function BigMagicEffect:onStart(data, avatar, isResume)

    local magicInfo = data.magic
    -- 实现变大效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        self:SetBigEffect(avatar)
        if data.uuid == App.Uuid then
            if self.magicManager.myAvatar then
                self.magicManager.myAvatar:SetMoveSpeedFactor(0)
            end
        end
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        avatar:SetAvatarScale(magicInfo.scale, function()
            if data.uuid == App.Uuid then
                if self.magicManager.myAvatar then
                    self.magicManager.myAvatar:SetMoveSpeedFactor(1)
                end
                self.magicManager.observerService:Fire("ABCZONE_COMBAT_PARAM_CHANGE",
                    { status = 1, damageRadius = 4, avatarScale = magicInfo.scale })
            end
            if magicInfo.jumpRate then
                avatar:SetJumpFactor(magicInfo.jumpRate)
            end
            if magicInfo.speedRate then
                avatar:SetMoveSpeedFactor(magicInfo.speedRate)
            end
        end)
    end
end

function BigMagicEffect:onEnd(data, avatar) 
    -- 实现恢复效果
    avatar:SetAvatarScale(1, function()
        avatar:SetJumpFactor(1)
        avatar:SetMoveSpeedFactor(1)
        if data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.MAGIC then
            self.magicManager.observerService:Fire("ABCZONE_COMBAT_PARAM_CHANGE", { status = 0, avatarScale = 1 })
            if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
                self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, App.Uuid)
            end
        end
    end)
end


--从effectPool中获取一个特效 放到avatar上
function BigMagicEffect:SetBigEffect(avatar)
    if not self.bigEffect then
        return
    end
    if not avatar then
        return
    end
    local effect = table.remove(self.magicManager.effectPool)
    if not effect then
        effect = GameObject.Instantiate(self.bigEffect)
    end
    effect.transform:SetParent(avatar.Body.transform, false)
    effect.transform.localPosition = CS.UnityEngine.Vector3.zero
    effect.transform.localRotation = CS.UnityEngine.Quaternion.identity
    effect.transform.localScale = CS.UnityEngine.Vector3.one * 3
    effect:SetActive(true)
    self.magicManager.commonService:DispatchAfter(6, function()
        effect:SetActive(false)
        table.insert(self.magicManager.effectPool, effect)
    end)
end

return BigMagicEffect