local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

---@class PropMagicEffect : BaseMagicEffect --道具魔法特效 --平衡车
local PropMagicEffect = class("PropMagicEffect", BaseMagicEffect)

function PropMagicEffect:initialize(magicManager)
    PropMagicEffect.super.initialize(self, magicManager)
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    -- 初始化大变身特效资源
    self.observerService:Watch("ABCZONE_GUIDE_MODE_CTRL", function(key, value)
        local data = value[0]
        if data then
            self.isGuideMode = data.isGuideMode
        end
    end)
end

function PropMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        self.magicManager.avatarPropMap[data.uuid] = { status = 1, avatar = avatar }
        local uaddress = magicInfo.uAddress
        self.magicManager:_LoadPropPrefabs(uaddress)
        self.magicManager.commonService:StartCoroutine(function()
            self.magicManager.commonService:Yield(self.magicManager.commonService:WaitUntil(function()
                return self.magicManager.propPrefabMap[uaddress] and
                    self.magicManager.propPrefabMap[uaddress].status == 1
            end))
            if not self.magicManager.avatarPropMap[data.uuid] then
                return
            end
            if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
                self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
            end
            if AVATAR_ENUM.ANIMATOR[magicInfo.action] then
                avatar:commitAnimatiorLayerAction(AVATAR_ENUM.ANIMATOR[magicInfo.action], false, false, 1, true)
            end
            local prefabs = self.magicManager.propPrefabMap[uaddress].prefabs

            local prop = GameObject.Instantiate(prefabs)
            local anim = prop:GetComponent(typeof(CS.UnityEngine.Animator))
            prop.transform:SetParent(avatar.Body.transform, false)
            prop.transform.localPosition = CS.UnityEngine.Vector3(magicInfo.position[1], magicInfo.position[2],
                magicInfo.position[3])
            prop.transform.localRotation = CS.UnityEngine.Quaternion.Euler(magicInfo.rotation[1],
                magicInfo.rotation[2], magicInfo.rotation[3])
            prop.transform.localScale = CS.UnityEngine.Vector3(magicInfo.scale, magicInfo.scale, magicInfo.scale)
            self.magicManager.avatarPropMap[data.uuid].prop = prop
            self.magicManager.avatarPropMap[data.uuid].anim = anim
            self.magicManager.avatarPropMap[data.uuid].propShow = true
            if magicInfo.gravityRate then
                avatar:SetGravityFactor(magicInfo.gravityRate)
            end
            if magicInfo.jumpRate then
                if self.isGuideMode then
                    avatar:SetJumpFactor(25)
                else
                    avatar:SetJumpFactor(magicInfo.jumpRate)
                end
            end
            if magicInfo.speedRate then
                avatar:SetMoveSpeedFactor(magicInfo.speedRate)
            end
            --调整名字的高度
            self.magicManager:Fire("Event_NamePanel_OFFSET", avatar, CS.UnityEngine.Vector3(0, 0.2, 0))
        end)
    end
end

function PropMagicEffect:onEnd(data, avatar) 
    local magicInfo = data.magic
    -- 实现恢复效果
    if self.magicManager.avatarPropMap[data.uuid] or App.Uuid == data.uuid then
        if self.magicManager.avatarPropMap[data.uuid] then
            self.magicManager.avatarPropMap[data.uuid].status = 0
        end
        avatar:SetGravityFactor(1)
        avatar:SetJumpFactor(1)
        avatar:SetMoveSpeedFactor(1)

        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
            self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        if AVATAR_ENUM.ANIMATOR[magicInfo.action] then
            avatar:commitAnimatiorLayerAction(AVATAR_ENUM.ANIMATOR[magicInfo.action], false, false, 0, true)
        end
        if self.magicManager.avatarPropMap[data.uuid] then
            local prop = self.magicManager.avatarPropMap[data.uuid].prop
            if prop and not prop:IsNull() then
                GameObject.Destroy(prop)
                self.magicManager.avatarPropMap[data.uuid].prop = nil
            end
            self.magicManager.avatarPropMap[data.uuid] = nil
        end
        --调整名字的高度
        self.magicManager:Fire("Event_NamePanel_OFFSET", avatar, CS.UnityEngine.Vector3(0, 0, 0))
    end
end

return PropMagicEffect