local class = require("middleclass")
local TransformationEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/transformation_effect")

-- Configuration specific to TransformationMath
local CONFIG = {
    uaddress = "1040691753440532/assets/Prefabs/female_student_new.prefab"
}

local user_data = {
    stat = 1,
    code = 0,
    msg = "success",
    data = {
        user_id = 2090001982,
        nick_name = "Lily4",
        avatar = "https://static0.xesimg.com/next-app/avatar/avatar8.png",
        defend_phone = "",
        dress_info = {
            list = {{
                id = 1059,
                name = "",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1729223718065-13.png",
                package = {
                    ios = "",
                    android = "",
                    ios_high = "",
                    android_high = "",
                    package_id = 0,
                    asset_name = "",
                    body_part_type = 0,
                    u_address = "",
                    u_address_high = "",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1729223718065-13.png",
                    sketch_url = "",
                    decorate_type = 5,
                    cut_type = 0,
                    is_default = 1,
                    ios_md5 = "",
                    ios_high_md5 = "",
                    android_md5 = "",
                    android_high_md5 = "",
                    material_id = 0,
                    effect_video = "",
                    texture_url = "",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    emoji_list = {{
                        emoji_type = "normal",
                        emoji_urls = {"https://static0.xesimg.com/next-scm/goods/gcover-1730862396218-0-4.png"}
                    }, {
                        emoji_type = "blink",
                        emoji_urls = {"https://static0.xesimg.com/next-scm/goods/gcover-1730862400075-0-20.png"}
                    }, {
                        emoji_type = "jump",
                        emoji_urls = {"https://static0.xesimg.com/next-scm/goods/gcover-1729223747976-0-69.png"}
                    }},
                    entry_animation = "",
                    entry_audio = ""
                },
                level = 1,
                user_id = 2090001982,
                type = 5
            }, {
                id = 1072,
                name = "数学男普通下装",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1729565034390-32.png",
                package = {
                    ios = "https://static0.xesimg.com/next-studio-pub/ios_bundle/920941729490293.zip",
                    android = "https://static0.xesimg.com/next-studio-pub/android_bundle/920941729490293.zip",
                    ios_high = "https://static0.xesimg.com/next-studio-pub/ios_bundle/920941729490293.zip",
                    android_high = "https://static0.xesimg.com/next-studio-pub/android_bundle/920941729490293.zip",
                    package_id = 92094,
                    asset_name = "数学男普通下装",
                    body_part_type = 10,
                    u_address = "920941729490293/assets/Prefabs/M_SX_yonghunan (3).prefab",
                    u_address_high = "920941729490293/assets/Prefabs/M_SX_yonghunan (3).prefab",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1729565034390-32.png",
                    sketch_url = "https://static0.xesimg.com/wx-mobile-fe/下装.png",
                    decorate_type = 3,
                    cut_type = 5,
                    is_default = 0,
                    ios_md5 = "897f6c03ecbec403121dc80954246b6b",
                    ios_high_md5 = "897f6c03ecbec403121dc80954246b6b",
                    android_md5 = "54ed3da7adad5e148e371be15ddd4487",
                    android_high_md5 = "54ed3da7adad5e148e371be15ddd4487",
                    material_id = 116150,
                    effect_video = "",
                    texture_url = "",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    emoji_list = nil,
                    entry_animation = "",
                    entry_audio = ""
                },
                level = 10,
                user_id = 2090001982,
                type = 3
            }, {
                id = 1148,
                name = "",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1730791606580-59.png",
                package = {
                    ios = "",
                    android = "",
                    ios_high = "",
                    android_high = "",
                    package_id = 0,
                    asset_name = "",
                    body_part_type = 0,
                    u_address = "",
                    u_address_high = "",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1730791606580-59.png",
                    sketch_url = "",
                    decorate_type = 4,
                    cut_type = 0,
                    is_default = 1,
                    ios_md5 = "",
                    ios_high_md5 = "",
                    android_md5 = "",
                    android_high_md5 = "",
                    material_id = 0,
                    effect_video = "",
                    texture_url = "https://static0.xesimg.com/next-scm/resource/source-1730716609426-67.png",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    emoji_list = nil,
                    entry_animation = "",
                    entry_audio = ""
                },
                level = 1,
                user_id = 2090001982,
                type = 4
            }, {
                id = 1210,
                name = "英格力士紫头部",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1732848955642-69.png",
                package = {
                    ios = "https://static0.xesimg.com/next-studio-pub/ios_bundle/943051732698597.zip",
                    android = "https://static0.xesimg.com/next-studio-pub/android_bundle/943051732698597.zip",
                    ios_high = "https://static0.xesimg.com/next-studio-pub/ios_bundle/943051732698597.zip",
                    android_high = "https://static0.xesimg.com/next-studio-pub/android_bundle/943051732698597.zip",
                    package_id = 94305,
                    asset_name = "英格力士紫头部",
                    body_part_type = 7,
                    u_address = "943051732698597/assets/Prefabs/M_SX_yonghunv_rig (1).prefab",
                    u_address_high = "943051732698597/assets/Prefabs/M_SX_yonghunv_rig (1).prefab",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1732848955642-69.png",
                    sketch_url = "https://static0.xesimg.com/wx-mobile-fe/头部.png",
                    decorate_type = 1,
                    cut_type = -1,
                    is_default = 0,
                    ios_md5 = "b841b5d0735d0e4af3906fb1401f142c",
                    ios_high_md5 = "b841b5d0735d0e4af3906fb1401f142c",
                    android_md5 = "b976d487ac45a89e8976a27055228b03",
                    android_high_md5 = "b976d487ac45a89e8976a27055228b03",
                    material_id = 119554,
                    effect_video = "",
                    texture_url = "",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    emoji_list = nil,
                    entry_animation = "",
                    entry_audio = ""
                },
                level = 30,
                user_id = 2090001982,
                type = 1
            }, {
                id = 1211,
                name = "英格力士紫上装",
                pic = "https://static0.xesimg.com/next-scm/resource/source-1732848984038-46.png",
                package = {
                    ios = "https://static0.xesimg.com/next-studio-pub/ios_bundle/943051732698597.zip",
                    android = "https://static0.xesimg.com/next-studio-pub/android_bundle/943051732698597.zip",
                    ios_high = "https://static0.xesimg.com/next-studio-pub/ios_bundle/943051732698597.zip",
                    android_high = "https://static0.xesimg.com/next-studio-pub/android_bundle/943051732698597.zip",
                    package_id = 94305,
                    asset_name = "英格力士紫上装",
                    body_part_type = 4,
                    u_address = "943051732698597/assets/Prefabs/M_SX_yonghunv_rig (2).prefab",
                    u_address_high = "943051732698597/assets/Prefabs/M_SX_yonghunv_rig (2).prefab",
                    cover_url = "https://static0.xesimg.com/next-scm/resource/source-1732848984038-46.png",
                    sketch_url = "https://static0.xesimg.com/wx-mobile-fe/上衣.png",
                    decorate_type = 2,
                    cut_type = 1,
                    is_default = 0,
                    ios_md5 = "b841b5d0735d0e4af3906fb1401f142c",
                    ios_high_md5 = "b841b5d0735d0e4af3906fb1401f142c",
                    android_md5 = "b976d487ac45a89e8976a27055228b03",
                    android_high_md5 = "b976d487ac45a89e8976a27055228b03",
                    material_id = 119555,
                    effect_video = "",
                    texture_url = "",
                    effect_start_pic = "",
                    effect_end_pic = "",
                    preview_video = "",
                    emoji_list = nil,
                    entry_animation = "",
                    entry_audio = ""
                },
                level = 30,
                user_id = 2090001982,
                type = 2
            }},
            has_dress = false
        },
        continue_study_day = 0,
        total_continue_study_day = 0,
        cheese_cnt = 1603,
        power_cnt = 3,
        fashion_level = 5,
        has_friend = false,
        prosperity = 9617,
        is_vip = true,
        union_id = "1y2p0ij32dxl9"
    },
    traceId = "bbcb21de698c619b"
}
local user_data_vip = {
    stat = 1,
    code = 0,
    msg = "success",
    data = {
        user_id = 2001000044,
        nick_name = "兰陵王",
        avatar = "https://static0.xesimg.com/next-app/abc-zone/touxiang6.png",
        defend_phone = "157****5931",
        dress_info = {
            list = {
                {
                    id = 1059,
                    name = "",
                    pic = "https://static0.xesimg.com/next-scm/resource/source-1729223718065-13.png",
                    package = {
                        ios = "",
                        android = "",
                        ios_high = "",
                        android_high = "",
                        package_id = 0,
                        asset_name = "",
                        body_part_type = 0,
                        u_address = "",
                        u_address_high = "",
                        cover_url = "https://static0.xesimg.com/next-scm/resource/source-1729223718065-13.png",
                        sketch_url = "",
                        decorate_type = 5,
                        cut_type = 0,
                        is_default = 1,
                        ios_md5 = "",
                        ios_high_md5 = "",
                        android_md5 = "",
                        android_high_md5 = "",
                        material_id = 0,
                        effect_video = "",
                        texture_url = "",
                        effect_start_pic = "",
                        effect_end_pic = "",
                        preview_video = "",
                        emoji_list = {
                            {
                                emoji_type = "normal",
                                emoji_urls = {
                                    "https://static0.xesimg.com/next-scm/goods/gcover-1730862396218-0-4.png"
                                }
                            },
                            {
                                emoji_type = "blink",
                                emoji_urls = {
                                    "https://static0.xesimg.com/next-scm/goods/gcover-1730862400075-0-20.png"
                                }
                            },
                            {
                                emoji_type = "jump",
                                emoji_urls = {
                                    "https://static0.xesimg.com/next-scm/goods/gcover-1729223747976-0-69.png"
                                }
                            }
                        },
                        entry_animation = "",
                        entry_audio = ""
                    },
                    level = 1,
                    user_id = 2001000044,
                    type = 5
                },
                {
                    id = 1145,
                    name = "",
                    pic = "https://static0.xesimg.com/next-scm/resource/source-1730974095309-57.png",
                    package = {
                        ios = "",
                        android = "",
                        ios_high = "",
                        android_high = "",
                        package_id = 0,
                        asset_name = "",
                        body_part_type = 0,
                        u_address = "",
                        u_address_high = "",
                        cover_url = "https://static0.xesimg.com/next-scm/resource/source-1730974095309-57.png",
                        sketch_url = "",
                        decorate_type = 4,
                        cut_type = 0,
                        is_default = 1,
                        ios_md5 = "",
                        ios_high_md5 = "",
                        android_md5 = "",
                        android_high_md5 = "",
                        material_id = 0,
                        effect_video = "",
                        texture_url = "https://static0.xesimg.com/next-scm/resource/source-1730947515400-60.png",
                        effect_start_pic = "",
                        effect_end_pic = "",
                        preview_video = "",
                        emoji_list = nil,
                        entry_animation = "",
                        entry_audio = ""
                    },
                    level = 1,
                    user_id = 2001000044,
                    type = 4
                },
                {
                    id = 1457,
                    name = "小龙女·敖凌",
                    pic = "https://static0.xesimg.com/next-scm/resource/source-1746774005845-61.png",
                    package = {
                        ios = "https://static0.xesimg.com/next-studio-pub/ios_bundle/983371742523929.zip",
                        android = "https://static0.xesimg.com/next-studio-pub/android_bundle/983371742523929.zip",
                        ios_high = "https://static0.xesimg.com/next-studio-pub/ios_bundle/983371742523929.zip",
                        android_high = "https://static0.xesimg.com/next-studio-pub/android_bundle/983371742523929.zip",
                        package_id = 98337,
                        asset_name = "小龙女·敖凌",
                        body_part_type = 0,
                        u_address = "983371742523929/assets/Prefabs/xiaolongnv_rig.prefab",
                        u_address_high = "983371742523929/assets/Prefabs/xiaolongnv_rig.prefab",
                        cover_url = "https://static0.xesimg.com/next-scm/resource/source-1746774005845-61.png",
                        sketch_url = "",
                        decorate_type = 7,
                        cut_type = 0,
                        is_default = 0,
                        ios_md5 = "",
                        ios_high_md5 = "",
                        android_md5 = "",
                        android_high_md5 = "",
                        material_id = 127418,
                        effect_video = "",
                        texture_url = "",
                        effect_start_pic = "",
                        effect_end_pic = "",
                        preview_video = "",
                        emoji_list = nil,
                        entry_animation = "",
                        entry_audio = ""
                    },
                    level = 40,
                    user_id = 2001000044,
                    type = 7
                }
            },
            has_dress = false
        },
        continue_study_day = 0,
        total_continue_study_day = 0,
        cheese_cnt = 976049,
        power_cnt = 2,
        fashion_level = 2920,
        has_friend = false,
        prosperity = 11000,
        is_vip = false,
        union_id = "1y2p0ij32dxmw"
    },
    traceId = "5a280a01abeedd13"
}

local TransformationMath = class("TransformationMath", TransformationEffect)

function TransformationMath:initialize(magicManager)
    TransformationMath.super.initialize(self, magicManager)
    
    -- Register and load the specific prefab for math transformation
    self.magicManager:RegisterDownloadUaddress(CONFIG.uaddress)
    self.magicManager:LoadRemoteUaddress(CONFIG.uaddress, function(success, prefab)
        if success then
            self.prefab = prefab
        end
    end)
end

-- Override to provide config
function TransformationMath:getConfig()
    return CONFIG
end

-- Override to provide test data
function TransformationMath:getTestUserData()
    if self:shouldUseVIPData() then
        return user_data_vip
    else
        return user_data
    end
end
function TransformationMath:shouldUseVIPData()
    -- You can implement your own logic here
    -- For example, check a global variable, user property, or random selection
    
    -- Option 1: Check if VIP mode is enabled globally
    if _G.USE_VIP_TEST_DATA then
        return true
    end
    
    -- Option 2: Random selection for testing (50% chance)
    -- return math.random() > 0.5
    
    -- Option 3: Check specific avatar property
    -- local avatar = self.magicManager.avatarService.selfAvatar
    -- if avatar and avatar.is_vip then
    --     return true
    -- end
    
    -- Default to normal data
    return false
end
-- Override share skeleton method for Math-specific behavior
function TransformationMath:ShareSkeletonForVirtualAvatar(skinMeshRd, skeletonBase, bodyPartType, oldSkinMeshRd, oldMeshGo)
    local boneRoot = skeletonBase
    
    if bodyPartType == 7 then -- Hair
        boneRoot = skeletonBase:FindChildWithName("Character_Spine1")
    else
        boneRoot = skeletonBase:FindChildWithName("Character_Hips") or
                       skeletonBase:FindChildWithName("Character_Hip")
    end

    if not boneRoot then
        self:Print("error: cannot find bone root")
        -- Try to find other possible bone roots
        local charRef = skeletonBase:Find("Character_Reference")
        if charRef then
            self:Print("found Character_Reference, trying to find child nodes")
            for i = 0, charRef.childCount - 1 do
                local child = charRef:GetChild(i)
                self:Print("  - " .. child.name)
                if string.find(child.name, "Hip") then
                    boneRoot = child
                    self:Print("found bone root: " .. child.name)
                    break
                end
            end
        end

        if not boneRoot then
            return
        end
    end

    self:Print("bone root: " .. boneRoot.name)

    local newBones = CS.System.Array.CreateInstance(typeof(CS.UnityEngine.Transform), skinMeshRd.bones.Length)
    local meshBones = skinMeshRd.bones
    local missingBones = 0

    self:Print("bones to map: " .. meshBones.Length)

    for i = 0, meshBones.Length - 1 do
        local boneName = meshBones[i].name
        local newBoneTrans = boneRoot:FindInAll(boneName)
        if newBoneTrans then
            newBones[i] = newBoneTrans
        else
            missingBones = missingBones + 1
            if missingBones <= 5 then -- only print first 5 missing bones
                self:Print("warning: cannot find bone " .. boneName)
            end
        end
    end

    if missingBones > 5 then
        self:Print("and " .. (missingBones - 5) .. " more bones not found")
    end

    skinMeshRd.bones = newBones
    skinMeshRd.rootBone = skeletonBase
    self:Print("bone sharing complete")
end

return TransformationMath