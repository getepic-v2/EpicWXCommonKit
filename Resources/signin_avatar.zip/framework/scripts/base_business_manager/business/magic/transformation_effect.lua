local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local TRANSFORM_EFFECT_PREFAB = "1042881753933365/assets/Prefabs/Stars17.prefab" -- 变身爆炸特效地址
local AVATAR_STATUS = {
    NORMAL = 0,
    MAGIC = 1
}

-- {"stat":1,"code":0,"msg":"success","data":{"user_id":0,"nick_name":"56110081","avatar":"https://static0.xesimg.com/next-app/avatar/avatar8.png","defend_phone":"","dress_info":{"list":null,"has_dress":false},"continue_study_day":0,"total_continue_study_day":0,"cheese_cnt":0,"power_cnt":0,"fashion_level":0,"has_friend":false,"prosperity":776,"school_id":0,"is_vip":false,"union_id":"1y2p0ij32dvep","unread_moment_count":0,"recent_moment_time":""},"traceId":"6a59a9ab0b408483"}

---@class TransformationEffect : BaseMagicEffect
local TransformationEffect = class("TransformationEffect", BaseMagicEffect)

function TransformationEffect:initialize(magicManager)
    TransformationEffect.super.initialize(self, magicManager)

    -- init dress data
    self.currentEquipInfo = {}
    self.virtualAvatars = {} -- store virtual avatar instances
    self.transformEffects = {} -- store transformation effect instances

    -- 兜底定时器相关
    self.safetyTimers = {} -- 存储每个avatar的兜底定时器

    -- get services
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()

    -- 预加载爆炸特效
    self.effectPrefab = nil
    CourseEnv.ServicesManager:GetResourceService():LoadRemoteResourceByUaddress(TRANSFORM_EFFECT_PREFAB, function(s, p)
        if p then
            self.effectPrefab = p
            -- self:Print("爆炸特效预加载成功")
        else
            self:Print("爆炸特效预加载失败")
        end
    end, false)
end

-- subclass must override this method to provide config
function TransformationEffect:getConfig()
    error("Subclass must implement getConfig method")
end

-- subclass must override this method to provide test data
function TransformationEffect:getTestUserData()
    error("Subclass must implement getTestUserData method")
end

-- subclass can override this method to provide subject
function TransformationEffect:getSubject()
    return "math" -- default subject
end

function TransformationEffect:onStart(data, avatar, isResume)
    if self.isStarted == true then
        return
    end
    self.isStarted = true
    local magicInfo = data.magic
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else

        self:Transformation(avatar, data)

        -- 启动兜底定时器，20秒后强制关闭变身
        self:StartSafetyTimer(avatar, data)

        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.TRANSFORMATION and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.TRANSFORMATION, data.uuid)
        end
    end
end

function TransformationEffect:onEnd(data, avatar)
    if self.isStarted ~= true then
        return
    end
    self.isStarted = false
    -- 停止兜底定时器
    self:StopSafetyTimer(avatar)

    -- recovery effect
    if data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.MAGIC then
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.TRANSFORMATION and self.magicManager.avatarService.StopBusiness then
            self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.TRANSFORMATION, App.Uuid)
        end

    end

    if self.virtualAvatars[avatar] then
        self:ShowTransformationEffect(avatar, nil)
    end

    -- 在变身结束时显示爆炸特效（使用与开始时相同的函数）

    self:CleanupEffect(self.virtualAvatars[avatar], avatar)
end

function TransformationEffect:Print(msg)
    g_Log(self.class.name .. ": " .. tostring(msg))
end

-- 启动兜底定时器
function TransformationEffect:StartSafetyTimer(avatar, data)
    -- 先停止之前的定时器（如果存在）
    self:StopSafetyTimer(avatar)
    
    -- 创建30秒的兜底定时器
    local timerId = self.magicManager.commonService:DispatchAfter(20, function()
        self:Print("变身超时30秒，强制关闭变身效果 - avatar: " .. tostring(avatar and avatar.UnionId or "unknown"))
        
        -- 强制清理变身效果
        if self.virtualAvatars[avatar] then
            self:ShowTransformationEffect(avatar, nil)
            self:CleanupEffect(self.virtualAvatars[avatar], avatar)
        end
        
        -- 清理定时器引用
        self.safetyTimers[avatar] = nil
    end)
    
    -- 存储定时器ID
    self.safetyTimers[avatar] = timerId
    self:Print("启动变身兜底定时器，30秒后自动关闭 - avatar: " .. tostring(avatar and avatar.UnionId or "unknown"))
end

-- 停止兜底定时器
function TransformationEffect:StopSafetyTimer(avatar)
    if self.safetyTimers[avatar] then
        -- 取消定时器
        if self.magicManager.commonService and self.magicManager.commonService.CancelDispatch then
            self.magicManager.commonService:CancelDispatch(self.safetyTimers[avatar])
        end
        
        -- 清理定时器引用
        self.safetyTimers[avatar] = nil
        self:Print("停止变身兜底定时器 - avatar: " .. tostring(avatar and avatar.UnionId or "unknown"))
    end
end

function TransformationEffect:RequestOthersInfo(unionId, cb)
    -- self:Print("start RequestOthersInfo userId = " .. tostring(unionId))
    local url = "https://app.chuangjing.com/abc-api/v3/ucenter/get-other-user-data"
    if App.IsStudioClient then
        -- self:Print("use test data mode")
        if cb then
            cb(self:getTestUserData().data)
        end
        return
    end
    local success = function(resp)
        local ok = false
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                if msg.data then
                    ok = true
                    self.data = msg.data
                    if msg.data.dress_info == nil or msg.data.dress_info.list == nil or type(msg.data.dress_info.list) ~= "table" or #msg.data.dress_info.list == 0 then
                        self:Print("dress_info.list is nil or empty")
                        cb(nil)
                        return
                    end
                    -- self:Print("RequestOthersInfo success, nick_name: " .. tostring(msg.data.nick_name))
                    -- self:Print("dress count: " .. tostring(msg.data.dress_info and #msg.data.dress_info.list or 0))
                    if cb then
                        cb(msg.data)
                    end
                else
                    -- self:Print("RequestOthersInfo data is empty")
                end
            else
                self:Print("RequestOthersInfo error code: " .. tostring(msg and msg.code or "unknown"))
            end
        end
        if not ok then
            -- self:Print("RequestOthersInfo failed not data")
        end
    end

    local fail = function(resp)
        self:Print("RequestOthersInfo failed " .. self.jsonService:encode(resp))
    end

    -- self:Print("send request: " .. url .. " union_id=" .. tostring(unionId))
    self:HttpRequest(url, {
        union_id = unionId,
        subject = self:getSubject()
    }, success, fail)
end

function TransformationEffect:HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

function TransformationEffect:Transformation(avatar, params)
    self:Print("start transformation effect")

    if not self.prefab then
        self:Print("error: prefab not loaded")
        return
    end
    if not avatar then
        self:Print("error: avatar is nil")
        return
    end

    -- self:Print("create new virtual avatar instance")

    if self.virtualAvatars[avatar] ~= nil then
        self:CleanupEffect(self.virtualAvatars[avatar], avatar)
    end

    local effect = GameObject.Instantiate(self.prefab)
    effect.transform:SetParent(avatar.Body.transform, false)
    effect.transform.localPosition = CS.UnityEngine.Vector3.zero
    effect.transform.localRotation = CS.UnityEngine.Quaternion.identity
    effect.transform.localScale = CS.UnityEngine.Vector3.one
    -- store virtual avatar reference
    self.virtualAvatars[avatar] = effect
    -- self:Print("virtual avatar activated and stored")

    -- 添加爆炸特效到虚拟avatar
    self:ShowTransformationEffect(avatar, effect)

    local unionId = avatar.UnionId or avatar:GetProperty("UnionId")
    -- self:Print("request user dress data userId=" .. tostring(unionId))
    effect:SetActive(false)
    
    self:RequestOthersInfo(unionId, function(data)
        if data then
            if self.isStarted ~=true then
                return
            end
            -- self:Print("got user data, start change dress")
            self:ChangeDress(avatar, data, function(isVIPOutfit)
                if self.isStarted ~=true then
                    self:CleanupEffect(effect, avatar)
                    return
                end
                self:Print("transformation complete")

                -- For VIP outfit, it has its own handling in ReplaceVirtualAvatarWithVIP
                if not isVIPOutfit then
                    self:ActivateAndSyncAnimator(avatar, effect)
                end

                if params.callback and params.debug == true then
                    params.callback(effect)
                    self:CleanupEffect(effect, avatar)
                    self.isStarted = false
                    return
                end
                -- self.magicManager.commonService:DispatchAfter(6, function()
                --     if effect and not effect:IsNull() then
                --         effect:SetActive(false)
                --         self:CleanupEffect(effect, avatar)
                --     end
                -- end)
            end)
        else
            self:ActivateAndSyncAnimator(avatar, effect)
            if params.callback and params.debug == true then
                params.callback(effect)
                self:CleanupEffect(effect, avatar)
            end
            self:Print("get user data failed, skip change dress")
        end
    end)
end



-- 显示变身爆炸特效
function TransformationEffect:ShowTransformationEffect(avatar, virtualAvatar)
    if not self.effectPrefab then
        self:Print("爆炸特效未加载，尝试实时加载")
        CourseEnv.ServicesManager:GetResourceService():LoadRemoteResourceByUaddress(TRANSFORM_EFFECT_PREFAB,
            function(s, p)
                if p then
                    self:CreateAndShowEffect(p, avatar, virtualAvatar)
                else
                    self:Print("爆炸特效加载失败")
                end
            end, false)
    else
        self:CreateAndShowEffect(self.effectPrefab, avatar, virtualAvatar)
    end
end

-- 创建并显示特效
function TransformationEffect:CreateAndShowEffect(prefab, avatar, virtualAvatar)
    if not prefab or not avatar then
        return
    end

    -- 清理旧特效
    if self.transformEffects[avatar] and not self.transformEffects[avatar]:IsNull() then
        GameObject.Destroy(self.transformEffects[avatar])
    end

    -- 创建特效实例（不挂载到任何对象）
    local effectInstance = GameObject.Instantiate(prefab)
    effectInstance.transform:SetParent(nil, false)

    -- 获取avatar的世界位置并设置特效位置
    local avatarWorldPos = avatar.Body.transform.position
    effectInstance.transform.position = avatarWorldPos + CS.UnityEngine.Vector3(0, 0.8, 0)
    effectInstance.transform.rotation = CS.UnityEngine.Quaternion.identity
    effectInstance.transform.localScale = CS.UnityEngine.Vector3.one
    effectInstance:SetActive(true)

    -- 存储特效引用
    self.transformEffects[avatar] = effectInstance
    -- self:Print("爆炸特效已显示在世界坐标: " .. tostring(effectInstance.transform.position))

    -- 2秒后删除特效
    self.magicManager.commonService:DispatchAfter(2, function()
        if effectInstance and not effectInstance:IsNull() then
            GameObject.Destroy(effectInstance)
            -- self:Print("爆炸特效已删除")
        end
        if self.transformEffects[avatar] == effectInstance then
            self.transformEffects[avatar] = nil
        end
    end)
end

function TransformationEffect:ChangeDress(avatar, data, callback)
    local effect = self.virtualAvatars[avatar]
    if not effect then
        self:Print("error: cannot find virtual avatar instance")
        if callback then
            callback()
        end
        return
    end

    -- self:Print("start process dress data")

    -- process dress data
    if data.dress_info and data.dress_info.list then
        local validEquips = {}
        local vipOutfit = nil
        local totalItems = #data.dress_info.list
        -- self:Print("total dress items: " .. totalItems)

        for i, item in ipairs(data.dress_info.list) do
            -- Check for VIP outfit (decorate_type = 7)
            if item.package and item.package.decorate_type == 7 and
                (item.package.ios ~= "" or item.package.android ~= "") then
                vipOutfit = item
                -- self:Print(string.format("found VIP outfit[%d]: name=%s, decorateType=%d", i,
                --     item.name or "unnamed", item.package.decorate_type))
                -- filter items without resource package
            elseif item.package and item.package.body_part_type > 0 and
                (item.package.ios ~= "" or item.package.android ~= "") then
                table.insert(validEquips, item)
                -- self:Print(string.format("valid equip[%d]: type=%d, name=%s, decorateType=%d", i,
                --     item.package.body_part_type, item.name or "unnamed", item.package.decorate_type))
            else
                -- self:Print(string.format("filter equip[%d]: type=%s, decorateType=%s, reason=%s", i,
                --     tostring(item.package and item.package.body_part_type or "nil"),
                --     tostring(item.package and item.package.decorate_type or "nil"), not item.package and "no package" or
                --         item.package.body_part_type == 0 and "body_part_type is 0" or "no resource URL"))
            end
        end

        -- Apply VIP outfit if found
        if vipOutfit then
            -- self:Print("applying VIP outfit")
            self:ApplyVIPOutfit(avatar, vipOutfit, function()
                if callback then
                    callback(true) -- Pass true to indicate VIP outfit was applied
                end
            end)
            -- Otherwise apply normal equips
        elseif #validEquips > 0 then
            -- self:Print("valid equips count: " .. #validEquips)
            self:ApplyMultipleEquipments(avatar, validEquips, function()
                if callback then
                    callback(false) -- Pass false to indicate normal equips were applied
                end
            end)
        else
            -- self:Print("no valid equips, skip change dress")
            if callback then
                callback(false) -- Pass false for no equips
            end
        end
    else
        -- self:Print("no dress data")
        if callback then
            callback()
        end
    end
end

-- batch apply equipments
function TransformationEffect:ApplyMultipleEquipments(avatar, equipInfoList, callback)
    local virtualAvatar = self.virtualAvatars[avatar]
    if not virtualAvatar or virtualAvatar:IsNull() then
        self:Print("error: virtual avatar is invalid")
        if callback then
            callback()
        end
        return
    end

    local totalCount = #equipInfoList
    local completedCount = 0
    local successCount = 0

    -- self:Print("start batch apply equips, total: " .. totalCount)

    if totalCount == 0 then
        if callback then
            callback()
        end
        return
    end

    -- process each equip
    for i, equipData in ipairs(equipInfoList) do
        local equipInfo = self:ConvertToEquipInfo(equipData)
        -- self:Print(string.format("process equip[%d/%d]: bodyType=%d, decorateType=%d", i, totalCount,
        --     equipInfo.bodyPartType, equipInfo.decorateType))

        self:DownloadAndApplyEquipment(virtualAvatar, equipInfo, function(success)
            completedCount = completedCount + 1
            if success then
                successCount = successCount + 1
                -- self:Print(string.format("equip load success[%d/%d]", completedCount, totalCount))
            else
                -- self:Print(string.format("equip load failed[%d/%d]", completedCount, totalCount))
            end

            if completedCount >= totalCount then
                -- self:Print(string.format("batch equip done: success=%d, failed=%d", successCount,
                --     totalCount - successCount))
                if callback then
                    callback()
                end
            end
        end)
    end
end

-- convert data format
function TransformationEffect:ConvertToEquipInfo(itemData)
    local package = itemData.package
    local platform = CS.UnityEngine.Application.platform

    -- determine URL to use
    local url = package.ios -- default use iOS
    if App.IsStudioClient then
        -- Studio client use Mac bundle
        if package.ios and package.ios ~= "" then
            url = string.gsub(package.ios, "ios_bundle", "mac_bundle")
            -- self:Print("convert to Mac platform URL: " .. url)
        end
    elseif platform == CS.UnityEngine.RuntimePlatform.Android then
        url = package.android
    end

    local equipInfo = {
        url = url,
        urlAndroid = package.android,
        urlIos = package.ios,
        uAddress = package.u_address,
        bodyPartType = package.body_part_type,
        cutType = package.cut_type,
        md5Android = package.android_md5,
        md5Ios = package.ios_md5,
        decorateType = package.decorate_type
    }

    return equipInfo
end

-- public interface: change virtual avatar equipment
function TransformationEffect:ChangeVirtualAvatarEquipment(avatar, equipInfo)
    local virtualAvatar = self.virtualAvatars[avatar]
    if not virtualAvatar or virtualAvatar:IsNull() then
        return false
    end

    -- download and apply equipment
    self:DownloadAndApplyEquipment(virtualAvatar, equipInfo)
    return true
end

-- download and apply equipment
function TransformationEffect:DownloadAndApplyEquipment(virtualAvatar, equipInfo, callback)
    if not equipInfo or not equipInfo.url or not equipInfo.uAddress then
        self:Print("error: equip info incomplete")
        if callback then
            callback(false)
        end
        return
    end

    -- parse resource package info
    local zipUrl = equipInfo.url
    local uAddress = equipInfo.uAddress
    local bodyPartType = equipInfo.bodyPartType
    local cutType = equipInfo.cutType or -1

    -- fix platform related URL
    if not App.IsStudioClient then
        local platform = CS.UnityEngine.Application.platform
        if platform == CS.UnityEngine.RuntimePlatform.Android then
            zipUrl = equipInfo.urlAndroid or zipUrl
        elseif platform == CS.UnityEngine.RuntimePlatform.IPhonePlayer then
            zipUrl = equipInfo.urlIos or zipUrl
        end
    end

    -- self:Print(string.format("prepare download equip: bodyType=%d, url=%s", bodyPartType, zipUrl))

    -- parse package name
    local zipSplits = self:StringSplit(zipUrl, "/")
    if not zipSplits then
        self:Print("error: cannot parse resource package URL - " .. zipUrl)
        if callback then
            callback(false)
        end
        return
    end

    local zipName = zipSplits[#zipSplits]
    local pkgName = string.gsub(zipName, ".zip", "")

    -- self:Print("package name: " .. pkgName .. ", address: " .. uAddress)

    -- download resource package
    local md5 = ""
    if App.IsStudioClient then
        -- Mac platform no MD5 check
        md5 = ""
    else
        local platform = CS.UnityEngine.Application.platform
        if platform == CS.UnityEngine.RuntimePlatform.Android then
            md5 = equipInfo.md5Android or ""
        else
            md5 = equipInfo.md5Ios or ""
        end
    end

    -- self:Print("start download resource package, MD5=" .. (md5 ~= "" and md5 or "none"))

    App:GetService("Avatar"):LoadAvatarSkin(pkgName, zipUrl, md5, 100, function(status, skinPkgName)
        if status == "success" then
            -- self:Print("resource package download success: " .. skinPkgName)
            -- import and load resource
            ImportAsync(skinPkgName, function(p)
                local fullAddress = "modules/" .. uAddress
                -- self:Print("load GameObject: " .. fullAddress)

                ResourceManager:LoadGameObjectWithExName(fullAddress, function(gameGo)
                    if not gameGo then
                        self:Print("error: load GameObject failed - " .. fullAddress)
                        if callback then
                            callback(false)
                        end
                        return
                    end

                    if not virtualAvatar or virtualAvatar:IsNull() then
                        self:Print("error: virtual avatar is invalid")
                        if callback then
                            callback(false)
                        end
                        return
                    end

                    -- self:Print("GameObject load success, start apply equip")
                    -- instantiate and apply equip
                    local insGo = GameObject.Instantiate(gameGo)
                    self:ApplyEquipmentToVirtualAvatar(virtualAvatar, insGo, bodyPartType, cutType)
                    GameObject.Destroy(insGo)

                    -- self:Print("equip apply done")
                    if callback then
                        callback(true)
                    end
                end)
            end)
        else
            self:Print("error: download resource package failed - " .. tostring(status) .. " url=" .. zipUrl)
            if callback then
                callback(false)
            end
        end
    end)
end

-- apply equipment to virtual avatar
function TransformationEffect:ApplyEquipmentToVirtualAvatar(virtualAvatar, equipGo, bodyPartType, cutType)
    local skeletonBase = virtualAvatar.transform

    -- body part name mapping
    local bodyPartNames = {
        [4] = "Clothes", -- clothes
        [7] = "Hair", -- hair
        [10] = "Pants", -- pants
        [12] = "Shoes" -- shoes
    }

    local partName = bodyPartNames[bodyPartType]
    if not partName then
        self:Print("error: unknown body part type " .. tostring(bodyPartType))
        return
    end

    -- self:Print(string.format("apply equip: bodyType=%d, partName=%s, cutType=%d", bodyPartType, partName, cutType))

    -- find original part
    local basePartMesh = self:FindPartMesh(skeletonBase, partName)

    if not basePartMesh then
        self:Print("error: cannot find original part " .. partName)
        -- try print virtual avatar structure
        -- self:Print("virtual avatar structure:")
        local geometry = skeletonBase:Find("Geometry")
        if geometry then
            for i = 0, geometry.childCount - 1 do
                local child = geometry:GetChild(i)
                -- self:Print("  - " .. child.name)
            end
        end
        return
    end

    -- self:Print("found original part: " .. basePartMesh.name)

    -- find new part
    local gamePartMesh = equipGo.transform:Find("Geometry/" .. partName)
    if not gamePartMesh then
        gamePartMesh = equipGo.transform:Find("Geometry/Character/" .. partName)
    end

    if gamePartMesh then
        -- self:Print("found new part mesh: " .. gamePartMesh.name)

        -- replace mesh
        self:ReplaceVirtualAvatarMesh(basePartMesh.gameObject, skeletonBase, gamePartMesh, bodyPartType)

        -- update visibility
        if cutType and cutType ~= -1 then
            -- self:Print("update part visibility, cutType=" .. cutType)
            self:UpdateVirtualAvatarPartVisibility(virtualAvatar, cutType)
        end

        -- self:Print("equip apply success: " .. partName)
    else
        self:Print("error: cannot find new part mesh " .. partName)
        -- try print equip structure
        -- self:Print("equip structure:")
        local equipGeometry = equipGo.transform:Find("Geometry")
        if equipGeometry then
            for i = 0, equipGeometry.childCount - 1 do
                local child = equipGeometry:GetChild(i)
                -- self:Print("  - " .. child.name)
            end
        end
    end
end

-- find part mesh - subclass can override this method
function TransformationEffect:FindPartMesh(skeletonBase, partName)
    local basePartMesh = skeletonBase:Find("Geometry/" .. partName)
    if not basePartMesh then
        basePartMesh = skeletonBase:Find(partName)
    end
    return basePartMesh
end

-- replace virtual avatar mesh
function TransformationEffect:ReplaceVirtualAvatarMesh(oldMeshGo, skeletonBase, newMeshTransform, bodyPartType)
    if not newMeshTransform then
        self:Print("error: newMeshTransform is nil")
        return
    end

    -- self:Print("start replace mesh: " .. oldMeshGo.name)

    -- set parent and transform
    local geometryParent = skeletonBase:Find("Geometry")
    if not geometryParent then
        geometryParent = skeletonBase
    end

    newMeshTransform:SetParent(geometryParent)
    newMeshTransform.localPosition = oldMeshGo.transform.localPosition
    newMeshTransform.localRotation = oldMeshGo.transform.localRotation
    newMeshTransform.localScale = oldMeshGo.transform.localScale
    newMeshTransform.name = oldMeshGo.name

    -- share skeleton
    local newSkinMesh = newMeshTransform:GetComponent(typeof(CS.UnityEngine.SkinnedMeshRenderer))
    local oldSkinMesh = oldMeshGo:GetComponent(typeof(CS.UnityEngine.SkinnedMeshRenderer))

    if newSkinMesh and oldSkinMesh then
        -- self:Print("start share skeleton")
        self:ShareSkeletonForVirtualAvatar(newSkinMesh, skeletonBase, bodyPartType, oldSkinMesh, oldMeshGo)
    else
        -- self:Print("warning: cannot find SkinnedMeshRenderer component")
    end

    -- destroy old mesh
    GameObject.DestroyImmediate(oldMeshGo)
    -- self:Print("mesh replace done")
end

-- share skeleton for virtual avatar - subclass must override this method
function TransformationEffect:ShareSkeletonForVirtualAvatar(skinMeshRd, skeletonBase, bodyPartType, oldSkinMeshRd,
    oldMeshGo)
    error("Subclass must implement ShareSkeletonForVirtualAvatar method")
end

-- update virtual avatar part visibility
function TransformationEffect:UpdateVirtualAvatarPartVisibility(virtualAvatar, cutType)
    -- define visible/invisible parts for each cut type
    local CutTypeVisibleMap = {
        [1] = {"Clothes", "Hand"}, -- long sleeve
        [2] = {"Arm", "Clothes", "Forearm", "Hand"}, -- short sleeve
        [3] = {"Arm", "Body", "Clothes", "Forearm", "Hand"}, -- vest
        [4] = {"Pants"}, -- stack pants
        [5] = {"Pants", "Shank"}, -- medium pants
        [6] = {"Pants", "Shank", "Thigh"}, -- shorts
        [7] = {"Shoes"}, -- high shoes
        [8] = {"Ankle", "Shoes"}, -- low shoes
        [9] = {"Ankle", "Shoes", "Foot"} -- slippers or no shoes
    }

    local CutTypeInVisibleMap = {
        [1] = {"Arm", "Body", "Forearm"}, -- long sleeve
        [2] = {"Body"}, -- short sleeve
        [3] = {}, -- vest
        [4] = {"Thigh", "Shank"}, -- stack pants
        [5] = {"Thigh"}, -- medium pants
        [6] = {}, -- shorts
        [7] = {"Foot", "Ankle"}, -- high shoes
        [8] = {"Foot"}, -- low shoes
        [9] = {} -- slippers or no shoes
    }

    local visibleParts = CutTypeVisibleMap[cutType] or {}
    local invisibleParts = CutTypeInVisibleMap[cutType] or {}

    -- set visible parts
    for _, partName in ipairs(visibleParts) do
        local part = virtualAvatar.transform:Find("Geometry/" .. partName)
        if part and part.gameObject then
            part.gameObject:SetActive(true)
        end
    end

    -- set invisible parts
    for _, partName in ipairs(invisibleParts) do
        local part = virtualAvatar.transform:Find("Geometry/" .. partName)
        if part and part.gameObject then
            part.gameObject:SetActive(false)
        end
    end
end

-- Apply VIP outfit (complete replacement)
function TransformationEffect:ApplyVIPOutfit(avatar, vipOutfitData, callback)
    local virtualAvatar = self.virtualAvatars[avatar]
    if not virtualAvatar or virtualAvatar:IsNull() then
        self:Print("error: virtual avatar is invalid")
        if callback then
            callback()
        end
        return
    end

    local equipInfo = self:ConvertToEquipInfo(vipOutfitData)
    -- self:Print("start apply VIP outfit: " .. (vipOutfitData.name or "unnamed"))

    -- Download and load VIP outfit
    self:DownloadAndApplyVIPOutfit(virtualAvatar, equipInfo, avatar, function(success)
        if success then
            -- self:Print("VIP outfit apply success")
        else
            self:Print("VIP outfit apply failed")
        end
        if callback then
            callback()
        end
    end)
end

-- Download and apply VIP outfit with complete replacement
function TransformationEffect:DownloadAndApplyVIPOutfit(virtualAvatar, equipInfo, avatar, callback)
    if not equipInfo or not equipInfo.url or not equipInfo.uAddress then
        self:Print("error: VIP outfit info incomplete")
        if callback then
            callback(false)
        end
        return
    end

    local zipUrl = equipInfo.url
    local uAddress = equipInfo.uAddress

    -- Fix platform related URL
    if not App.IsStudioClient then
        local platform = CS.UnityEngine.Application.platform
        if platform == CS.UnityEngine.RuntimePlatform.Android then
            zipUrl = equipInfo.urlAndroid or zipUrl
        elseif platform == CS.UnityEngine.RuntimePlatform.IPhonePlayer then
            zipUrl = equipInfo.urlIos or zipUrl
        end
    end

    -- self:Print(string.format("prepare download VIP outfit: url=%s", zipUrl))

    -- Parse package name
    local zipSplits = self:StringSplit(zipUrl, "/")
    if not zipSplits then
        self:Print("error: cannot parse VIP outfit URL - " .. zipUrl)
        if callback then
            callback(false)
        end
        return
    end

    local zipName = zipSplits[#zipSplits]
    local pkgName = string.gsub(zipName, ".zip", "")

    -- self:Print("VIP package name: " .. pkgName .. ", address: " .. uAddress)

    -- Get MD5
    local md5 = ""
    if not App.IsStudioClient then
        local platform = CS.UnityEngine.Application.platform
        if platform == CS.UnityEngine.RuntimePlatform.Android then
            md5 = equipInfo.md5Android or ""
        else
            md5 = equipInfo.md5Ios or ""
        end
    end

    -- self:Print("start download VIP outfit package, MD5=" .. (md5 ~= "" and md5 or "none"))

    App:GetService("Avatar"):LoadAvatarSkin(pkgName, zipUrl, md5, 100, function(status, skinPkgName)
        if status == "success" then
            -- self:Print("VIP outfit package download success: " .. skinPkgName)
            -- Import and load resource
            ImportAsync(skinPkgName, function(p)
                local fullAddress = "modules/" .. uAddress
                -- self:Print("load VIP GameObject: " .. fullAddress)

                ResourceManager:LoadGameObjectWithExName(fullAddress, function(gameGo)
                    if not gameGo then
                        self:Print("error: load VIP GameObject failed - " .. fullAddress)
                        if callback then
                            callback(false)
                        end
                        return
                    end

                    if not virtualAvatar or virtualAvatar:IsNull() then
                        self:Print("error: virtual avatar is invalid")
                        if callback then
                            callback(false)
                        end
                        return
                    end

                    -- self:Print("VIP GameObject load success, start replace virtual avatar")

                    -- Instantiate VIP outfit
                    local vipInstance = GameObject.Instantiate(gameGo)

                    -- Replace virtual avatar completely
                    self:ReplaceVirtualAvatarWithVIP(virtualAvatar, vipInstance, avatar)

                    -- self:Print("VIP outfit apply done")
                    if callback then
                        callback(true)
                    end
                end)
            end)
        else
            self:Print("error: download VIP outfit package failed - " .. tostring(status) .. " url=" .. zipUrl)
            if callback then
                callback(false)
            end
        end
    end)
end

-- Replace virtual avatar with VIP complete outfit
function TransformationEffect:ReplaceVirtualAvatarWithVIP(virtualAvatar, vipInstance, avatar)
    -- self:Print("start replace virtual avatar with VIP outfit")

    -- Step 1: Hide all children of virtual avatar
    -- self:Print("Step 1: Hiding all virtual avatar children")
    for i = 0, virtualAvatar.transform.childCount - 1 do
        local child = virtualAvatar.transform:GetChild(i)
        child.gameObject:SetActive(false)
        -- self:Print("  - Hidden child: " .. child.name)
    end
    virtualAvatar:SetActive(true)
    -- Step 2: Mount VIP instance to virtual avatar
    -- self:Print("Step 2: Mounting VIP instance to virtual avatar")
    vipInstance.transform:SetParent(virtualAvatar.transform, false)
    vipInstance.transform.localPosition = CS.UnityEngine.Vector3.zero
    vipInstance.transform.localRotation = CS.UnityEngine.Quaternion.identity
    vipInstance.transform.localScale = CS.UnityEngine.Vector3.one

    -- Step 3: Get virtual avatar's animator and its controller
    -- self:Print("Step 3: Getting virtual avatar animator controller")
    local virtualAnimator = virtualAvatar:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
    if virtualAnimator and virtualAnimator.runtimeAnimatorController then
        local virtualController = virtualAnimator.runtimeAnimatorController
        -- self:Print("  - Found virtual animator controller: " .. tostring(virtualController))

        -- Step 4: Find animator in VIP instance and assign controller
        -- self:Print("Step 4: Finding VIP animator and assigning controller")
        local vipAnimator = vipInstance:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
        if vipAnimator then
            -- self:Print("  - Found VIP animator, assigning virtual controller")
            vipAnimator.runtimeAnimatorController = virtualController

            -- Copy animator parameters
            self:CopyAnimatorState(virtualAnimator, vipAnimator)

            -- Step 5: Use the same activation logic as normal outfit
            -- self:Print("Step 5: Activating VIP outfit with standard method")
            self:ActivateAndSyncAnimator(avatar, vipInstance)

            -- self:Print("VIP outfit successfully applied with virtual animator controller")
        else
            self:Print("ERROR: VIP instance has no animator component!")
            -- Fallback: try to add animator component
            local newAnimator = vipInstance:AddComponent(typeof(CS.UnityEngine.Animator))
            if newAnimator then
                -- self:Print("  - Added new animator component to VIP instance")
                newAnimator.runtimeAnimatorController = virtualController
                self:ActivateAndSyncAnimator(avatar, vipInstance)
            end
        end
    else
        self:Print("ERROR: Virtual avatar has no animator or controller!")
        -- Last resort: just use VIP's own animator if it has one
        local vipAnimator = vipInstance:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
        if vipAnimator then
            -- self:Print("  - Fallback: using VIP's own animator")
            self:ActivateAndSyncAnimator(avatar, vipInstance)
        end
    end

    -- Store VIP instance reference
    self.currentVIPInstance = vipInstance

    -- self:Print("VIP outfit replacement complete")
end

-- Activate and sync animator for virtual avatar or VIP outfit
function TransformationEffect:ActivateAndSyncAnimator(avatar, effectObject)
    -- self:Print("Activating and syncing animator")

    -- Hide original avatar
    avatar.avatarBase.gameObject:SetActive(false)

    -- Activate effect with the toggle trick to ensure proper initialization
    effectObject:SetActive(true)
    effectObject:SetActive(false)
    effectObject:SetActive(true)

    -- Find and sync animator
    local animator = effectObject:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
    if animator then
        avatar.characterCtrl:SetSyncAnimator(animator)
        -- self:Print("Animator synced successfully")
    else
        self:Print("WARNING: No animator found in effect object")
    end
end

-- Copy animator state from source to target
function TransformationEffect:CopyAnimatorState(fromAnimator, toAnimator)
    if not fromAnimator or not toAnimator then
        return
    end

    -- self:Print("Copying animator state")

    -- Get all parameters from source animator
    local parameters = fromAnimator.parameters
    if parameters then
        for i = 0, parameters.Length - 1 do
            local param = parameters[i]
            local paramName = param.name
            local paramType = param.type

            -- Copy parameter based on type
            local success, value = pcall(function()
                if paramType == CS.UnityEngine.AnimatorControllerParameterType.Float then
                    local val = fromAnimator:GetFloat(paramName)
                    toAnimator:SetFloat(paramName, val)
                    -- self:Print("  - Copied float param: " .. paramName .. " = " .. val)
                elseif paramType == CS.UnityEngine.AnimatorControllerParameterType.Int then
                    local val = fromAnimator:GetInteger(paramName)
                    toAnimator:SetInteger(paramName, val)
                    -- self:Print("  - Copied int param: " .. paramName .. " = " .. val)
                elseif paramType == CS.UnityEngine.AnimatorControllerParameterType.Bool then
                    local val = fromAnimator:GetBool(paramName)
                    toAnimator:SetBool(paramName, val)
                    -- self:Print("  - Copied bool param: " .. paramName .. " = " .. tostring(val))
                elseif paramType == CS.UnityEngine.AnimatorControllerParameterType.Trigger then
                    -- Triggers are one-time events, skip copying
                    -- self:Print("  - Skipped trigger param: " .. paramName)
                end
            end)

            if not success then
                -- self:Print("  - Failed to copy param: " .. paramName)
            end
        end
    end

    -- Try to match current animation state
    local currentState = fromAnimator:GetCurrentAnimatorStateInfo(0)
    if currentState then
        -- Play the same state on target animator
        pcall(function()
            toAnimator:Play(currentState.fullPathHash, 0, currentState.normalizedTime)
            -- self:Print("  - Matched animation state")
        end)
    end
end

-- Override cleanup to handle VIP instance
function TransformationEffect:CleanupEffect(effect, avatar)
    -- 停止兜底定时器
    self:StopSafetyTimer(avatar)
    
    -- Clean up VIP instance if exists
    if self.currentVIPInstance and not self.currentVIPInstance:IsNull() then
        GameObject.Destroy(self.currentVIPInstance)
        self.currentVIPInstance = nil
    end

    -- Clean up transformation effect if exists
    if self.transformEffects[avatar] and not self.transformEffects[avatar]:IsNull() then
        GameObject.Destroy(self.transformEffects[avatar])
        self.transformEffects[avatar] = nil
    end

    -- Call original cleanup
    GameObject.Destroy(effect)
    self.virtualAvatars[avatar] = nil
    if avatar.avatarBase and not avatar.avatarBase:IsNull() then
        avatar.avatarBase.gameObject:SetActive(true)
    end
    if avatar.characterCtrl  then
        avatar.characterCtrl:RemoveSyncAnimator()
    end
end

-- string split helper function
function TransformationEffect:StringSplit(target_string, pattern)
    if target_string == nil or target_string == '' or pattern == nil then
        return nil
    end

    local result = {}
    for match in (target_string .. pattern):gmatch("(.-)" .. pattern) do
        table.insert(result, match)
    end
    return result
end

return TransformationEffect
