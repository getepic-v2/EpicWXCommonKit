local class = require("middleclass")

---@class BaseMagicEffect
local BaseMagicEffect = class("BaseMagicEffect")

function BaseMagicEffect:Print(...)
    g_Log(self.class.name, ...)
end

function BaseMagicEffect:initialize(magicManager)
    self.magicManager = magicManager
    self.effectPool = {}
end

--选择技能
function BaseMagicEffect:SelectSkill(data)
    -- 基类实现
end

--按钮cd中
function BaseMagicEffect:OnButtonCd()
    -- 基类实现
end

function BaseMagicEffect:onStart(data, avatar, isResume)
    -- 基类实现
end

function BaseMagicEffect:onEnd(data, avatar)
    -- 基类实现  
end

function BaseMagicEffect:SelfAvatarCreated(avatar)
    -- 基类实现
end

function BaseMagicEffect:Tick()
    -- 基类实现
end

function BaseMagicEffect:Exit()
    -- 基类实现
end

return BaseMagicEffect