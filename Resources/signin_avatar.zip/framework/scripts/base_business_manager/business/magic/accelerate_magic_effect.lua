local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local Util                        = require(MAIN_SCRIPTS_LOC .. "common/util")
local cs_coroutine                = require('common/cs_coroutine')

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

--水花登场
local waterEffectUAddress         = "982611742379785/assets/Prefabs/vfx_dengchang.prefab"
--水花行走
local waterMoveEffectUAddress     = "980801741946281/assets/Prefabs/VFX_SHUIHUA.prefab"

---@class AccelerateMagicEffect : BaseMagicEffect --加速魔法 --乘风破浪
local AccelerateMagicEffect = class("AccelerateMagicEffect", BaseMagicEffect)

function AccelerateMagicEffect:initialize(magicManager)
    AccelerateMagicEffect.super.initialize(self, magicManager)

    self.magicManager:SubscribeMsgKey("RUNNIN_GACCELERATE_ANI")

    -- 初始化大变身特效资源
    self.magicManager:RegisterDownloadUaddress(waterEffectUAddress)
    self.magicManager:LoadRemoteUaddress(waterEffectUAddress, function(success, prefabs)
        if success then
            self.waterEffect = prefabs
        end
    end)

    self.magicManager:RegisterDownloadUaddress(waterMoveEffectUAddress)
    self.magicManager:LoadRemoteUaddress(waterMoveEffectUAddress, function(success, prefabs)
        if success then
            self.waterMoveEffect = prefabs
        end
    end)

      --监听摇杆
    self.magicManager.joystickService.OnDirChanged:connect(function(v)
       
        if self.avatar and self.avatar.isRunningAccelerate then
            -- g_Log(TAG, "移动魔法")
            self:SetRunningAccelerate({ uuid = App.Uuid, runing = true }, self.avatar)
            self.magicManager:SendCustomMessage("RUNNIN_GACCELERATE_ANI", { uuid = App.Uuid, runing = true })
        end
    end)
    self.magicManager.joystickService.OnMoveEnd:connect(function(v)
        if self.avatar and self.avatar.isRunningAccelerate then
            -- g_Log(TAG, "停止移动魔法")
            self:SetRunningAccelerate({ uuid = App.Uuid, runing = false }, self.avatar)
            self.magicManager:SendCustomMessage("RUNNIN_GACCELERATE_ANI", { uuid = App.Uuid, runing = false })
        end
    end)
end

function AccelerateMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        --执行开始动效动效
        self:showOpenAccelerateEffect(avatar, magicInfo, function()
            --添加甩尾
            self:showMoveAccelerateEffect(avatar, magicInfo, true)
        end)
        --设置移速
        avatar:SetMoveSpeedFactor(magicInfo.speedRate)

        --角色处于加速技能释放状态
        avatar.isRunningAccelerate = true    
    end
end

function AccelerateMagicEffect:onEnd(data, avatar) 
    -- 实现恢复效果
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end
    self:showMoveAccelerateEffect(avatar, magicInfo, false)
    avatar:SetMoveSpeedFactor(1)
    --用户当前处于加速技能状态
    avatar.isRunningAccelerate = false
end

function AccelerateMagicEffect:ReceiveMessage(key, value, isResume)
    if key == "RUNNIN_GACCELERATE_ANI" then
        for _, v in ipairs(value) do
            local data = self.magicManager.jsonService:decode(v)
            local avatar = self.magicManager.avatarService:GetAvatarByUUID(data.uuid)
            if avatar then
                self:SetRunningAccelerate(data, avatar, isResume)
            end
        end
    end
end

function AccelerateMagicEffect:SetRunningAccelerate(data, avatar, isResume)
    -- g_Log(TAG, "加速动画显隐状态", table.dump(data))
    if not Util:IsNil(avatar.waterMoveEffect) then
        if data.runing and avatar.isRunningAccelerate then
            avatar.waterMoveEffect.gameObject:SetActive(true)
        else
            avatar.waterMoveEffect.gameObject:SetActive(false)
        end
    end
end

---展示开启加速技能特效
function AccelerateMagicEffect:showOpenAccelerateEffect(avatar, magicInfo, finishCallBack)
    if not self.waterEffect then
        return
    end
    if not avatar then
        return
    end

    if Util:IsNil(avatar.waterEffect) then
        avatar.waterEffect = GameObject.Instantiate(self.waterEffect)
    end

    if avatar.waterEffect then
        avatar.waterEffect.transform:SetParent(avatar.Body.transform, false)
        avatar.waterEffect.transform.localPosition = Vector3(magicInfo.free_position[1], magicInfo.free_position[2],
            magicInfo.free_position[3])
        avatar.waterEffect.transform.localRotation = Quaternion.Euler(magicInfo.free_rotation[1],
            magicInfo.free_rotation[2], magicInfo.free_rotation[3])
        avatar.waterEffect.transform.localScale = CS.UnityEngine.Vector3.one
        avatar.waterEffect:SetActive(true)
        self.magicManager.commonService:DispatchAfter(2, function()
            avatar.waterEffect:SetActive(false)
            if finishCallBack then
                finishCallBack()
            end
        end)
    end
end

---浪花行走特效
function AccelerateMagicEffect:showMoveAccelerateEffect(avatar, magicInfo, isShow)
    if not self.waterMoveEffect then
        return
    end
    if not avatar then
        return
    end
    if isShow then ---开启
        if Util:IsNil(avatar.waterMoveEffect) then
            avatar.waterMoveEffect = GameObject.Instantiate(self.waterMoveEffect)
        end
        if avatar.waterMoveEffect then
            avatar.waterMoveEffect.transform:SetParent(avatar.Body.transform, false)
            avatar.waterMoveEffect.transform.localPosition = Vector3(magicInfo.continue_position[1],
                magicInfo.continue_position[2], magicInfo.continue_position[3])
            avatar.waterMoveEffect.transform.localRotation = Quaternion.Euler(magicInfo.continue_rotation[1],
                magicInfo.continue_rotation[2], magicInfo.continue_rotation[3])
            avatar.waterMoveEffect.transform.localScale = CS.UnityEngine.Vector3.one
            --通过移动状态控制显隐
            -- avatar.waterMoveEffect:SetActive(true)
        end
    else
        ---关闭
        if avatar.waterMoveEffect then
            avatar.waterMoveEffect:SetActive(false)
        end
    end
end

function AccelerateMagicEffect:SelfAvatarCreated(avatar)
    self.avatar = avatar
end


return AccelerateMagicEffect