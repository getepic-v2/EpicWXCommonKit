local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local Util                        = require(MAIN_SCRIPTS_LOC .. "common/util")
local cs_coroutine                = require('common/cs_coroutine')

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

--蹦床资源
local TrampolineEffectUAddress         = "1010161747986323/assets/Prefabs/M_BENGCHUAN.prefab"

---@class TrampolineMagicEffect : BaseMagicEffect --蹦床
local TrampolineMagicEffect = class("TrampolineMagicEffect", BaseMagicEffect)

function TrampolineMagicEffect:initialize(magicManager)
    TrampolineMagicEffect.super.initialize(self, magicManager)

    -- 初始蹦床特效资源
    self.magicManager:RegisterDownloadUaddress(TrampolineEffectUAddress)
    self.magicManager:LoadRemoteUaddress(TrampolineEffectUAddress, function(success, prefabs)
        if success then
            self.TrampolineEffect = prefabs
        end
    end)

    self.propMap = {}
end

function TrampolineMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        self:placeTrampoline(avatar,data)
    end
end

function TrampolineMagicEffect:onEnd(data, avatar) 
    -- 实现恢复效果
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end

    --恢复宠物跟随
    if data.uuid == App.Uuid then
        self.magicManager.observerService:Fire("PETSYSTEM_SET_PET_FOLLOW_STATE", { follow = true })
    end
end


--放置蹦床
function TrampolineMagicEffect:placeTrampoline(avatar,data)
    local uuid = data.uuid
    local magicInfo = data.magic
    local propInfo = self.propMap[uuid]
    if propInfo then
        propInfo.prop.transform.localPosition = avatar.VisElement.transform.position 
        propInfo.prop.transform.localRotation = Quaternion.Euler(0, 0, 0)
        propInfo.prop.transform.localScale = Vector3(1, 1, 1)
    else
        local prop = GameObject.Instantiate(self.TrampolineEffect)
        prop.transform.localPosition = avatar.VisElement.transform.position 
        prop.transform.localRotation = Quaternion.Euler(0, 0, 0)
        prop.transform.localScale = Vector3(1, 1, 1)
        local ani = prop:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
        propInfo = {prop = prop, ani = ani,magicInfo = magicInfo}
        self.propMap[uuid] = propInfo
        self:initPropListener(self.propMap[uuid])
    end
    --开启蹦床消息倒计时
    propInfo.state = true
    propInfo.prop:SetActive(true)
    --家园单机mod 更新频率是一秒4帧
    if HOME_CONFIG_INFO and HOME_CONFIG_INFO.IsSingleMode then
        App.frameNum = 4
    end
    propInfo.endFrameIndex = self.frameIndex + App.frameNum * magicInfo.showTime

    --停止宠物跟随
    if data.uuid == App.Uuid then
        self.magicManager.observerService:Fire("PETSYSTEM_SET_PET_FOLLOW_STATE", { follow = false })
    end
end

--收起蹦床
function TrampolineMagicEffect:hideTrampoline(propInfo)
    propInfo.state = false
    propInfo.prop:SetActive(false)
end

--初始化道具监听
function TrampolineMagicEffect:initPropListener(propInfo) 
    local prop = propInfo.prop
    local ani = propInfo.ani
    local data = propInfo.magicInfo
    local boxCollider = prop:GetComponent(typeof(CS.UnityEngine.BoxCollider))
    boxCollider.isTrigger = true    
    CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(prop, function(other)
        self:Print("other", other)
         if other.name == self.avatar.VisElement.gameObject.name then
            self:Print("有用户触发蹦床")
            ani:SetBool("tanchu", false)
            self.magicManager.commonService:DispatchNextFrame(function()
                ani:SetBool("tanchu", true)
            end)
            if self.avatar and self.avatar.characterCtrl then
                self.avatar.characterCtrl:DoSuperJump(data.speed, function()
                    self.avatar.characterCtrl:SetMoveOffset(0, 0, 0)
                end)
            end
        end
    end)
end


function TrampolineMagicEffect:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

-- 更新帧索引
function TrampolineMagicEffect:UpdateFrameIndex(frameIndex)
    self.frameIndex = frameIndex
    for _, propInfo in pairs(self.propMap) do   
        if propInfo.state then
            if propInfo.endFrameIndex < frameIndex then
                self:hideTrampoline(propInfo)
            end
        end
    end
end

return TrampolineMagicEffect