local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local Util                        = require(MAIN_SCRIPTS_LOC .. "common/util")
local cs_coroutine                = require('common/cs_coroutine')

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

--云踏
local cloudEffectUAddress         = "1013811748935997/assets/Prefabs/Vfx_Yuntiaoban.prefab"
local CLOUD_PEDAL = 11
local MAX_HEIGHT = 104

---@class CloudPedalMagicEffect : BaseMagicEffect --加速魔法 --乘风破浪
local CloudPedalMagicEffect = class("CloudPedalMagicEffect", BaseMagicEffect)

function CloudPedalMagicEffect:initialize(magicManager)
    CloudPedalMagicEffect.super.initialize(self, magicManager)
    -- self.magicManager:SubscribeMsgKey("RUNNIN_FIREWORK_ROCKET_ANI")
    self:initValues()
    self:AddEvents()

end

function CloudPedalMagicEffect:AddEvents()
    --监听是否切换到了 该技能
    self.magicManager.observerService:Watch("ABCZONE_SPEECH_MAGIC_DID_CHANGE", function(key, args)
        local data = args[0]
        if data then
            local canUse = data.canUse
            self.canUse = canUse
            if data.magicInfo.type == CLOUD_PEDAL then  ---切换的是云朵踏板
                self.isSelectCloudEffect = true    
            else
                self.isSelectCloudEffect = false
            end
        end
    end)
    self.magicManager.observerService:Watch("SKILL_BUTTON_DID_SELECTED_EVENT", function(key, args)
        local data = args[0]
        if data then
            local magicInfo = data.magicInfo
            if magicInfo.type == CLOUD_PEDAL and self.isSelectCloudEffect and self.canUse then
                g_Log("gyz", "云朵踏板技能 可用", self.avatar)
                self:AddCloudEffect(self.avatar, App.Uuid)
            else
                g_Log("gyz", "云朵踏板技能 不可用")
            end
        end
    end)
end

--- 踏云技能 添加云朵踏板
function CloudPedalMagicEffect:AddCloudEffect(avatar, uuid)
    if avatar then
        avatar:Jump()
        local seq = DOTween:Sequence()
        seq:AppendInterval(0.5)
        seq:AppendCallback(function()
            g_Log("gyz", "添加云朵踏板11111", avatar.VisElement)
            if uuid == App.Uuid then
                --只有自己的时候才播音频
                if self.skillAudio then
                    self.magicManager.audioService:PlayClipOneShot(self.skillAudio, function() end)
                else
                    self.magicManager.audioService:GetMp3AudioFromGetUrl(
                        "https://static0.xesimg.com/next-studio-pub/app/1750316919415/gDQS7ZajRU76dSQ7IuKf.mp3",
                        function(error)
                            print("音频加载失败")
                        end, function(clip)
                            self.skillAudio = clip
                            self.magicManager.audioService:PlayClipOneShot(self.skillAudio, function() end)
                    end)
                end
            end
            --- 位置出现在 角色 avatar.Body.transform.forward 方向 0.5米处
            local forward = avatar.Body.transform.forward
            local position = avatar.VisElement.transform.position + forward * 0.3
            if position.y >= MAX_HEIGHT then
                position.y = MAX_HEIGHT
                if uuid == App.Uuid then  -- 如果是自己，提示
                    self.magicManager.observerService:Fire("ABCZONE_COMMON_TOAST", { content = "不能再往上了哦" })
                end
            end
            local cloudEffect = GameObject.Instantiate(self.cloudEffect)
            cloudEffect.transform:SetParent(self.VisElement.transform)
            cloudEffect.name = "cloudEffect"
            cloudEffect.transform.localPosition = position
            cloudEffect.transform.localScale = Vector3.one
            cloudEffect.transform.localRotation = Quaternion.identity
            self.commonService:DispatchAfter(4, function()
                cloudEffect.transform:SetParent(nil)
                GameObject.Destroy(cloudEffect)
                cloudEffect = nil
                seq:Kill()
            end)
        end)
    end
end

function CloudPedalMagicEffect:ResetCloudEffect(avatar)

end

function CloudPedalMagicEffect:initValues()
    self.startCloudEffect = false
    self.isSelectCloudEffect = false
    self.VisElement = self.magicManager.VisElement
    self.commonService = self.magicManager.commonService
    -- 初始化大变身特效资源
    self.magicManager:RegisterDownloadUaddress(cloudEffectUAddress)
    self.magicManager:LoadRemoteUaddress(cloudEffectUAddress, function(success, prefabs)
        if success then
            self.cloudEffect = prefabs
        end
    end)
end
function CloudPedalMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        ---这里只处理不等于自己的情况
        if data.uuid ~= App.Uuid then
            g_Log("gyz", "添加云朵踏板")
            self:AddCloudEffect(avatar, data.uuid)
        end
    end
end


function CloudPedalMagicEffect:onEnd(data, avatar) 
    -- 实现恢复效果
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end
    -- self:ResetCloudEffect(avatar)
end

function CloudPedalMagicEffect:ReceiveMessage(key, value, isResume)
    -- if key == "RUNNIN_GACCELERATE_ANI" then
    --     for _, v in ipairs(value) do
    --         local data = self.magicManager.jsonService:decode(v)
    --         local avatar = self.magicManager.avatarService:GetAvatarByUUID(data.uuid)
    --         if avatar then
    --             self:SetRunningAccelerate(data, avatar, isResume)
    --         end
    --     end
    -- end
end


function CloudPedalMagicEffect:SelfAvatarCreated(avatar)
    self.avatar = avatar
end


return CloudPedalMagicEffect
