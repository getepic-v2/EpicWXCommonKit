local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")

local AimLineRenderer = require("gameplay/aimLineRenderer")
local hookUAddress = "993191744278016/assets/Prefabs/M_GouZhua.prefab"
local lineUAddress = "993191744278016/assets/Prefabs/GouLine.prefab"

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

--播放出钩子动画
local PLAY_HOOK_ANIMATION = "PLAY_HOOK_ANIMATION"

local HOOK_ANIMATION = class("HOOK_ANIMATION")


function HOOK_ANIMATION:Print(...)
     g_Log(HOOK_ANIMATION, ...)
end

function HOOK_ANIMATION:initialize(avatar,hookPrefab,linePrefab)
    self.avatar = avatar
    --初始化钩子
    self.hook = GameObject.Instantiate(hookPrefab)
    self.hook.transform.localScale = Vector3.one
    self.hook.transform.localPosition = Vector3.zero
    self.hook.transform.localRotation = Quaternion.identity
    self.hook.gameObject:SetActive(false)
    --初始化线
    local line = GameObject.Instantiate(linePrefab)
    self.lineRenderer = line:GetComponent(typeof(CS.UnityEngine.LineRenderer)) 
    self.lineRenderer.useWorldSpace = true
    self.lineRenderer.positionCount = 0

    self.startPoint = nil
    self.endPoint = nil
    --钩子发射时长
    self.fireTime =  0.8  -- 总移动时间（秒）
    --钩子收回时长
    self.pickUpTime =  0.2
    self.firePoints = nil  -- 所有路径点
    self.passedPoints = {}  -- 已经经过的路径点
    self.currentPos = nil  -- 当前钩子头位置
end

--发射钩子
function HOOK_ANIMATION:FireHook(firePoints)
    -- self:Print("FireHook", table.dump(firePoints))
    self.firePoints = firePoints
    self.startPoint = firePoints[1]
    self.endPoint = firePoints[#firePoints]
    self.currentTime = 0
    self.isFireMoving = true
    self.passedPoints = {self.startPoint}  -- 初始化已经过点
    self.currentPos = self.startPoint 
    self.hook.gameObject:SetActive(true)
    self.lineRenderer.gameObject:SetActive(true)
end

--更新勾子和线
function HOOK_ANIMATION:UpdateHookLine(currentPos)
    -- 更新当前位置
    self.currentPos = currentPos
    -- 添加到已经过路径点
    table.insert(self.passedPoints, currentPos)
    
    -- 更新线渲染器显示已经过的路径
    self.lineRenderer.positionCount = #self.passedPoints
    self.lineRenderer:SetPositions(self.passedPoints)
    
    -- 更新钩子朝向
    if #self.passedPoints >= 2 then
        -- 获取移动方向
        local prevPos = self.passedPoints[#self.passedPoints - 1]
        local direction = {
            x = currentPos.x - prevPos.x,
            y = currentPos.y - prevPos.y,
            z = currentPos.z - prevPos.z
        }
        -- 使用移动方向计算旋转
        local rotation = Quaternion.LookRotation(direction)
        -- 添加额外旋转以调整钩子的朝向
        self.hook.transform.rotation = rotation
    end
    self.hook.transform.position = currentPos
end

function HOOK_ANIMATION:UpdateDragLine()
    local avatarTrasform = self.avatar.VisElement.gameObject.transform
    local startPos = avatarTrasform.position + {x=0,y=1.1,z=0.3}
    local points = {}
    table.insert(points, startPos)
    table.insert(points, self.endPoint)
      -- 更新线渲染器显示已经过的路径
    self.lineRenderer.positionCount = #points
    self.lineRenderer:SetPositions(points)
end

function HOOK_ANIMATION:Tick()
    if self.isFireMoving and self.firePoints then
        self.currentTime = self.currentTime + CS.UnityEngine.Time.deltaTime
        local progress = math.min(self.currentTime / self.fireTime, 1)
        -- 计算当前帧应该在的位置
        if progress < 1 then
            local totalPoints = #self.firePoints
            -- 根据当前进度计算在路径中的位置
            local exactIndex = 1 + (totalPoints - 1) * progress
            local index1 = math.floor(exactIndex)
            local index2 = math.ceil(exactIndex)
            -- 确保索引在有效范围内
            index1 = math.max(1, math.min(index1, totalPoints))
            index2 = math.max(1, math.min(index2, totalPoints))
            -- 如果两个索引相同，直接使用该点
            if index1 == index2 then
                self:UpdateHookLine(self.firePoints[index1])
            else
                -- 否则在两点之间进行插值
                local t = exactIndex - index1
                local p1 = self.firePoints[index1]
                local p2 = self.firePoints[index2]
                local currentPos = {
                    x = p1.x + (p2.x - p1.x) * t,
                    y = p1.y + (p2.y - p1.y) * t,
                    z = p1.z + (p2.z - p1.z) * t
                }
                self:UpdateHookLine(currentPos)
            end
        else
            -- 到达终点
            self.isFireMoving = false
            self.isDragMoving = true
            self.currentTime = 0
            self:Print("到达目标点")
            self.avatar:SetBombedWithFinalPos(self.endPoint, 5, function() end)
        end
    end

    if self.isDragMoving then
        self.currentTime = self.currentTime + CS.UnityEngine.Time.deltaTime
        local progress = math.min(self.currentTime / self.pickUpTime, 1)
        if progress < 1 then
            self:UpdateDragLine()
        else
            self.isDragMoving = false
            self.hook.gameObject:SetActive(false)
            self.lineRenderer.positionCount = 0
            self.lineRenderer.gameObject:SetActive(false)
        end
    end
end




---@class HookMagicEffect : BaseMagicEffect --钩子魔法
local HookMagicEffect = class("HookMagicEffect", BaseMagicEffect)

function HookMagicEffect:initialize(magicManager)
    HookMagicEffect.super.initialize(self, magicManager)
    self.magicManager:SubscribeMsgKey(PLAY_HOOK_ANIMATION)
    -- 初始化资源
    self.magicManager:RegisterDownloadUaddress(hookUAddress)
    self.magicManager:LoadRemoteUaddress(hookUAddress, function(success, prefabs)
        if success then
            self.hookPrefab = prefabs
        end
    end)

    self.magicManager:RegisterDownloadUaddress(lineUAddress)
    self.magicManager:LoadRemoteUaddress(lineUAddress, function(success, prefabs)
        if success then
            self.linePrefab = prefabs
        end
    end)

    self.useStatus = 0
    self.initSkillUI = false
    self.allHookAni = {}
    self.isCd = false
end

--初始化技能操作UI
function HookMagicEffect:InitSkillUI(btn,data)
    if self.initSkillUI then
        return
    end
    self.skillBtn = btn
    self:Print("初始化技能操作UI")
    self.initSkillUI = true

    local offset = data.offset and {x = data.offset[1],y = data.offset[2],z = data.offset[3]} or {x=0,y=1.1,z=0.3}
    local speed = data.speed and {x = data.speed[1],y = data.speed[2],z = data.speed[3]} or {x=0.2,y=16,z=8}
    local aoe_range = data.aoe_range or 0.3
    local max_degree = data.max_degree or 90
    local min_degree = data.min_degree or -10
    local bullet = {
        offset = offset,
        speed = speed,
        size = {0.3},
        aoe_range = aoe_range,
        max_degree = max_degree,
        min_degree = min_degree
    }
    self.bullet = bullet

    self.aimLineRenderer = AimLineRenderer:new(btn.gameObject, bullet, function(collider)
        if not self.avatar then
            return false
        end
        local isValid = not collider.gameObject.transform:IsChildOf(self.avatar.VisElement.gameObject.transform)
        isValid = isValid and collider.gameObject ~= self.avatar.VisElement.gameObject
        isValid = isValid and collider.name ~= "过滤业务触发器(Clone)"
        isValid = isValid and collider.name ~= "过滤业务触发器(Clone)(Clone)"
        return isValid
    end)

    self.aimLineRenderer:HideCancelButton()
    self.aimLineRenderer.eventEmitter:on("OnAimFire", function(data, rateY, points)
        self:Print("OnAimFire", table.dump(points))
        -- 获取起点和终点
        local firePoints = {}
        for i = 1, #points, 1 do
            local point = points[i]
            table.insert(firePoints, {x=point.x,y=point.y,z=point.z})
        end
        local magicInfo = {uuid = App.Uuid,firePoints = firePoints}
        --用户自己本地直接执行
        self:palyHookAni(magicInfo)
        self.magicManager:SendCustomMessage(PLAY_HOOK_ANIMATION,magicInfo)
        -- 点击技能使用按钮
        btn.onClick:Invoke()
        self.aimLineRenderer.enabled = false
    end)

    self.aimLineRenderer.eventEmitter:on("OnAimCancel", function(data)
        self:Print("OnAimCancel")
    end)
    self.aimLineRenderer.eventEmitter:on("OnStartAimFire", function()
        self:Print("OnStartAimFire")
    end)

    self.aimLineRenderer.eventEmitter:on("OnAim", function(y)
        if not self.avatar then
            return
        end
    end)
end

--刷新钩爪按钮状态
function HookMagicEffect:RefreshBtnState()
    self.skillCanUse = self.magicManager:CheckMagicCanUse()
    -- self:Print("self.useStatus-",self.useStatus)
    -- self:Print("self.skillCanUse-",self.skillCanUse)
    -- self:Print("self.isCd-",self.isCd)
    if self.useStatus == 1 then --使用钩爪技能时
        if self.skillCanUse then
            if self.aimLineRenderer then
                self.aimLineRenderer.enabled = not self.isCd
            end
            if self.skillBtn then
                self.skillBtn.interactable = false
            end
        else
            if self.aimLineRenderer then
                self.aimLineRenderer.enabled = false
            end
            if self.skillBtn then
                self.skillBtn.interactable = true
            end
        end
    else
        if self.aimLineRenderer then
            self.aimLineRenderer.enabled = false
        end
        if self.skillBtn then
            self.skillBtn.interactable = not self.isCd
        end
    end
end

--按钮cd中
function HookMagicEffect:OnButtonCd(isCd)
    self.isCd = isCd
    self:RefreshBtnState()
end

--检查技能是否可以使用
function HookMagicEffect:CheckCanUseState()
    self:RefreshBtnState()
end

--退出操作UI
function HookMagicEffect:ExitSkillUI(btn,data)
    if self.aimLineRenderer then
        self.aimLineRenderer:Release(true)
    end
end

--选择技能
function HookMagicEffect:SelectSkill(btn,data)
    if data.type == 8 then
        self:Print("钩子魔法选择技能-放开",self.isCd)
        self.useStatus = 1
        self.magicInfo = data
        --替换操作UI
        self:InitSkillUI(btn,data)
        self:RefreshBtnState()
    else
        self:Print("钩子魔法选择技能-关闭",self.isCd)
        self.useStatus = 0
        self:RefreshBtnState()
        --还原操作UI
        self:ExitSkillUI(btn,data)
    end
end


function HookMagicEffect:onStart(data, avatar, isResume)
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
        self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end
end

function HookMagicEffect:onEnd(data, avatar) 
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end
end

function HookMagicEffect:palyHookAni(magicInfo)
    local uuid = magicInfo.uuid
    local avatar = self.magicManager.avatarService:GetAvatarByUUID(uuid)
    if not avatar then
        return
    end
    local hookAni = self.allHookAni[uuid]
    if not hookAni then
        hookAni = HOOK_ANIMATION:new(avatar, self.hookPrefab, self.linePrefab,magicInfo)
        self.allHookAni[uuid] = hookAni
    end
    hookAni:FireHook(magicInfo.firePoints)
end

function HookMagicEffect:ReceiveMessage(key, value, isResume)
    if key == PLAY_HOOK_ANIMATION and not isResume then
        for _, v in ipairs(value) do
            local data = self.magicManager.jsonService:decode(v)
            if data.uuid ~= App.Uuid then
                self:palyHookAni(data)
            end
        end
    end
end

function HookMagicEffect:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

function HookMagicEffect:Exit()
    if self.aimLineRenderer then
        self.aimLineRenderer:OnExit()
    end
end

function HookMagicEffect:Tick()
    if self.aimLineRenderer then
        self.aimLineRenderer:Tick()
    end
    for _,hookAni in pairs(self.allHookAni) do
        hookAni:Tick()
    end
end

return HookMagicEffect