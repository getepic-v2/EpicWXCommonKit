local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")


local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

---@class IceBulletMagicEffect : BaseMagicEffect --仔仔冰弹 
local IceBulletMagicEffect = class("IceBulletMagicEffect", BaseMagicEffect)

function IceBulletMagicEffect:initialize(magicManager)
    IceBulletMagicEffect.super.initialize(self, magicManager)
    -- 初始化特效资源
end

function IceBulletMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现变大效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        ---获取uuid的宠物
        self.magicManager.observerService:Fire("PETMANAGER_GET_PET_BY_UUID", {
            uuid = data.uuid,
            callback = function(pet)
                if pet then
                    --宠物执行攻击效果
                    local petGo = pet.assetObj
                    --宠物朝向跟avatar保持一致
                    petGo.transform.forward = avatar.Body.transform.forward
                    local animator = petGo.transform:GetComponent(typeof(CS.UnityEngine.Animator))
                    if animator then
                        local seq = DOTween:Sequence()
                        self.seq = seq
                        seq:AppendCallback(function()
                            animator:SetLayerWeight(1, 1)
                            animator:SetTrigger("skill")
                        end)
                        seq:AppendInterval(1.4)
                        seq:AppendCallback(function()
                            if self.skillAudio then
                                self.magicManager.audioService:PlayClipOneShot(self.skillAudio, function() end)
                            else
                                self.magicManager.audioService:GetMp3AudioFromGetUrl(
                                    "https://static0.xesimg.com/next-studio-pub/app/1733728973842/HH7UYqVvp4W2Te7LRIp9.mp3",
                                    function(error)
                                        print("音频加载失败")
                                    end, function(clip)
                                        self.skillAudio = clip
                                        self.magicManager.audioService:PlayClipOneShot(self.skillAudio, function() end)
                                    end)
                            end
                            --重置层
                            animator:SetLayerWeight(1, 0)
                            --投掷冰弹 如果发消息的是自己
                            if data.uuid == App.Uuid then
                                self.magicManager.observerService:Fire("ABC_ZONE_THROW_PROPS", {
                                    propUid = "2001",
                                    propId = 100,
                                    isMagic = true,
                                    magicParams = {
                                        fromPos = pet.assetObj.transform.position
                                    }
                                })
                            end
                            seq:Kill()
                            self.seq = nil
                        end)
                    end
                end
            end
        })
        -- end
    end
end

function IceBulletMagicEffect:onEnd(data, avatar) 
    -- 实现恢复效果
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end
end

return IceBulletMagicEffect