local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local Util                        = require(MAIN_SCRIPTS_LOC .. "common/util")
local cs_coroutine                = require('common/cs_coroutine')

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

--混天绫特效

local HTLEffectUAddress     = "1017401749547667_v1/assets/Prefabs/M_HunTianLing@anim_01kunbang.prefab"

---@class HTLMagicEffect : BaseMagicEffect --混天绫-保护罩
local HTLMagicEffect = class("HTLMagicEffect", BaseMagicEffect)

function HTLMagicEffect:initialize(magicManager)
    HTLMagicEffect.super.initialize(self, magicManager)

    -- 初始化混天绫特效资源
    self.magicManager:RegisterDownloadUaddress(HTLEffectUAddress)
    self.magicManager:LoadRemoteUaddress(HTLEffectUAddress, function(success, prefabs)
        if success then
            self.HTLEffect = prefabs
        end
    end)
end

function HTLMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        self:ShowHTLAni(data,avatar, magicInfo)
    end
end

function HTLMagicEffect:onEnd(data, avatar) 
    -- 实现恢复效果
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end
    self:HTLEffectEnd(data,avatar)
end

---展示开启加速技能特效
function HTLMagicEffect:ShowHTLAni(data,avatar, magicInfo, finishCallBack)
    if not self.HTLEffect then
        return
    end
    if not avatar then
        return
    end
    --不会被炸
    avatar.Invincible = true
    if Util:IsNil(avatar.htlEffect) then
        avatar.htlEffect = GameObject.Instantiate(self.HTLEffect)
    end

    if avatar.htlEffect then
        avatar.htlEffect.transform:SetParent(avatar.Body.transform, false)
        avatar.htlEffect.transform.localPosition = Vector3.zero
        avatar.htlEffect.transform.localRotation = Quaternion.identity
        avatar.htlEffect.transform.localScale = CS.UnityEngine.Vector3.one
        avatar.htlEffect:SetActive(true)
        local ani = avatar.htlEffect:GetComponent(typeof(CS.UnityEngine.Animator))
        local audio = avatar.htlEffect:GetComponentInChildren(typeof(CS.UnityEngine.AudioSource))
        audio.enabled = data.uuid == App.Uuid
        local seq = DOTween:Sequence()
        seq:AppendInterval(1.33)
        seq:AppendCallback(function()
            ani:SetBool("anim_02daiji", true)
            if finishCallBack then
                finishCallBack()
            end
        end)
    end
end

--- 混天绫特效结束
function HTLMagicEffect:HTLEffectEnd(data,avatar,finishCallBack)
     avatar.Invincible = false
    if not Util:IsNil(avatar.htlEffect) then
        local htlEffect = avatar.htlEffect
        local ani = htlEffect:GetComponent(typeof(CS.UnityEngine.Animator))
        local audio = htlEffect:GetComponentInChildren(typeof(CS.UnityEngine.AudioSource))
        audio.enabled = data.uuid == App.Uuid
        ani:SetBool("anim_03songbang", true)
        ani:SetBool("anim_02daiji", false)
        local seq = DOTween:Sequence()
        avatar.htlEffect = nil
        seq:AppendInterval(0.9)
        seq:AppendCallback(function()
            htlEffect:SetActive(false)
            GameObject.Destroy(htlEffect)
            if finishCallBack then
                finishCallBack()
            end
        end)
    end
end

function HTLMagicEffect:SelfAvatarCreated(avatar)
    self.avatar = avatar
end


return HTLMagicEffect