local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local Util                        = require(MAIN_SCRIPTS_LOC .. "common/util")
local cs_coroutine                = require('common/cs_coroutine')

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

---@class HoldMagicEffect : BaseMagicEffect --舞龙
local HoldMagicEffect = class("HoldMagicEffect", BaseMagicEffect)

function HoldMagicEffect:initialize(magicManager)
    HoldMagicEffect.super.initialize(self, magicManager)
    -- 初始化特效资源
end

function HoldMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        self.magicManager.avatarPropMap[data.uuid] = { status = 1, avatar = avatar }

        local uaddress = magicInfo.uAddress
        self.magicManager:_LoadPropPrefabs(uaddress)
        self.magicManager.commonService:StartCoroutine(function()
            self.magicManager.commonService:Yield(self.magicManager.commonService:WaitUntil(function()
                return self.magicManager.propPrefabMap[uaddress] and
                    self.magicManager.propPrefabMap[uaddress].status == 1
            end))
            if not self.magicManager.avatarPropMap[data.uuid] then
                return
            end


            if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
                self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
            end
            if AVATAR_ENUM.ANIMATOR[magicInfo.action] then
                avatar:commitAnimatiorLayerAction(AVATAR_ENUM.ANIMATOR[magicInfo.action], false, false, 1, true)
            end
            local prefabs = self.magicManager.propPrefabMap[uaddress].prefabs

            --获取道具挂载点
            self:SearchAvatarPoint(avatar, magicInfo.propParentName, function(parentT)
                local prop = GameObject.Instantiate(prefabs)
                prop.name = "道具新春舞龙"
                local anim = prop:GetComponent(typeof(CS.UnityEngine.Animator))
                prop.transform:SetParent(parentT, false)
                prop.transform.localPosition = CS.UnityEngine.Vector3(magicInfo.position[1], magicInfo.position[2],
                    magicInfo.position[3])
                prop.transform.localRotation = CS.UnityEngine.Quaternion.Euler(magicInfo.rotation[1],
                    magicInfo.rotation[2], magicInfo.rotation[3])
                prop.transform.localScale = CS.UnityEngine.Vector3(magicInfo.scale, magicInfo.scale, magicInfo.scale)
                if self.magicManager.avatarPropMap[data.uuid] then
                    self.magicManager.avatarPropMap[data.uuid].prop = prop
                    self.magicManager.avatarPropMap[data.uuid].anim = anim
                    self.magicManager.avatarPropMap[data.uuid].propShow = true
                end
            end)
        end)
    end

end

function HoldMagicEffect:SearchAvatarPoint(avatar, name, callback)
    local character = avatar:GetCharacter()
    if Util:IsNil(character) then
        cs_coroutine.start(function()
            coroutine.yield(App:GetService("CommonService"):WaitUntil(function()
                return avatar:GetCharacter()
            end))
            character = avatar:GetCharacter()
            local point = character.transform:FindInAll(name)
            if callback then
                callback(point)
            end
        end)
    else
        local point = character.transform:FindInAll(name)
        if callback then
            callback(point)
        end
    end
end

function HoldMagicEffect:onEnd(data, avatar) 
    local magicInfo = data.magic
    if self.magicManager.avatarPropMap[data.uuid] or App.Uuid == data.uuid then
        if self.magicManager.avatarPropMap[data.uuid] then
            self.magicManager.avatarPropMap[data.uuid].status = 0
        end
        avatar:SetGravityFactor(1)
        avatar:SetJumpFactor(1)
        avatar:SetMoveSpeedFactor(1)

        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
            self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        if AVATAR_ENUM.ANIMATOR[magicInfo.action] then
            avatar:commitAnimatiorLayerAction(AVATAR_ENUM.ANIMATOR[magicInfo.action], false, false, 0, true)
        end
        if self.magicManager.avatarPropMap[data.uuid] then
            local prop = self.magicManager.avatarPropMap[data.uuid].prop
            if prop and not prop:IsNull() then
                GameObject.Destroy(prop)
                self.magicManager.avatarPropMap[data.uuid].prop = nil
            end
            self.magicManager.avatarPropMap[data.uuid] = nil
        end
    end
end

return HoldMagicEffect