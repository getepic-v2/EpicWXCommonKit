local class = require("middleclass")
local BaseMagicEffect = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/base_magic_effect")
local Util                        = require(MAIN_SCRIPTS_LOC .. "common/util")
local cs_coroutine                = require('common/cs_coroutine')

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

-- 飞行状态枚举
local FLIGHT_STATE = {
    GROUNDED = "grounded",      -- 在地面
    LAUNCHED = "launched",      -- 发射状态（替代起飞和飞行）
    FALLING = "falling"         -- 掉落中
}

local uAddress_rocket = "1012901748508167/assets/Prefabs/M_YanHua_@huojian.prefab"
local uAddress_firework = "1012901748508167/assets/Prefabs/vfx_yanhua.prefab"

---@class FireworkRocketMagicEffect : BaseMagicEffect --加速魔法 --乘风破浪
local FireworkRocketMagicEffect = class("FireworkRocketMagicEffect", BaseMagicEffect)

function FireworkRocketMagicEffect:initialize(magicManager)
    FireworkRocketMagicEffect.super.initialize(self, magicManager)
    self.VisElement = magicManager.VisElement
    self.commonService = magicManager.commonService
    self.joystickService = magicManager.joystickService
    self:InitValues()
    -- 监听摇杆输入
    if self.joystickService and self.joystickService.OnDirChanged then
        self.joystickService.OnDirChanged:connect(function(direction)
            if self.openSkill then
                -- g_Log("gyz 摇杆输入: " .. direction.x .. ", " .. direction.y)
                self:OnJoystickDirectionChanged(direction)
            end
        end)
    end
end

function FireworkRocketMagicEffect:onStart(data, avatar, isResume)
    local magicInfo = data.magic
    -- 实现效果
    if isResume and data.uuid == App.Uuid and self.magicManager.curStatus == AVATAR_STATUS.NORMAL then
        self.magicManager:SendMagicMessage(false, magicInfo)
    else
        if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StartBusiness then
            self.magicManager.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
        end
        if data.uuid == App.Uuid then  --是自己使用技能
            self.openSkill = true
        end
        -- TODO: 执行开始动效动效
        self:StartSkill(avatar, data.uuid)
    end
end

function FireworkRocketMagicEffect:onEnd(data, avatar) 
    -- 实现恢复效果
    if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.magicManager.avatarService.StopBusiness then
        self.magicManager.avatarService:StopBusiness(BUSINESS_NAME_ENUM.BIG, data.uuid)
    end
    -- TODO: 结束技能动效
    if data.uuid == App.Uuid then  --是自己使用技能
        self.openSkill = false
        avatar.characterCtrl.disableTickMove = false
        self.magicManager.observerService:Fire("PETSYSTEM_SET_PET_FOLLOW_STATE", { follow = true })
    end
end

function FireworkRocketMagicEffect:ReceiveMessage(key, value, isResume)

end


function FireworkRocketMagicEffect:SelfAvatarCreated(avatar)
    self.avatar = avatar
end



function FireworkRocketMagicEffect:InitValues()
    self.openSkill = false
    -- 初始化飞行相关属性
    self.flightState = FLIGHT_STATE.GROUNDED
    self.isFlying = false
    self.originalPosition = nil
    self.groundHeight = 0             -- 地面基准高度
    self.lastFlightHeight = 0         -- 上一帧的飞行高度，用于计算高度差
    self.maxFlightHeight = 5      -- 最大飞行高度5米
    self.maxFlightSpeed = 8       -- 最大飞行速度（降低从15到8）
    self.totalFlightDuration = 3  -- 总飞行持续时间5秒（按图表调整）
    self.joystickControlSpeed = 6 -- 摇杆控制速度
    
    -- 飞行阶段定义（严格按照图表曲线）
    self.heightUpPhase = 1.0      -- 0-2秒：高度上升阶段
    self.heightPeakPhase = 1.0    -- 2-3秒：高度保持峰值阶段  
    self.heightDownPhase = 1.0    -- 3-5秒：高度下降回地面阶段
    
    self.speedUpPhase = 1.0       -- 0-1秒：速度快速加速阶段
    self.speedCruisePhase = 1.0   -- 1-4秒：速度保持最高阶段
    self.speedDownPhase = 1.0     -- 4-5秒：速度快速减速阶段
    
    -- 发射方向控制
    self.launchDirection = CS.UnityEngine.Vector3.zero     -- 初始发射方向
    self.lastControlDirection = CS.UnityEngine.Vector3.zero -- 最后一次摇杆控制方向
    self.currentFlightSpeed = 0
    self.joystickInput = CS.UnityEngine.Vector2.zero

    self.magicManager:RegisterDownloadUaddress(uAddress_rocket)
    self.magicManager:LoadRemoteUaddress(uAddress_rocket, function(success, prefab)
        if success and prefab then
            self.roket_prefab = prefab
        end
    end, false)

    self.magicManager:RegisterDownloadUaddress(uAddress_firework)
    self.magicManager:LoadRemoteUaddress(uAddress_firework, function(success, prefab)
        if success and prefab then
            self.firework_prefab = prefab
        end
    end, false)
end

--点击处理
function FireworkRocketMagicEffect:StartSkill(avatar, uuid)
    g_Log("炮弹发射按钮被点击 - 时间:" .. CS.UnityEngine.Time.time .. " 当前状态:" .. self.flightState)
    
    if not avatar then
        g_Log("Avatar不存在，无法发射")
        return
    end
    
    -- 只有在地面状态才能发射
    if self.flightState == FLIGHT_STATE.GROUNDED then
        self:LaunchAvatar(avatar, uuid)
    else
        g_Log("当前状态不允许发射: " .. self.flightState)
    end
end

---加火箭
function FireworkRocketMagicEffect:AddRocket(avatar, uuid)
    -- self:AsyncGetAvatar(uuid, AvatarLoadType.PrefabLoaded, function(avatar)
    -- avatar.characterCtrl.isOnlyRotate = true
    -- avatar:SetMoveSpeedFactor(0)
    -- avatar:SetGravityFactor(0)
    avatar.characterCtrl.disableTickMove = true
    --设置动画层
        avatar:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_ride", nil, true)
        local gm = GameObject.Instantiate(self.roket_prefab)
        gm.name = "saoba"
        gm.transform:SetParent(avatar.Body.transform)
        gm.transform.localPosition = Vector3(0, -0.1, 0)
        gm.transform.localEulerAngles = Vector3(0, 0, 0)
        gm.transform.localScale = Vector3(0.8, 0.8, 0.8)
        gm.gameObject:SetActive(true)
        self.commonService:DispatchAfter(2, function()
            self:RemoveRocket(avatar, uuid)
        end)
        if uuid == App.Uuid then
            if self.skillAudio then
                self.magicManager.audioService:PlayClipOneShot(self.skillAudio, function() end)
            else
                self.magicManager.audioService:GetMp3AudioFromGetUrl(
                    "https://static0.xesimg.com/next-studio-pub/app/1750316919419/iktlAQFjOR5ZYoUvPX6g.mp3",
                    function(error)
                        print("音频加载失败")
                    end, function(clip)
                        self.skillAudio = clip
                        self.magicManager.audioService:PlayClipOneShot(self.skillAudio, function() end)
                end)
            end
            self.magicManager.observerService:Fire("PETSYSTEM_SET_PET_FOLLOW_STATE", { follow = false })
        end
    -- end)
end

---移除火箭
function FireworkRocketMagicEffect:RemoveRocket(avatar, uuid)
    -- self:AsyncGetAvatar(uuid, AvatarLoadType.PrefabLoaded, function(avatar)
    avatar:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "stop_ride", nil, true) 
    local gm = avatar.Body.transform:Find("saoba")
    if gm then
        print("gyz 删除saoba")
        gm.gameObject:SetActive(false)
        gm.transform:SetParent(nil)
        GameObject.DestroyImmediate(gm.gameObject)
        avatar.characterCtrl.disableTickMove = false
    end
    self:AddFirework(avatar.VisElement.transform.position, uuid)
    -- end)
end

function FireworkRocketMagicEffect:AddFirework(position, uuid)
    local firework = GameObject.Instantiate(self.firework_prefab)
    firework.name = "firework"
    firework.transform:SetParent(self.VisElement.transform)
    firework.transform.localPosition = position
    firework.transform.localEulerAngles = Vector3(0, 0, 0)
    firework.transform.localScale = Vector3(0.8, 0.8, 0.8)
    firework.gameObject:SetActive(true)
    if uuid == App.Uuid then
        if self.boomAudio then
            self.magicManager.audioService:PlayClipOneShot(self.boomAudio, function() end)
        else
            self.magicManager.audioService:GetMp3AudioFromGetUrl(
                "https://static0.xesimg.com/next-studio-pub/app/1750316919421/SfuyrfOma3UkX4mw2AXK.mp3",
                function(error)
                    print("音频加载失败")
                end, function(clip)
                    self.boomAudio = clip
                    self.magicManager.audioService:PlayClipOneShot(self.boomAudio, function() end)
            end)
        end
    end
    self.commonService:DispatchAfter(2, function()
        firework.transform:SetParent(nil)
        GameObject.DestroyImmediate(firework)
        firework = nil
    end)
end

-- 发射Avatar
function FireworkRocketMagicEffect:LaunchAvatar(avatar, uuid)
    g_Log("开始精确轨迹飞行")
    
    if not avatar or not avatar.VisElement then
        g_LogError("Avatar或VisElement不存在")
        return
    end

    self:AddRocket(avatar, uuid)
    
    -- 完整的状态重置（修复叠加问题）
    self.flightState = FLIGHT_STATE.LAUNCHED
    self.isFlying = true
    self.joystickInput = CS.UnityEngine.Vector2.zero  -- 重置摇杆输入
    self.currentFlightSpeed = 0
    self.originalPosition = avatar.VisElement.transform.position
    
    -- 重要修复：记录初始地面高度作为基准，而不是从0开始
    self.groundHeight = avatar.VisElement.transform.position.y
    self.lastFlightHeight = 0  -- 相对于地面的高度，从0开始
    
    g_Log("记录地面基准高度: " .. self.groundHeight .. "米")
    
    -- 标记角色控制器：正在进行特殊飞行，避免常规移动逻辑干扰
    if avatar.characterCtrl then
        avatar.characterCtrl.specialFlightMode = true
        g_Log("设置角色控制器为特殊飞行模式")
    end
    
    -- 获取发射方向（avatar.Body的方向）
    local bodyDirection = CS.UnityEngine.Vector3.zero
    if avatar.Body and avatar.Body.transform then
        bodyDirection = avatar.Body.transform.forward
    else
        bodyDirection = avatar.VisElement.transform.forward
    end
    
    -- 设置水平发射方向
    self.launchDirection = CS.UnityEngine.Vector3(bodyDirection.x, 0, bodyDirection.z).normalized
    self.lastControlDirection = self.launchDirection  -- 初始化最后控制方向为发射方向
    
    g_Log("精确轨迹飞行开始，发射方向: " .. bodyDirection.x .. ", " .. bodyDirection.z .. ", 地面高度: " .. self.groundHeight)
    
    -- 开始飞行控制协程
    self.commonService:StartCoroutine(function()
        self:PrecisionFlightCoroutine(avatar)
    end)
end

-- 精确飞行控制协程（根据图表曲线）
function FireworkRocketMagicEffect:PrecisionFlightCoroutine(avatar)
    local transform = avatar.VisElement.transform
    local flightTime = 0
    local currentFlightDirection = self.launchDirection  -- 当前飞行方向
    
    -- 检查是否有characterCtrl
    if not avatar.characterCtrl then
        g_LogError("Avatar没有characterCtrl，无法使用MoveTo方法")
        self:EndFlight()
        return
    end
    
    -- g_Log("协程开始，总飞行时间: " .. self.totalFlightDuration .. "秒")
    
    while self.flightState == FLIGHT_STATE.LAUNCHED and flightTime < self.totalFlightDuration do
        local deltaTime = CS.UnityEngine.Time.deltaTime
        flightTime = flightTime + deltaTime
        
        -- 根据图表计算当前高度和速度
        local currentHeight = self:CalculateHeightByTime(flightTime)
        local currentSpeed = self:CalculateSpeedByTime(flightTime)
        
        -- 改进的方向控制逻辑（摇杆只控制方向，不影响速度）
        if self.joystickInput and self.joystickInput.magnitude > 0.1 then
            -- 有摇杆输入：摇杆只控制飞行方向，不影响速度大小
            
            local joystickV3 = CS.UnityEngine.Vector3(
                self.joystickInput.x,
                0,
                self.joystickInput.y  -- 摇杆的y对应世界的z轴
            ).normalized  -- 标准化方向，忽略强度
            
            -- 转换摇杆方向到世界坐标系（简化逻辑）
            local worldDirection = CS.UnityEngine.Vector3.zero
            
            -- 优先使用LookRotation进行转换
            if avatar.LookRotation and avatar.LookRotation.transform then
                local isOld = false
                if avatar.IsOldVersion then
                    isOld = avatar:IsOldVersion()
                end
                
                if isOld then
                    worldDirection = avatar.LookRotation.transform.rotation * joystickV3
                else
                    worldDirection = avatar.LookRotation.transform.localRotation * joystickV3
                end
            elseif avatar.Body and avatar.Body.transform then
                -- 备选方案：使用avatar的Body朝向
                worldDirection = avatar.Body.transform.rotation * joystickV3
            else
                -- 最简单的备选方案：直接使用摇杆输入
                worldDirection = joystickV3
            end
            
            -- 确保只在水平面上移动（清除Y轴分量）
            currentFlightDirection = CS.UnityEngine.Vector3(
                worldDirection.x,
                0,
                worldDirection.z
            ).normalized
            
            -- 保存最后的控制方向，松开摇杆后继续沿此方向飞行
            self.lastControlDirection = currentFlightDirection
            
            -- 简化的调试日志
            -- g_Log("摇杆控制: (" .. self.joystickInput.x .. ", " .. self.joystickInput.y .. ") -> 方向: (" .. currentFlightDirection.x .. ", " .. currentFlightDirection.z .. ")")
        else
            -- 无摇杆输入：使用最后一次的控制方向
            currentFlightDirection = self.lastControlDirection
        end
        
        -- 确保方向向量有效
        if currentFlightDirection.magnitude < 0.1 then
            currentFlightDirection = self.launchDirection
        end
        
        -- 计算水平移动（应用摇杆强度，避免叠加加速）
        local horizontalMovement = currentFlightDirection * currentSpeed * deltaTime
        
        -- 计算高度变化（相对于上一帧的高度差）
        local heightDelta = currentHeight - self.lastFlightHeight
        self.lastFlightHeight = currentHeight
        print("gyz 高度变化: " .. heightDelta)
        -- 构建完整的移动向量（使用相对位移）
        local moveOffset = CS.UnityEngine.Vector3(
            horizontalMovement.x,
            heightDelta,  -- 使用高度差而不是绝对高度
            horizontalMovement.z
        )
        
        -- -- 调试：输出移动相关信息
        -- if self.joystickInput and self.joystickInput.magnitude > 0.1 then
        --     g_Log(string.format("移动计算: 时间=%.2f, 速度=%.2f, deltaTime=%.4f, 水平移动=(%.4f,%.4f), 高度变化=%.4f", 
        --         flightTime, currentSpeed, deltaTime, horizontalMovement.x, horizontalMovement.z, heightDelta))
        -- end
        
        -- -- 高度调试：每次高度变化都记录
        -- if math.abs(heightDelta) > 0.001 then
        --     g_Log(string.format("高度变化详情: 时间=%.2f, 当前相对高度=%.3f, 上一帧高度=%.3f, 高度差=%.3f", 
        --         flightTime, currentHeight, self.lastFlightHeight, heightDelta))
        -- end
        
        -- 使用characterCtrl的MoveTo方法进行移动（允许旋转但阻止额外移动）
        if avatar.characterCtrl and avatar.characterCtrl.MoveTo then
            -- 不完全禁用摇杆数据，让角色控制器处理旋转
            -- 但我们控制移动逻辑
            
            -- 执行火箭飞行移动
            avatar.characterCtrl:MoveTo(moveOffset)
            
        else
            g_LogError("characterCtrl或MoveTo方法不存在，回退到直接操作transform")
            -- 回退到原始方法作为备选方案
            local currentPos = transform.position
            local newPos = CS.UnityEngine.Vector3(
                currentPos.x + moveOffset.x,
                currentPos.y + moveOffset.y,
                currentPos.z + moveOffset.z
            )
            transform.position = newPos
        end
        
        -- 角色朝向飞行方向（加强旋转控制）
        if currentFlightDirection.magnitude > 0.1 then
            local targetRotation = CS.UnityEngine.Quaternion.LookRotation(currentFlightDirection)
            local oldRotation = transform.rotation
            transform.rotation = CS.UnityEngine.Quaternion.Slerp(transform.rotation, targetRotation, 5 * deltaTime)
            
            -- 调试：输出旋转信息
            if self.joystickInput and self.joystickInput.magnitude > 0.1 then
                local rotationDiff = CS.UnityEngine.Quaternion.Angle(oldRotation, transform.rotation)
                if rotationDiff > 0.1 then
                    -- g_Log(string.format("角色旋转: 方向=(%.3f,%.3f), 旋转差=%.2f度", 
                    --     currentFlightDirection.x, currentFlightDirection.z, rotationDiff))
                end
            end
        end
        
        self.commonService:YieldEndFrame()
    end
    
    -- g_Log("协程结束，最终飞行时间: " .. flightTime .. "秒，当前状态: " .. self.flightState)
    self:EndFlight()
end

-- 根据时间计算高度（严格按照图表曲线）
function FireworkRocketMagicEffect:CalculateHeightByTime(time)
    if time <= 0 then
        return 0
    elseif time <= self.heightUpPhase then
        -- 0-2秒：线性上升到最大高度
        local progress = time / self.heightUpPhase
        return self.maxFlightHeight * progress
    elseif time <= (self.heightUpPhase + self.heightPeakPhase) then
        -- 2-3秒：保持最大高度
        return self.maxFlightHeight
    elseif time <= self.totalFlightDuration then
        return self.maxFlightHeight
        -- -- 3-5秒：线性下降回地面
        -- local declineStartTime = self.heightUpPhase + self.heightPeakPhase  -- 3秒
        -- local declineTime = time - declineStartTime
        -- local progress = declineTime / self.heightDownPhase  -- 下降进度(0-1)
        -- return self.maxFlightHeight * (1 - progress)  -- 从最大高度线性下降到0
    else
        -- 超过5秒：回到地面
        return self.maxFlightHeight
    end
end

-- 根据时间计算速度（严格按照图表曲线）
function FireworkRocketMagicEffect:CalculateSpeedByTime(time)
    if time <= 0 then
        return 0
    elseif time <= self.speedUpPhase then
        -- 0-1秒：快速加速到最大速度
        local progress = time / self.speedUpPhase
        local easeProgress = progress * progress  -- 平方曲线，快速加速
        return self.maxFlightSpeed * easeProgress
    elseif time <= (self.speedUpPhase + self.speedCruisePhase) then
        -- 1-4秒：保持最大速度
        return self.maxFlightSpeed
    elseif time <= self.totalFlightDuration then
        -- 4-5秒：快速减速到0
        local decelerationStartTime = self.speedUpPhase + self.speedCruisePhase  -- 4秒
        local decelerationTime = time - decelerationStartTime
        local progress = decelerationTime / self.speedDownPhase  -- 减速进度(0-1)
        local easeProgress = 1 - (progress * progress)  -- 平方曲线，快速减速
        return self.maxFlightSpeed * easeProgress
    else
        -- 超过5秒：速度为0
        return 0
    end
end

-- 摇杆方向变化处理
function FireworkRocketMagicEffect:OnJoystickDirectionChanged(direction)
    -- 增加输入验证（修复叠加问题）
    if not direction then
        self.joystickInput = CS.UnityEngine.Vector2.zero
        -- g_Log("摇杆输入清零：无方向输入，将继续沿最后控制方向飞行")
        return
    end
    
    if self.flightState == FLIGHT_STATE.LAUNCHED then
        -- 飞行状态中：记录摇杆输入（纯方向控制，不影响速度）
        self.joystickInput = direction
        if direction.magnitude > 0.1 then
            -- g_Log("飞行中接收摇杆输入: (" .. direction.x .. ", " .. direction.y .. ") [纯方向控制，不影响速度]")
        else
            -- g_Log("飞行中接收摇杆输入: 强度过小，忽略，继续沿最后控制方向飞行")
        end
    else
        -- 非飞行状态：清零摇杆输入
        self.joystickInput = CS.UnityEngine.Vector2.zero
        -- g_Log("非飞行状态，摇杆输入被忽略")
    end
end

-- 结束飞行
function FireworkRocketMagicEffect:EndFlight()
    -- g_Log("准备结束飞行，当前状态: " .. self.flightState)
    
    -- 清除角色控制器的特殊飞行模式标记
    if self.avatar and self.avatar.characterCtrl then
        self.avatar.characterCtrl.specialFlightMode = false
        g_Log("清除角色控制器的特殊飞行模式")
    end
    
    -- 彻底的状态重置（修复叠加问题）
    self.flightState = FLIGHT_STATE.GROUNDED
    self.isFlying = false
    self.joystickInput = CS.UnityEngine.Vector2.zero
    self.currentFlightSpeed = 0
    self.originalPosition = nil
    self.groundHeight = 0  -- 重置地面基准高度
    self.lastFlightHeight = 0  -- 重置上一帧高度
    self.launchDirection = CS.UnityEngine.Vector3.zero  -- 清零发射方向
    self.lastControlDirection = CS.UnityEngine.Vector3.zero  -- 清零最后控制方向
    
    -- g_Log("精确轨迹飞行序列完成，状态已重置为: " .. self.flightState)
    
    -- 可以在这里添加着陆特效
    self:OnLandingEffect()
end

-- 着陆特效（可扩展）
function FireworkRocketMagicEffect:OnLandingEffect()
    -- g_Log("着陆特效触发")
end

-- 公共方法：设置最大飞行高度
function FireworkRocketMagicEffect:SetMaxFlightHeight(height)
    if height and height > 0 then
        self.maxFlightHeight = height
        g_Log("设置最大飞行高度为: " .. height .. "米")
    end
end

-- 公共方法：设置最大飞行速度
function FireworkRocketMagicEffect:SetMaxFlightSpeed(speed)
    if speed and speed > 0 then
        self.maxFlightSpeed = speed
        g_Log("设置最大飞行速度为: " .. speed)
    end
end

-- 公共方法：设置飞行持续时间
function FireworkRocketMagicEffect:SetFlightDuration(duration)
    if duration and duration > 0 then
        self.totalFlightDuration = duration
        g_Log("设置飞行持续时间为: " .. duration .. "秒")
    end
end

-- 公共方法：获取当前飞行状态
function FireworkRocketMagicEffect:GetFlightState()
    return self.flightState
end

-- 公共方法：强制结束飞行
function FireworkRocketMagicEffect:ForceEndFlight()
    if self.isFlying then
        g_Log("强制结束精确轨迹飞行")
        self:EndFlight()
    end
end

-- 调试方法：验证高度计算曲线
function FireworkRocketMagicEffect:DebugHeightCurve()
    g_Log("=== 高度曲线验证 ===")
    for i = 0, 50 do
        local time = i * 0.1  -- 每0.1秒采样
        local height = self:CalculateHeightByTime(time)
        if i % 5 == 0 then  -- 每0.5秒输出一次
            g_Log(string.format("时间: %.1f秒, 高度: %.2f米", time, height))
        end
    end
    g_Log("=== 高度曲线验证结束 ===")
end

-- 调试方法：获取当前飞行高度信息  
function FireworkRocketMagicEffect:GetFlightHeightInfo()
    if not self.avatar or not self.avatar.VisElement then
        return "无Avatar信息"
    end
    
    local currentPos = self.avatar.VisElement.transform.position
    local relativeHeight = currentPos.y - self.groundHeight
    
    return string.format("地面高度: %.2f, 当前世界高度: %.2f, 相对飞行高度: %.2f", 
        self.groundHeight, currentPos.y, relativeHeight)
end





return FireworkRocketMagicEffect