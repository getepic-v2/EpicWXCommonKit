---
---  Author: 【王德】
---  AuthorID: 【102030】
---  CreateTime: 【2023-7-29 16:35:40】
--- 【FSync】
--- 【语音答题面板】
---
-- self.observerService:Fire(EVENT_BUSINESS_PROP_ANSWER_QUESTION, {
--     status = 1,
--     showAwardType = 7, --2 小游戏 ，3 npc对话 ，4芝士 ，5 宠物饲料 6 跳一跳，7道具互动，8摩天轮 9 宠物pk 10 阵营活动
--     reTryCount = self.reTryCount, --0或1 0答一次 1 答两次
--     callBack = function(score, isFinal, isNoSpeaking)

--     end
-- })
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class QuestionPanel : WorldBaseElement
local QuestionPanel = class("QuestionPanel", WBElement)
local TAG = "语音答题面板"
local EVENT_EVALUATION_AND_RECOGNITION_SERVICE = "EVENT_EVALUATION_AND_RECOGNITION_SERVICE"
local EVENT_ABCZONE_ALL_MUSIC_VOLUME = "EVENT_ABCZONE_ALL_MUSIC_VOLUME"
local EVENT_BUSINESS_PROP_ANSWER_QUESTION = "EVENT_BUSINESS_PROP_ANSWER_QUESTION"

local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/questionPanel/"
local prefabPath = ResourcePathRoot .. "assets/Prefabs/QuestionPanel.prefab"

-- 260 -110 150   单词268
---@param worldElement CS.Tal.framesync.WorldElement
function QuestionPanel:initialize(worldElement)
    QuestionPanel.super.initialize(self, worldElement)
    self.domain = "https://app.chuangjing.com/abc-api"
    self.root = self.VisElement.gameObject
    self.rootTrans = self.root.transform
    self.passScore = 75
    self.uiGap = 0
    self.questionList = {}
    -- self.questionIndex = 1
    self.reTryCount = 1
    self.appVersion = App.Info.appVersionNumber
    self.curViewMode = 0
    self.fromViewGap = 78
    self.jewel = 0
    self:InitService()
    self:InitView()
    self:InitListener()

    -- 监听宝石数量更新事件
    self.observerService:Watch("EVENT_BUSINESS_JEWEL_COUNT_UPDATE", function(key, value)
        local data = value[0]
        if data and data.count ~= nil then
            self.jewel = data.count
            if self.rbJewelCountTmp then
                self.rbJewelCountTmp.text = tostring(self.jewel)
            end
        end
    end)

    -- 请求获取当前宝石数量
    self.observerService:Fire("EVENT_BUSINESS_JEWEL_COUNT_GET", {
        callback = function(count)
            if count ~= nil then
                self.jewel = count
                if self.rbJewelCountTmp then
                    self.rbJewelCountTmp.text = tostring(self.jewel)
                end
            end
        end
    })

    if not (App.IsStudioClient) then
        self.pluginJson = App.Info.plugins
        if self.pluginJson ~= nil and type(self.pluginJson) == "string" then
            -- log("开始动态资源相关配置")
            self:InitPluginInfo()
        end
    end

    self.observerService:Watch("add_diamond_from_read", function(key, args)
        local value = args[0]
        if value.addDiamond then
            self.jewel = self.jewel + value.addDiamond
            if self.rbJewelCountTmp then
                self.rbJewelCountTmp.text = tostring(self.jewel)
            end
            -- 发送宝石数量更新事件
            self.observerService:Fire("EVENT_BUSINESS_JEWEL_COUNT_UPDATE", {
                count = self.jewel
            })
        end
    end)

    -- self.commonService:DispatchAfter(5, function()
    --     local text_en = "A trip to the zoo."
    --     local indexArray = { { 0, 0 }, { 2, 5 }, { 14, 18 } }
    --     local text = self:GetKeyWordTextByIndex(text_en, indexArray)
    --     g_Log(TAG, text)
    -- end)
end

function QuestionPanel:InitPluginInfo()
    local list = self.jsonService:decode(self.pluginJson)
    for _, v in pairs(list) do
        if v.pluginName == "ABC动态资源配置" then
            xpcall(function()
                if v.pluginVal.abc_evaluation_pass_score then
                    self.passScore = tonumber(v.pluginVal.abc_evaluation_pass_score)
                end
            end, function(err)

            end)
        end
    end
end

function QuestionPanel:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()

    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

function QuestionPanel:InitView()
    self.root = self.VisElement.gameObject
    self.rootTrans = self.root.transform
    ResourceManager:LoadGameObjectWithExName(prefabPath, function(go)
        self.questionPanel = GameObject.Instantiate(go).transform
        self.questionPanel:SetParent(self.rootTrans)
        self.questionPanel.localPosition = Vector3.zero
        self.questionPanel.localScale = Vector3.one
        self.questionPanel.localRotation = Quaternion.identity


        self.canvas = self.questionPanel:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
        self.canvas.sortingOrder = 1090
        self.bg = self.questionPanel:FindChildWithName("bg")
        ---@type CS.UnityEngine.UI.Image
        local bgImage = self.bg:GetComponent(typeof(CS.UnityEngine.UI.Image))
        bgImage.color = CS.UnityEngine.Color(0, 0, 0, 0.6)
        self.title = self.questionPanel:FindChildWithName("title")
        self.titleImage = self.title:GetComponent(typeof(CS.UnityEngine.UI.Image))

        self.titleImage:SetNativeSize()
        self.panel = self.questionPanel:FindChildWithName("panel")
        self.panelRect = self.panel:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.panelRect.sizeDelta = CS.UnityEngine.Vector2(688, self.panelRect.sizeDelta.y)
        self.senText = self.questionPanel:FindChildWithName("Sen")
        self.senTextTmp = self.senText:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.senTextRect = self.senText:GetComponent(typeof(CS.UnityEngine.RectTransform))

        ---读课文UI
        self.readBookPanelBg = self.questionPanel:FindChildWithName("ReadBookPanelBg")
        self.transTag = self.readBookPanelBg:FindChildWithName("Tag")
        self.transZuanShi = self.readBookPanelBg:FindChildWithName("zuanshi")
        self.readBookPanelBg.gameObject:SetActive(true)
        self.rbContentEn = self.readBookPanelBg:FindChildWithName("ContentEn")
        self.rbContentEnTmp = self.rbContentEn:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.rbContentEnPre = self.readBookPanelBg:FindChildWithName("ContentEnPre")
        self.rbContentEnPreTmp = self.rbContentEnPre:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.rbContentEnPreRect = self.rbContentEnPre:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.rbContentEnLast = self.readBookPanelBg:FindChildWithName("ContentEnLast")
        self.rbContentEnLastTmp = self.rbContentEnLast:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.rbContentEnLastRect = self.rbContentEnLast:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.rbContentCn = self.readBookPanelBg:FindChildWithName("ContentCn")
        self.rbContentCnTmp = self.rbContentCn:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.rbContentCnRect = self.rbContentCn:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.rbJewel = self.readBookPanelBg:FindChildWithName("zuanshi")
        self.rbJewelAnim = self.rbJewel:GetComponent(typeof(CS.UnityEngine.Animator))
        self.rbJewelCount = self.rbJewel:FindChildWithName("Text_1")
        self.rbJewelCountTmp = self.rbJewelCount:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.readBookPanelBg.gameObject:SetActive(false)
        ---读句子UI
        self.sentencePanelBg = self.questionPanel:FindChildWithName("SenPanelBg")

        self.questionTagRoot = self.questionPanel:FindChildWithName("TagRoot")
        ---句式标签
        self.sentencePattern = self.questionPanel:FindChildWithName("SentencePattern")
        self.spRect = self.sentencePattern:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.spContent = self.sentencePattern:FindChildWithName("SPContent")
        self.spContentRect = self.spContent:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.spContentTmp = self.spContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        ---时态标签
        self.tense = self.questionPanel:FindChildWithName("Tense")
        self.tenseRect = self.tense:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.tenseContent = self.tense:FindChildWithName("TenseContent")
        self.tenseContentRect = self.tenseContent:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.tenseContentTmp = self.tenseContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.questionTagRoot.gameObject:SetActive(false)
        ---deepseek标签
        self.deepseekTag = self.questionPanel:FindChildWithName("DeepseekTag")
        if self.deepseekTag then
            self.deepseekTagRect = self.deepseekTag:GetComponent(typeof(CS.UnityEngine.RectTransform))
            self.deepseekTagImage = self.deepseekTag:GetComponent(typeof(CS.UnityEngine.UI.Image))
            self.deepseekTagImage.gameObject:SetActive(false)
        end

        self.questionFrom = self.questionPanel:FindChildWithName("from")
        self.questionFromRect = self.questionFrom:GetComponent(typeof(CS.UnityEngine.RectTransform))
        ---@type CS.UnityEngine.UI.HorizontalLayoutGroup
        self.questionFromHorz = self.questionFrom:GetComponent(typeof(CS.UnityEngine.UI.HorizontalLayoutGroup))
        self.questionFromHorz.spacing = 2
        self.questionFromPre = self.questionFrom:FindChildWithName("fromPre")
        self.questionFromPreTmp = self.questionFromPre:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.questionFromPreTmp.text = "来源："
        self.questionFromBook = self.questionFrom:FindChildWithName("book")
        self.questionFromBookRect = self.questionFromBook:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.questionFromBookRect.sizeDelta = Vector2(14, 20)
        self.questionFromBookImg = self.questionFromBook:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.questionFromDetail = self.questionFrom:FindChildWithName("fromDetail")
        self.questionFromDetailTmp = self.questionFromDetail:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.typeIcon = self.questionPanel:FindChildWithName("typeIcon")
        self.typeIconImage = self.typeIcon:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.typeIcon.gameObject:SetActive(false)
        self.questionFrom.gameObject:SetActive(false)
        self.questionPanel.gameObject:SetActive(false)
        self.commonService:StartCoroutine(function()
            self.commonService:Yield(self.commonService:WaitUntil(function()
                return self.recoverComplete
            end))
            self:SetDeepSeekTag()
        end)
    end)

    self.micRect = {
        anchorMax = Vector2(1, 0),
        anchorMin = Vector2(1, 0),
        anchoredPosition = Vector2(-320, 0),
    }

    self.audioClickCallback = function()
        if not self.isPlaying then
            self:playSound()
        end
    end
    self.reSpeakClickCallback = function()
        if self.audioSource then
            self.audioService:StopAudioSource(self.audioSource)
        end
    end
end

function QuestionPanel:SetViewMode(mode)
    if mode == 1 then
        self.panelRect.sizeDelta = Vector2(560, self.panelRect.sizeDelta.y)
        self.panelRect.anchorMax = Vector2(1, 0.5)
        self.panelRect.anchorMin = Vector2(1, 0.5)
        self.panelRect.anchoredPosition = Vector2(-320, 81)
        self.senTextRect.sizeDelta = Vector2(480, self.senTextRect.sizeDelta.y)
        -- self.fromViewGap = 84
    else
        self.panelRect.sizeDelta = Vector2(688, self.panelRect.sizeDelta.y)
        self.panelRect.anchorMax = Vector2(0.5, 0.5)
        self.panelRect.anchorMin = Vector2(0.5, 0.5)
        self.panelRect.anchoredPosition = CS.UnityEngine.Vector2(0, 81)
        self.senTextRect.sizeDelta = Vector2(600, self.senTextRect.sizeDelta.y)
        -- self.fromViewGap = 84
    end
end

function QuestionPanel:SetDeepSeekTag()
    if not self.deepseekTag then
        return
    end
    self.observerService:Fire("EVENT_ABCZONE_DEEPSEEK_TAG_SERVICE", {
        callBack = function(isShow, imageList)
            if isShow then
                self.showDeepSeekTag = true
                self.deepseekTagImage.gameObject:SetActive(true)
                if imageList['ds_chuti_img'] and imageList['ds_chuti_img'] ~= "" then
                    self.httpService:LoadNetWorkTexture(imageList['ds_chuti_img'], function(sprite)
                        if sprite then
                            self.deepseekTagImage.sprite = sprite
                            -- 设置图片高度为32，并按比例设置宽度
                            if self.deepseekTagRect then
                                local originalWidth = sprite.rect.width
                                local originalHeight = sprite.rect.height
                                local targetHeight = 32
                                local targetWidth = (originalWidth / originalHeight) * targetHeight
                                self.deepseekTagRect.sizeDelta = Vector2(targetWidth, targetHeight)
                            end
                        end
                    end)
                end
            else
                self.deepseekTagImage.gameObject:SetActive(false)
            end
        end
    })
end

function QuestionPanel:InitListener()
    self.lastRewardCount = -1
    self.observerService:Watch(EVENT_BUSINESS_PROP_ANSWER_QUESTION, function(key, value)
        local data = value[0]
        local status = data.status
        g_Log("收到answer事件2")
        if status == 1 then
            local showAwardType = data.showAwardType
            local awardCount = data.awardCount
            self.reTryCount = data.reTryCount or 1
            local noLeadReading = data.noLeadReading
            local callBack = data.callBack
            local viewMode = data.viewMode
            local hideMask = data.hideMask
            self.passText = data.passText
            self.notpassText = data.notPassText
            self.transQuestion = data.question
            self.evaInfo = { showAwardType = showAwardType, awardCount = awardCount }
            for k, v in pairs(data) do
                if k ~= "status" and k ~= "callBack" and k ~= "question" then
                    self.evaInfo[k] = v
                end
            end
            if viewMode == 1 then
                self.evaInfo["micRect"] = self.micRect
            end
            if viewMode then
                if viewMode ~= self.curViewMode then
                    self.curViewMode = viewMode
                    self:SetViewMode(viewMode)
                end
            else
                if self.curViewMode ~= 0 then
                    self.curViewMode = 0
                    self:SetViewMode(0)
                end
            end

            if hideMask then
                self.bg.gameObject:SetActive(false)
            else
                self.bg.gameObject:SetActive(true)
            end
            self:startAnswer(noLeadReading, callBack)
        else
            self:cancelAnswer()
        end
    end)
    self.observerService:Watch("EVENT_BUSINESS_QUESTION_FROM_INFO", function(key, value)
        local data = value[0]
        local bookImageUrl = data.bookImageUrl
        local bookName = data.bookName
        local bookLevel = data.bookLevel
        self.bookName = bookName
        ---异步加载资源 所以需要等加载完成再显示
        self.commonService:StartCoroutine(function()
            self.commonService:Yield(self.commonService:WaitUntil(function()
                return self.questionFrom
            end))
            self.questionFrom.gameObject:SetActive(true)
            self.httpService:LoadNetWorkTexture(bookImageUrl, function(sprite)
                if sprite then
                    self.commonService:DispatchNextFrame(function()
                        self.questionFromBookImg.sprite = sprite
                    end)
                end
            end)
            self.questionFromDetailTmp.text = " " .. bookName .. " " .. bookLevel
        end)
        self.uiGap = 46
    end) 

    self.observerService:Watch("on_change_last_reward_count", function(key, params)
        local data = params[0]
        if data then
            self.lastRewardCount = data.count or -1
        end
        if not self.transTag or not self.transZuanShi then
            return
        end
        self.transTag.gameObject:SetActive(self.lastRewardCount > 0)
        self.transZuanShi.gameObject:SetActive(self.lastRewardCount > 0)
    end)
end

function QuestionPanel:SetBookTypeImage(bookTypeImage)
    if self.hasSetBookTypeImage or (not bookTypeImage) or bookTypeImage == "" then
        return
    end
    self.httpService:LoadNetWorkTexture(bookTypeImage, function(sprite)
        if sprite then
            self.hasSetBookTypeImage = true
            self.commonService:DispatchNextFrame(function()
                self.typeIcon.gameObject:SetActive(true)
                self.typeIconImage.sprite = sprite
                self.fromViewGap = 102
            end)
        end
    end)
end

function QuestionPanel:playSound()
    self.isPlaying = true
    -- local PlayVideo, videoViewType = self:CanPlayVideoGuide()
    -- if PlayVideo then
    --     self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
    --         op = "PlayVideo",
    --         viewType = videoViewType,
    --         question = self.question,
    --         callback = function(res)
    --             self.isPlaying = false
    --             --播放完成--隐藏video视图
    --             self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", { op = "hide" })
    --             self.speechAssessmentBusiness:ChangePlaySoundAnim(false)
    --             self.observerService:Fire(EVENT_ABCZONE_ALL_MUSIC_VOLUME, { mute = false })
    --         end
    --     })
    -- else
    local audio = self.question.audio
    local audioClip = self.question.audioClip
    if audioClip then
        self.speechAssessmentBusiness:ChangePlaySoundAnim(true)
        self.observerService:Fire(EVENT_ABCZONE_ALL_MUSIC_VOLUME, { mute = true })
        self.audioSource = self.audioService:PlayClipOneShot(audioClip, function()
            self.isPlaying = false
            self.speechAssessmentBusiness:ChangePlaySoundAnim(false)
            self.observerService:Fire(EVENT_ABCZONE_ALL_MUSIC_VOLUME, { mute = false })
        end)
    else
        self.audioService:GetMp3AudioFromGetUrl(audio, function()
            self.isPlaying = false
            self:_reportData("下载音频失败", { url = audio, text_en = self.question.text_en, id = self.question.id }, "0")
        end, function(clip)
            self.question.audioClip = clip
            self:playSound()
        end)
    end
    -- end
end

-- 是否启动视频引导
function QuestionPanel:CanPlayVideoGuide()
    g_Log(TAG, "playFirstSound", table.dump(self.evaInfo))
    --是否开启外教领读
    local isShowVideo = self.evaInfo.isShowVideo
    local videoViewType = self.evaInfo.videoViewType or 1
    --播放引导视频是否可用
    local PlayVideo = false
    --播放视频功能是否可用 --版本、是否是测试环境
    local canUse = false
    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
        op = "Available",
        callback = function(use)
            canUse = use
        end
    })
    g_Log(TAG, "canUse", canUse)
    local videoUrl = self.question.video
    if isShowVideo and videoUrl and videoUrl ~= "" and canUse then
        PlayVideo = true
    end
    return PlayVideo, videoViewType
end

function QuestionPanel:playFirstSound(noLeadReading, callBack)
    if noLeadReading then
        g_Log(TAG, "不播放引导音")
        callBack()
        return
    end

    local PlayVideo, videoViewType = self:CanPlayVideoGuide()

    if PlayVideo then
        -- g_Log(TAG, "展示外教领读-UI样式", videoViewType)
        self.isPlaying = true
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
            op = "PlayVideo",
            viewType = videoViewType,
            question = self.question,
            callback = function(res)
                self.isPlaying = false
                if self.outTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                    self.outTimeCoroutine = nil
                end
                --播放完成--隐藏video视图
                self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", { op = "hide" })
                --异常上报
                if res.status == "error" then
                    self:_reportData("外教引导视频播放失败",
                        { url = audio, text_en = self.question.text_en, id = self.question.id }, "1")
                end
                callBack()
            end
        })
        --超时兜底
        if self.outTimeCoroutine then
            self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
            self.outTimeCoroutine = nil
        end
        self.outTimeCoroutine = self.commonService:StartCoroutine(function()
            self.commonService:YieldSeconds(8)
            if self.isPlaying then
                self.isPlaying = false
                self:_reportData("播放音频超时", { url = audio, text_en = self.question.text_en, id = self.question.id }, "1")
                callBack()
            end
        end)
    else
        self.isPlaying = true
        local audio = self.question.audio
        local audioClip = self.question.audioClip
        if audioClip then
            self.audioSource = self.audioService:PlayClipOneShot(audioClip, function()
                if self.outTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                    self.outTimeCoroutine = nil
                end
                if not self.isPlaying then
                    return
                end
                self.isPlaying = false
                callBack()
            end)
        else
            self.audioService:GetMp3AudioFromGetUrl(audio, function()
                self.isPlaying = false
                if self.outTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                    self.outTimeCoroutine = nil
                end
                callBack()
                self:_reportData("下载音频失败", { url = audio, text_en = self.question.text_en, id = self.question.id }, "0")
            end, function(clip)
                if self.outTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                    self.outTimeCoroutine = nil
                end
                self.question.audioClip = clip
                self:playFirstSound(noLeadReading, callBack)
            end)
        end
        if self.outTimeCoroutine then
            self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
            self.outTimeCoroutine = nil
        end
        self.outTimeCoroutine = self.commonService:StartCoroutine(function()
            self.commonService:YieldSeconds(8)
            if self.isPlaying then
                self.isPlaying = false
                if self.audioSource then
                    self.audioService:StopAudioSource(self.audioSource)
                end
                self:_reportData("播放音频超时", { url = audio, text_en = self.question.text_en, id = self.question.id }, "1")
                callBack()
            end
        end)
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function QuestionPanel:ReceiveMessage(key, value, isResume)

end

function QuestionPanel:cancelAnswer()
    self.isAnswer = false
    self.questionPanel.gameObject:SetActive(false)
    if self.grayJoyId then
        self.joystickService:setGrayVisibleJoyWithID(self.grayJoyId)
        self.grayJoyId = nil
    end
    if self.evaInfo and not self.evaInfo.noChangeChat then
        APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
            open = true,
            isShow = true
        }, function()

        end)
    end

    --取消视频领读UI
    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", { op = "stop" })

    if self.audioSource then
        self.audioService:StopAudioSource(self.audioSource)
    end
    self.observerService:Fire(EVENT_ABCZONE_ALL_MUSIC_VOLUME, { mute = false })
    -- self.observerService:Fire(EVENT_EVALUATION_AND_RECOGNITION_SERVICE, {
    --     action = "cancel"
    -- })
    self.speechAssessmentBusiness:CancelAssessment()
end

function QuestionPanel:startAnswer(noLeadReading, businessCallBack)
    if self.reTryCount < 0 then
        self:cancelAnswer()
        return
    end
    self.isAnswer = true
    self.observerService:Fire(EVENT_ABCZONE_ALL_MUSIC_VOLUME, { mute = true })
    if not self.evaInfo.noChangeChat then
        APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
            open = false,
            isShow = false
        }, function()

        end)
    end

    if self.grayJoyId then
        self.joystickService:setGrayVisibleJoyWithID(self.grayJoyId)
    end
    if not self.evaInfo.notSetJoy then
        self.grayJoyId = self.joystickService:setGrayJoyWithID()
    end

    -- if self.questionIndex > #self.questionList then
    --     self.questionIndex = 1
    -- end
    if self.transQuestion then
        self.question = self.transQuestion
        self:_doAnswer(noLeadReading, businessCallBack)
        return
    end
    self.observerService:Fire("EVENT_ABCZONE_QUESTION_MANATER", {
        params = { { qType = 51, qCount = 1 } },
        callBack = function(question)
            if self.businessConflict or not self.isAnswer then
                self.questionPanel.gameObject:SetActive(false)
                return
            end
            -- local question = self.questionList[self.questionIndex]
            question = question["51"][1]
            self.question = question
            g_Log(TAG, table.dump(question))
            ---数据错误重新取题
            if not self.question.text_en or self.question.text_en == "" then
                self:startAnswer(noLeadReading, businessCallBack)
                return
            end
            self:_doAnswer(noLeadReading, businessCallBack)
        end
    })
end

function QuestionPanel:_doAnswer(noLeadReading, businessCallBack)
    -- if self.delayAddJewelCoroutine then
    --     self.commonService:StopCoroutineSafely(self.delayAddJewelCoroutine)
    --     self.delayAddJewelCoroutine = nil
    -- end
    if self.question.activeQuestionType == 1 then
        if self.question.style == 52 then
            self:_setReadBookView()
        else
            self:_setSentenceView()
        end
    else
        self:_setQuestionView()
    end
    self:playFirstSound(noLeadReading, function()
        if self.businessConflict or not self.isAnswer then
            self.questionPanel.gameObject:SetActive(false)
            return
        end

        local showAwardType = self.evaInfo.showAwardType
        local petExp = 1
        if showAwardType == 5 then
            petExp = 2
        end
        local showResult = true
        if self.evaInfo.showResult == false then
            showResult = false
        end
        local questionStyle = "51"
        if self.question.style == 52 then
            self.evaInfo.showAwardType = 14
            showAwardType = 14
            questionStyle = "52"
        end
        local params = {
            action = "start",
            serviceType = "evaAndRect",
            showMicView = true,
            preserveType = showAwardType,
            questionStyle = questionStyle,
            awardCount = self.evaInfo.awardCount,
            questionId = self.question.id,
            text_cn = self.question.text_cn,
            text_en = self.question.text_en,
            passBy = self.question.passBy,
            countdown = 10,
            passScore = self.passScore,
            showResult = showResult,
            reTryCount = self.reTryCount,
            isShowAudio = true,
            audioClickCallback = self.audioClickCallback,
            reSpeakClickCallback = self.reSpeakClickCallback,
            isShowStop = true,
            showAwardType = showAwardType,
            petExp = petExp,
            passText = self.passText,
            notpassText = self.notpassText,
            micRect = self.evaInfo.micRect,
            fightingTipType = 2,
            callBack = function(score, isFinal, isNoSpeaking)
                local hasCallBack = false
                if isFinal then
                    self.transQuestion = nil
                    self.observerService:Fire(EVENT_ABCZONE_ALL_MUSIC_VOLUME, { mute = false })
                    if self.grayJoyId then
                        self.joystickService:setGrayVisibleJoyWithID(self.grayJoyId)
                        self.grayJoyId = nil
                    end
                    if not self.evaInfo.noChangeChat then
                        APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
                            open = true,
                            isShow = true
                        }, function()

                        end)
                    end
                    self.reTryCount = self.reTryCount - 1
                    self.questionPanel.gameObject:SetActive(false)
                else
                    self.reTryCount = self.reTryCount - 1
                end
                -- if businessCallBack and not hasCallBack then
                if businessCallBack then
                    businessCallBack(score, isFinal, isNoSpeaking, score >= self.passScore)
                end
                ---用于切换下一题
                self.observerService:Fire("change_next_question", {
                    score = score,
                    isFinal = isFinal,
                    isNoSpeaking = isNoSpeaking,
                    isPass = score >= self.passScore,
                    isReadBook = showAwardType == 14
                })
            end,
            stepCallBack = function(step)

            end
        }
        for k, v in pairs(self.evaInfo) do
            params[k] = v
        end
        self.speechAssessmentBusiness:StartAssessment(params, params.callBack)

        -- self.observerService:Fire(EVENT_EVALUATION_AND_RECOGNITION_SERVICE, params)
    end)
end

function QuestionPanel:_setQuestionView()
    self.readBookPanelBg.gameObject:SetActive(false)
    self.sentencePanelBg.gameObject:SetActive(false)
    self.senText.gameObject:SetActive(true)
    local keyWord = self.question.word
    local indexArray = self.question.indexArray
    local text_en = ""
    if indexArray then
        if type(indexArray) == 'string' then
            indexArray = self.jsonService:decode(indexArray)
        end
        if indexArray and type(indexArray) == 'table' then
            text_en = self:GetKeyWordTextByIndex(self.question.text_en, indexArray)
        end
    end
    if (not text_en) or text_en == "" then
        -- g_Log(TAG, self.question.text_en, keyWord)
        text_en = self:GetKeyWordText(self.question.text_en, keyWord)
    end
    self.senTextTmp.text = "<b>" .. text_en ..
        "</b>" .. "<br><size=28><color=#666666>" .. self.question.text_cn ..
        "</color></size>"
    -- self.panelRect.anchoredPosition = CS.UnityEngine.Vector2(self.panelRect.anchoredPosition.x, 251)
    -- end
    if self.question.level_name and self.bookName then
        self.questionFrom.gameObject:SetActive(true)
        self.questionFromDetailTmp.text = " " .. self.bookName .. " " .. self.question.level_name
        self.uiGap = 46
    end
    -- self.question.contentTag = "祈使句"
    local tagGap = 0
    if (self.question.contentTag and self.question.contentTag ~= "") or (self.question.tenseTag and self.question.tenseTag ~= "") or (self.showDeepSeekTag and self.deepseekTag) then
        self.questionTagRoot.gameObject:SetActive(true)
        self.senTextRect.anchoredPosition = Vector2(0, -114)
        tagGap = 40
        if (self.question.contentTag and self.question.contentTag ~= "") then
            self.spContentTmp.text = self.question.contentTag
            self.sentencePattern.gameObject:SetActive(true)
        else
            self.sentencePattern.gameObject:SetActive(false)
        end
        if (self.question.tenseTag and self.question.tenseTag ~= "") then
            self.tenseContentTmp.text = self.question.tenseTag
            self.tense.gameObject:SetActive(true)
        else
            self.tense.gameObject:SetActive(false)
        end
    else
        self.questionTagRoot.gameObject:SetActive(false)
        self.senTextRect.anchoredPosition = Vector2(0, -74)
    end
    self.questionPanel.gameObject:SetActive(true)
    self.questionFromRect.sizeDelta = Vector2(self.questionFromDetailTmp.preferredWidth + self.fromViewGap,
        self.questionFromRect.sizeDelta.y)
    self.panelRect.sizeDelta = CS.UnityEngine.Vector2(688,
        self.senTextTmp.preferredHeight + 108 + self.uiGap + tagGap)
    if (self.question.tenseTag and self.question.tenseTag ~= "") then
        self.tenseRect.sizeDelta = Vector2(self.tenseContentTmp.preferredWidth + 32, self.tenseRect.sizeDelta.y)
    end
    if (self.question.contentTag and self.question.contentTag ~= "") then
        self.spRect.sizeDelta = Vector2(self.spContentTmp.preferredWidth + 32, self.spRect.sizeDelta.y)
    end
    if self.avatar.bookType then
        self:SetBookTypeImage(self.avatar.bookType)
    end
end

function QuestionPanel:_setSentenceView()
    self:_setQuestionView()
    self.sentencePanelBg.gameObject:SetActive(true)
end

function QuestionPanel:_setReadBookView()
    self.readBookPanelBg.gameObject:SetActive(true)
    self.sentencePanelBg.gameObject:SetActive(false)
    self.senText.gameObject:SetActive(false)
    self.questionTagRoot.gameObject:SetActive(false)
    self.transTag.gameObject:SetActive(self.lastRewardCount > 0)
    self.transZuanShi.gameObject:SetActive(self.lastRewardCount > 0)
    local keyWord = self.question.word
    local indexArray = self.question.indexArray
    local text_en = ""
    if indexArray then
        if type(indexArray) == 'string' then
            indexArray = self.jsonService:decode(indexArray)
        end
        local froStr, endStr = self:GetKeyWordTextByIndex3(self.question.display, indexArray)
        if not froStr or not endStr then
            froStr, endStr = self:GetKeyWordText1(self.question.display, self.question.text_en)
        end
        self.rbContentEnPre.gameObject:SetActive(true)
        self.rbContentEnLast.gameObject:SetActive(true)
        self.rbContentEnPreTmp.text = froStr
        self.rbContentEnLastTmp.text = endStr
    end
    self.rbContentEnTmp.text = self.question.text_en
    self.rbContentCnTmp.text = self.question.text_cn

    if self.question.level_name and self.bookName then
        self.questionFrom.gameObject:SetActive(true)
        self.questionFromDetailTmp.text = " " .. self.bookName .. " " .. self.question.level_name
        self.uiGap = 46
    end

    self.questionPanel.gameObject:SetActive(true)
    self.questionFromRect.sizeDelta = Vector2(self.questionFromDetailTmp.preferredWidth + self.fromViewGap,
        self.questionFromRect.sizeDelta.y)

    local enPreferredWidth = self.rbContentEnTmp.preferredWidth
    local enContentGap = 88
    if enPreferredWidth <= 600 then
        self.rbContentCnRect.sizeDelta = Vector2(600, self.rbContentCnRect.sizeDelta.y)
        local contentPreORLastWidth = (600 - enPreferredWidth) / 2
        self.rbContentEnPreRect.sizeDelta = Vector2(contentPreORLastWidth, self.rbContentEnPreRect.sizeDelta.y)
        self.rbContentEnLastRect.sizeDelta = Vector2(contentPreORLastWidth, self.rbContentEnLastRect.sizeDelta.y)
        self.panelRect.sizeDelta = CS.UnityEngine.Vector2(688,
            self.rbContentCnTmp.preferredHeight + 200 + self.uiGap)
    else
        self.rbContentCnRect.sizeDelta = Vector2(enPreferredWidth, self.rbContentCnRect.sizeDelta.y)
        self.rbContentEnPreRect.sizeDelta = Vector2(0, self.rbContentEnPreRect.sizeDelta.y)
        self.rbContentEnLastRect.sizeDelta = Vector2(0, self.rbContentEnLastRect.sizeDelta.y)
        self.panelRect.sizeDelta = CS.UnityEngine.Vector2(enPreferredWidth + enContentGap,
            self.rbContentCnTmp.preferredHeight + 200 + self.uiGap)
    end

    if self.avatar.bookType then
        self:SetBookTypeImage(self.avatar.bookType)
    end
end

function QuestionPanel:GetKeyWordTextByIndex(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then return text end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                else
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#2D6EFF>" .. middleStr .. "</color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return text
end

function QuestionPanel:GetKeyWordTextByIndex3(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then return nil, nil end
    if not index[1] then return nil, nil end
    local index1 = index[1]

    local startIndex = index1[1]
    local endIndex = index1[2]
    local frontStr = ""

    if startIndex > 0 then
        frontStr = string.sub(text, 1, startIndex)
    end

    --- 对frontStr 反转
    local frontStrReverse = string.reverse(frontStr)
    local endStr = ""
    if endIndex + 2 <= #text then
        endStr = string.sub(text, endIndex + 2, #text)
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return frontStrReverse, endStr
end

-- 处理对应重点单词文字
function QuestionPanel:GetKeyWordText(text, word)
    if not text and not word then return "" end
    if not word or word == "" then return text end
    for keyWord in string.gmatch(word, "%w+") do
        local keyWordLower = keyWord:lower()
        local lowerText = text:lower()
        local startIndex, endIndex = string.find(lowerText, keyWordLower)
        if startIndex and endIndex then
            -- local key = string.sub(text, startIndex, endIndex)
            -- g_Log(TAG, "使用关键词高亮显示"..keyWord)
            text = text:gsub('(%f[%a]' .. keyWord .. '[%p]*%f[^%a])', "<color=#2D6EFF>" .. keyWord .. "</color>")
        end
    end
    -- 替换所有出现的关键词
    return text
end

function QuestionPanel:GetKeyWordText1(text, word)
    if not text and not word then return "", "" end
    if not word or word == "" then return "", "" end
    if not text or text == "" then return "", "" end
    local startIndex, endIndex = string.find(text, word)
    local frontStr = ""
    local endStr = ""
    if startIndex and startIndex > 1 then
        frontStr = string.sub(text, 1, startIndex - 1)
    end
    local frontStrReverse = string.reverse(frontStr)
    if endIndex and endIndex + 1 <= #text then
        endStr = string.sub(text, endIndex + 1, #text)
    end
    -- 替换所有出现的关键词
    return frontStrReverse, endStr
end

function QuestionPanel:test()
    self.questionList = {
        {
            audio = "https://static0.xesimg.com/next-studio-pub/englishTTS/ttsWords/tts_20230707200827_110820_16.mp3",
            id = "4722",
            text_cn = "他们说英文和中文。",
            text_en = "They speak English and Chinese."
        },
        {
            audio = "https://static0.xesimg.com/next-studio-pub/englishTTS/ttsWords/tts_20230707200727_916551_619.mp3",
            id = "4645",
            text_cn = "对，她是一个老师。",
            text_en = "Yes, she is a teacher."
        },
        {
            audio = "https://static0.xesimg.com/next-studio-pub/englishTTS/ttsWords/tts_20230707200717_482615_439.mp3",
            id = "4631",
            text_cn = "更多还是更少？",
            text_en = "More or less?"
        },
        {
            audio = "https://static0.xesimg.com/next-studio-pub/englishTTS/ttsWords/tts_20230707200613_251739_86.mp3",
            id = "4593",
            text_cn = "你喜欢中文。",
            text_en = "You like Chinese."
        },
        {
            audio = "https://static0.xesimg.com/next-studio-pub/englishTTS/ttsWords/tts_20230707200712_423501_98.mp3",
            id = "4625",
            text_cn = "秋天很冷。",
            text_en = "Fall is cold."
        },
        {
            audio = "https://static0.xesimg.com/next-studio-pub/englishTTS/ttsWords/tts_20230707200710_737979_876.mp3",
            id = "4623",
            text_cn = "冷水",
            text_en = "cold water"
        },
        {
            audio = "https://static0.xesimg.com/next-studio-pub/englishTTS/ttsWords/tts_20230707200617_996575_841.mp3",
            id = "4598",
            text_cn = "我的房子",
            text_en = "my house"
        },
        {
            audio = "https://static0.xesimg.com/next-studio-pub/englishTTS/ttsWords/tts_20230707200731_733274_233.mp3",
            id = "4650",
            text_cn = "我是一个学生。",
            text_en = "I am a student."
        }

    }
    self:randomQuestions()

    -- self.propButton = self.canvasTrans:FindChildWithName("道具按钮")
    -- self.propDoBtn = self.propButton:GetComponent(typeof(CS.UnityEngine.UI.Button))
    -- self.propDoText = self.propButton:FindChildWithName("文本属性"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    -- self.commonService:AddEventListener(self.propDoBtn, "onClick", function()
    --     if self.evaInfo then
    --         local count = self.evaInfo.count
    --         if count > 0 then
    --             self:doPropAction()
    --         end
    --         self.evaInfo.count = self.evaInfo.count - 1
    --         self.propDoText.text = "使用道具 x" .. self.evaInfo.count
    --         if self.evaInfo.count == 0 then
    --             self.observerService:Fire("EVENT_HOLD_PROP_BY_ID", {
    --                 propId = tonumber(self.holdPropId),
    --                 holdState = 0
    --             })
    --             self.holdPropId = nil
    --             self.evaInfo = nil
    --             self:showOrHidePropBtn(false)
    --         end
    --     end
    -- end)
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function QuestionPanel:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionPanel:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionPanel:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionPanel:AvatarCreated(avatar)
end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function QuestionPanel:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function QuestionPanel:LogicMapStartRecover()
    QuestionPanel.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function QuestionPanel:LogicMapEndRecover()
    QuestionPanel.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function QuestionPanel:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

-- 收到Trigger事件
function QuestionPanel:OnReceiveTriggerEvent(interfaceId)

end

-- 收到GetData事件
function QuestionPanel:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------


function QuestionPanel:_reportData(label, value, action)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("evaluation_panel", "82032", "Special-Interaction",
            label, action, value)
    end
end

-- 脚本释放
function QuestionPanel:Exit()
    QuestionPanel.super.Exit(self)
end

return QuestionPanel
