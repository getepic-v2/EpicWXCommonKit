---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2025-03-04 15:34:40】
--- 【FSync】
--- 【题目来源左侧UI】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

--题目来源右侧展示UI 素材id:126410
local uAddress = "977751741165481/assets/Prefabs/Canvas.prefab"
local picPath  = "?x-oss-process=image/resize,w_152,h_211/quality,q_80"
---@class Question_Source_Left : WorldBaseElement
local Question_Source_Left = class("Question_Source_Left", WBElement)

function Question_Source_Left:Print(...)
    g_Log("【题目来源左侧UI】", ...)
end

---@param worldElement CS.Tal.framesync.WorldElement
function Question_Source_Left:initialize(worldElement)
    Question_Source_Left.super.initialize(self, worldElement)
    self.domain = "https://app.chuangjing.com/abc-api"
    self.root = self.VisElement.gameObject
    self.panelUI = nil
    self.isInitBookInfo = false
    self.article_info = {}
    self:RegisterDownloadUaddress(uAddress)

    self:InitService()
    self:InitListener()
end

function Question_Source_Left:InitService()
    ---@type CommonService
    self.commonService            = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService              = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService              = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService          = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService            = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService             = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService                = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService            = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService             = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService          = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService             = CourseEnv.ServicesManager:GetDebugService()

    self.gate                     = CourseEnv.ServicesManager.Gate
    self.businessConflictService  = CourseEnv.ServicesManager:GetBusinessConflictService()
    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

function Question_Source_Left:IsAbUser()

    if App.IsStudioClient then
        return false
    end

    local userId = tostring(App.Info.userId)
    --判断userId尾号是否是0-4
    local lastChar = userId:sub(-1)
    local lastNum = tonumber(lastChar)

    if lastNum and lastNum > 4 then
        return false
    end

    local key = "NewUser_CreateTime"..App.Info.userId
    local registerTime = CS.UnityEngine.PlayerPrefs.GetString(key)
    if registerTime then
        --判断下registerTime是今天，晚上12点以前
        local nowTime = os.time()
        local registerTime = tonumber(registerTime)
        
        -- 获取当前日期的年月日
        local nowDate = os.date("*t", nowTime)
        -- 获取注册时间的年月日
        local regDate = os.date("*t", registerTime)
        
        -- 判断是否是同一天
        if nowDate.year ~= regDate.year or nowDate.month ~= regDate.month or nowDate.day ~= regDate.day then
            return false
        end

    end
    return true
end

function Question_Source_Left:InitListener()
    --更新题目来源UI
    self.observerService:Watch("QUESTION_SOURCE_LEFT_UPDATA_QUESTION", function(event, value)
        local data = value[0]
        local question = data.question

        --TODO判断一下 是否ab的用户 否则不展示
        -- if self:IsAbUser() then
        --     return
        -- end
        self:ShowPanel(function()
        self:InitBookInfo(function()
                self:RefreshUI(question)    
            end)
        end)
    end)

    --设置题目来源UI显示隐藏
     self.observerService:Watch("QUESTION_SOURCE_LEFT_SHOW", function(event, value)
        local data = value[0]
        local show = data.show
        if self.panelUI then
            self.panelUI.gameObject:SetActive(show)
        end
    end)

    -- 适配家园添加左侧UI位置控制逻辑begin
    self.observerService:Watch("QUESTION_SOURCE_LEFT_SET_UI_OFFSET", function(event, value)
        local data = value[0]
        self.xOffset = data.xOffset
        self.yOffset = data.yOffset
        if self.panelUI and self.oriAnchoredPosition then
            local rect = self.panelUI:Find("Panel"):GetComponent(typeof(CS.UnityEngine.RectTransform))
            rect.anchoredPosition = Vector2(self.oriAnchoredPosition.x + self.xOffset, self.oriAnchoredPosition.y + self.yOffset)
        end
    end)
    -- 适配家园添加左侧UI位置控制逻辑end
end

--显示督促弹窗
function Question_Source_Left:ShowPanel(callback)
    if not self.panelUI then
        self:LoadRemoteUaddress(uAddress, function(success, prefab)
            if success and prefab then
                self.panelUI = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
                -- 适配家园添加左侧UI位置控制逻辑begin
                local rect = self.panelUI:Find("Panel"):GetComponent(typeof(CS.UnityEngine.RectTransform))
                self.oriAnchoredPosition = rect.anchoredPosition
                if self.xOffset and self.yOffset then
                    rect.anchoredPosition = Vector2(self.oriAnchoredPosition.x + self.xOffset, self.oriAnchoredPosition.y + self.yOffset)
                end
                -- 适配家园添加左侧UI位置控制逻辑end
                self:InitUIComponent()
                self.panelUI.gameObject:SetActive(true)
                if callback then
                    callback()
                end
            end
        end)
    else
        self.panelUI.gameObject:SetActive(true)
        if callback then
            callback()
        end
    end
end

--初始化UI
function Question_Source_Left:InitUIComponent()
    local canvas = self.panelUI:GetComponent(typeof(CS.UnityEngine.Canvas))
    canvas.sortingOrder = 1000
    self.panelUI.gameObject:SetActive(false)
    --教材-学习单元
    self.textbook_lab = self.panelUI:Find("Panel/textbook_lab").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    --教材图片
    self.cover = self.panelUI:Find("Panel/cover").gameObject
    --句子模式节点
    self.sentence_Node = self.panelUI:Find("Panel/sentence_Node").gameObject
    --句子模式图片
    self.sentence_count_lab = self.panelUI:Find("Panel/sentence_Node/count_lab").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    --课文模式节点
    self.text_Node = self.panelUI:Find("Panel/text_Node").gameObject
    --课文模式图片
    self.text_count_lab = self.panelUI:Find("Panel/text_Node/count_lab").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
end

--关闭UI
function Question_Source_Left:ClosePanel()
    if self.panelUI then
        self.panelUI.gameObject:SetActive(false)
    end
end

--初始化教材信息
function Question_Source_Left:InitBookInfo(callback)
    if self.isInitBookInfo then
        if callback then
            callback()
        end
        return
    end
    self:GetUserStudyModeStatus(function(data)
        self:Print("教材信息", data)
        self.isInitBookInfo = true
        self.article_info = data.article_info
        self.book_cover = data.book_cover
        self.textbook_lab.text = data.book_name .. "\n" .. data.level_name
        self.sentence_count_lab.text = data.sen_count .. "句"
        self.text_count_lab.text = data.sen_count .. "句"
        if callback then
            callback()
        end
    end)
end

--刷新UI
function Question_Source_Left:RefreshUI(question)
    local style_id = question.style_id
    local coverImage = self.book_cover
    
    -- -- 课文模式下查找对应图片
    -- if style_id == 52 then
    --     local paragraph_rects = question.paragraph_rects   
    --     if paragraph_rects and paragraph_rects[1] then
    --         local page = paragraph_rects[1].page
    --         if page then
    --             for _, info in ipairs(self.article_info) do
    --                 if info.page == page then
    --                     coverImage = info.image
    --                     break
    --                 end
    --             end
    --         end
    --     end
    -- end

    -- 根据最终的 style_id 设置显示状态
    self.sentence_Node.gameObject:SetActive(style_id == 51)
    self.text_Node.gameObject:SetActive(style_id == 52)

    -- 检查图片是否需要更新
    if not self.last_cover_image or self.last_cover_image ~= coverImage then
        local image = self.cover:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.httpService:LoadNetWorkTexture(coverImage .. picPath, function(sprite)
            if sprite then
                image.sprite = sprite
                self.last_cover_image = coverImage
            end
        end, "QUESTION_SOURCE_LEFT_COVER")
    end
end

--查询用户模式用到的状态信息
function Question_Source_Left:GetUserStudyModeStatus(callBack)
    local url = self.domain .. "/v3/book-article/get-mode-status"
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041/v3/book-article/get-mode-status"
    end

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                if msg.data then
                    callBack(msg.data)
                end
            end
        end
    end

    local fail = function(err)
        if not err then
            err = ""
        end
        if type(err) == "table" then
            err = table.dump(err)
        end
        callBack(nil)
    end
    self:_HttpRequest(url, {}, success, fail)
end

--http请求
function Question_Source_Left:_HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function Question_Source_Left:ReceiveMessage(key, value, isResume)

end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function Question_Source_Left:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function Question_Source_Left:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function Question_Source_Left:SelfAvatarPrefabLoaded(avatar)
    --自己的人物模型加载完成
    self.selfAvatarLoaded = true
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function Question_Source_Left:AvatarCreated(avatar)
end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function Question_Source_Left:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function Question_Source_Left:LogicMapStartRecover()
    Question_Source_Left.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function Question_Source_Left:LogicMapEndRecover()
    Question_Source_Left.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function Question_Source_Left:LogicMapAllComponentRecoverComplete()
    self.allComponentRecover = true
end

-- 收到Trigger事件
function Question_Source_Left:OnReceiveTriggerEvent(interfaceId)

end

-- 收到GetData事件
function Question_Source_Left:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------
-- function Question_Source_Left:Tick()

-- end

-- 脚本释放
function Question_Source_Left:Exit()
    Question_Source_Left.super.Exit(self)
end

return Question_Source_Left
