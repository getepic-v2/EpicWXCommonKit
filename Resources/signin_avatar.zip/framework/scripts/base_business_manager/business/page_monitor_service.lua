---
--- Author: 【王德】
---  AuthorID: 【102030】
--- CreateTime: 【2024-03-21 10:00:00】
--- 页面性能监控服务
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class PageMonitorService : WorldBaseElement
local PageMonitorService = class("PageMonitorService", WBElement)

-- 页面性能数据记录
local pagePerformanceMap = {}

---@param worldElement CS.Tal.framesync.WorldElement
function PageMonitorService:initialize(worldElement)
    PageMonitorService.super.initialize(self, worldElement)
    self.eventPrefix = "PAGE_MONITOR"
    self.monitorService = App:GetService("MonitorService")
    self.commonService = App:GetService("CommonService")
end

--- 记录页面打开
---@param pageId string 页面ID
---@param pageName string 页面名称
function PageMonitorService:recordPageOpen(pageId, pageName)
    -- 记录页面打开时间
    local startTime = os.clock()
    if not pagePerformanceMap[pageId] then
        pagePerformanceMap[pageId] = {}
    end
    pagePerformanceMap[pageId].startTime = startTime
    pagePerformanceMap[pageId].pageName = pageName
    pagePerformanceMap[pageId].usedMemory = self.monitorService:GetLastUserMemory()
    local param_two = 0
    if pagePerformanceMap[pageId].usedMemory > 0 then
        param_two = math.floor(pagePerformanceMap[pageId].usedMemory * 10) / 10
    end
    local avgFps = self.monitorService:GetAvgFPS()
    local param_three = 0
    if avgFps > 0 then
        param_three = math.floor(avgFps * 10) / 10
    end
    local extraParams =
    {
        param_two = param_two,
        param_three = param_three,
        action = pageName
    }
    self:_reportData(self.eventPrefix .. "_OPEN", pageId, pageName, extraParams)
end

--- 记录页面加载完成
---@param pageId string 页面ID
function PageMonitorService:recordPageLoadComplete(pageId)
    if not pagePerformanceMap[pageId] then
        return
    end

    local endTime = os.clock()
    local startTime = pagePerformanceMap[pageId].startTime
    local pageName = pagePerformanceMap[pageId].pageName
    local usedMemory = pagePerformanceMap[pageId].usedMemory
    local costTime = math.floor((endTime - startTime) * 1000)
    local avgFps = self.monitorService:GetAvgFPS()
    local param_three = 0
    if avgFps > 0 then
        param_three = math.floor(avgFps * 10) / 10
    end
    -- 延迟1秒上报 用于取到最新的内存和fps
    self.commonService:DispatchAfter(1, function()
        local param_two = 0
        if usedMemory > 0 then
            param_two = math.floor((self.monitorService:GetLastUserMemory() - usedMemory) * 10) / 10
        end
        local extraParams =
        {
            param_two = param_two,
            param_three = param_three,
            action = costTime,
        }
        self:_reportData(self.eventPrefix .. "_OPEN_COMPLETE", pageId, pageName, extraParams)
    end)
end

--- 记录页面关闭
---@param pageId string 页面ID
function PageMonitorService:recordPageClose(pageId)
    if not pagePerformanceMap[pageId] then
        return
    end
    local endTime = os.clock()
    local startTime = pagePerformanceMap[pageId].startTime
    local pageName = pagePerformanceMap[pageId].pageName
    local usedMemory = pagePerformanceMap[pageId].usedMemory
    local costTime = math.floor((endTime - startTime) * 1000)
    local avgFps = self.monitorService:GetAvgFPS()
    local param_three = 0
    if avgFps > 0 then
        param_three = math.floor(avgFps * 10) / 10
    end
    --关闭后延迟1秒上报 用于取到最新的内存和fps
    self.commonService:DispatchAfter(2, function()
        local param_two = 0
        if usedMemory > 0 then
            param_two = math.floor((self.monitorService:GetLastUserMemory() - usedMemory) * 10) / 10
        end
        local extraParams =
        {
            param_two = param_two,
            param_three = param_three,
            action = costTime,
        }
        self:_reportData(self.eventPrefix .. "_CLOSE", pageId, pageName, extraParams)
        pagePerformanceMap[pageId] = nil
    end)
end

-- 私有方法：上报页面PV
function PageMonitorService:_reportData(eventId, pageId, pageName, extraParams)
    local params = {
        category = pageName,
        param_one = pageId
    }
    if extraParams then
        for k, v in pairs(extraParams) do
            params[k] = tostring(v)
        end
    end
    LogBridge.SNoStatisticsWithParam(eventId, params)
end

return PageMonitorService
