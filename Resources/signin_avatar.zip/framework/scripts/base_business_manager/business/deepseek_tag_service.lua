local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class DeepSeekTagService : WorldBaseElement
local DeepSeekTagService = class("DeepSeekTagService", WBElement)

function DeepSeekTagService:initialize(worldElement)
    DeepSeekTagService.super.initialize(self, worldElement)
    self.imageList = {}
    self:RequestImages()
    self:Watch("EVENT_ABCZONE_DEEPSEEK_TAG_SERVICE", function(key, value)
        local data = value[0]
        if self.isShow ~= nil then
            if data.callBack ~= nil then
                data.callBack(self.isShow, self.imageList)
            end
        else
            self.commonService:StartCoroutine(function()
                self.commonService:Yield(self.commonService:WaitUntil(function()
                    return self.isShow ~= nil
                end))
                if data.callBack ~= nil then
                    data.callBack(self.isShow, self.imageList)
                end
            end)
        end
    end)
end

function DeepSeekTagService:RequestImages()
    -- "is_show": true, // 是否展示
    -- "ds_chuti_img": "https://static0.xesimg.com/next-app/abc-zone/ds_chuti.png", // 智能出题
    -- "ds_cuoti_img": "https://static0.xesimg.com/next-app/abc-zone/ds_cuoti.png", // 智能错题推荐
    -- "ds_wenda_img": "https://static0.xesimg.com/next-app/abc-zone/ds_wenda.png", // 智能问答
    -- "ds_bubble_img": "https://static0.xesimg.com/next-app/abc-zone/ds_bubble.png", // deepseek气泡
    -- "ds_bubble_wenda_img": "https://static0.xesimg.com/next-app/abc-zone/ds_bubble_wenda.png", // deepseek智能问答气泡
    -- "ds_bubble_study_img": "https://static0.xesimg.com/next-app/abc-zone/ds_bubble_xuexi.png" // deepseek智能学习气泡
    self.httpService:HttpRequest("/v3/common/get-ds-img", {}, function(res)
        if res and res ~= "" then
            local msg = nil
            if type(res) == "string" then
                msg = self.jsonService:decode(res)
            else
                msg = res
            end
            if msg and msg.code == 0 then
                self.imageList = msg.data
                self.isShow = msg.data.is_show
            end
        end
    end, function(err)

    end)
end

return DeepSeekTagService
