---
---  Author: 【王德】
---  AuthorID: 【102030】
---  CreateTime: 【2023-5-31 15:55:34】
--- 【FSync】
--- 【纠音评测服务】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class SpeechAssessmentBusiness : WorldBaseElement
local SpeechAssessmentBusiness = class("SpeechAssessmentBusiness", WBElement)

---@type CS.UnityEngine.UI.Button
local Button = CS.UnityEngine.UI.Button
---@type CS.UnityEngine.PlayerPrefs
local PlayerPrefs = CS.UnityEngine.PlayerPrefs
---@type CS.UnityEngine.UI.Text
local Text = CS.UnityEngine.UI.Text
local EVENT_EVALUATION_AND_RECOGNITION_SERVICE = "EVENT_EVALUATION_AND_RECOGNITION_SERVICE"
local EVENT_NOTICE_OTHER_EVALUATION_STATUS = "EVENT_NOTICE_OTHER_EVALUATION_STATUS"

--答题上报需要上报是否是邀请者或者被邀请关系 --邀请用户id通过remote启动消息传过来
local fsync_activateRoom = "activateRoom"

local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/speech_assessment/"
local micPrefabPath = ResourcePathRoot .. "assessmentMic/assets/Prefabs/shuohua.prefab"
local resultPrefabPath = ResourcePathRoot .. "assessmentResult/assets/Prefabs/jiuyin-cheese.prefab"
local picturePathRoot = ResourcePathRoot .. "picture/"
local audioPathRoot = ResourcePathRoot .. "audio/"

local preserveTypes = {
    game = 2,
    npc = 3,
    cheese = 4,
    petFood = 5,
    jump = 6,
    prop = 7,
    ferrisWheel = 8,
    petPk = 9,
    camp = 10,
    campus = 11,
    worldBoss = 12,
    home = 13,
    readBook = 14,
    homeEnergy = 15
}

---@param worldElement CS.Tal.framesync.WorldElement
function SpeechAssessmentBusiness:initialize(worldElement)
    SpeechAssessmentBusiness.super.initialize(self, worldElement)
    self:SubscribeMsgKey(fsync_activateRoom)
    local appVersion = App.Info.appVersionNumber
    if appVersion then
        if tonumber(appVersion) >= 10300 then
            self.useTotalScore = true
        end
    end
    self.evaIndex = 0
    self.game_id = 0
    local game_id = App.Info.configMap.game_id
    if game_id then
        self.game_id = tonumber(game_id)
    end
    self.isInvite = false
    self:_InitService()
    self:_InitVar()
    self:_InitConfig()
    self:_InitView()
    self:_InitListener()

    self.observerService:Watch("unity.api.page.show", function()
        if self.noAuth then
            local platform = CS.UnityEngine.Application.platform
            if platform == CS.UnityEngine.RuntimePlatform.Android and tonumber(appVersion) < 10809 then
                self:_checkAuth()
            end
        end
    end)
end

-----------------------------------------------对外提供的调用方法-------------------------------------------------

---开始语音评测
function SpeechAssessmentBusiness:StartAssessment(param, callback)
    self.isPlayAudio = false
    self.noSpeaking = true
    self.isCancel = false
    self.isStop = false
    self.isReTry = false
    self.preserveType = param.preserveType or
        2                                --2 小游戏 ，3 npc对话 ，4芝士 ，5 宠物饲料 6 跳一跳，7道具互动，8摩天轮 9 宠物pk 10 阵营活动 11校园争霸 12 世界boss 13家园 14 读课文 15家园能量条
    self.serviceType = param.serviceType --evaAndRect 测评和识别发到聊天区  / eva 只进行测评
    self.showMicView = param.showMicView --是否显示麦克风动效
    self.isShowStop = param.isShowStop   --是否显示手动截停按钮
    if self.showMicView == nil then
        self.showMicView = true
    end
    self.passText = param.passText
    self.notPassText = param.notPassText

    local micRect = param.micRect

    if self.showMicView and self.micBaseRootRect then
        if not micRect then
            self.micBaseRootRect.anchorMax = CS.UnityEngine.Vector2(0.5, 0)
            self.micBaseRootRect.anchorMin = CS.UnityEngine.Vector2(0.5, 0)
            self.micBaseRootRect.anchoredPosition = CS.UnityEngine.Vector2(0, 144)
        else
            self.micBaseRootRect.anchorMax = micRect.anchorMax
            self.micBaseRootRect.anchorMin = micRect.anchorMin
            self.micBaseRootRect.anchoredPosition = micRect.anchoredPosition + CS.UnityEngine.Vector2(0, 144)
        end
    end
    self.isShowAudio = param.isShowAudio                       --是否显示播放原音按钮
    if self.isShowAudio then
        self.audioClickCallback = param.audioClickCallback     --播放原音按钮点击回调 用于业务控制原音播放
        self.reSpeakClickCallback = param.reSpeakClickCallback --点玩原音按钮 点击重录回调 用于业务控制原音播放定制 不需要业务调用纠音
        self.audioDuration = param.audioDuration or 3          --原音播放时长
    end
    self.questionId = param.questionId                         --题目ID
    self.questionStyle = param.questionStyle or "51"           --题目类型
    self.setId = param.setId                                   --setId 游戏用
    self.showResult = param.showResult                         --是否显示结果页
    if self.showResult == nil then
        self.showResult = true
    end
    -- if self.showResult then
    --     self.showScore = param.showScore     --结果页是否显示分数 -- 废弃
    -- end
    self.content_en = param.text_en                       --英文测评文本
    self.content_ch = param.text_cn                       --中文文本
    self.passScore = param.passScore or self.orgPassScore --通过分数阈值
    self.reTryCount = param.reTryCount or 0               --未过阈值自动重试次数
    self.callBack = function(score, isFinal, isNoSpeaking)
        local isPass = score >= self.passScore
        local isReadBook = tostring(self.questionStyle) == "52"
        if isFinal and isPass then
            if isReadBook then
                self.observerService:Fire("on_read_book_success")
            end
            self.observerService:Fire("add_pet_exp_from_read", {
                petExp = 1,
            })
        end
       
        if callback then
            callback(score, isFinal, isNoSpeaking)
        end
    end                              --结果回调（分数，是否最后结束（自动重试需要重试后返回的是false，最后一次才是true），是否开口）
    self.stepCallBack = param.stepCallBack                --步骤回调（1：开始录音，2：结束录音，3：显示结果, 4:点击结束）
    self.noChangeChat = param.noChangeChat                --是否不改变聊天区显隐状态
    if param.countDown then
        self.countDown = param.countDown                  --纠音倒计时
    end
    -- self.isGame = param.isGame               --是否游戏 是的话 结果页是fighting   否则是nice try 废弃
    self.showAwardType = param.showAwardType --awardType 4 ：5个芝士，10阵营，11校园争霸
    self.resultContent = param.resultContent --结果页文案
    self.awardCount = param.awardCount       --awardCount 5个芝士数量

    -- self.boomCount = param.boomCount         --应该获得的炸弹个数 废弃
    self.petExp = param.petExp                            --宠物经验数量 不传默认1
    self.noAutoReTry = param.noAutoReTry                  --是否不自动重试
    self.passBy = param.passBy                            --接口上报使用
    self.needInterception = param.needInterception        --是否需要截停
    self.highScore = param.highScore or self.orgHighScore --高分截停分数
    self.fightingTipType = param.fightingTipType          --1 未达标不能获得奖励哦～ 2 未达标不能通过哦～
    self:_showChat(false)
    self:_checkAuth()

    self:AI_Log("开始")
end

---结束语音评测
function SpeechAssessmentBusiness:StopAssessment()
    self.isStop = true
    --- 收到Cancel立马消失
    self.stopBtnGO:SetActive(false)
    CS.UnityEngine.AudioListener.volume = 1
    self:_showChat(true)
    if self.isEvaluating or self.noAuth then
        self:_onFinish()
    end
    -- self:_setVoiceAnim(false)
    self:_ResetPage()
end

---取消语音评测
function SpeechAssessmentBusiness:CancelAssessment()
    self.isCancel = true
    --- 收到Cancel立马消失
    self.stopBtnGO:SetActive(false)
    CS.UnityEngine.AudioListener.volume = 1
    self:_showChat(true)
    if self.isEvaluating then
        self:_onFinish(true)
        self:_reportData("评测取消", {
            preserveType = self.preserveType,
            content = self.content_en
        }, "2")
    end
    if self.waitResultCoroutine then
        self.commonService:StopCoroutineSafely(self.waitResultCoroutine)
        self.waitResultCoroutine = nil
    end

    -- self:_setVoiceAnim(false)
    self:_ResetPage()
end

---控制语音评测UI
function SpeechAssessmentBusiness:ChangePlaySoundAnim(isPlaying)
    if isPlaying then
        self.audioIconAnim:SetBool("play", true)
    else
        self.audioIconAnim:SetBool("play", false)
        self.audioIconBtn.interactable = true
    end
end

--------------------------------------------------------------------------------------------------



---------------------------------内部方法 不要调用---------------------------------

function SpeechAssessmentBusiness:_InitVar()
    self.domain = "https://app.chuangjing.com/abc-api"
    self.eventId = "ABCZONE_EVALUATION_AND_RECOGNITION"
    self.perfectScore = 100
    self.excellentScore = 90
    self.passScore = 60
    self.orgPassScore = 60
    self.countDown = 10
    self.reTryCount = 0
    self.eos = 2000
    self.noSpeaking = true
    self.noAuth = false
    self.startTime = os.time()
    self.awardImageMap = {}
    self.bolangY = 0
    self.lastBolangY = 0
    self.volumeMinOld = 35
    self.volumeMaxOld = 71
    self.volumeMaxNew = 100

    self.highScore = 60
    self.orgHighScore = 60
    self.lowScore = 30
    self.frontSilence = 3
    self.backSilence = 1
    self.needInterception = false

    self.fightingTips = { "未达标不能获得奖励哦～", "未达标不能通过哦～" }

    if not (App.IsStudioClient) then
        self.pluginJson = App.Info.plugins
        if self.pluginJson ~= nil and type(self.pluginJson) == "string" then
            -- log("开始动态资源相关配置")
            self:_InitPluginInfo()
        end
    end
end

function SpeechAssessmentBusiness:_InitPluginInfo()
    local list = self.jsonService:decode(self.pluginJson)
    for _, v in pairs(list) do
        if v.pluginName == "ABC动态资源配置" then
            xpcall(function()
                if v.pluginVal.abc_evaluation_pass_score then
                    self.passScore = tonumber(v.pluginVal.abc_evaluation_pass_score)
                    self.orgPassScore = self.passScore
                end
                if v.pluginVal.abc_evaluation_config then
                    local evaluationConfig = self.jsonService:decode(v.pluginVal.abc_evaluation_config)
                    if evaluationConfig.front_silence then
                        self.frontSilence = tonumber(evaluationConfig.front_silence)
                    end
                    if evaluationConfig.back_silence then
                        self.backSilence = tonumber(evaluationConfig.back_silence)
                    end
                    if evaluationConfig.high_score then
                        self.highScore = tonumber(evaluationConfig.high_score)
                        self.orgHighScore = self.highScore
                    end
                    if evaluationConfig.low_score then
                        self.lowScore = tonumber(evaluationConfig.low_score)
                    end
                    if evaluationConfig.pass_score then
                        self.passScore = tonumber(evaluationConfig.pass_score)
                        self.orgPassScore = self.passScore
                    end
                end
            end, function(err)

            end)
        end
    end
end

function SpeechAssessmentBusiness:_InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
end

function SpeechAssessmentBusiness:_InitConfig()
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "audioTip.mp3", function(audioclip)
        self.audioTip = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "audioWrong.mp3", function(audioclip)
        self.audioWrong = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "greatSound.mp3", function(audioclip)
        self.greatClip = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "nicetrySound.mp3", function(audioclip)
        self.niceTryClip = audioclip
    end)
    self.yellowNumImage = {}
    self.blueNumImage = {}
    for i = 0, 9 do
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "abc_color_num_y_" .. i .. ".png", function(sprite)
            self.yellowNumImage[i] = sprite
        end)
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "abc_color_num_b_" .. i .. ".png", function(sprite)
            self.blueNumImage[i] = sprite
        end)
    end
    self.resultImage = {}
    for i = 1, 3 do
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "result_" .. i .. ".png", function(sprite)
            self.resultImage[i] = sprite
        end)
    end
    local awardImageList = { "4", "10", "13" }
    for i, v in ipairs(awardImageList) do
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. v .. ".png", function(sprite)
            self.awardImageMap[v] = sprite
        end)
    end
end

function SpeechAssessmentBusiness:_InitView()
    self.root = self.VisElement.gameObject
    self.root.transform.localScale = Vector3.one
    ---@type CS.UnityEngine.Animator
    -- self.anim = self.micRoot.transform:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
    ResourceManager:LoadGameObjectWithExName(micPrefabPath, function(go)
        self.micRoot = GameObject.Instantiate(go)
        self.micRoot.transform:SetParent(self.root.transform)
        self.micRoot.transform.localPosition = Vector3.zero
        self.micRoot.transform.localScale = Vector3.one
        self.micRoot.transform.localRotation = Quaternion.identity

        self.micRoot.transform:FindChildWithName("Canvas").gameObject:GetComponent(typeof(CS.UnityEngine.Canvas)).sortingOrder = 1100
        -- self.authCanvas = self.root.transform:Find("屏幕画布").gameObject:GetComponent(typeof(CS.UnityEngine.Canvas))



        self.textTips = self.micRoot.transform:FindChildWithName("text-qingfayan").gameObject:GetComponent(typeof(CS
            .TMPro
            .TextMeshProUGUI))

        ---@type CS.UnityEngine.GameObject
        self.stopBtnGO = self.micRoot.transform:FindChildWithName("wancheng").gameObject
        self.stopBtnGO:SetActive(false)
        self.reSpeak = self.micRoot.transform:FindChildWithName("dianjikaikou").gameObject
        self.reSpeak:SetActive(false)
        self.reSpeakBtn = self.reSpeak:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.audioIcon = self.micRoot.transform:FindChildWithName("bofang").gameObject
        self.audioIcon:SetActive(false)
        ---@type CS.UnityEngine.UI.Button
        self.audioIconBtn = self.audioIcon:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.audioIconBtn.colors.disabledColor = CS.UnityEngine.Color(1, 1, 1, 1)
        self.audioIconAnim = self.audioIcon:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
        -- self.dianjikaikou = self.micRoot.transform:FindChildWithName("dianjikaikou").gameObject

        self.micBaseRoot = self.micRoot.transform:FindChildWithName("root")
        self.micBaseRootAnim = self.micBaseRoot:GetComponent(typeof(CS.UnityEngine.Animator))
        if self.micBaseRoot then
            self.micBaseRootRect = self.micBaseRoot:GetComponent(typeof(CS.UnityEngine.RectTransform))
        end

        self.shuohua_di = self.micBaseRoot.transform:Find("shuohua_di").gameObject
        self.bolang = self.shuohua_di.transform:Find("circle/cigcle_01/bolang")
        self.bolangRect = self.bolang:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.shuohua_da = self.micBaseRoot.transform:Find("shuohua_da").gameObject
        self.dashengshuohua = self.micBaseRoot.transform:Find("dashengshuohua").gameObject
        self.shanguang = self.micBaseRoot.transform:Find("shanguang").gameObject

        local canvasTrans = self.micRoot.transform:FindChildWithName("Canvas")
        ---@type CS.UnityEngine.Canvas
        self.micCanvas = canvasTrans:GetComponent(typeof(CS.UnityEngine.Canvas))
        self.micCanvas.sortingOrder = 1100
        self.micCanvas.renderMode = CS.UnityEngine.RenderMode.ScreenSpaceOverlay
        ---@type CS.UnityEngine.UI.Button
        self.stopBtn = self.stopBtnGO:GetComponent(typeof(CS.UnityEngine.UI.Button))

        -- 截停
        self.commonService:AddEventListener(self.stopBtn, "onClick", function()
            self:AI_Log("点击完成")
            if self.stepCallBack then
                self.stepCallBack(4)
            end
            self:_onFinish()
            self.micBaseRootAnim:SetBool("complete", false)
            self.micRoot:SetActive(false)
        end)

        -- 重录
        self.commonService:AddEventListener(self.reSpeakBtn, "onClick", function()
            if self.reSpeakClickCallback then
                self.reSpeakClickCallback()
            end
            self.bolangY = 0
            self.lastBolangY = 0
            self.micBaseRootAnim:SetBool("complete", false)
            self.micBaseRootAnim:SetBool("reset", false)
            self.audioIconBtn.interactable = true
            self.isPlayAudio = false
            self.noSpeaking = true
            self.isCancel = false
            self.isStop = false
            self:_showChat(false)
            self:_checkAuth()
        end)

        -- 播放
        self.commonService:AddEventListener(self.audioIconBtn, "onClick", function()
            self:AI_Log("播放原音")
            self.isCancel = true
            self.isPlayAudio = true

            --- 收到Cancel立马消失
            self.stopBtnGO:SetActive(false)
            CS.UnityEngine.AudioListener.volume = 1
            self.micBaseRootAnim:SetBool("complete", false)
            self.micBaseRootAnim:SetBool("reset", true)
            self.bolangY = 0
            self.lastBolangY = 0
            if self.isEvaluating then
                self:_onFinish(true)
            end
            if self.audioClickCallback then
                self.audioClickCallback()
            end
            -- self.dianjikaikou:SetActive(false)

            self.reSpeak:SetActive(true)
            self.textTips.text = "点击开口"
            self.audioIconAnim:SetBool("play", true)
            self.audioIconBtn.interactable = false
            self:_showEffect(false)
            self:_reportData("评测取消", {
                preserveType = self.preserveType,
                content = self.content_en
            }, "2")
        end)
        -- 无权限
        self.micAuthBtn = self.micRoot.transform:FindChildWithName("authorBg").gameObject:GetComponent(typeof(Button))
        self.authCanvas = self.micAuthBtn.transform.parent:GetComponent(typeof(CS.UnityEngine.Canvas))
        self.authCanvas.sortingOrder = 1500
        -- 申请权限
        self.commonService:AddEventListener(self.micAuthBtn, "onClick", function()
            self:AI_Log("用户手动点击请求权限按钮")
            if self.isInterceptMicTouch then
                return
            end
            self.isInterceptMicTouch = true
            self:_sendNativeRequestAuth()
        end)
        self:_SetStudioStyle()
        self.bolangRect.anchoredPosition = Vector2(0, 0)
        self.micBaseRootAnim:SetBool("complete", false)
        self.micRoot:SetActive(false)
        self.stopBtnGO:SetActive(false)
        self.gBtn.gameObject:SetActive(false)
        self.lBtn.gameObject:SetActive(false)
        self.micAuthBtn.gameObject:SetActive(false)
    end)

    ResourceManager:LoadGameObjectWithExName(resultPrefabPath, function(go)
        self.resultRoot = GameObject.Instantiate(go).transform
        self.resultRoot:SetParent(self.root.transform)
        self.resultRoot.localPosition = Vector3.zero
        self.resultRoot.localScale = Vector3.one
        self.resultRoot.localRotation = Quaternion.identity

        local canvas = self.resultRoot:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
        canvas.sortingOrder = 1100
        -- self.greatDot = self.resultRoot:FindChildWithName("dot-great+good")
        -- self.greatStar = self.resultRoot:FindChildWithName("star-great+good")
        self.greatRoot = self.resultRoot:FindChildWithName("GREATROOT")
        self.greatRootRect = self.greatRoot:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.greatScoreRoot = self.greatRoot:FindChildWithName("score")
        self.great = self.greatRoot:FindChildWithName("GREAT")
        self.greatImage = self.great:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.greatRect = self.great:GetComponent(typeof(CS.UnityEngine.RectTransform))

        local greatHun = self.greatScoreRoot:FindChildWithName("hun")
        local greatHunImg = greatHun:GetComponent(typeof(CS.UnityEngine.UI.Image))
        local greatTen = self.greatScoreRoot:FindChildWithName("ten")
        local greatTenImg = greatTen:GetComponent(typeof(CS.UnityEngine.UI.Image))
        local greatOne = self.greatScoreRoot:FindChildWithName("one")
        local greatOneImg = greatOne:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.greatScore = {
            hun = greatHun,
            ten = greatTen,
            one = greatOne,
            hunImg = greatHunImg,
            tenImg = greatTenImg,
            oneImg = greatOneImg
        }
        self.greatCheese = self.greatRoot:FindChildWithName("cheeseAndPet")
        self.greatCheeseNum = self.greatCheese:FindChildWithName("cheeseScore")
        self.greatCheeseNumTmp = self.greatCheeseNum:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.greatCheeseImageView = self.greatCheese:FindChildWithName("cheeseImage")
        self.greatCheeseImage = self.greatCheeseImageView:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.greatCheesePetNum = self.greatCheese:FindChildWithName("petScore")
        self.greatCheesePetNumTmp = self.greatCheesePetNum:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

        self.greatTmp = self.greatRoot:FindChildWithName("FightingContent"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.greatCheeseRoot = self.greatRoot:FindChildWithName("cheese")
        self.greatPetRoot = self.greatRoot:FindChildWithName("pet")

        self.greatPetExp = self.greatRoot:FindChildWithName("petExp")
        self.greatBoom = self.greatRoot:FindChildWithName("boom")
        self.greatPetExpRect = self.greatPetExp:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.greatPetExpNum = self.greatPetExp:FindChildWithName("petScore")
        self.greatPetExpNumTmp = self.greatPetExpNum:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

        self.schoolRoot = self.resultRoot:FindChildWithName("schoolRoot")
        if self.schoolRoot then
            self.schoolEnergyScore = self.schoolRoot:FindChildWithName("energyScore")
            self.schoolEnergyScoreRect = self.schoolEnergyScore:GetComponent(typeof(CS.UnityEngine.RectTransform))
            self.schoolEnergyScoreTmp = self.schoolEnergyScore:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
            self.schoolEnergyIcon = self.schoolRoot:FindChildWithName("energyIcon")
            self.schoolEnergyIconImg = self.schoolEnergyIcon:GetComponent(typeof(CS.UnityEngine.UI.Image))
        end


        self.tryAgainRoot = self.resultRoot:FindChildWithName("Try Again")
        self.tryAgainScoreRoot = self.tryAgainRoot:FindChildWithName("score")
        self.fightingBg = self.tryAgainRoot:FindChildWithName("fightingBg")
        if self.fightingBg then
            self.fightingContent = self.tryAgainRoot:FindChildWithName("FightingContent")
            self.fightingContentTmp = self.fightingContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        end

        self.diamondFailed = self.fightingBg:FindChildWithName("diamondFailed")
        self.petExpIcon = self.greatCheese:Find("pet")
        self.greatCheeseNumTmp.text = "学识+1"

        local tryAgainHun = self.tryAgainScoreRoot:FindChildWithName("hun")
        local tryAgainHunImg = tryAgainHun:GetComponent(typeof(CS.UnityEngine.UI.Image))
        local tryAgainTen = self.tryAgainScoreRoot:FindChildWithName("ten")
        local tryAgainTenImg = tryAgainTen:GetComponent(typeof(CS.UnityEngine.UI.Image))
        local tryAgainOne = self.tryAgainScoreRoot:FindChildWithName("one")
        local tryAgainOneImg = tryAgainOne:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.tryAgainScore = {
            hun = tryAgainHun,
            ten = tryAgainTen,
            one = tryAgainOne,
            hunImg = tryAgainHunImg,
            tenImg = tryAgainTenImg,
            oneImg = tryAgainOneImg
        }

        self.tryAgain = self.tryAgainRoot:FindChildWithName("tryAgain")
        self.niceTry = self.tryAgainRoot:FindChildWithName("niceTry")
        self.fighting = self.tryAgainRoot:FindChildWithName("Fighting")
        self.timeline = self.resultRoot:FindChildWithName("Timeline-jiuyinjiazhishi")
        ---@type CS.UnityEngine.Playables.PlayableDirector
        self.playableDirector = self.timeline:GetComponent(typeof(CS.UnityEngine.Playables.PlayableDirector))
        self.timeLineDuration = self.playableDirector.duration

        -- self.greatDot.gameObject:SetActive(false)
        -- self.greatStar.gameObject:SetActive(false)
        self.greatRoot.gameObject:SetActive(true)
        self.tryAgainRoot.gameObject:SetActive(true)
        self.greatCheese.gameObject:SetActive(true)
        self.greatPetExp.gameObject:SetActive(true)
        self.commonService:DispatchNextFrame(function()
            self.greatRoot.gameObject:SetActive(false)
            self.tryAgainRoot.gameObject:SetActive(false)
            self.greatCheese.gameObject:SetActive(false)
            self.greatPetExp.gameObject:SetActive(false)
            self.resultRoot.gameObject:SetActive(false)
        end)
    end)
end

function SpeechAssessmentBusiness:_showEffect(show)
    self.shuohua_di:SetActive(show)
    self.shuohua_da:SetActive(show)
    self.dashengshuohua:SetActive(show)
    self.shanguang:SetActive(show)
end

function SpeechAssessmentBusiness:_showBoomGreat(number)
    if number < 0 or number > 9 then
        self.greatBoom.gameObject:SetActive(false)
        return
    end

    self.greatBoom.gameObject:SetActive(true)

    for i = 1, 9 do
        local gm = self.greatBoom:FindChildWithName(tostring(i))
        if gm then
            if i == number then
                gm.gameObject:SetActive(true)
            else
                gm.gameObject:SetActive(false)
            end
        end
    end
end

function SpeechAssessmentBusiness:_InitListener()
    self.observerService:Watch(EVENT_EVALUATION_AND_RECOGNITION_SERVICE, function(key, value)
        local data = value[0]
        local action = data.action -- start  cancel（没结果回调） stop
        self:AI_Log("收到消息：" .. table.dump(data))
        if action == "start" then
            self:StartAssessment(data, data.callBack)
        elseif action == "stop" then
            self:StopAssessment()
        elseif action == "cancel" then
            self:CancelAssessment()
        elseif action == "playSound" then
            self:ChangePlaySoundAnim(data.playing)
        end
    end)
    self.lastRewardCount = -1
    self.observerService:Watch("on_change_last_reward_count", function(key, params)
        local data = params[0]
        if data then
            self.lastRewardCount = data.count or -1
        end
    end)
end

function SpeechAssessmentBusiness:_SetStudioStyle()
    self.gBtn = self.micRoot.transform:FindChildWithName("通过").gameObject:GetComponent(typeof(Button))
    self.lBtn = self.micRoot.transform:FindChildWithName("不通过").gameObject:GetComponent(typeof(Button))
    -- self.testAddBtn = self.micRoot:Find("屏幕画布/加").gameObject:GetComponent(typeof(Button))
    -- self.testSubBtn = self.micRoot:Find("屏幕画布/减").gameObject:GetComponent(typeof(Button))
    -- self.testShow = self.micRoot:Find("屏幕画布/最高")
    -- self.testAddBtn.gameObject:SetActive(false)
    -- self.testSubBtn.gameObject:SetActive(false)
    -- self.testShow.gameObject:SetActive(false)
    -- self.testShowTmp = self.testShow:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.observerService:Watch("speech_assessment_test", function(key, value)
        local data = value[0]
        if data.pass then
            self:AI_Log("用户点击通过按钮")
            self.noSpeaking = false
            if self.testTimer then
                self.commonService:UnregisterGlobalTimer(self.testTimer)
                self.testTimer = nil
            end
            self:_checkEvalScore(100)
        else
            self:AI_Log("用户点击不通过按钮")
            if self.testTimer then
                self.commonService:UnregisterGlobalTimer(self.testTimer)
                self.testTimer = nil
            end
            self:_checkEvalScore(0)
        end
    end)
    self.commonService:AddEventListener(self.gBtn, "onClick", function()
        self:AI_Log("用户点击通过按钮")
        self.noSpeaking = false
        if self.testTimer then
            self.commonService:UnregisterGlobalTimer(self.testTimer)
            self.testTimer = nil
        end
        self:_checkEvalScore(100)
    end)
    self.commonService:AddEventListener(self.lBtn, "onClick", function()
        self:AI_Log("用户点击不通过按钮")
        if self.testTimer then
            self.commonService:UnregisterGlobalTimer(self.testTimer)
            self.testTimer = nil
        end
        self:_checkEvalScore(0)
    end)
    -- self.commonService:AddEventListener(self.testAddBtn, "onClick", function()
    --     self.volumeMaxOld = self.volumeMaxOld + 1
    --     self.testShowTmp.text = "阈值：" .. tostring(self.volumeMaxOld)
    -- end)

    -- self.commonService:AddEventListener(self.testSubBtn, "onClick", function()
    --     self.volumeMaxOld = self.volumeMaxOld - 1
    --     self.testShowTmp.text = "阈值：" .. tostring(self.volumeMaxOld)
    -- end)
end

function SpeechAssessmentBusiness:_studioStart()
    self.isEvaluating = true
    self.isSuccessConnectNative = true
    self.gBtn.gameObject:SetActive(true)
    self.lBtn.gameObject:SetActive(true)
    if self.showMicView then
        self:_showUI(self.isShowStop, self.isShowAudio)
    end
    if self.testTimer then
        self.commonService:UnregisterGlobalTimer(self.testTimer)
        self.testTimer = nil
    end
    self.testTimer = self.commonService:RegisterGlobalTimer(0.3, function()
        if self.bolangY < self.volumeMaxNew then
            local volume = math.random(1, 72)
            if volume < 35 then
                volume = 35
            end
            -- if volume > 70 then
            --     volume = 70
            -- end
            local volume = self:_normalize(volume)
            if volume > self.volumeMaxNew then
                volume = self.volumeMaxNew
            end
            self.bolangY = volume
            self.lastBolangY = self.bolangRect.anchoredPosition.y
            -- self.bolangRect.anchoredPosition = Vector2(0, volume)
            -- if volume >= 100 then
            --     self.micBaseRootAnim:SetBool("complete", true)
            -- end
        end
    end)
end

function SpeechAssessmentBusiness:_onStart()
    if self.isCancel or self.isStop or self.isEvaluating then
        return
    end
    -- if self.isCancel or self.isStop  then
    --     return
    -- end
    ---关uinity环境音

    --
    -- 监听测评结果
    self:_registerResultListener()
    local time = tostring(os.time())
    self.curEvalId = time
    self.isFinish = false
    self:_sendNativeStart()
    self.isEvaluating = true
    self.observerService:Fire(EVENT_NOTICE_OTHER_EVALUATION_STATUS, {
        status = 0
    })
end

--- 正在录音
function SpeechAssessmentBusiness:_startEvaluating()
    self:AI_Log("正式开始收音")
    if self.stepCallBack then
        self.stepCallBack(1)
    end
    -- self:evaluatingStyle()
    self.autoStop = false
    if self.coroutineEvaluating then
        App:GetService("CommonService"):StopCoroutineSafely(self.coroutineEvaluating)
        self.coroutineEvaluating = nil
    end

    -- 倒计时开始
    local duration = self.countDown
    self:_formatCountDownTime(duration)

    self.coroutineEvaluating = self.commonService:StartCoroutine(function()
        for i = 1, duration, 1 do
            self.commonService:YieldSeconds(1)
            duration = duration - 1
            self:_formatCountDownTime(duration)
            if (duration < 1) and (not self.isFinish) then
                self.autoStop = true
                self:_onFinish()
            end
        end
    end)
end

function SpeechAssessmentBusiness:_setVoiceAnim(isShow)
    if isShow then
        CS.UnityEngine.AudioListener.volume = 1
        self.audioService:PlayClipOneShot(self.audioTip, function()
            if not self.isCancel and not self.isStop then
                CS.UnityEngine.AudioListener.volume = 0
            end
        end)
    end
end

function SpeechAssessmentBusiness:_formatCountDownTime(countDownTime)
    self.textTips.text = "请发言(" .. tostring(countDownTime) .. "s)"
end

function SpeechAssessmentBusiness:_checkEvalScore(score)
    if self.coroutineLoading then
        self.commonService:StopCoroutineSafely(self.coroutineLoading)
        self.coroutineLoading = nil
    end
    if self.mAPIBridge then
        self.mAPIBridge:UnBind()
        self.mAPIBridge = nil
    end
    self.observerService:Fire(EVENT_NOTICE_OTHER_EVALUATION_STATUS, {
        status = 2
    })
    if (not self.isEvaluating) and (not self.noAuth) then
        return
    end
    self.observerService:Fire("ABCZONE_ASSESSMENT_RESULT_NOTICE", { score = score, isPass = score >= self.passScore })
    CS.UnityEngine.AudioListener.volume = 1
    self:_showChat(true)
    -- self:_setVoiceBtn(false)
    self.isEvaluating = false
    if not self.isPlayAudio then
        self:_ResetPage()
    end
    ---对分数四舍五入
    -- score = math.floor(score + 0.5)

    if not self.isCancel then
        if self.showResult then
            local showType = 1
            if score < self.passScore then
                showType = 4
                if self.isReTry then
                    showType = 3
                end
            end
            if self.stepCallBack then
                self.stepCallBack(3)
            end
            self:_showResultView(showType, score)
            self.waitResultCoroutine = self.commonService:StartCoroutine(function()
                self.commonService:YieldSeconds(self.timeLineDuration)
                -- self.greatDot.gameObject:SetActive(false)
                -- self.greatStar.gameObject:SetActive(false)
                self.greatRoot.gameObject:SetActive(false)
                self.tryAgainRoot.gameObject:SetActive(false)
                self.resultRoot.gameObject:SetActive(false)

                if self.reTryCount > 0 then
                    if self.isCancel then
                        return
                    end
                    if score < self.passScore then
                        self.isReTry = true
                        self:AI_Log("分数不够，重新开始")
                        self.isCancel = false
                        self.isStop = false
                        self:_showChat(false)
                        self:_checkAuth()
                    end
                end
                self.reTryCount = self.reTryCount - 1
                if self.callBack then
                    if self.noAutoReTry then
                        self.callBack(score, showType == 1, self.noSpeaking)
                    else
                        self.callBack(score, self.reTryCount < 0 or showType == 1, self.noSpeaking)
                    end
                    if self.reTryCount < 0 and self.noAutoReTry and score < self.passScore then
                        self.micRoot:SetActive(true)
                        -- self.dianjikaikou:SetActive(false)
                        self:_showEffect(false)
                        self.stopBtnGO:SetActive(false)
                        self.reSpeak:SetActive(true)
                        self.textTips.text = "点击开口"
                        self.audioIconAnim:SetBool("play", false)
                        self.audioIconBtn.interactable = true
                    end
                end
            end)
        else
            if self.reTryCount > 0 then
                if self.isCancel then
                    return
                end
                if score < self.passScore then
                    self.waitResultCoroutine = self.commonService:StartCoroutine(function()
                        self.commonService:YieldSeconds(2)
                        self.isReTry = true
                        self.isCancel = false
                        self.isStop = false
                        self:AI_Log("分数不够，重新开始")
                        self:_showChat(false)
                        self:_checkAuth()
                    end)
                end
            end
            self.reTryCount = self.reTryCount - 1
            if self.callBack then
                self.callBack(score, self.reTryCount < 0 or score >= self.passScore, self.noSpeaking)
            end
        end
    end
end

function SpeechAssessmentBusiness:_onFinish(cancel)
    self:AI_Log("计时结束")

    self.isFinish = true

    if self.coroutineEvaluating then
        App:GetService("CommonService"):StopCoroutineSafely(self.coroutineEvaluating)
        self.coroutineEvaluating = nil
    end

    -- self:_setVoiceAnim(false)

    if App.IsStudioClient then
        if self.testTimer then
            self.commonService:UnregisterGlobalTimer(self.testTimer)
            self.testTimer = nil
        end
        self:_checkEvalScore(0)
        return
    end
    if cancel then
        self:_sendNativeCancel()
        if self.stepCallBack then
            self.stepCallBack(2)
        end
        CS.UnityEngine.AudioListener.volume = 1
        -- self:_showChat(true)
        if self.mAPIBridge then
            self.mAPIBridge:UnBind()
            self.mAPIBridge = nil
        end
        -- self:_setVoiceBtn(false)
        self.isEvaluating = false
        if not self.isPlayAudio then
            self:_ResetPage()
        end
        self.observerService:Fire(EVENT_NOTICE_OTHER_EVALUATION_STATUS, {
            status = 2
        })
    else
        -- self.isEvaluating = false
        self:_sendNativeStop()
        if self.isDataExceptional then
            self:_checkEvalScore(0)
            return
        end
        if self.stepCallBack then
            self.stepCallBack(2)
        end
        -- 最长等待*S
        self.coroutineLoading = App:GetService("CommonService"):StartCoroutine(function()
            App:GetService("CommonService"):YieldSeconds(6)
            self:_checkEvalScore(0)
        end)
    end
end

function SpeechAssessmentBusiness:_registerResultListener()
    self:AI_Log("注册监听纠音结果")
    self.mAPIBridge = APIBridge.CreateService("unity.buss.aispeech.result", "", function(args)
        -- self:AI_Log("纠音结果 args" .. table.dump(args))
        -- local evaType = args.type
        -- if evaType == 1 then
        --     --处理识别
        --     self:AI_Log("识别结果 args" .. table.dump(args))
        --     local data = args.data
        --     local result = data.result
        --     if result then
        --         self:AI_Log("纠音结果 发送到聊天" .. result)
        --         APIBridge.RequestAsync("app.buss.ircchat.send", {
        --             chatRoomMsg = {
        --                 content = result
        --             }
        --         })
        --     end
        --     return
        -- end
        -- 避免重复数据
        if not self.isEvaluating then
            return
        end
        self.isSuccessConnectNative = true

        if args and args.noticeType == "temp" then
            local data = args.data
            local status = args.status
            if not data or type(data) == "function" or (not data.data) or type(data.data) == "function" then
                return
            end
            if data.data and data.data.volume and self.bolangY < 100 then
                local volume = data.data.volume
                if volume < self.volumeMinOld then
                    volume = self.volumeMinOld
                end
                -- if volume > 70 then
                --     volume = 70
                -- end
                local volume = self:_normalize(volume)
                if volume > self.volumeMaxNew then
                    volume = self.volumeMaxNew
                end
                self.bolangY = volume
                self.lastBolangY = self.bolangRect.anchoredPosition.y
                -- self.bolangRect.anchoredPosition = Vector2(0, volume)
                -- if volume >= 100 then
                --     self.micBaseRootAnim:SetBool("complete", true)
                -- end

                -- if volume >= 60  then
                --     self.bolangY = self.bolangRect.anchoredPosition.y + 15
                --     if y < 100 then
                --         self.bolangRect.anchoredPosition = Vector2(0, y)
                --     else
                --         self.bolangRect.anchoredPosition = Vector2(0, 100)
                --         self.micBaseRootAnim:SetBool("complete", true)
                --     end
                -- end
            end
            return
        end

        if args then
            local id = args.id
            -- if id ~= self.curEvalId then
            --     return
            -- end
            local data = args.data
            local status = args.status
            if id then
                self:AI_Log("纠音结果 返回id：" .. id .. " curId = " .. self.curEvalId .. " 返回status：" .. status)
            end

            if (status == "success") then
                if not self.isFinish then
                    self:_onFinish()
                end
                if (data.data == nil) then
                    self:AI_Log("纠音结果 返回data为nil")
                    self.isDataExceptional = true
                    return
                end
                local score = tonumber(data.data.total_score)
                local pronScore = data.data.pron_score
                local fluency = data.data.fluency
                local overall = nil
                if fluency then
                    overall = tonumber(fluency.overall)
                end
                local integrity = data.data.integrity
                local audioUrl = data.data.url
                local tempWords = data.data.words
                local words = {}
                if tempWords then
                    for i, v in ipairs(tempWords) do
                        local word = {}
                        word.word = v.word
                        word.score = v.score
                        table.insert(words, word)
                    end
                end
                if not self.useTotalScore then
                    if pronScore and overall and integrity then
                        pronScore = tonumber(pronScore)
                        overall = tonumber(overall)
                        integrity = tonumber(integrity)
                        if integrity == 0 then
                            integrity = 100
                        end
                        if overall == 0 then
                            overall = 100
                        end

                        --计算加权分
                        score = math.floor((pronScore * 0.5 + overall * 0.1 + integrity * 0.46) + 0.5)
                        if score > 100 then
                            score = 100
                        end
                        self:AI_Log("纠音结果 加权score：" ..
                            score ..
                            " pronScore = " .. pronScore .. " fluency = " .. overall .. " integrity = " .. integrity)
                    end
                else
                    self:AI_Log("纠音结果 使用totalScore: " .. score)
                end

                local engineType = args.engineType
                if engineType ~= "st" then
                    ---10S自动停止 并且分数大于0才上报分数
                    if (not self.autoStop) or (self.autoStop and score > 0) then
                        self:_updateScore(score, pronScore, overall, integrity, audioUrl, words)
                    else
                        self:_updateScore(-1, pronScore, overall, integrity, audioUrl, words)
                    end
                end

                if score > 30 then
                    self.noSpeaking = false
                end
                self:_reportData("评测结果", {
                    preserveType = self.preserveType,
                    score = score,
                    content = self.content_en,
                    autoStop = self.autoStop
                }, "1")
                self:AI_Log("纠音最终结果 score：" .. score)

                -- 数据正常计算分数
                self:_checkEvalScore(score)
                if self.serviceType == "evaAndRect" and score >= self.passScore then
                    self:AI_Log("纠音结果 发送到聊天" .. self.content_en)
                    local petEXP = self.petExp or 1
                    -- self:_showChat(true)
                    APIBridge.RequestAsync("app.buss.ircchat.send", {
                        chatRoomMsg = {
                            showillegalTips = 0,
                            content = self.content_en,
                            translate = self.content_ch,
                            petEXP = petEXP
                        }
                    })
                end
            else
                self.isDataExceptional = true
                if self.coroutineEvaluating then
                    App:GetService("CommonService"):StopCoroutineSafely(self.coroutineEvaluating)
                    self.coroutineEvaluating = nil
                    self:_onFinish()
                elseif self.beginStart then
                    self.beginStart = false
                    self:_onFinish()
                end
            end
        else
            self:AI_Log("纠音结果 args为nil")
            self.isDataExceptional = true
        end
    end)
    -- if self.mRecBridge then
    --     return
    -- end
    -- self.mRecBridge = APIBridge.CreateService("unity.buss.aispeechsst.result", "", function(args)
    --     self:AI_Log("识别结果 args" .. table.dump(args))
    --     local evaType = args.type
    --     if evaType == 1 and args.data then
    --         local data = args.data
    --         local result = data.result
    --         if result then
    --             self:AI_Log("纠音结果 发送到聊天" .. result)
    --             self:_showChat(true)
    --             local petEXP = self.petExp or 1
    --             APIBridge.RequestAsync("app.buss.ircchat.send", {
    --                 chatRoomMsg = {
    --                     showillegalTips = 0,
    --                     content = result,
    --                     petEXP = petEXP
    --                 }
    --             })
    --         end
    --         return
    --     end
    -- end)
end

function SpeechAssessmentBusiness:_normalize(value)
    local maxNew = 100
    return ((value - self.volumeMinOld) / (self.volumeMaxOld - self.volumeMinOld)) * (maxNew)
end

--- 调用端上开始纠音
function SpeechAssessmentBusiness:_sendNativeStart()
    if self.setId == nil then
        self.setId = os.time()
    end
    self.setId = tostring(self.setId) .. tostring(self.evaIndex)
    self.evaIndex = self.evaIndex + 1
    if self.questionId == nil then
        self.questionId = 1
    end
    self.moduleId = tostring(self.setId) .. tostring(self.questionId)

    local updateUrl = "https://app.chuangjing.com/abc-api/v3/study-level/game-answer"
    if tostring(self.questionStyle) == "52" then
        updateUrl = "https://app.chuangjing.com/abc-api/v3/book-article/game-answer"
    end
    local requestParam = {
        id = self.curEvalId,
        needUploadOss = true,
        sttservice = false,
        noticeType = "change",
        bussType = "enEvl",
        module_id = self.moduleId,
        eos = self.eos,
        needInterception = self.needInterception,
        interceptionParam = {
            highScore = self.highScore,
            lowScore = self.lowScore,
            frontSilence = self.frontSilence,
            backSilence = self.backSilence,

        },
        data = {
            assess_ref = {
                text = self.content_en,
                support_repeat = false
            },
            control_param = {
                vad_max_sec = -1,
                vad_pause_sec = -1,
                vad_st_sil_sec = -1,
                suffix_penal_quick = 1,
                high_score_threshold = 31,
                high_stop_low_threshold = 30
            }
        },
        updateUrl = updateUrl,
        updateParam = {
            business_type = 2,
            question_id = self.questionId,
            set_id = self.setId,
            preserve_module_id = self.moduleId,
            plan_id = App.Info.liveId,
            preserve_type = tonumber(self.preserveType),
            game_id = self.game_id,
            invite = self.isInvite,
            -- preserve_score = tostring(score),
            -- pron_score = pronScore,
            -- fluency_score = fluency,
            -- integrity_score = integrity,
            -- audio = audioUrl,
            -- cost_time = tostring(cost_time),
            -- words = self.jsonService:encode(words)
        },
    }
    
    if self.passBy then
        if self.passBy["question_index"] then
            self.passBy["question_index"] = tonumber(self.passBy["question_index"])
        end
        if self.passBy["book_id"] then
            self.passBy["book_id"] = tonumber(self.passBy["book_id"])
        end
        if self.passBy["question_sort_no"] then
            self.passBy["question_sort_no"] = tonumber(self.passBy["question_sort_no"])
        end
        for k, v in pairs(self.passBy) do
            requestParam.updateParam[k] = v
        end
    end
    self:_reportData("评测开始", {
        preserveType = self.preserveType,
        content = self.content_en
    }, "0")
    self:AI_Log("开始调用原生:" .. self.content_en)
    self.isDataExceptional = false

    self.beginStart = true -- 等待原生回调
    APIBridge.RequestAsync("app.buss.aispeech.start", requestParam, function(params)
        if (params) then
            self.beginStart = false
            if self.isCancel or self.isStop then
                self:_sendNativeStop()
                return
            end
            self.startTime = os.time()
            self:_showChat(false)
            self:AI_Log("开始调用原生回调数据：" .. table.dump(params))
            if self.showMicView then
                self:_showUI(self.isShowStop)
            end
            self.observerService:Fire(EVENT_NOTICE_OTHER_EVALUATION_STATUS, {
                status = 1
            })
            self:_startEvaluating()
        end
    end)
end

function SpeechAssessmentBusiness:Tick()
    if self.isEvaluating then
        if self.bolangRect.anchoredPosition.y < 100 then
            local y = self.bolangRect.anchoredPosition.y + (self.bolangY - self.lastBolangY) / 10
            if y >= self.volumeMaxNew then
                y = self.volumeMaxNew
                self.micBaseRootAnim:SetBool("complete", true)
            end
            self.bolangRect.anchoredPosition = Vector2(0, y)
        end
    end
end

--- 调用端上结束纠音
function SpeechAssessmentBusiness:_sendNativeStop()
    self:AI_Log("结束调用原生:" .. self.content_en)

    APIBridge.RequestAsync("app.buss.aispeech.stop", {
        id = self.curEvalId
    }, function(params)
        if (params) then
            self:AI_Log("结束调用原生回调数据：" .. table.dump(params))
        end
    end)
end

function SpeechAssessmentBusiness:_sendNativeCancel()
    self:AI_Log("结束调用原生:" .. self.content_en)

    APIBridge.RequestAsync("app.buss.aispeech.cancel", {
        id = self.curEvalId
    }, function(params)
        if (params) then
            self:AI_Log("结束调用原生回调数据：" .. table.dump(params))
        end
    end)
end

function SpeechAssessmentBusiness:_ResetPage()
    self.bolangY = 0
    self.lastBolangY = 0
    self.bolangRect.anchoredPosition = Vector2(0, 0)
    self.micBaseRootAnim:SetBool("complete", false)
    self.micRoot:SetActive(false)
    self.stopBtnGO:SetActive(false)
    self.gBtn.gameObject:SetActive(false)
    self.lBtn.gameObject:SetActive(false)
    self.micAuthBtn.gameObject:SetActive(false)
end

function SpeechAssessmentBusiness:_showUI(isShowStop)
    self.bolangRect.anchoredPosition = Vector2(0, 0)
    self:_showEffect(true)
    self.micCanvas.gameObject:SetActive(true)
    self.micRoot:SetActive(true)
    if isShowStop then
        self.stopBtnGO:SetActive(true)
    else
        self.stopBtnGO:SetActive(false)
    end
    if self.isShowAudio then
        self.audioIcon:SetActive(true)
        self.audioIconBtn.interactable = true
    else
        self.audioIcon:SetActive(false)
    end
    if self.reSpeak then
        self.reSpeak:SetActive(false)
    end

    -- self.dianjikaikou:SetActive(true)
    self:_setVoiceAnim(true)
end

function SpeechAssessmentBusiness:_isConfigType(awardType)
    return self.awardImageMap[tostring(awardType)]
end

function SpeechAssessmentBusiness:_showResultView(showType, score)
    if showType == 1 then
        if not self.petExp then
            self.petExp = 1
        end

        self.petExpIcon.gameObject:SetActive(true)
        self.greatTmp.gameObject:SetActive(false)
        self.greatCheeseRoot.gameObject:SetActive(true)
        self.greatPetRoot.gameObject:SetActive(true)
        if self.showAwardType == preserveTypes.home or self.showAwardType == preserveTypes.readBook then
            --学识
            -- local awardImage = self.awardImageMap[tostring(self.showAwardType)]
            local awardImage = self.awardImageMap[tostring(preserveTypes.home)]
            self.greatCheeseImage.sprite = awardImage
            self.greatPetExp.gameObject:SetActive(false)
            self.greatCheese.gameObject:SetActive(self.lastRewardCount > 0)
            if self.awardCount then
                self.greatCheeseNumTmp.text = "学识+" .. self.awardCount
            else
                self.greatCheeseNumTmp.text = "学识+1"
            end
            self.petExpIcon.gameObject:SetActive(false)

            self.greatCheeseNumTmp.gameObject:SetActive(false)
            self.commonService:DispatchNextFrame(function()
                self.greatCheeseNumTmp.gameObject:SetActive(true)
            end)
        elseif self.showAwardType == preserveTypes.cheese or self:_isConfigType(self.showAwardType) then
            local awardImage = self.awardImageMap[tostring(self.showAwardType)]
            self.greatCheeseImage.sprite = awardImage
            self.greatPetExp.gameObject:SetActive(false)
            self.greatCheese.gameObject:SetActive(true)
            if self.schoolRoot then
                self.schoolRoot.gameObject:SetActive(false)
            end
            self.greatCheesePetNumTmp.text = "经验+" .. self.petExp
            if self.showAwardType == 4 then
                self.greatCheeseNumTmp.text = "+5"
            else
                if self.awardCount then
                    self.greatCheeseNumTmp.text = "+" .. self.awardCount
                else
                    self.greatCheeseNumTmp.text = "+1"
                end
            end

            if self.schoolRoot then
                self.schoolRoot.gameObject:SetActive(false)
            end
        elseif self.showAwardType == preserveTypes.campus then
            self.greatCheese.gameObject:SetActive(false)
            self.greatPetExp.gameObject:SetActive(false)
            if self.resultContent then
                self.schoolEnergyIcon.gameObject:SetActive(false)
                self.schoolEnergyScoreTmp.text = self.resultContent
            else
                self.schoolEnergyIcon.gameObject:SetActive(true)
                self.schoolEnergyScoreRect.sizeDelta = Vector2(213, 60)
                self.schoolEnergyScoreTmp.text = "获得能量+" .. self.awardCount
            end

            self.schoolRoot.gameObject:SetActive(true)
            -- self.schoolEnergyIconImg.sprite = self.schoolEnergyIconImage
        else
            if self.passText ~= nil then
                self.greatTmp.gameObject:SetActive(true)
                self.greatCheeseRoot.gameObject:SetActive(false)
                self.greatPetRoot.gameObject:SetActive(false)
                self.greatPetExp.gameObject:SetActive(false)
                self.greatCheese.gameObject:SetActive(true)
                self.greatTmp.text = self.passText
            else
                self.greatCheese.gameObject:SetActive(false)
                self.greatPetExp.gameObject:SetActive(true)
                self.greatPetExpNumTmp.text = "经验+" .. self.petExp

                if self.schoolRoot then
                    self.schoolRoot.gameObject:SetActive(false)
                end
            end
        end
        self.greatRoot.gameObject:SetActive(true)
        self.tryAgainRoot.gameObject:SetActive(false)

        self.audioService:PlayClipOneShot(self.greatClip, function()

        end)
    elseif showType == 2 then
        self.diamondFailed.gameObject:SetActive(false)
        self.greatRoot.gameObject:SetActive(false)
        self.tryAgainRoot.gameObject:SetActive(true)
        self.tryAgain.gameObject:SetActive(true)
        self.niceTry.gameObject:SetActive(false)
        self.fighting.gameObject:SetActive(false)
        self.audioService:PlayClipOneShot(self.niceTryClip, function()

        end)
        if self.fightingBg then
            if self.fightingTipType == 1 or self.fightingTipType == 2 then
                self.fightingBg.gameObject:SetActive(true)
                self.fightingContentTmp.text = self.notPassText or self.fightingTips[self.fightingTipType]
            else
                self.fightingBg.gameObject:SetActive(false)
            end
        end
    elseif showType == 3 then
        self.diamondFailed.gameObject:SetActive(false)
        self.greatRoot.gameObject:SetActive(false)
        self.tryAgainRoot.gameObject:SetActive(true)
        self.tryAgain.gameObject:SetActive(false)
        self.fighting.gameObject:SetActive(false)
        self.niceTry.gameObject:SetActive(true)
        self.audioService:PlayClipOneShot(self.niceTryClip, function()

        end)
        if self.fightingBg then
            if self.fightingTipType == 1 or self.fightingTipType == 2 then
                self.fightingBg.gameObject:SetActive(true)
                self.fightingContentTmp.text = self.notPassText or self.fightingTips[self.fightingTipType]
            else
                self.fightingBg.gameObject:SetActive(false)
            end
        end

        if self.showAwardType == 13 then
            self.diamondFailed.gameObject:SetActive(true)
            self.fightingContentTmp.text = ""
        else
            self.diamondFailed.gameObject:SetActive(false)
        end
    elseif showType == 4 then
        self.diamondFailed.gameObject:SetActive(false)
        self.greatRoot.gameObject:SetActive(false)
        self.tryAgainRoot.gameObject:SetActive(true)
        self.tryAgain.gameObject:SetActive(false)
        self.fighting.gameObject:SetActive(true)
        self.niceTry.gameObject:SetActive(false)
        self.audioService:PlayClipOneShot(self.niceTryClip, function()

        end)
        if self.fightingBg then
            if self.fightingTipType == 1 or self.fightingTipType == 2 then
                self.fightingBg.gameObject:SetActive(true)
                self.fightingContentTmp.text = self.notPassText or self.fightingTips[self.fightingTipType]
            else
                self.fightingBg.gameObject:SetActive(false)
            end
        end
    end
    self:_setScore(showType, score)

    self.commonService:DispatchNextFrame(function()
        self.resultRoot.gameObject:SetActive(true)
    end)
end

function SpeechAssessmentBusiness:_setScore(showType, score)
    local hun = 0
    local ten = 0
    local one = 0
    local hunShow = false
    local tenShow = true
    if score >= 100 then
        hun = 1
        ten = 0
        one = 0
        hunShow = true
    else
        hun = 0
        ten = math.floor(score / 10)
        one = score % 10
        if ten == 0 then
            tenShow = false
        end
    end
    if showType == 1 then
        if hunShow then
            self.greatScore.hun.gameObject:SetActive(true)
            self.greatScore.hunImg.sprite = self.yellowNumImage[hun]
        else
            self.greatScore.hun.gameObject:SetActive(false)
        end
        if tenShow then
            self.greatScore.ten.gameObject:SetActive(true)
            self.greatScore.tenImg.sprite = self.yellowNumImage[ten]
        else
            self.greatScore.ten.gameObject:SetActive(false)
        end
        if score >= self.perfectScore then
            self.greatImage.sprite = self.resultImage[1]
        elseif score >= self.excellentScore then
            self.greatImage.sprite = self.resultImage[2]
        else
            self.greatImage.sprite = self.resultImage[3]
        end
        self.greatImage:SetNativeSize()
        self.greatScore.one.gameObject:SetActive(true)
        self.greatScore.oneImg.sprite = self.yellowNumImage[one]

        self.greatScoreRoot.gameObject:SetActive(true)
        self.tryAgainScoreRoot.gameObject:SetActive(false)
    else
        if hunShow then
            self.tryAgainScore.hun.gameObject:SetActive(true)
            self.tryAgainScore.hunImg.sprite = self.blueNumImage[hun]
        else
            self.tryAgainScore.hun.gameObject:SetActive(false)
        end
        if tenShow then
            self.tryAgainScore.ten.gameObject:SetActive(true)
            self.tryAgainScore.tenImg.sprite = self.blueNumImage[ten]
        else
            self.tryAgainScore.ten.gameObject:SetActive(false)
        end

        self.tryAgainScore.one.gameObject:SetActive(true)
        self.tryAgainScore.oneImg.sprite = self.blueNumImage[one]
        self.greatScoreRoot.gameObject:SetActive(false)
        self.tryAgainScoreRoot.gameObject:SetActive(true)
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function SpeechAssessmentBusiness:ReceiveMessage(key, value, isResume)
    -- TODO:
    if key == fsync_activateRoom then
        local lastMsg = value[#value]
        if lastMsg then --游戏中用户是邀请者或者被邀请者关系
            self:AI_Log("activateRoom " .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if msg.team_user_ids and type(msg.team_user_ids) == "string" then
                    --邀人或被邀请人的所有用户id ,逗号分隔的
                    local uids = string.split(msg.team_user_ids, ",")
                    for i, uid in ipairs(uids) do
                        if tonumber(uid) == tonumber(App.Info.userId) then
                            self.isInvite = true
                            break
                        end
                    end
                end
            end
        end
    end
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function SpeechAssessmentBusiness:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function SpeechAssessmentBusiness:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function SpeechAssessmentBusiness:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function SpeechAssessmentBusiness:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function SpeechAssessmentBusiness:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function SpeechAssessmentBusiness:LogicMapStartRecover()
    SpeechAssessmentBusiness.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function SpeechAssessmentBusiness:LogicMapEndRecover()
    SpeechAssessmentBusiness.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function SpeechAssessmentBusiness:LogicMapAllComponentRecoverComplete()
end

-- 收到Trigger事件
function SpeechAssessmentBusiness:OnReceiveTriggerEvent(interfaceId)

end

-- 收到GetData事件
function SpeechAssessmentBusiness:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

function SpeechAssessmentBusiness:_micAuthStyle(isShow)
    if isShow then
        self.micRoot:SetActive(true)
    end
    self.micCanvas.gameObject:SetActive(not isShow)
    self.micAuthBtn.gameObject:SetActive(isShow)
end

function SpeechAssessmentBusiness:_checkAuth()
    if self.callBack == nil then
        self:AI_Log("纠音.话筒样式：未配置回调！或者没有给权限")
        return
    end
    if self.content_en == nil then
        g_LogError("纠音.话筒样式：未配置纠音内容！")
        return
    end
    self:AI_Log("判断权限：" .. self.content_en)
    -- 开始纠音
    if App.IsStudioClient then
        self:_studioStart()
    else
        -- self:_studioStart()
        self:_sendNativeCheckAuth()
    end
end

function SpeechAssessmentBusiness:_showChat(show)
    if self.noChangeChat then
        return
    end
    APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
        open = show,
        isShow = show
    }, function()

    end)
end

function SpeechAssessmentBusiness:_sendNativeCheckAuth()
    APIBridge.RequestAsync("app.auth.checkAuth", {
        microphoneAuth = true
    }, function(params)
        local micAuth = params.microphoneAuth
        if (micAuth == true) or (micAuth == 1) then
            self:AI_Log("判断权限-有权限")
            self:_micAuthStyle(false)
            self.noAuth = false
            ---第二次才给 那就不开启了
            if not self.callBack then
                return
            end
            self:_onStart()
        else
            local platform = CS.UnityEngine.Application.platform
            if platform == CS.UnityEngine.RuntimePlatform.IPhonePlayer then
                -- self:_micAuthStyle(true)
                self.noAuth = true
                self:_sendNativeRequestAuth()
                self:AI_Log("判断权限-没有权限")
            else
                local identifier = CS.UnityEngine.Application.identifier
                ---xpad 不需要 一定有权限
                if identifier == "com.xueersi.abczone.xpad" then
                    self:_micAuthStyle(false)
                    self.noAuth = false
                    self:_onStart()
                else
                    -- self:_micAuthStyle(true)
                    self.noAuth = true
                    self:_sendNativeRequestAuth()
                    self:AI_Log("判断权限-没有权限")
                end
                -- APIBridge.RequestAsync("app.api.channel", {}, function(res)
                --     if res.channel == "xpadlauncher" then

                --     else

                --     end
                -- end)
            end
        end
    end)
end

--- 调用端上请求权限
function SpeechAssessmentBusiness:_sendNativeRequestAuth()
    local platform = CS.UnityEngine.Application.platform
    APIBridge.RequestAsync("app.auth.requestAuth", {
        microphoneAuth = true
    }, function(params)
        local micAuth = params.microphoneAuth
        if (micAuth) then
            self:AI_Log("申请权限-有权限")
            self.noAuth = false
            self:_micAuthStyle(false)
            ---第二次才给 那就不开启了
            if not self.callBack then
                return
            end
            self:_onStart()
        else
            self.isInterceptMicTouch = false
            self.noAuth = true
            self:AI_Log("申请权限-没有权限")
            if platform == CS.UnityEngine.RuntimePlatform.IPhonePlayer then
                local appVersion = App.Info.appVersionNumber
                if appVersion then
                    if tonumber(appVersion) < 10700 then
                        APIBridge.RequestAsync("app.api.auth.jumpSetting")
                    end
                end
            end
            self:_micAuthStyle(true)
            if self.callBack then
                self.callBack(0, true, true)
                CS.UnityEngine.AudioListener.volume = 1
                if self.stepCallBack then
                    self.stepCallBack(2)
                end
                self.isEvaluating = false
                self:_showChat(true)
                self:_ResetPage()
                self.callBack = nil
            end
        end
    end)
end

function SpeechAssessmentBusiness:_setVoiceBtn(p_hide)
    local uiService = CourseEnv.ServicesManager:GetUIService()
    if p_hide then
        self.hidenVoiceId = uiService:SetHidenVoiceBtnWithID()
    else
        if self.hidenVoiceId then
            uiService:SetVisibleHidenVoiceBtnWithID(self.hidenVoiceId)
        end
    end
end

function SpeechAssessmentBusiness:AI_Log(log)
    -- g_Log("纠音评测服务", log)
end

function SpeechAssessmentBusiness:_reportData(label, value, action)
    -- if not App.IsStudioClient then
    --     NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(self.eventId, "64007", "Special-Interaction",
    --         label, action, value)
    -- end
end

function SpeechAssessmentBusiness:_updateScore(score, pronScore, fluency, integrity, audioUrl, words)
    if pronScore then
        pronScore = tonumber(pronScore)
    else
        pronScore = 0
    end
    if fluency then
        fluency = tonumber(fluency)
    else
        fluency = 0
    end
    if integrity then
        integrity = tonumber(integrity)
    else
        integrity = 0
    end
    if not audioUrl then
        audioUrl = ""
    end
    local url = self.domain .. "/v3/study-level/game-answer"
    if tostring(self.questionStyle) == "52" then
        url = self.domain .. "/v3/book-article/game-answer"
    end
    if App.IsStudioClient then
        url = "http://yapi.xesv5.com/mock/2041/v3/study-level/answer"
    end
    local endTime = os.time()
    local cost_time = endTime - self.startTime
    local params = {
        business_type = 2,
        question_id = tostring(self.questionId),
        set_id = tostring(self.setId),
        preserve_module_id = tostring(self.moduleId),
        preserve_score = tostring(score),
        plan_id = tostring(App.Info.liveId),
        preserve_type = self.preserveType,
        pron_score = pronScore,
        fluency_score = fluency,
        integrity_score = integrity,
        audio = audioUrl,
        cost_time = tostring(cost_time),
        game_id = self.game_id,
        invite = self.isInvite,
        words = self.jsonService:encode(words)
    }
    if self.passBy then
        for k, v in pairs(self.passBy) do
            params[k] = v
        end
    end
    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                self:AI_Log("上报升级成功")
            end
        end
    end
    local fail = function(err)

    end
    self.hasReport = true
    self:_HttpRequest(url, params, success, fail)
end

function SpeechAssessmentBusiness:_HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

-- 脚本释放
function SpeechAssessmentBusiness:Exit()
    SpeechAssessmentBusiness.super.Exit(self)
end

return SpeechAssessmentBusiness
