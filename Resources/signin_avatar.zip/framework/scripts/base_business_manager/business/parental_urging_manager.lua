---
---  Author: 【吕清林】
---  AuthorID: 【102030】
---  CreateTime: 【2024-10-17 15:34:40】
--- 【FSync】
--- 【家长督促管理】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

--家长督促UI090901 素材id:139926
local uAddress = "1063361757575425/assets/Prefabs/Canvas.prefab"
local NEW__VERSION = 12500      -- 版本控制，低于这个版本功能不可用
local MATH_NEW__VERSION = 21500 -- 数学支持周中学版本号
---@class Parentalurging_manager : WorldBaseElement
local Parentalurging_manager = class("Parentalurging_manager", WBElement)

function Parentalurging_manager:Print(...)
    g_Log("【家长督促管理】", ...)
end

---@param worldElement CS.Tal.framesync.WorldElement
function Parentalurging_manager:initialize(worldElement)
    Parentalurging_manager.super.initialize(self, worldElement)
    self.domain = "https://app.chuangjing.com/abc-api"
    self.root = self.VisElement.gameObject

    self.panelUI = nil
    --是否显示
    self.isShow = false
    --是否需要恢复unity音频音量
    self.needRecoverUnityVolume = false
    --新手引导是否完成
    self.isNewbieFinish = false
    --任务完成状态
    self.allTaskFinish = false
    --场次id
    self.liveId = App.Info.liveId
    local appVersion = App.Info.appVersionNumber
    if appVersion then
        -- g_Log(TAG, "appVersion:" .. appVersion)
        self.appVersion = tonumber(appVersion)
    end
    if App.IsStudioClient then
        self.appVersion = 12400
    end

    --判断是什么app
    self.isAbcZoneApp = App.modPlatformId == MOD_PLATFORM.ABCZone
    self.isMathApp = App.modPlatformId == MOD_PLATFORM.Math
    if self.isMathApp then
        NEW__VERSION = MATH_NEW__VERSION
    end
    --判断是什么mod场景
    --是否是AbcZone主场景
    self.isAbcZone = App:IsAbcZoneMain()
    --是否是数学主场景
    self.isMath = App:IsMathMain()
    --是否是家园场景
    self.isHome = App:IsHome()
    --学习类型
    self.studyType = 0 --0背单词 1-刷真题
    self:RegisterDownloadUaddress(uAddress)

    self:InitService()
    self:InitListener()
end

function Parentalurging_manager:InitService()
    ---@type CommonService
    self.commonService            = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService              = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService              = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService          = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService            = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService             = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService                = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService            = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService             = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService          = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService             = CourseEnv.ServicesManager:GetDebugService()

    self.gate                     = CourseEnv.ServicesManager.Gate
    self.businessConflictService  = CourseEnv.ServicesManager:GetBusinessConflictService()
    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

function Parentalurging_manager:InitListener()
    --监听家长督促状态弹窗
    self.observerService:Watch("SUPER_SCHOLAR_PROMPTING", function(event, value)
        local data = value[0]
        if type(data) == 'table' then
            self:Print("收到推送消息" .. table.dump(data))
            self:CheckStudyPushState()
        end
    end)

    --监听用户主动触发家长督促检测
    self.observerService:Watch("ACTIVITE_TRIGGERING_PARENTALURGING_CHECK", function(event, value)
        local data = value[0]
        self:Print("用户主动触发家长督促检测")
        self:CheckStudyPushState()
    end)

    --新手引导
    self.observerService:Watch("EVENT_NEWBIE_TASK_ALL_COMPLETE", function(event, value)
        local data = value[0]
        self.isNewbieFinish = true
        self:CheckStudyPushState()
    end)

    --监听世界boss活动状态
    self.observerService:Watch("ABC_ZONE_WORLD_UPDATA_PLAYER_DATA", function(key, value)
        local data = value and value[0]
        if data and data.uuid then
            if data.uuid == App.Uuid then
                if not data.IAT then
                    --用户退出世界boss战斗
                    --检测一下在线状态
                    self:CheckStudyPushState()
                end
            end
        end
    end)

    --用户退出宠物pvp或pve
    self.observerService:Watch("ABC_ZONE_WORLD_BOSS_CHECK_PLAYER_JOIN_ACTIVITE", function(key, value)
        local data = value and value[0]
        self:CheckStudyPushState()
    end)


    --监听app切入后台
    self.pauseFunction = function(pause)
        if pause then
            self:Print("用户进入后台")
        else
            self:Print("用户进入前台")
            self:CheckStudyPushState()
        end
    end

    self.commonService:DispatchAfter(1, function()
        if self.gate.worldController.World.OnApplicationPauseAction == nil then
            self.gate.worldController.World.OnApplicationPauseAction = self.pauseFunction
        else
            self.gate.worldController.World.OnApplicationPauseAction = self.gate.worldController.World
                .OnApplicationPauseAction + self.pauseFunction
        end
    end)
end

--显示督促弹窗
function Parentalurging_manager:ShowPanel(callback)
    if not App.IsStudioClient then
        if self.isAbcZoneApp then
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("app_parent_push_show", "888888",
                "app_parent_push_show",
                "【曝光】督促学习弹窗", "0", { param_one = self.studyType })
        elseif self.isMathApp then
            local param_one = self.task_1_state and 1 or 0
            local param_two = self.task_2_state and 1 or 0
            local param_three = self.task_3_state and 1 or 0
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("app_parent_push_show", "888888",
                "app_parent_push_show",
                "【曝光】督促学习弹窗", "0", { param_one = param_one, param_two = param_two, param_three = param_three })
        end
    end

    if not self.isShow then
        --隐藏聊天区
        self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = false })
    end

    if not self.panelUI then
        self:LoadRemoteUaddress(uAddress, function(success, prefab)
            if success and prefab then
                self.panelUI = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
                self:InitUIComponent()
                self.panelUI.gameObject:SetActive(true)
                if callback then
                    callback()
                end
            end
        end, true)
    else
        self.panelUI.gameObject:SetActive(true)
        if callback then
            callback()
        end
    end
end

--初始化UI
function Parentalurging_manager:InitUIComponent()
    local canvas = self.panelUI:GetComponent(typeof(CS.UnityEngine.Canvas))
    canvas.sortingOrder = 10100
    self.panelUI.gameObject:SetActive(false)
    --用户名称
    self.nameText = self.panelUI:Find("bg/nameText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    --描述
    self.desText = self.panelUI:Find("bg/desText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.desText.text = "今天需要先完成<color=#315DF0>2个学霸必学任务</color>，才能在APP内自由活动哦～"

    ---------------------------------------英语展示样式--------------------------------
    --任务一
    self.abcTaskList = {}
    local task1 = self.panelUI:Find("bg/item1")
    local taskName1 = task1:Find("name").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    taskName1.text = "任务一"
    local taskDes1 = task1:Find("desText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    taskDes1.text = "背单词30题"
    self.taskDes1 = taskDes1
    local taskState1 = task1:Find("stateText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    taskState1.text = "未完成"
    self.taskState1 = taskState1
    --状态按钮
    local taskStateBtn1 = task1:Find("stateBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.taskStateBtn1 = taskStateBtn1
    table.insert(self.abcTaskList,{ item = task1, task_name = taskDes1, task_status = taskState1, task_state_btn = taskStateBtn1 })
    --任务二
    local task2 = self.panelUI:Find("bg/item2")
    local taskName2 = task2:Find("name").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    taskName2.text = "任务二"
    local taskDes2 = task2:Find("desText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    taskDes2.text = "真题练习20题"
    self.taskDes2 = taskDes2
    local taskState2 = task2:Find("stateText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    taskState2.text = "未完成"
    self.taskState2 = taskState2
    --状态按钮
    local taskStateBtn2 = task2:Find("stateBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.taskStateBtn2 = taskStateBtn2
    table.insert(self.abcTaskList,{ item = task2, task_name = taskDes2, task_status = taskState2, task_state_btn = taskStateBtn2 })
    ---------------------------------------数学展示样式--------------------------------
    self.mathTaskList = {}
    --任务一
    local item_1_m = self.panelUI:Find("bg/item_1_m")
    local name_1_m = item_1_m:Find("name").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    name_1_m.text = "任务一"
    local desText_1_m = item_1_m:Find("desText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    desText_1_m.text = "背单词30题"
    local stateText_1_m = item_1_m:Find("stateText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    stateText_1_m.text = "未完成"
    --状态按钮
    local stateBtn_1_m = item_1_m:Find("stateBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    table.insert(self.mathTaskList,{ item = item_1_m, task_name = desText_1_m, task_status = stateText_1_m, task_state_btn = stateBtn_1_m })

    --任务二
    local item_2_m = self.panelUI:Find("bg/item_2_m")
    local name_2_m = item_2_m:Find("name").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    name_2_m.text = "任务二"
    local desText_2_m = item_2_m:Find("desText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    local stateText_2_m = item_2_m:Find("stateText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    --状态按钮
    local stateBtn_2_m = item_2_m:Find("stateBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    table.insert(self.mathTaskList,{ item = item_2_m, task_name = desText_2_m, task_status = stateText_2_m, task_state_btn = stateBtn_2_m })
    --任务三
    local item_3_m = self.panelUI:Find("bg/item_3_m")
    local name_3_m = item_3_m:Find("name").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    name_3_m.text = "任务三"
    local desText_3_m = item_3_m:Find("desText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    local stateText_3_m = item_3_m:Find("stateText").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    local stateBtn_3_m = item_3_m:Find("stateBtn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    table.insert(self.mathTaskList,{ item = item_3_m, task_name = desText_3_m, task_status = stateText_3_m, task_state_btn = stateBtn_3_m })

    --奖励icon
    self.rewardIcons = self.panelUI:Find("bg/icons").gameObject
    self.tempItem = self.rewardIcons.transform:Find("item")
    self.tempItem.gameObject:SetActive(false)
    --去完成按钮
    self.btn_go = self.panelUI:Find("bg/btn_go"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.btn_go, "onClick", function()
        self:ClosePanel()
        self:GoStudy()
    end)

    --继续完成按钮
    self.btn_jixu = self.panelUI:Find("bg/btn_jixu"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.btn_jixu, "onClick", function()
        self:ClosePanel()
        self:GoStudy()
    end)
end

--跳转去学习
function Parentalurging_manager:GoStudy()
    self:Print("跳转去学习")
    APIBridge.RequestAsync("app.api.jump.scheme", {
        scheme = self.jumpStudyUrl,
        keepClass = true
    })

    if not App.IsStudioClient then
        if self.isAbcZoneApp then
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("app_parent_push_click", "888888",
                "app_parent_push_click",
                "【点击】督促学习弹窗", "0", { param_one = self.studyType })
        elseif self.isMathApp then
            local param_one = self.task_1_state and 1 or 0
            local param_two = self.task_2_state and 1 or 0
            local param_three = self.task_3_state and 1 or 0
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("app_parent_push_click", "888888",
                "app_parent_push_click",
                "【点击】督促学习弹窗", "0", { param_one = param_one, param_two = param_two, param_three = param_three })
        end
    end
end

--关闭UI
function Parentalurging_manager:ClosePanel()
    self.isShow = false
    if self.panelUI then
        if self.panelUI.gameObject.activeSelf then
            self.panelUI.gameObject:SetActive(false)
            --恢复聊天区
            self.observerService:Fire("GLOBAL_NEED_CTRL_CHAT_CLOSE_OR_OPEN", { isOpen = true })
        end
    end

    if self.needRecoverUnityVolume then
        self:Print("恢复unity音频音量")
        self.needRecoverUnityVolume = false
        CS.UnityEngine.AudioListener.volume = 1
    end
end

--刷新UI
function Parentalurging_manager:RefreshUI(data)
    if not data or type(data) ~= "table" then
        self:Print("数据为空-关闭督促UI")
        self:ClosePanel()
        return
    end

    if self.appVersion and tonumber(self.appVersion) < NEW__VERSION then
        self:Print("版本低于功能支持版本，不展示")
        return
    end

    --设置任务完成状态
    self.allTaskFinish = data.is_finish

    if not data.is_set_prompting then
        self:Print("未设置开启督促-关闭督促UI")
        self:ClosePanel()
        return
    end

    if data and data.is_finish then
        self:Print("任务已经完成-关闭督促UI")
        self:ClosePanel()
        return
    end

    --任务未完成
    if data and not data.is_finish then
        --所有任务都未完成
        local worldState = false --背单词完成状态
        local realState = false  --真题完成状态
        --任务完成状态
        self.task_1_state = false
        self.task_2_state = false
        self.task_3_state = false
        if data.task_list and #data.task_list > 0 then
            for i = 1, #data.task_list do
                local task = data.task_list[i]
                if task.task_id == 1 and task.task_status == 1 then
                    worldState = true
                    self.task_1_state = true
                end
                if task.task_id == 2 and task.task_status == 1 then
                    realState = true
                    self.task_2_state = true
                end
                if task.task_id == 3 and task.task_status == 1 then
                    self.task_3_state = true
                end
            end
        end
        --学习类型
        if not worldState then
            self.studyType = 0
        else
            self.studyType = 1
        end

        self:ShowPanel(function()
            --第一次打开时检测一下unity音频音量
            if not self.isShow then
                if CS.UnityEngine.AudioListener.volume == 1 then
                    self:Print("关闭unity音频音量")
                    self.needRecoverUnityVolume = true
                    CS.UnityEngine.AudioListener.volume = 0
                end
            end

            self.isShow = true
            -- self:Print("刷新UI->", table.dump(data))
            --设置刷新学习跳转链接
            self.jumpStudyUrl = data.schema
            self.nameText.text = data.nick_name .. "小朋友"

            if data.task_list and #data.task_list > 0 then
                for i = 1, #data.task_list do
                    local task = data.task_list[i]
                    self:RefreshTaskUI(task)
                end
            end

            if data.reward_list and #data.reward_list > 0 then
                --隐藏所有奖励
                for i = 0, self.rewardIcons.transform.childCount - 1 do
                    local child = self.rewardIcons.transform:GetChild(i)
                    child.gameObject:SetActive(false)
                end
                for i = 1, #data.reward_list do
                    local reward = data.reward_list[i]
                    self:RefreshRewardUI(reward)
                end
            end

            local study_plan_is_do = data.study_plan_is_do
            self.btn_go.gameObject:SetActive(not worldState and not realState)
            self.btn_jixu.gameObject:SetActive(worldState or realState or study_plan_is_do)

            --广播家长督促UI展示事件
            self.observerService:Fire("EVENT_PARENTAL_URGING_SHOW", {})
        end)
    end
end

--刷新任务状态
function Parentalurging_manager:RefreshTaskUI(task)
    if self.isAbcZoneApp then
        local taskitem = self.abcTaskList[task.task_id]
        if taskitem then
            local item = taskitem.item
            taskitem.task_name.text = task.task_name
            taskitem.task_state_btn.interactable = task.task_status == 1
            taskitem.task_status.text = task.task_status == 1 and "已完成" or "未完成"
            taskitem.task_status.color = task.task_status == 1 and
                CS.UnityEngine.Color(153 / 255, 153 / 255, 153 / 255, 1) or
                CS.UnityEngine.Color(1, 102 / 255, 61 / 255, 1)
            item.gameObject:SetActive(true)
        end
    end
    if self.isMathApp then
        local taskitem = self.mathTaskList[task.task_id]
        if taskitem then
            local item = taskitem.item
            taskitem.task_name.text = task.task_name
            taskitem.task_state_btn.interactable = task.task_status ~= 1
            taskitem.task_status.text = task.task_status == 1 and "已完成" or "未完成"
            taskitem.task_status.color = task.task_status == 1 and
                CS.UnityEngine.Color(153 / 255, 153 / 255, 153 / 255, 1) or
                CS.UnityEngine.Color(1, 102 / 255, 61 / 255, 1)
            item.gameObject:SetActive(true)
        end
    end
end

--刷新奖励UI
function Parentalurging_manager:RefreshRewardUI(reward)
    self:Print("刷新奖励UI->", table.dump(reward))
    local item = GameObject.Instantiate(self.tempItem.gameObject, self.rewardIcons.transform)
    item.gameObject:SetActive(true)
    local itemIcon = item.transform:Find("icon").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    local iconUrl = reward.reward_img
    self.httpService:LoadNetWorkTexture(iconUrl .. "?x-oss-process=image/resize,w_84,h_84/quality,q_80", function(sprite)
        if not sprite then
            return
        end
        itemIcon.sprite = sprite
        itemIcon.gameObject:SetActive(true)
    end)
    local itemName = item.transform:Find("name").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    itemName.text = reward.reward_num
    --双倍
    local double = item.transform:Find("double")
    double.gameObject:SetActive(reward.is_double)
    --上新
    local new = item.transform:Find("suo")
    new.gameObject:SetActive(not reward.is_own or not reward.is_use)

    --限时活动
    local limited = item.transform:Find("xianshi")
    limited.gameObject:SetActive(reward.is_time_limit)
end

--主动监测连续和持续在线时长限制
function Parentalurging_manager:CheckStudyPushState()
    if not self.isAbcZone and not self.isHome and not self.isMath then
        self:Print("家长督促功能不开启")
        return
    end

    if self:CheckOtherBusinessState() then
        self:Print("用户处于不可打断状态、不弹出学习督促弹窗")
        return
    end

    self:GetStudyPushState(function(data)
        self:RefreshUI(data)
    end)
end

--检测用户是否处于宠物pvp或pve状态
function Parentalurging_manager:CheckPlayerPetPvpOrPveState()
    local pet_pvp = 0
    self.observerService:Fire("PET_SYSTEM_GET_PVP_BATTLE_STATE",
        {
            uuid = App.Uuid,
            callBack = function(state)
                if state then
                    pet_pvp = state
                end
            end
        })

    --检测用户是否在pve战斗中
    local pet_pve = 0
    self.observerService:Fire("PET_SYSTEM_GET_PVE_BATTLE_STATE",
        {
            uuid = App.Uuid,
            callBack = function(state)
                if state then
                    pet_pve = state
                    -- self:Print("被邀请人pet_pve->", pet_pve)
                end
            end
        })

    --用户处于对战中状态重置计时
    if tonumber(pet_pvp) == 1 or tonumber(pet_pve) == 1 then
        return false
    end
    return true
end

--业务逻辑宠物pvp、pve、世界bos、、、状态判断
function Parentalurging_manager:CheckOtherBusinessState()
    --如果是abczone主场景额外检测一些互动的状态是否可用
    --有的场次不判定新手引导
    if self.isAbcZone then
        if not self.isNewbieFinish then
            self:Print("用户未完成新手引导、不弹出学习督促弹窗")
            return true
        end

        --检测用户是否处于宠物pvp或pve状态
        if not self:CheckPlayerPetPvpOrPveState() then
            self:Print("否处于宠物pvp或pve状态、不弹出学习督促弹窗")
            return true
        end

        --世界boss
        local playerData = nil
        self.observerService:Fire("ABC_ZONE_WORLD_GET_ACTIVITE_PLAYER_DATA",
            {
                uid = App.Info.userId,
                callBack = function(data)
                    playerData = data
                end
            })

        if playerData and playerData.IAT then
            self:Print("处于世界Boss活动、不弹出学习督促弹窗")
            return true
        end
    end
    --数学场景检测
    if self.isMath then
        if not self.isNewbieFinish then
            self:Print("用户未完成新手引导、不弹出学习督促弹窗")
            return true
        end
    end
    --家园场景检测
    if self.isHome then
        --判定是否在不可打断状态
        local block = false
        self.observerService:Fire("EVENT_CHECK_PARENTALURGING_CAN_USE", {
            callBack = function(canUse)
                block = not canUse
            end
        })
        self:Print("用户在不可打断状态、不弹出防学习督促弹窗", block)
        return block
    end
    return false
end

--获取家长督促任务状态
function Parentalurging_manager:GetStudyPushState(callBack)
    local url = self.domain .. "/v3/book/get-super-scholar"
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041/v3/book/get-super-scholar"
    end

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                if msg.data then
                    callBack(msg.data)
                end
            end
        end
    end

    local fail = function(err)
        if not err then
            err = ""
        end
        if type(err) == "table" then
            err = table.dump(err)
        end
        callBack(nil)
    end
    self:_HttpRequest(url, {}, success, fail)
end

--http请求
function Parentalurging_manager:_HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function Parentalurging_manager:ReceiveMessage(key, value, isResume)

end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function Parentalurging_manager:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function Parentalurging_manager:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function Parentalurging_manager:SelfAvatarPrefabLoaded(avatar)
    --自己的人物模型加载完成
    self.selfAvatarLoaded = true
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function Parentalurging_manager:AvatarCreated(avatar)
end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function Parentalurging_manager:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function Parentalurging_manager:LogicMapStartRecover()
    Parentalurging_manager.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function Parentalurging_manager:LogicMapEndRecover()
    Parentalurging_manager.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function Parentalurging_manager:LogicMapAllComponentRecoverComplete()
    self.allComponentRecover = true
end

-- 收到Trigger事件
function Parentalurging_manager:OnReceiveTriggerEvent(interfaceId)

end

-- 收到GetData事件
function Parentalurging_manager:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------
-- function Parentalurging_manager:Tick()

-- end

-- 脚本释放
function Parentalurging_manager:Exit()
    Parentalurging_manager.super.Exit(self)
end

return Parentalurging_manager
