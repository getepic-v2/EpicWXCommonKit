---
---  Author: 【王德】
---  AuthorID: 【102030】
---  CreateTime: 【2024-11-1 15:23:48】
--- 【FSync】
--- 【口语魔法】
---
local class                       = require("middleclass")
local WBElement                   = require("mworld/worldBaseElement")

local Util                        = require(MAIN_SCRIPTS_LOC .. "common/util")
local cs_coroutine                = require('common/cs_coroutine')

---@class speech_magic : WorldBaseElement
local SpeechMagic                 = class("speech_magic", WBElement)
local ResourcePathRoot            = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/MagicButton"
local prefabPath                  = ResourcePathRoot .. "/assets/Prefabs/MagicButton.prefab"

local fsync_abc_zone_avatar_magic = "fsync_abc_zone_avatar_magic"
local TAG                         = "SpeechMagic"
local conflictKey                 = "AVATAR_BIG"
local ENUM_MAGIC_TYPE             = {
    BIG = 1,        ---大大大
    PROP = 2,       ---外挂道具
    ICEBullet = 3,  ---冰弹
    HOLD = 4,       ---手持道具
    BIG_JUMP = 5,   ---二段跳
    ACCELERATE = 6, ---加速 --(乘风破浪)
    FLOAT_SHELL = 7,---浮空贝壳
    HOOK = 8,       ---钩爪
    TRAMPOLINRE = 9, ---蹦床
    HTL = 10,      --混天绫（保护罩） 
    CLOUD_PEDAL = 11, ---云朵踏板
    FIREWORK_ROCKET = 12, ---烟花火箭
    TRANSFORMATION_MATH = 13, ---数学魔法
    TRANSFORMATION_ENGLISH = 14, ---英语魔法
}

local AVATAR_STATUS               = {
    NORMAL = 0,
    MAGIC = 1,
}

local AVATAR_RUN_STATUS           = {
    "normal",
    "weak",
    "rushing",
}

local APP_PLATFORM            = {
    ABCZone = 1000,        --英语
    MathZone = 1001        --数学
}

---@param worldElement CS.Tal.framesync.WorldElement
function SpeechMagic:initialize(worldElement)
    SpeechMagic.super.initialize(self, worldElement)

    self.magicEffects = {}
    -- 样板间mod不执行
    if App.ModName == "pVrv7TcGDEaXcx0uY9UpQ" then
        return
    end
    self.isMath = App.modPlatformId == MOD_PLATFORM.Math
    self.isABC = App.modPlatformId == MOD_PLATFORM.ABCZone
   
    if App.Info.appVersionNumber ~= nil then
        self.version = tonumber(App.Info.appVersionNumber)
    end
    if App.IsStudioClient then
        self.version = 11600
        if self.isMath then
            self.version = 20800
        end
    end
    if self.version < 11600 and self.isABC then
        return
    end
    if self.version < 20800 and self.isMath then
        return
    end
    if App.IsStudioClient then
        self.observerService:Watch("EVENT_NEWBIE_TASK_ALL_COMPLETE", function(key, value)
            self:_Init()
        end)
        return
    end
    ---移除掉对家园的reture
    -- if tonumber(App.Info.liveId) == AbcHomePlanId1 or tonumber(App.Info.liveId) == AbcHomePlanId2 then
    --     return
    -- end
    self:_Init()
end

function SpeechMagic:_Init()
    self:_InitVar()
    -- 订阅KEY消息
    self:SubscribeMsgKey(fsync_abc_zone_avatar_magic)
  
    self:_getMagicList(false, function(data)
        if self:_isShowMagicButton() then
            self.commonService:StartCoroutine(function()
                ---等底部栏加载完成
                self.commonService:Yield(self.commonService:WaitUntil(function()
                    return self.uiService.commonMenu.OnCreateFinished
                end))
                ---等一帧再把按钮加上
                self.commonService:YieldEndFrame()
                self:_initUI()
            end)
        end
    end)
    self:_InitListener()
    self:_InitMagicEffects()
end

function SpeechMagic:_InitVar()
    self.isMainPlan = false
    ---是否为【家园场景】
    self.isABCHomePlan = false
    if self.isABC then
   
        self.isMainPlan = App:IsAbcZoneMain()
    elseif self.isMath then
       
        self.isMainPlan = App:IsMathMain()
    end
    self.isABCHomePlan = App:IsHome()
    self.magicList = nil
    self.studyData = nil
    self.currentMagicId = nil
    --- type,uAddress, action,duration,cold_time,scale,position,rotation,audio,icon,name_image
    self.currentMagicInfo = nil
    self.magicMap = {}
    self.curStatus = AVATAR_STATUS.NORMAL
    self.effectPool = {}
    self.conflict = false
    self.propPrefabMap = {}
    self.avatarPropMap = {}
    self.speedHash = self:NameToHash("Speed")
    self.checkCount = 0

    self.magicEffects = {}
end

function SpeechMagic:_initUI(callback)
    g_Log(TAG, "初始化UI")
    self.startInitUI = true
    ResourceManager:LoadGameObjectWithExName(prefabPath, function(go)
        g_Log(TAG, "加载UI成功")
        local tempGo = GameObject.Instantiate(go).transform
        tempGo.gameObject:SetActive(false)
        local magic = tempGo.transform:FindChildWithName("Big")
        local magicRect = magic:GetComponent(typeof(CS.UnityEngine.RectTransform))
        magicRect.sizeDelta = CS.UnityEngine.Vector2(92, 92)
        self.magicRoot = magic
        self.magicBtn = magic:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.bigMask = self.magicRoot:FindChildWithName("Mask")
        local bigMaskRect = self.bigMask:GetComponent(typeof(CS.UnityEngine.RectTransform))
        bigMaskRect.anchoredPosition = CS.UnityEngine.Vector2(0, 0)
        self.countDownView = self.magicRoot:FindChildWithName("CountDown")
        self.countDownViewTmp = self.countDownView:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        -- 触发TextMeshPro内部刷新机制
        if self.countDownViewTmp then
            local _ = self.countDownViewTmp.font
            local _ = self.countDownViewTmp.fontMaterial
        end
        self.bigMagicImage = self.magicBtn.image
        self.nameImage = self.magicRoot:FindChildWithName("Name"):GetComponent(typeof(CS.UnityEngine.UI.Image))
        local nameImageRect = self.nameImage.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
        nameImageRect.anchoredPosition = CS.UnityEngine.Vector2(0, 4)
        local data = {
            normalSprite = self.magicBtn.image.sprite,
            clickSprite = self.magicBtn.image.sprite,
            priority = 1,
        }
        self.nameImageRect = nameImageRect
        ---@type CS.UnityEngine.GameObject
        self.viewRoot = self.uiService:AddButtonToOperationAreaV2(data).gameObject
        ---@type CS.UnityEngine.UI.Button
        local orgBtn = self.viewRoot:GetComponent(typeof(CS.UnityEngine.UI.Button))
        local orgImage = self.viewRoot:GetComponent(typeof(CS.UnityEngine.UI.Image))
        if orgImage then
            GameObject.Destroy(orgImage)
        end
        if orgBtn then
            GameObject.Destroy(orgBtn)
        end
        magic.transform:SetParent(self.viewRoot.transform, false)
        magic.localPosition = CS.UnityEngine.Vector3.zero
        magic.localScale = CS.UnityEngine.Vector3.one
        magicRect.anchoredPosition = CS.UnityEngine.Vector2(0, 4)
        self.tapCount = 3
        --CountNode
        self.countNode = magic:Find("CountNode")
        if self.countNode then
            self.countTextCom = self.countNode:Find("Count"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
            --屏蔽self.countTextCom 的 raycast
            self.countTextCom.raycastTarget = false
            self.countNode.gameObject:SetActive(true)
        end
        ---点击大大大按钮在数学天天中需要判断是否在安全区内
        self.commonService:AddEventListener(self.magicBtn, "onClick", function()
            self.magicBtn.interactable = false
            self:ReportBigButtonClick(self.currentMagicInfo.id)
            if self.isGuideMode then
                self.canUser = true
            end
            if self.canUser then
                if App.modPlatformId == MOD_PLATFORM.Math and self.isInValidRegion then
                    --在数学天天练中且在安全区内
                    self.magicBtn.interactable = true
                    self.observerService:Fire("ABCZONE_COMMON_TOAST", { content = "安全区内禁止口算魔法" })
                    return
                end
                if App.modPlatformId == MOD_PLATFORM.Math and self.isJumping then
                    self.observerService:Fire("ABCZONE_COMMON_TOAST", { content = "跳台飞行中禁止使用口算魔法" })
                    self.magicBtn.interactable = true
                    return
                end
                ---如果是 英语天天练 的 【乐园】场次，判断下当前状态是否为疲惫
                if App.modPlatformId == MOD_PLATFORM.ABCZone and self.isABCHomePlan then
                    local avatar = self.avatarService:GetAvatarByUUID(App.Uuid)
                    if avatar and avatar.state == "weak" then
                        ---todo: Toast
                        self.observerService:Fire("ABCZONE_COMMON_TOAST", { content = "疲惫状态下不可以使用口语魔法哦，快去开口吧！" })
                        self.magicBtn.interactable = true
                        return
                    end
                end
                if self.isGuideMode then  --只需要切技能 不需要CD
                    self.curStatus = AVATAR_STATUS.MAGIC
                    self.sendMagicInfo = self.currentMagicInfo
                    self:SendMagicMessage(true, self.currentMagicInfo)
                    self:OnlyShowSkillNoCDTime(self.currentMagicInfo)
                    self.observerService:Fire("MagicButton_Did_Selected_Event", { magicId = self.currentMagicInfo.id })
                else 
                    self.curStatus = AVATAR_STATUS.MAGIC
                    self.sendMagicInfo = self.currentMagicInfo
                    if self.currentMagicInfo.type == ENUM_MAGIC_TYPE.CLOUD_PEDAL then  --- 这里又特殊处理，因为云朵踏板技能的CD逻辑是 连续3次使用后，才需要CD
                        self.tapCount = self.tapCount - 1
                        if self.tapCount <= 0 then
                            self:StartCountdownCoroutine(self.currentMagicInfo.cold_time, self.currentMagicInfo.duration)
                            self:StartHoldTimeCoroutine(self.currentMagicInfo.duration, self.currentMagicInfo)
                        else
                            self:OnlyShowSkillNoCDTime(self.currentMagicInfo)
                            self:StartHoldTimeCoroutine(1, self.currentMagicInfo)
                            if self.countTextCom then
                                self.countTextCom.text = tostring(self.tapCount)
                            end
                        end
                    else
                        self:StartCountdownCoroutine(self.currentMagicInfo.cold_time, self.currentMagicInfo.duration)
                        self:StartHoldTimeCoroutine(self.currentMagicInfo.duration, self.currentMagicInfo)
                    end
                    ---提示： 这里没有直接使用 MagicButton_Did_Selected_Event 是因为 新手引导有一些特殊处理，换一个key, 避免冲突
                    self.observerService:Fire("SKILL_BUTTON_DID_SELECTED_EVENT", { magicInfo = self.currentMagicInfo })
                    self:SendMagicMessage(true, self.currentMagicInfo)
                end
            else
                g_Log(TAG, "未完成历年真题当前不可点击")
                self.magicBtn.interactable = true
                self.observerService:Fire("ABCZONE_SPEECH_MAGIC_NOT_CAN_USE", {})
            end
        end)


        if self.isMainPlan and self.newbieTaskComplete == nil then
            self.viewRoot:SetActive(false)
        else
            self.viewRoot:SetActive(true)
        end
        self.commonService:StartCoroutine(function()
            self.commonService:Yield(self.commonService:WaitUntil(function()
                return self.recoverComplete
            end))
            self.observerService:Fire("ABCZONE_SPEECH_MAGIC_VIEW_ROOT", { viewRoot = self.viewRoot })
            --【家园】初始化默认不展示
            if self.isABCHomePlan then
                self.viewRoot:SetActive(false)
            end
            if callback then
                callback()
            end
        end)
        self:SetCurrentMagicInfo(self.magicList[1].id)
        for _, v in ipairs(self.magicList) do
            if v.use_status == 2 then ---使用中
                self:SetCurrentMagicInfo(v.id)
                break
            end
        end
    end)
end

--检查技能是否可以使用
function SpeechMagic:CheckMagicCanUse()
    if self.canUser then
        if App.modPlatformId == MOD_PLATFORM.Math and self.isInValidRegion then
            return false
        end
        ---如果是 英语天天练 的 【乐园】场次，判断下当前状态是否为疲惫
        if App.modPlatformId == MOD_PLATFORM.ABCZone and self.isABCHomePlan then
            local avatar = self.avatarService:GetAvatarByUUID(App.Uuid)
            if avatar and avatar.state == "weak" then
                return false
            end
        end
    else
        return false
    end

    return true
end

function SpeechMagic:_InitMagicEffects()
    if #self.magicEffects > 0 then
        g_Log("gyz", "magicEffects 已经初始化")
        return
    end
    self.magicEffects = {
        [ENUM_MAGIC_TYPE.BIG] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/big_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.PROP] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/prop_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.ICEBullet] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/ice_bullet_effect"):new(self),
        [ENUM_MAGIC_TYPE.BIG_JUMP] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/jump_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.ACCELERATE] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/accelerate_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.HOLD] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/hold_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.FLOAT_SHELL] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/float_shell_effect"):new(self),
        [ENUM_MAGIC_TYPE.HOOK] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/hook_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.TRAMPOLINRE] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/trampoline_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.HTL] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/htl_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.CLOUD_PEDAL] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/cloud_pedal_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.FIREWORK_ROCKET] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/fireworkrocket_magic_effect"):new(self),
        [ENUM_MAGIC_TYPE.TRANSFORMATION_MATH] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/transformation_math"):new(self),
        [ENUM_MAGIC_TYPE.TRANSFORMATION_ENGLISH] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/magic/transformation_abc"):new(self),
        -- 添加其他魔法效果
    }
end

function SpeechMagic:_InitListener()

    self.observerService:Watch("ABCZONE_GUIDE_MODE_CTRL", function(key, value)
        local data = value[0]
        if data then
            self.isGuideMode = data.isGuideMode
            if self.isGuideMode then
                self.canUser = true
            else
                if self.studyData then
                    self.canUser = self.studyData.today_status
                else
                    self:_getMagicList(false, function(data)
                    end)
                end
            end
        end
    end)

    self.observerService:Watch("ABCZONE_EVENT_FIND_VIEW_ROOT", function(key, value)
        g_Log("gyz xxxxxxxxxxxxxxxxxxxxx:",self.viewRoot)
        local data = value[0]
        if data then
            self.findViewRootCallback = data.callback
            if self.viewRoot then -- 如果已经找到，则直接调用
                self.findViewRootCallback({ viewRoot = self.viewRoot })
            else
                self:_getMagicList(false, function(data)
                    g_Log("gyz xxxxxxxxxxxxxxxxxxxxx444444444:",self.viewRoot)
                    self.isGuideMode = true
                    -- if self:_isShowMagicButton() then
                        g_Log("gyz xxxxxxxxxxxxxxxxxxxxx55555555:",self.viewRoot)
                        self:_initUI(function() 
                            g_Log("gyz xxxxxxxxxxxxxxxxxxxxx2222222:",self.viewRoot)
                            if self.findViewRootCallback then
                                self.findViewRootCallback({ viewRoot = self.viewRoot })
                            end
                        end)
                    -- end
                end)
            end
        end
    end)

    self.observerService:Watch("ABCZONE_EVENT_GET_MAGIC_LIST", function(key, value) 
        local data = value[0]
        if data then
            local callback = data.callback
            self:_getMagicList(false, function(data)
                if callback then
                    callback({ respData = data } )
                end
            end)
        end
    end)

    -- 刷技能列表接口同步数据
    self.observerService:Watch("ABCZONE_SPEECH_MAGIC_REQUEST_LIST", function(key, value)
        self:_getMagicList(false, function(data)
            if self:_isShowMagicButton() then
                self:_initUI()
            end
        end)
    end)

    self.observerService:Watch("unity.api.page.show", function(key, value)
        self:_getMagicList(false, function(data)
            if self:_isShowMagicButton() then
                self:_initUI()
            end
        end)
    end)

    --数学专用，安全区内禁止使用技能
    self.observerService:Watch("Math_Invalid_Region_Update_Event", function(key, value)
        local data = value[0]
        self.isInValidRegion = data.isInValidRegion
        if self.isInValidRegion and self.sendMagicInfo and self.curStatus and self.curStatus == AVATAR_STATUS.MAGIC then
            if self.holdTimeCoroutine then
                self.commonService:StopCoroutineSafely(self.holdTimeCoroutine)
                self.holdTimeCoroutine = nil
            end
            self:SendMagicMessage(false, self.sendMagicInfo)
            self.sendMagicInfo = nil
        end
        --通知各个技能技能可用状态发生变更
        for _, magic in pairs(self.magicEffects) do
            if magic.CheckCanUseState then
                magic:CheckCanUseState()
            end
        end
    end)

    --数学跳台飞行中
    self.observerService:Watch("MATH_JUMP_FLYING", function(key, value)
        local data = value[0]
        if data then
            self.isJumping = data.isJumping
        end
    end)

    --一键传送
    self.observerService:Watch("ONE_CLICK_TELEPORTATION", function(key, value)
        if self.curStatus and self.curStatus == AVATAR_STATUS.MAGIC then
            if self.sendMagicInfo then
                if self.currentMagicInfo.type == ENUM_MAGIC_TYPE.FLOAT_SHELL or self.currentMagicInfo.type == ENUM_MAGIC_TYPE.HTL then
                    self:SendMagicMessage(false, self.sendMagicInfo)
                    local effect = self.magicEffects[self.currentMagicInfo.type]
                    if effect then
                        effect:onEnd(self.sendMagicInfo, self.myAvatar)
                    end
                end
                self.sendMagicInfo = nil
            end
        end
    end)

    --手持类道具在使用过程中换装、直接停止
    self.observerService:Watch("ABC_ZONE_ON_CHANGE_SKIN", function(key, args)
        if self.curStatus and self.curStatus == AVATAR_STATUS.MAGIC then
            if self.sendMagicInfo then
                if self.currentMagicInfo.type == ENUM_MAGIC_TYPE.HOLD or self.currentMagicInfo.type == ENUM_MAGIC_TYPE.FLOAT_SHELL then
                    self:SendMagicMessage(false, self.sendMagicInfo)
                    local effect = self.magicEffects[self.currentMagicInfo.type]
                    if effect then
                        effect:onEnd(self.sendMagicInfo, self.myAvatar)
                    end
                    self.sendMagicInfo = nil
                elseif self.currentMagicInfo.type == ENUM_MAGIC_TYPE.TRANSFORMATION_MATH or self.currentMagicInfo.type == ENUM_MAGIC_TYPE.TRANSFORMATION_ENGLISH then
                    self:SendMagicMessage(false, self.sendMagicInfo)
                    local effect = self.magicEffects[self.currentMagicInfo.type]
                    if effect then
                        effect:onEnd(self.sendMagicInfo, self.myAvatar)
                    end
                    self.sendMagicInfo = nil
                end
            end
        end
    end)


    self.businessConflictService:Register(conflictKey, function(status, block, extract, from)
        for i, v in ipairs(block) do
            if v == "ON_OFF" then
                if status == 1 then
                    self.conflict = true
                    if self.holdTimeCoroutine then
                        self.commonService:StopCoroutineSafely(self.holdTimeCoroutine)
                        self.holdTimeCoroutine = nil
                    end
                    if self.curStatus == AVATAR_STATUS.MAGIC then
                        if self.sendMagicInfo then
                            self:SendMagicMessage(false, self.sendMagicInfo)
                            local effect = self.magicEffects[self.currentMagicInfo.type]
                            if effect then
                                effect:onEnd(self.sendMagicInfo, self.myAvatar)
                            end
                            self.sendMagicInfo = nil
                        end
                    end
                    if self.bigPopCoroutine then
                        self.commonService:StopCoroutineSafely(self.bigPopCoroutine)
                        self.bigPopCoroutine = nil
                        self.magicBtn.interactable = true
                    end
                    if from == "WORLD_BOSS" then
                        self.conflict = false
                        ---切到第一个，第一个应该是变大魔法
                        if self.magicList and #self.magicList > 0 then
                            self.observerService:Fire("ABCZONE_SPEECH_MAGIC_CHANGE_MAGIC", { id = self.magicList[1].id })
                        end
                    end
                else
                    self.conflict = false
                end
            elseif v == "UI" then
                if status == 1 then
                    self.conflict = true
                    if self.viewRoot then
                        self.viewRoot:SetActive(false)
                    end
                    if self.bigPopCoroutine then
                        self.commonService:StopCoroutineSafely(self.bigPopCoroutine)
                        self.bigPopCoroutine = nil
                        self.magicBtn.interactable = true
                    end
                else
                    self.conflict = false
                    if self.viewRoot and self.newbieTaskComplete then
                        self.viewRoot:SetActive(true)
                    end
                end
            end
        end
        self.observerService:Fire("ABCZONE_SPEECH_MAGIC_CONFLICT",
            { status = status, block = block, extract = extract, from = from })
    end)

    self.observerService:Watch("EVENT_NEWBIE_TASK_ALL_COMPLETE", function(key, value)
        self.newbieTaskComplete = true
        if not self.conflict and self.viewRoot then
            self.viewRoot:SetActive(true)
        end
    end)

    self.observerService:Watch("ABCZONE_SPEECH_MAGIC_CHANGE_MAGIC", function(key, value)
        local data = value[0]
        self:SetCurrentMagicInfo(data.id)
    end)

    ---【家园】avater家园疲惫状态监听
    self.observerService:Watch("ABCZONE_GROUND_ENERGY_TIRED_NOTICE", function(key, value)
        local data = value[0]
        if data then
            self.currentAvatarIsTired = data.isTired
            g_Log(TAG, "avatar is tired", self.currentAvatarIsTired)
            if self.sendMagicInfo and self.curStatus and self.curStatus == AVATAR_STATUS.MAGIC and self.currentAvatarIsTired then
                if self.holdTimeCoroutine then
                    self.commonService:StopCoroutineSafely(self.holdTimeCoroutine)
                    self.holdTimeCoroutine = nil
                end
                self:SendMagicMessage(false, self.sendMagicInfo)
                self.sendMagicInfo = nil
                if self.countDownCoroutine then
                    self.commonService:StopCoroutineSafely(self.countDownCoroutine)
                    self.countDownCoroutine = nil
                end
                self.bigMask.gameObject:SetActive(false)
                self.magicBtn.interactable = true
            end
        end
    end)

    ---【家园】场景切换
    self.homeCurrentScene = 1
    self.observerService:Watch("HOME_SCENE_DID_CHANGED", function(key, value)
        local data = value[0]
        if data then
            local scene = data.scene
            self.homeCurrentScene = scene
            if self.viewRoot then
                self.viewRoot:SetActive(scene ~= 1 and not self.conflict)
            end
             if self.curStatus == AVATAR_STATUS.MAGIC then
                if self.sendMagicInfo then
                    self:SendMagicMessage(false, self.sendMagicInfo)
                    local effect = self.magicEffects[self.currentMagicInfo.type]
                    if effect then
                        effect:onEnd(self.sendMagicInfo, self.myAvatar)
                    end
                    self.sendMagicInfo = nil
                end
            end
        end
    end)

    ---【家园】编辑状态切换
    self.observerService:Watch("EVENT_EDITOR_MODE_CHANGED", function(key, args)
        local data = args[0]
        if data and self.viewRoot then
            local isEditor = data.isEditor
            if self.homeCurrentScene == 1 then
                self.viewRoot:SetActive(false)
            else
                self.viewRoot:SetActive(not isEditor and not self.conflict)
            end
        end
    end)

    if self.isABCHomePlan then
        ---【家园】骑乘状态监听
        self.observerService:Watch("MATH_DRIVE_MOUNTS_STATUS", function(key, value)
            local data = value[0]
            if data then
                local status = data.status
                if status == 1 then
                    -- 骑乘状态下,如果正在施法则停止
                    self.conflict = true
                    if self.holdTimeCoroutine then
                        self.commonService:StopCoroutineSafely(self.holdTimeCoroutine)
                        self.holdTimeCoroutine = nil
                    end
                    if self.curStatus == AVATAR_STATUS.MAGIC then
                        if self.sendMagicInfo then
                            self:SendMagicMessage(false, self.sendMagicInfo)
                            local effect = self.magicEffects[self.currentMagicInfo.type]
                            if effect then
                                effect:onEnd(self.sendMagicInfo, self.myAvatar)
                            end
                            self.sendMagicInfo = nil
                        end
                    end
                    if self.bigPopCoroutine then
                        self.commonService:StopCoroutineSafely(self.bigPopCoroutine)
                        self.bigPopCoroutine = nil
                        self.magicBtn.interactable = true
                    end
                    if self.viewRoot then
                        self.viewRoot:SetActive(false)
                    end
                    if self.bigPopCoroutine then
                        self.commonService:StopCoroutineSafely(self.bigPopCoroutine)
                        self.bigPopCoroutine = nil
                        self.magicBtn.interactable = true
                    end
                else
                    -- 骑乘状态结束
                    self.conflict = false
                    if self.viewRoot and self.homeCurrentScene ~= 1 then
                        self.viewRoot:SetActive(true)
                    end
                end
            end
        end)

        --家园游泳
        self.observerService:Watch("EVENT_SWIM_STATE_CHANGED", function(key, value)
            local data       = value[0]
            local isSwimming = data.isSwimming
            if isSwimming then
                if self.curStatus == AVATAR_STATUS.MAGIC then
                    if self.sendMagicInfo then
                        self:SendMagicMessage(false, self.sendMagicInfo)
                        local effect = self.magicEffects[self.currentMagicInfo.type]
                        if effect then
                            effect:onEnd(self.sendMagicInfo, self.myAvatar)
                        end
                        self.sendMagicInfo = nil
                    end
                end
            end
        end)

        --家园口语挑战赛
        self.observerService:Watch("GAME_CHALLENGE_START", function(key, value)
            local data       = value[0]
            local mode = data.mode
            local isStart = data.isStart

            if isStart then
               if self.curStatus == AVATAR_STATUS.MAGIC then
                    if self.sendMagicInfo then
                        self:SendMagicMessage(false, self.sendMagicInfo)
                        local effect = self.magicEffects[self.currentMagicInfo.type]
                        if effect then
                            effect:onEnd(self.sendMagicInfo, self.myAvatar)
                        end
                        self.sendMagicInfo = nil
                    end
                end
            end
            if self.viewRoot then
                self.viewRoot:SetActive((not isEditor) and (not self.conflict) and (not isStart ))    
            end
            
        end)
    end

    ---立即停止技能状态
    self.observerService:Watch("EVENT_MAGIC_SKILL_STOP", function (key, args)
        if self.currentMagicInfo then
            self.bigMask.gameObject:SetActive(false)
            self.magicBtn.interactable = true
            if self.countDownCoroutine then
                self.commonService:StopCoroutineSafely(self.countDownCoroutine)
                self.countDownCoroutine = nil
            end
            if self.holdTimeCoroutine then
                self.commonService:StopCoroutineSafely(self.holdTimeCoroutine)
                self.holdTimeCoroutine = nil
            end
            --通知各个技能cd已经好了
            for _, magic in pairs(self.magicEffects) do
                if magic.OnButtonCd then
                    magic:OnButtonCd(false)
                end
            end
            self:SendMagicMessage(false, self.currentMagicInfo)
            self.sendMagicInfo = nil
        end
    end)
end

function SpeechMagic:SetCurrentMagicInfo(id)
    self.currentMagicId = id
    self.currentMagicInfo = self.magicMap[tostring(id)].skill_effect.business_data
    self.currentMagicInfo.id = id

  

    g_Log(TAG, "切换魔法", tostring(self.currentMagicInfo))
    self:_changeButtonImage(id)
    self.observerService:Fire("ABCZONE_SPEECH_MAGIC_DID_CHANGE", {
        magicInfo = self.currentMagicInfo or {},
        canUse = self.canUser
    })

      --选择技能时通知每一个技能做前置工作
    for _, magic in pairs(self.magicEffects) do
        if magic.SelectSkill then
            magic:SelectSkill(self.magicBtn,self.currentMagicInfo)
        end
    end

    ---检测是否需要展示计次UI
    self:_checkNeedShowCountNode()

end

function SpeechMagic:_checkNeedShowCountNode()
    if self.currentMagicInfo then
        local needShow = self:needShowCountNode(self.currentMagicInfo)
        if self.countNode then
            self.countNode.gameObject:SetActive(needShow)
            if self.tapCount == 0 then
                self.tapCount = 3  ---默认3次,可以配置为下发
            end
            self.countTextCom.text = tostring(self.tapCount)
        end
    end
end
function SpeechMagic:needShowCountNode(magicInfo)
    -- 更多技能如果需要 可以在这里 配置
    return magicInfo.type == ENUM_MAGIC_TYPE.CLOUD_PEDAL
end

function SpeechMagic:_changeButtonImage(id)
    local icon = self.currentMagicInfo.icon
    local name_image = self.currentMagicInfo.name_image
    self.httpService:LoadNetWorkTexture(icon, function(sprite)
        self.bigMagicImage.sprite = sprite
    end)
    self.httpService:LoadNetWorkTexture(name_image, function(sprite)
        self.nameImage.sprite = sprite
        local w, h = sprite.rect.width, sprite.rect.height
        local realH = 26
        ---缩放比例
        local scale = realH / h
        local realW = w * scale
        self.nameImageRect.sizeDelta = CS.UnityEngine.Vector2(realW, realH)
    end)
end

function SpeechMagic:_isShowMagicButton()
    if self.startInitUI then
        return false
    end
    if App.IsStudioClient then
        return true
    end
    -- body
    if (self.isMainPlan or self.isABCHomePlan) and self.studyData then
        return true
    else
        if self.studyData and self.studyData.today_status then
            for _, v in ipairs(self.magicList) do
                if v.use_status == 2 then ---使用中
                    if v.skill_effect and v.skill_effect.plan_able then
                        return true
                    end
                end
            end
        else
            return false
        end
    end
    return false
end

function SpeechMagic:_UpdateData(data)
    self.commonService:StartCoroutine(function()
        self.commonService:Yield(self.commonService:WaitUntil(function()
            return self.recoverComplete
        end))
        g_Log(TAG, "data", tostring(data))
        self.observerService:Fire("ABCZONE_SPEECH_MAGIC_UPDATE_DATA", { data = data })
    end)
end

function SpeechMagic:StartCountdownCoroutine(coldTime, duration)
    local countDown = coldTime
    --通知各个技能cd已经好了
    for _, magic in pairs(self.magicEffects) do
        if magic.OnButtonCd then
            magic:OnButtonCd(true)
        end
    end
    if self.countNode then
        self.countNode.gameObject:SetActive(false)
    end
    self.bigMask.gameObject:SetActive(true)
    self.countDownViewTmp.text = tostring(duration) .. "S"
    self.countDownCoroutine = self.commonService:StartCoroutine(function()
        while countDown > 0 do
            self.countDownViewTmp.text = tostring(countDown) .. "S"
            countDown = countDown - 1
            self.commonService:YieldSeconds(1)
        end
        self.bigMask.gameObject:SetActive(false)
        self.magicBtn.interactable = true

        --通知各个技能cd已经好了
        for _, magic in pairs(self.magicEffects) do
            if magic.OnButtonCd then
                magic:OnButtonCd(false)
            end
        end
        self:_checkNeedShowCountNode()
    end)
end

function SpeechMagic:OnlyShowSkillNoCDTime(magicInfo)
    --通知各个技能cd已经好了
    for _, magic in pairs(self.magicEffects) do
        if magic.OnButtonCd then
            magic:OnButtonCd(true)
        end
    end
    self.bigMask.gameObject:SetActive(false)
    self.magicBtn.interactable = true
end

function SpeechMagic:StartHoldTimeCoroutine(duration, MagicInfo)
    self.holdTimeCoroutine = self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(duration)
        self:SendMagicMessage(false, MagicInfo)
        self.sendMagicInfo = nil
    end)
end

function SpeechMagic:SendMagicMessage(isOpen, magic)
    local platform = APP_PLATFORM.ABCZone   ---默认英语是0
    if self.isMath then
        platform = APP_PLATFORM.MathZone
    end
    self:SendCustomMessage(fsync_abc_zone_avatar_magic, { uuid = App.Uuid, isOpen = isOpen, appPlatform = platform, magic = magic })
    if not self.conflict then
        if isOpen then ---变大冲突立刻发
            if magic.type == ENUM_MAGIC_TYPE.ICEBullet then
                ---冰弹特殊的冲突处理
            elseif magic.type == ENUM_MAGIC_TYPE.BIG_JUMP then
                ---二段跳的冲突处理
            elseif magic.type == ENUM_MAGIC_TYPE.ACCELERATE then
                ---加速的冲突处理
            else
                if BUSINESS_NAME_ENUM and BUSINESS_NAME_ENUM.BIG and self.avatarService.StartBusiness then
                    self.avatarService:StartBusiness(BUSINESS_NAME_ENUM.BIG, App.Uuid)
                end
                self.businessConflictService:DidOpenBusiness(conflictKey, { AVATAR_BIG = magic.type })
                if magic.type ~= ENUM_MAGIC_TYPE.BIG then
                    self.observerService:Fire("EVENT_HOLD_PROP_SHOW_HIDE", { show = false })
                end
            end
        else
            self.businessConflictService:DidCloseBusiness(conflictKey)
        end
    end
    self.observerService:Fire("ABCZONE_SPEECH_MAGIC_SYNC_STATUS", { isOpen = isOpen, magic = magic })
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function SpeechMagic:ReceiveMessage(key, value, isResume)
    -- TODO:
    if key == fsync_abc_zone_avatar_magic then
        for _, v in ipairs(value) do
            local data = self.jsonService:decode(v)
            local avatar = self.avatarService:GetAvatarByUUID(data.uuid)
            if avatar then
                self:_doAction(data, avatar, isResume)
            end
        end
    end
    for _, magic in pairs(self.magicEffects) do
        if magic.ReceiveMessage then
            magic:ReceiveMessage(key, value, isResume)
        end
    end
end



function SpeechMagic:_doAction(data, avatar, isResume)
    local isOpen = data.isOpen
    local magicInfo = data.magic
    if not magicInfo then
        return
    end
    local magicInfo = data.magic
    local effect = self.magicEffects[magicInfo.type]
    if effect then
        if data.isOpen then
            effect:onStart(data, avatar, isResume)
        else
            effect:onEnd(data, avatar)
        end
    end
end

function SpeechMagic:_LoadPropPrefabs(uaddress)
    if self.propPrefabMap[uaddress] and self.propPrefabMap[uaddress].status then
        return
    end
    -- self:RegisterDownloadUaddress(uaddress)
    self.propPrefabMap[uaddress] = { status = 0, prefabs = nil }
    self:LoadRemoteUaddress(uaddress, function(success, prefabs)
        if success then
            self.propPrefabMap[uaddress] = { status = 1, prefabs = prefabs }
        else
            self.propPrefabMap[uaddress] = nil
        end
    end)
end

function SpeechMagic:Tick()
    --魔法效果的Tick
    if self.magicEffects then
        for _, magic in pairs(self.magicEffects) do
            if magic.Tick then
                magic:Tick()
            end
        end
    end
    -- body
    if self.avatarPropMap then
        for _, v in pairs(self.avatarPropMap) do
            if not Util:IsNil(v.anim) then
                local lastSpeed = v.speed
                local lastUpping = v.upping
                local lastFalling = v.falling
                if not lastSpeed or lastSpeed ~= v.avatar.lastSpeed or lastUpping ~= v.avatar.characterCtrl.upping or lastFalling ~= v.avatar.characterCtrl.falling then
                    if v.avatar.lastSpeed == 0 and v.avatar.characterCtrl.upping == false and v.avatar.characterCtrl.falling == false then
                        v.anim:SetFloat(self.speedHash, 0)
                    elseif v.avatar.lastSpeed <= 3.5 then
                        v.anim:SetFloat(self.speedHash, 0.5)
                    else
                        v.anim:SetFloat(self.speedHash, 1)
                    end
                end
                v.speed = v.avatar.lastSpeed
            end
            if not Util:IsNil(v.prop) then
                if self.checkCount and self.checkCount > 10 then
                    if v.prop and v.propShow and (not v.avatar.characterCtrl or v.avatar.characterCtrl.zombiePlayer or not v.avatar:IsOnline()) then
                        v.prop:SetActive(false)
                        v.propShow = false
                    elseif v.prop and not v.propShow and (v.avatar.characterCtrl and not v.avatar.characterCtrl.zombiePlayer) and v.avatar:IsOnline() then
                        v.prop:SetActive(true)
                        v.propShow = true
                    end
                else
                    self.checkCount = self.checkCount + 1
                end
            end
        end
    end
end

function SpeechMagic:NameToHash(name)
    return CS.UnityEngine.Animator.StringToHash(name)
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function SpeechMagic:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function SpeechMagic:SelfAvatarCreated(avatar)
    self.myAvatar = avatar
    g_Log("gyz", "SelfAvatarCreated 后 magicEffects:", #self.magicEffects)
    if #self.magicEffects == 0 then
        self:_InitMagicEffects()
    end
    for _, magic in pairs(self.magicEffects) do
        if magic.SelfAvatarCreated then
            magic:SelfAvatarCreated(avatar)
        end
    end
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function SpeechMagic:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function SpeechMagic:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function SpeechMagic:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function SpeechMagic:LogicMapStartRecover()
    SpeechMagic.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function SpeechMagic:LogicMapEndRecover()
    SpeechMagic.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function SpeechMagic:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

-- 收到Trigger事件
function SpeechMagic:OnReceiveTriggerEvent(interfaceId)

end

-- 收到GetData事件
function SpeechMagic:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

---接口请求
function SpeechMagic:_getMagicList(needShowUI, callback)
    ---接口文档https://yapi.xesv5.com/project/2041/interface/api/123069
    self.domain = "https://app.chuangjing.com/abc-api"
    local url = self.domain .. "/v3/prop-card/magic/list"
    if App.IsStudioClient then
        url = "http://yapi.xesv5.com/mock/2041/v3/prop-card/magic/list"
    end

    local game_id = App.Info.configMap.game_id
    if not game_id then
        game_id = 0
    end
    local params = {
        game_id = self.isMainPlan and nil or tonumber(game_id),
        show_location = 3
    }
    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end

            if msg and msg.code == 0 then
                local data = msg.data
                if data and type(data) == "table" then
                    self.magicList = data.list
                    table.sort(self.magicList, function(a, b)
                        return self:_SortRule(a, b)
                    end)
                    data.list = self.magicList
                    for _, v in ipairs(self.magicList) do
                        self.magicMap[tostring(v.id)] = v
                    end
                    self.studyData = data.study_data
                    self.canUser = self.studyData.today_status

                    self:_UpdateData(data)

                    if callback then
                        callback(data)
                    end
                else
                    if callback then
                        callback(nil)
                    end
                end
            else
                if callback then
                    callback(nil)
                end
            end
        end
    end
    local fail = function(err)
        if callback then
            callback(nil)
        end
    end
    self:HttpRequest(url, params, success, fail)
end

function SpeechMagic:_SortRule(a, b)
    if a.status == 1 and b.status == 0 then
        return true
    elseif a.status == 0 and b.status == 1 then
        return false
    else
        local aDays_own = a.days_own
        local bDays_own = b.days_own
        if a.status ~= 1 then
            local aActivity_days_own = a.activity_days_own
            local bActivity_days_own = b.activity_days_own
            if aActivity_days_own > 0 then
                aDays_own = aActivity_days_own
            end
            if bActivity_days_own > 0 then
                bDays_own = bActivity_days_own
            end
        end
        if aDays_own == bDays_own then
            return a.id < b.id
        else
            return aDays_own < bDays_own
        end
    end

    -- return aDays_own < bDays_own
end

function SpeechMagic:HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

function SpeechMagic:reportData(eventId, label, value, action)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(eventId, "67881", "Special-Interaction", label,
            action, value)
    end
end

function SpeechMagic:ReportBigButtonClick(id)
    self:reportData("3d_hugebtn_click", "大大大按钮点击", { param_one = self.canUser and "1" or "2", param_two = id }, "0")
end

-- 更新帧索引
function SpeechMagic:UpdateFrameIndex(frameIndex)
    for _, magic in pairs(self.magicEffects) do
        if magic.UpdateFrameIndex then
            magic:UpdateFrameIndex(frameIndex)
        end
    end
end
-- 脚本释放
function SpeechMagic:Exit()
    SpeechMagic.super.Exit(self)
    for _, magic in pairs(self.magicEffects) do
        if magic.Exit then
            magic:Exit()
        end
    end
end

return SpeechMagic
