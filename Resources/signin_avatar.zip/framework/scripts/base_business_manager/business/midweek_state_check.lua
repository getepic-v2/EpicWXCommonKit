---
---  Author: 【郭玉泽】
---  AuthorID: 【253523】
---  CreateTime: 【2025-5-27 15:04:50】
--- 【FSync】
--- 【周中学状态管理】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local Canvas = CS.UnityEngine.Canvas
local TMP = CS.TMPro.TextMeshProUGUI
local Image = CS.UnityEngine.UI.Image
local Button = CS.UnityEngine.UI.Button
local Vector3 = CS.UnityEngine.Vector3
local PlayerPrefs = CS.UnityEngine.PlayerPrefs
local LayoutElement = CS.UnityEngine.UI.LayoutElement
local RectTransform = CS.UnityEngine.RectTransform
local LoopType = CS.DG.Tweening.LoopType
local Ease = CS.DG.Tweening.Ease
local Vector2 = CS.UnityEngine.Vector2
local GameObject = CS.UnityEngine.GameObject
local ScrollRect = CS.UnityEngine.UI.ScrollRect
local GridLayoutGroup = CS.UnityEngine.UI.GridLayoutGroup
local Color = CS.UnityEngine.Color

---@class MidWeekStateCheck : WorldBaseElement
local MidWeekStateCheck = class("MidWeekStateCheck", WBElement)

local Fsync_Example_KEY = "_Example__Key_"
local uAddress = "1017461749549285/assets/Prefabs/MidWeekTimeAlert.prefab"
local PageId = "周中学超时弹窗"
local ABCZONE_EVENT_MIDWEEK_SHOW_TIMEOUT_PANEL = "ABCZONE_EVENT_MIDWEEK_SHOW_TIMEOUT_PANEL"
local ABCZONE_LAST_TIME_MODE = "ABCZONE_LAST_TIME_MODE111111"

local NEW__VERSION = 12500 -- 英语支持周中学版本号
local MATH_NEW__VERSION = 21500 -- 数学支持周中学版本号

local ABCMainPlanId = 202
local MATHMainPlanId = 131
local ABCHomePlanId = 296
local AbcHomePlanId2 = 297

---@param worldElement CS.Tal.framesync.WorldElement
function MidWeekStateCheck:initialize(worldElement)
    MidWeekStateCheck.super.initialize(self, worldElement) 
    --加下版本控制
    self.appVersion = App.Info.appVersionNumber
    self.isNewVersion = false
    self.last_time_mode_key = ABCZONE_LAST_TIME_MODE .. "_" .. App.Uuid
    self.isABCZone = App.modPlatformId == MOD_PLATFORM.ABCZone
    self.isMath = App.modPlatformId == MOD_PLATFORM.Math
    if self.isMath then
        NEW__VERSION = MATH_NEW__VERSION
    end

    if App.Info.configMap.env ~= "online" then
        ABCMainPlanId = 751
        ABCHomePlanId = 859
        AbcHomePlanId2 = 860
        MATHMainPlanId = 531
    end
    self.isABCMainPlan = tonumber(App.Info.liveId) == ABCMainPlanId
    self.isABCHomePlan = tonumber(App.Info.liveId) == ABCHomePlanId or tonumber(App.Info.liveId) == AbcHomePlanId2
    self.isMATHMainPlan = tonumber(App.Info.liveId) == MATHMainPlanId

    -- PlayerPrefs.GetInt(ABCZONE_LAST_TIME_MODE, 1)
    if self.appVersion and tonumber(self.appVersion) >= NEW__VERSION then
        self.isNewVersion = true
    end
    if App.IsStudioClient then
        self.isNewVersion = true
        self.isABCHomePlan = true
    end
    if not self.isNewVersion then
        g_Log("【周中学状态管理】 当前版本小于" .. NEW__VERSION .. "，不处理")
        return
    end

    if (not self.isABCZone) and (not self.isMath) then
        g_Log("【周中学状态管理】 非ABCZone或Math，不处理")
        return
    end

    print("获取模式：",PlayerPrefs.GetInt(self.last_time_mode_key))

    self:InitValues()
    self:AddObservers()
    -- self.commonService:DispatchAfter(5, function()
    --     self:ShowMainPanel(1)
    --     self.commonService:DispatchAfter(5, function()
    --         self:ShowMainPanel(1)
    --     end)
    -- end)
end

function MidWeekStateCheck:InitValues()

    self.pageMonitorService = CourseEnv.BaseBusinessManager:GetPageMonitorService()
    self.taskTimer = nil
    self.root = self.VisElement.gameObject
    self.rootTrans = self.root.transform
    self:RegisterDownloadUaddress(uAddress)
    self.mainPanel = nil
end

function MidWeekStateCheck:AddObservers()

    self.observerService:Watch(ABCZONE_EVENT_MIDWEEK_SHOW_TIMEOUT_PANEL, function(key, args)
        local data = args[0]
        if data then
            local showType = data.showType
            self:ShowMainPanel(showType)
        end
    end)

    self.isComleteNewTask = false -- 新手任务是否完成
    self.observerService:Watch("EVENT_NEWBIE_TASK_ALL_COMPLETE", function(key, value)
        self.isComleteNewTask = true
    end)
     -- mode:当前模式 1:自由学 2:严肃学 3.定制学
    --     {
    -- 	["desc_img"] = "https://static0.xesimg.com/next-app/continue/mode_1.png",
    -- 	["mode"] = 1,
    -- 	["btn_name"] = "我知道啦",
    -- 	["desc"] = "爸爸妈妈已修改学习模式为【自由学】",
    -- 	["nickname"] = "pk1",
    -- },
    --- 收到推送切模式提示
    APIBridge.CreateService("app.api.studyMode.switch", {}, function(res)
        g_Log("【周中学状态管理】 receive native app.api.studyMode.switch:",table.dump(res))
        if res then
            self.studyMode = res.mode
            g_Log("当前模式为：",res.mode)
            local forceOpen = res.mode == 2 or res.mode == 3
            if self.isABCZone or self.isMath then
                if self.isABCMainPlan or self.isMATHMainPlan then
                    self.observerService:Fire("EVENT_ABC_ZONE_CHANGE_MODE_TO_STRICT", { needOpen = forceOpen })
                else
                    App:GameReturn()        
                end
            else
                g_Log("【周中学状态管理】 非ABCZone or Math，不处理")
            end
            -- self.observerService:Fire("EVENT_ABC_ZONE_CHANGE_MODE_TO_STRICT", { needOpen = forceOpen })
        else
            g_Log("【周中学状态管理】收到的 res 数据异常：",res)
        end
    end)

    -- ---计时处理逻辑
    self.pauseFunction = function(pause)
        if pause then
            g_Log("【周中学状态管理】进入后台")
        else
            g_Log("【周中学状态管理】回到前台")
            self:CheckShowAlert()
        end
    end
    ---@type Gate
    self.gate = CourseEnv.ServicesManager.Gate
    self.commonService:DispatchAfter(1, function()
        -- self.gateService:RegisterAppPause(self.pauseFunction)
        if self.gate.worldController.World.OnApplicationPauseAction == nil then
            -- g_Log(TAG, "第一个注册前后台监听")
            self.gate.worldController.World.OnApplicationPauseAction = self.pauseFunction
        else
            -- g_Log(TAG, "非第一个注册前后台监听")
            self.gate.worldController.World.OnApplicationPauseAction = self.gate.worldController.World
                .OnApplicationPauseAction + self.pauseFunction
        end
    end)
    self.observerService:Watch("unity.api.page.show", function()
        g_Log("【周中学状态管理】收到unity.api.page.show事件")
        self:CheckShowAlert()
    end)
    self:CheckShowAlert()
end

--- is_continue_open = true 的情况才需要处理 ，当countdown == -1  直接弹出提示；否则判断 start_counter == true, 启动定时器；否则不处理
function MidWeekStateCheck:CheckShowAlert()

    -- local last_time_mode = PlayerPrefs.GetInt(self.last_time_mode_key)
    -- if last_time_mode == 0 then
    --     self:GetCurrentMode(function(is_strict)  
    --         local current_time_mode = is_strict and 2 or 1
    --         PlayerPrefs.SetInt(self.last_time_mode_key, current_time_mode)
    --         PlayerPrefs.Save()
    --         last_time_mode = current_time_mode
    --         g_Log("【周中学状态管理】 当前时间模式：", current_time_mode, "上一次时间模式：", last_time_mode)
    --         self:CheckModeSwitch(last_time_mode, function(data)
    --             ---下一个时段的模式
    --             local next_time_mode = data.next_time_mode -- 1-自由学，2-严肃学
    --             if next_time_mode == last_time_mode then
    --                 g_Log("【周中学状态管理】上一个时段模式和下一个时段模式相同，不处理")
    --                 return
    --             end
    --             g_Log("【周中学状态管理】 下一个时段的模式：", next_time_mode)
    --             --- 如果下一个时段的模式和当前模式不一致，则需要处理
    --             if data and data.is_continue_open then
    --                 if data.countdown <= 0 then
    --                     if self.taskTimer then
    --                         self.commonService:UnregisterGlobalTimer(self.taskTimer)
    --                         self.taskTimer = nil
    --                     end
    --                     self:ShowAlert(last_time_mode, next_time_mode)
    --                 elseif data.start_counter then
    --                     self:StartTimer(data.countdown, last_time_mode, next_time_mode)
    --                 end
    --             end
    --         end)
    --     end)
    -- else
    --     g_Log("【周中学状态管理】 当前时间模式：", last_time_mode, "上一次时间模式：", last_time_mode)
    --     self:CheckModeSwitch(last_time_mode, function(data)
    --         ---下一个时段的模式
    --         local next_time_mode = data.next_time_mode -- 1-自由学，2-严肃学
    --         if next_time_mode == last_time_mode then
    --             g_Log("【周中学状态管理】上一个时段模式和下一个时段模式相同，不处理")
    --             return
    --         end
    --         g_Log("【周中学状态管理】 下一个时段的模式：", next_time_mode)
    --         --- 如果下一个时段的模式和当前模式不一致，则需要处理
    --         if data and data.is_continue_open then
    --             if data.countdown <= 0 then
    --                 if self.taskTimer then
    --                     self.commonService:UnregisterGlobalTimer(self.taskTimer)
    --                     self.taskTimer = nil
    --                 end
    --                 self:ShowAlert(last_time_mode, next_time_mode)
    --             elseif data.start_counter then
    --                 self:StartTimer(data.countdown, last_time_mode, next_time_mode)
    --             end
    --         end
    --     end)
    -- end
    -- if self.isABCMainPlan or self.isMATHMainPlan then
        if not self.isComleteNewTask then
            g_Log("【周中学状态管理】 新手任务未完成，不处理")
            return
        end
    -- end

    self:GetCurrentMode(function(is_strict)
        -- 根据是否为管制时间判断当前时间模式： 1-自由时段，2-管控时段
        local current_time_mode = is_strict and 2 or 1
        --- 获取上一次本地记录的时间模式
        -- local last_time_mode = PlayerPrefs.GetInt(self.last_time_mode_key)
        -- if last_time_mode == 0 then
        --     ---没有记录的情况 默认给一下当前时段的模式
        --     last_time_mode = current_time_mode
        --     PlayerPrefs.SetInt(self.last_time_mode_key, current_time_mode)
        --     PlayerPrefs.Save()
        -- end
        g_Log("【周中学状态管理】 当前时间模式：", current_time_mode)
        self:CheckModeSwitch(current_time_mode, function(data)
            ---下一个时段的模式
            local next_time_mode = data.next_time_mode -- 1-自由学，2-严肃学
            if next_time_mode == current_time_mode then
                g_Log("【周中学状态管理】上一个时段模式和下一个时段模式相同，不处理")
                return
            end
            g_Log("【周中学状态管理】 下一个时段的模式：", next_time_mode)
            --- 如果下一个时段的模式和当前模式不一致，则需要处理
            if data and data.is_continue_open then
                if data.countdown == -1 then  -- 直接弹出提示
                    if self.taskTimer then
                        self.commonService:UnregisterGlobalTimer(self.taskTimer)
                        self.taskTimer = nil
                    end
                    self:ShowAlert(current_time_mode, next_time_mode)
                elseif data.start_counter then
                    self:StartTimer(data.countdown, current_time_mode, next_time_mode)
                end
            end
        end)
    end)
end

---开始计时
function MidWeekStateCheck:StartTimer(countdown, last_time_mode, next_time_mode)
    if self.taskTimer then
        self.commonService:UnregisterGlobalTimer(self.taskTimer)
        self.taskTimer = nil
    end
    self.taskTimer = self.commonService:RegisterGlobalTimer(1, function()
        if countdown <= 0 then
            self:ShowAlert(last_time_mode, next_time_mode)
            if self.taskTimer then
                self.commonService:UnregisterGlobalTimer(self.taskTimer)
                self.taskTimer = nil
            end
        end
        countdown = countdown - 1
    end, false)
end

function MidWeekStateCheck:ShowAlert(last_time_mode, next_time_mode)
    self:ShowMainPanel(1)
    -- if last_time_mode ~= next_time_mode then
        PlayerPrefs.SetInt(self.last_time_mode_key, next_time_mode)
        PlayerPrefs.Save()
    -- end
end

function MidWeekStateCheck:HideAlert()
    if self.mainPanel then
        self.mainPanel.gameObject:SetActive(false)
    end
    self:OnDestory()
end

---展示主入口的UI
function MidWeekStateCheck:ShowMainPanel(showType)
    self.pageMonitorService:recordPageOpen(PageId,"校园主页面")
    if self.mainPanel then
        self:Show(showType)
        return
    end
    self:LoadRemoteUaddress(uAddress, function(success, prefab)
        if success and prefab then
            if self.prefab then
                ResourceManager:ReleaseObject(self.prefab)
                self.prefab = nil
            end
            self.prefab = prefab
            local obj = GameObject.Instantiate(prefab)
            self.objRoot = obj
            obj.transform:SetParent(self.rootTrans)
            self.mainPanel = obj.transform
            self:InitView(showType)
            self.pageMonitorService:recordPageLoadComplete(PageId)
            self:Show(showType)
        end
    end, true)
end
--- UI
---@param showType number 1:趣味练习时间结束 2:学习时长达到最高时长
function MidWeekStateCheck:Show(showType)
    self.toStudyButton.gameObject:SetActive(showType == 1)
    self.exitButton.gameObject:SetActive(showType == 2)
    self.observerService:Fire("ABCZONE_USER_INFO_ALL", {
        keys = { "userName" },
        callBack = function(data)
            g_Log("gyz = 查询名字:",table.dump(data))
            self.nameTitle.text = data.userName.." 小朋友"
        end
    })
    if showType == 1 then   --- 趣味练习时间结束
        -- self.nameTitle.text = "xxx".." 小朋友"
        self.content.text = "<color=#FFA206>趣味练习</color>时间结束了，接下来要进行<color=#FFA206>严肃学习</color>啦！快去学习吧！"
    elseif showType == 2 then --- 学习时长达到最高时长
        -- self.nameTitle.text = "xxx".." 小朋友"
        self.content.text = "你已学习<color=#FFA206>2小时</color>了，达到了最高学习时长，明天在来学习吧！"
    end
    self.mainPanel.gameObject:SetActive(true)

    self:ReportData("time_switch_show", "【曝光】到达严肃学时间提示弹窗曝光", {}, "0")
end
function MidWeekStateCheck:InitView(showType)
    if self.inited then
        return
    end
    self.inited = true
    local canvasNode = self.mainPanel:FindChildWithName("Canvas")
    local canvas = canvasNode:GetComponentInChildren(typeof(Canvas))
    canvas.sortingOrder = 1000

    local Alert = self.mainPanel:FindChildWithName("Alert")
    if Alert then
        self.nameTitle = Alert:Find("Name_Title"):GetComponent(typeof(TMP))
        self.content = Alert:Find("Content"):GetComponent(typeof(TMP))
        self.toStudyButton = Alert:Find("去严肃学"):GetComponent(typeof(Button))
        self.toStudyButtonText = Alert:Find("去严肃学/Text (TMP)"):GetComponent(typeof(TMP))
        self.toStudyButtonText.text = "去严肃学习"
        self.commonService:AddEventListener(self.toStudyButton, "onClick", function()
            self:OnToStudyButtonClick()
        end)

        self.exitButton = Alert:Find("退出天天练"):GetComponent(typeof(Button))
        self.exitButtonText = Alert:Find("退出天天练/Text (TMP)"):GetComponent(typeof(TMP))
        self.commonService:AddEventListener(self.exitButton, "onClick", function()
            self:OnExitButtonClick()
        end)
        
        if self.isABCZone then
            self.exitButtonText.text = "退出英语天天练"
        elseif self.isMath then
            self.exitButtonText.text = "退出数学天天练"
        end

        self.toStudyButton.gameObject:SetActive(showType == 1)
        self.exitButton.gameObject:SetActive(showType == 2)
        self.observerService:Fire("ABCZONE_USER_INFO_ALL", {
                keys = { "userName" },
                callBack = function(data)
                    g_Log("gyz = 查询名字:",table.dump(data))
                    self.nameTitle.text = data.userName.." 小朋友"
                end
            })
        if showType == 1 then   --- 趣味练习时间结束
                -- self.nameTitle.text = "xxx".." 小朋友"
                self.content.text = "<color=#FFA206>趣味练习</color>时间结束了，接下来要进行<color=#FFA206>严肃学习</color>啦！快去学习吧！"
        elseif showType == 2 then --- 学习时长达到最高时长
                -- self.nameTitle.text = "xxx".." 小朋友"
                self.content.text = "你已学习<color=#FFA206>2小时</color>了，达到了最高学习时长，明天在来学习吧！"
        end
    end
end

function MidWeekStateCheck:OnToStudyButtonClick()
    print("去严肃练习")
    if self.isABCZone or self.isMath then
        if self.isABCMainPlan or self.isMATHMainPlan then
            self.observerService:Fire("EVENT_ABC_ZONE_CHANGE_MODE_TO_STRICT", { needOpen = true })
        else
            App:GameReturn()        
        end
    else
        g_Log("【周中学状态管理】 非ABCZone，不处理")
    end
    self:HideAlert()
    self:ReportData("time_switch_click", "【点击】到达严肃学时间提示弹窗点击", {}, "0")
end

function MidWeekStateCheck:OnExitButtonClick()
    print("退出天天练")
end


function MidWeekStateCheck:OnDestory()
    if self.toStudyButton then
        self.toStudyButton.onClick:RemoveAllListeners()
        self.toStudyButton = nil
    end
    if self.exitButton then
        self.exitButton.onClick:RemoveAllListeners()
        self.exitButton = nil
    end
    if self.objRoot then
        CS.UnityEngine.GameObject.Destroy(self.objRoot)
        self.objRoot = nil
    end
    if self.prefab then
        ResourceManager:ReleaseObject(self.prefab)
        self.prefab = nil
    end
    self.inited = false
    self.mainPanel = nil
    self.pageMonitorService:recordPageClose(PageId)
end

--- 检测是否需要启动定时器或直接提示
----- {
--     "data": {
--     	"next_time_mode": 2, // 1-自由学，2-严肃学
--     	"start_counter": true,// 是否需要开启定时器
--     	"is_continue_open": true, // 新连学是否开启（如果用户老 7 天连学没有结束，那么该值为 false）
--     	"countdown": 539, // 未来 2 小时内需要倒计时的时间单位秒 (<=0 直接改变, >0 计时)
--     },
--     "code": 0,
--     "msg":""
-- }
function MidWeekStateCheck:CheckModeSwitch(current_time_mode, callback)
    local url = self.domain .. "/v3/continue/get-mode-switch"
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041/v3/continue/get-mode-switch"
    end
    if current_time_mode == nil then
        g_Log("【周中学状态管理】 当前模式current_mode == nil")
        return
    end
    local params = {
        current_time_mode = current_time_mode
    }
    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            print("gyz = msg == ", table.dump(msg))
            if msg and msg.code == 0 then
                if msg.data then
                    if callback then
                        callback(msg.data)
                    end
                else
                    g_Log("【周中学状态管理】/v3/continue/get-mode-switch  = 数据code != 0")
                    callback(nil)
                end
            else
                g_Log("【周中学状态管理】/v3/continue/get-mode-switch  data = = nil")
            end
        end
    end
    local fail = function(err)
        if not err then
            err = ""
        end
        if callback then
            callback(nil)
        end
        g_Log("【周中学状态管理】/v3/continue/get-mode-switch  请求失败：", err)
    end
    self:HttpRequest(url, params, success, fail)
end


function MidWeekStateCheck:GetCurrentMode(callback)
    local url = self.domain .. "/v3/continue/get-study-mode-info"
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041/v3/continue/get-study-mode-info"
    end
    local params = {}
    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            print("gyz = msg == ", table.dump(msg))
            if msg and msg.code == 0 then
                if msg.data then
                    -- 是否是严肃学管制时间
                    self.is_strict = msg.data.is_strict
                    if callback then
                        callback(msg.data.is_strict)
                    end
                else
                    g_Log("【周中学状态管理】/v3/continue/get-study-mode-info  = 数据code != 0")
                    callback(false)
                end
            else
                g_Log("【周中学状态管理】/v3/continue/get-study-mode-infodata = = nil")
            end
        end
    end
    local fail = function(err)
        if not err then
            err = ""
        end
        if callback then
            callback(false)
        end
        g_Log("【周中学状态管理】/v3/continue/get-study-mode-info 请求失败：", err)
    end
    self:HttpRequest(url, params, success, fail)
end
---请求接口
function MidWeekStateCheck:HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        if not self.httpService then
            ---@type HttpService
            self.httpService = CourseEnv.ServicesManager:GetHttpService()
        end
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString

                success(resp)
            else
                fail(res)
            end
        end)
    end
end


function MidWeekStateCheck:ReportData(eventId, label, value, action)
    -- self:Print("埋点",eventId, label, action, value)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(eventId, "86904", "Home_2D", label, action, value)
    end
end


-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function MidWeekStateCheck:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function MidWeekStateCheck:SendCustomMessage(key, body)
    self:SendMessage(key,body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function MidWeekStateCheck:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function MidWeekStateCheck:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function MidWeekStateCheck:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function MidWeekStateCheck:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function MidWeekStateCheck:LogicMapStartRecover()
    MidWeekStateCheck.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function MidWeekStateCheck:LogicMapEndRecover()
    MidWeekStateCheck.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function MidWeekStateCheck:LogicMapAllComponentRecoverComplete()
end

--收到Trigger事件
function MidWeekStateCheck:OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function MidWeekStateCheck:OnReceiveGetDataEvent(interfaceId)
    return nil
end

-- 脚本释放
function MidWeekStateCheck:Exit()
    MidWeekStateCheck.super.Exit(self)
    if self.taskTimer then
        self.commonService:UnregisterGlobalTimer(self.taskTimer)
        self.taskTimer = nil
    end
end

return MidWeekStateCheck