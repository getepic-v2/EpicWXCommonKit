---
---  Author: 【王德】
---  AuthorID: 【102030】
---  CreateTime: 【2023-11-3 11:23:03】
--- 【FSync】
--- 【ABC题目管理】
---
---
-- 51: 语音评测题 返回格式
-- "51":[
--     {
--         "id":2629,
--         "style_id":51,
--         "answer": [],
--         "audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_put_my_books_in_my_bag.mp3",
--         "display": "I put my books in my bag.\n我把我的书放进了我的包里。",
--         "style": 51,
--         "text_cn": "我把我的书放进了我的包里。",
--         "text_en": "I put my books in my bag.",
--         "style_ch":"看文字说出内容",
--         "type":"",
--         "kp_id":70,
--         "question_index":0,
--         "passBy":{ "round_id": "ddlhljk" }
--     }
-- ]
-- 54 看图片，选择正确的单词
-- {
-- 	"id": 12968,
-- 	"style_id": 54,
-- 	"style_ch": "看图片，选择正确的单词",
-- 	"type": "",
-- 	"kp_id": 111,
-- 	"question_index": 1,
-- 	"choices": [{
-- 		"text_cn": "n. 胳膊",
-- 		"text_en": "arm"
-- 	}, {
-- 		"text_cn": "pron. 你（们）的",
-- 		"text_en": "your"
-- 	}, {
-- 		"text_cn": "n. 白色 adj. 白色的",
-- 		"text_en": "white"
-- 	}, {
-- 		"text_cn": "num. 三",
-- 		"text_en": "three"
-- 	}],
-- 	"correctIndex": "4",
-- 	"imageUrl": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/three_87980b0e49178f87f91f6e3ad543ab27_1.png"
--   "passBy":{ "round_id": "ddlhljk" }
-- }
-- 100: 听音频选图片
-- "100":[
-- {
--     "id": 1,
-- 	"style_id": 100,
--     "answer": [],
-- 	"options": [{
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/book_1.png"
-- 	}, {
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/book_2.png"
-- 	}, {
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/book_3.png"
-- 	}],
-- 	"stem": {
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/book.mp3",
-- 		"cn_text": "n. 书",
-- 		"phonetic": "/bʊk/",
-- 		"text": "book"
-- 	},
-- 	"style": 100,
--     "type": "",
-- 	"kp_id": 79,
-- 	"question_index": 0,
--   "passBy":{ "round_id": "ddlhljk" }
---}
-- ]
-- 101: 看单词选中文
-- "101":[
-- {
--  "id": 236,
-- 	"style_id": 101,
--  "style": 101,
--  "stem": {
-- 	  "text": "afternoon",
-- 	  "audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/afternoon.mp3"
--   },
--  "answer": ["4"],
--  "options": [{
-- 	 "text": " 再见"
--        }, {
-- 	 "text": " 再见"
--        }, {
-- 	 "text": "嗬"
--        }, {
-- 	 "text": " 下午"
--       }],
--  "style_ch": "看单词选中文",
-- 	"type": "",
-- 	"kp_id": 200,
-- 	"question_index": 0,
--   "passBy":{ "round_id": "ddlhljk" }
-- }
-- ]
-- 102: 看单词选图片 二选一
-- "102":[
-- {
--  "id": 1438,
--  "style_id": 102,
-- 	"answer": ["2"],
-- 	"options": [{
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/how_are_you.mp3",
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/how_are_you.png",
-- 		"text": "phrase. 你好吗? 你好!"
-- 	}, {
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/book.mp3",
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/book.png",
-- 		"text": "n. 书"
-- 	}],
-- 	"parse": [{
-- 		"cn_text": "n. 书",
-- 		"text": "book"
-- 	}],
-- 	"stem": {
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/book.mp3",
-- 		"text": "book"
-- 	},
-- 	"style": 102,
--  "style_ch": "单词二选一",
-- 	"type": "",
-- 	"kp_id": 79,
-- 	"question_index": 0,
--   "passBy":{ "round_id": "ddlhljk" }
-- }
-- ]
-- 103: 看单词选图片 四选一
-- "103":[
-- {
--     "id": 2794,
--     "style_id": 103,
--     "answer": ["4"],
-- 	"options": [{
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/yes.mp3",
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/yes.png",
-- 		"text": "adv. 是，是的"
-- 	}, {
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_m.mp3",
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/i_m.png",
-- 		"text": "abbr. 我是（=I am）"
-- 	}, {
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i.mp3",
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/i.png",
-- 		"text": "pron. 我"
-- 	}, {
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/bag.mp3",
-- 		"image": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/img/book/bag.png",
-- 		"text": "n. 包"
-- 	}],
-- 	"parse": [{
-- 		"cn_text": "n. 包",
-- 		"text": "bag"
-- 	}],
-- 	"stem": {
-- 		"audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/bag.mp3",
-- 		"text": "bag"
-- 	},
-- 	"style": 103
--     "style_ch": "单词四选一",
-- 	"type": "",
-- 	"kp_id": 70,
-- 	"question_index": 0,
--   "passBy":{ "round_id": "ddlhljk" }
-- }
-- ]
-- 105: 分音节组词
-- "105":[
--     {
--         "id": 9,
-- 		"style_id": 105,
--         "answer": ["p", "en"],
--         "options": ["en", "co", "p", "qui"],
--         "parse": [{
--             "cn_text": "n. 钢笔",
--             "text": "pen"
--         }],
--         "question": ["#", "#"],
--         "stem": {
--             "audio": "https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/pen.mp3",
--             "cn_text": "n. 钢笔",
--             "phonetic": "/pen/",
--             "text": "pen"
--         },
--         "style": 105,
--         "style_ch": "分音节组词",
-- 		"type": "",
-- 		"kp_id": 82,
-- 		"question_index": 0,
--       "passBy":{ "round_id": "ddlhljk" }
--     }
-- ]
----\\
-----------------------使用方法---------------------------------------------
-- self.observerService:Fire("EVENT_ABCZONE_QUESTION_MANATER",
--     {
--         params = { { qType = 51, qCount = 1 }, { qType = 100, qCount = 10 }, { qType = 101, qCount = 1 } },
--         callBack = function(questions)
--             for k, v in pairs(questions) do
--                 print("题目类型：" .. k)
--                 for i, j in ipairs(v) do
--                     print("题目：" .. i)
--                     print(table.dump(j))
--                 end
--             end
--         end
--     })
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class QuestionManager : WorldBaseElement
local QuestionManager = class("QuestionManager", WBElement)
local TAG = "ABC题目管理"
local fsync_activateRoom = "activateRoom"
local EVENT_ABCZONE_QUESTION_MANATER = "EVENT_ABCZONE_QUESTION_MANATER"
---@param worldElement CS.Tal.framesync.WorldElement
function QuestionManager:initialize(worldElement)
    QuestionManager.super.initialize(self, worldElement)
    self:SubscribeMsgKey(fsync_activateRoom)
    -- 订阅KEY消息
    self.maxCount = 0
    self.reTryCount = 2
    self.questionList = {}
    self.questionTypeIndex = {}
    self.questionType = {}
    self:_InitService()
    self.questionType["51"] = {
        questionCount = 40,
        questionType = 51
    }
    self.questionTypeIndex["51"] = 0
    -- self:_backQuestion()
    self.requestList = {}
    self.requesting = false
    self.lastRewardCount = 0

    self.observerService:Watch(EVENT_ABCZONE_QUESTION_MANATER, function(key, value)
        local data = value[0]
        if self.hasRequest then
            self:_doCallBackQuestion(data, {})
        else
            self.commonService:StartCoroutine(function()
                self.commonService:Yield(self.commonService:WaitUntil(function()
                    return self.hasRequest
                end))
                self:_doCallBackQuestion(data, {})
            end)
        end
    end)

    self.observerService:Watch("on_read_book_success", function(key, value)
        self.lastRewardCount = self.lastRewardCount - 1
        if self.lastRewardCount < 0 then
            self.lastRewardCount = 0
        else
            self.observerService:Fire("add_diamond_from_read", {
                addDiamond = 1,
            })
        end
        self:Print("on_read_book_success 剩余奖励次数：" .. self.lastRewardCount)
        self.observerService:Fire("on_change_last_reward_count", {
            count = self.lastRewardCount
        })
    end)

    self.observerService:Watch("EVENT_ABCZONE_GET_ALL_QUESTION", function(key, value)
        local data = value[0]
        self.commonService:StartCoroutine(function()
            self.commonService:Yield(self.commonService:WaitUntil(function()
                return self.hasRequest
            end))
            ---延一帧等处理完数据后再回调
            self.commonService:YieldEndFrame()
            data.callback(self.questionList)
        end)
    end)

    ---监听教材变化 重新刷新接口
    self.observerService:Watch("EVENT_ABCZONE_NOTICE_CHANGE_BOOK", function(key, value)
        local data = value[0]
        if data.changed then
            g_Log(TAG, "教材变化重新请求接口")
            self.questionList = {}
            self:SetConfig(self.questionTypeList, 0)
        end
    end)

    -- 获取预告题目内容
    self.observerService:Watch("EVENT_ABCZONE_GET_FORECAST_QUESTION", function(key, value)
        local data = value[0]
        local questionIndex = data.questionIndex
        local callback = data.callback
        if self.questionList["51"][questionIndex] then
            if callback then
                callback(self.questionList["51"][questionIndex])
            end
        end
    end)
end

function QuestionManager:SetConfig(questionTypeList, activeQuestionType)
    if questionTypeList then
        self.questionTypeList = questionTypeList
        for i, v in ipairs(questionTypeList) do
            local questionType = tonumber(v.questionType)
            local questionCount = tonumber(v.questionCount)
            if questionCount > self.maxCount then
                self.maxCount = questionCount
            end
            self.questionType[tostring(questionType)] = {
                questionCount = questionCount,
                questionType = questionType
            }
            self.questionTypeIndex[tostring(questionType)] = 0
        end
    else
        self.questionType["51"] = {
            questionCount = 40,
            questionType = 51
        }
        self.questionTypeIndex["51"] = 0
    end
    if activeQuestionType then
        self.activeQuestionType = activeQuestionType
    else
        self.activeQuestionType = 1
    end
    self:_getQuestions(self.questionType)
end
function QuestionManager:Print(str)
    g_Log(TAG .. str)
end
function QuestionManager:_doCallBackQuestion(data, callBackQuestions)
    self:Print(string.format("_doCallBackQuestion开始执行，当前requestList长度: %d", #self.requestList))
    local params = data.params
    -- local questionCount = data.questionCount
    local callBack = data.callBack
    local hasAllData = true

    local questionTypes = {}
    for _, v in ipairs(params) do
        local questionType = tostring(v.qType)
        local questionCount = v.qCount
        local questions = self.questionList[questionType]
        local index = self.questionTypeIndex[questionType]

        if not questions then
            questionTypes[questionType] = self.questionType[questionType]
            hasAllData = false
            self:Print(string.format("题目类型 %s 缺少数据，hasAllData设为false", questionType))
        else
            if index + questionCount > #questions then
                questionTypes[questionType] = self.questionType[questionType]
                hasAllData = false
                self:Print(string.format(
                    "题目类型 %s 数量不足(需要:%d,现有:%d,索引:%d)，hasAllData设为false", questionType,
                    questionCount, #questions, index))
            else
                if not callBackQuestions[questionType] then
                    callBackQuestions[questionType] = {}
                    for i = index + 1, index + questionCount do
                        table.insert(callBackQuestions[questionType], questions[i])
                    end
                    -- g_Log(TAG, table.dump(callBackQuestions[questionType]))

                    self.questionTypeIndex[questionType] = index + questionCount
                    self:Print(string.format("题目类型 %s 成功获取 %d 道题目，更新索引到 %d",
                        questionType, questionCount, self.questionTypeIndex[questionType]))
                end
            end
        end
    end
    if not hasAllData then
        self.businessNeedQuestion = true
        table.insert(self.requestList, data)
        self:Print(string.format(
            "数据不全，将请求添加到requestList，当前长度: %d，准备调用_getQuestions",
            #self.requestList))
        self:_getQuestions(questionTypes, data, callBackQuestions)
    else
        self:Print("所有数据准备完毕，hasAllData=true")
    end
    if callBack and hasAllData then
        self:Print("执行回调函数")
        callBack(callBackQuestions)
    end
end

function QuestionManager:_InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function QuestionManager:ReceiveMessage(key, value, isResume)
    -- TODO:
    -- if key == fsync_activateRoom then
    --     local lastMsg = value[#value]
    --     if lastMsg and not self.activeQuestionType then
    --         g_Log(TAG, "activateRoom " .. lastMsg)
    --         local msg = self.jsonService:decode(lastMsg)
    --         if msg and msg.question_type then
    --             self.activeQuestionType = tonumber(msg.question_type)
    --         else
    --             self.activeQuestionType = 0
    --         end

    --     end
    -- end
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function QuestionManager:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionManager:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionManager:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionManager:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function QuestionManager:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function QuestionManager:LogicMapStartRecover()
    QuestionManager.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)_backQuestion
function QuestionManager:LogicMapEndRecover()
    QuestionManager.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function QuestionManager:LogicMapAllComponentRecoverComplete()

end

-- 收到Trigger事件
function QuestionManager:OnReceiveTriggerEvent(interfaceId)
end

-- 收到GetData事件
function QuestionManager:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------
function QuestionManager:_getQuestions(questionsTypes, data, callBackQuestions)
    self:Print(string.format("_getQuestions开始执行，requesting状态: %s，当前requestList长度: %d",
        tostring(self.requesting), #self.requestList))
    if self.requesting then
        self:Print("已经在请求中，直接返回")
        return
    end
    self.requesting = true
    self:Print("设置requesting=true，开始网络请求")
    self.domain = "https://app.chuangjing.com/abc-api"
    local url = self.domain .. "/v3/book/get-game-question"
    if App.IsStudioClient then
        url = "http://yapi.xesv5.com/mock/2041/v3/book/get-game-question"
    end
    local info = {}
    for i, v in pairs(questionsTypes) do
        table.insert(info, {
            style_id = v.questionType,
            num = v.questionCount
        })
    end
    local params = {
        info = info
    }

    if self.activeQuestionType == 1 then
        url = self.domain .. "/v3/book-article/get-article-question"
        if App.IsStudioClient then
            url = "http://yapi.xesv5.com/mock/2041/v3/book-article/get-article-question"
        end
        params = {
            style_id = 52,
            backup_style_id = 51,
            num = questionsTypes["51"].questionCount
        }
    end

    local success = function(resp)
        self:Print("收到网络请求成功回调")
        self.requesting = false
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                if msg.data then
                    -- if self.businessNeedQuestion and not data then
                    --     g_Log(TAG, "重复请求")
                    --     return
                    -- end
                    self.businessNeedQuestion = false
                    self.hasRequest = true
                    self.reTryCount = 2
                    local qList = msg.data.game_list
                    ---读课文模式
                    if self.activeQuestionType == 1 then
                        local list = msg.data.list
                        xpcall(function()
                            self.lastRewardCount = msg.data.remain_get or 9999
                            self.observerService:Fire("on_change_last_reward_count", {
                                count = self.lastRewardCount
                            })
                        end, function(err)
                            g_LogError(err)
                        end)
                        qList = {}
                        qList["51"] = {
                            list = list
                        }
                    end
                    if not qList then
                        return
                    end
                    g_Log(TAG, "处理数据")
                    for k, v in pairs(qList) do
                        local questionsType = k
                        if not self.questionList[tostring(questionsType)] then
                            self.questionList[tostring(questionsType)] = {}
                        end
                        -- local oddElements = {}
                        -- local evenElements = {}
                        for _, m in ipairs(v.list) do
                            local content = m.content
                            if content and type(content) == "string" then
                                m.content = self.jsonService:decode(content)
                                for key, n in pairs(m.content) do
                                    m[key] = n
                                end
                            elseif not content then
                                m.style_id = questionsType
                            end
                            m.book_id = msg.data.book_id
                            if msg.data.round_id then
                                m.round_id = msg.data.round_id
                            end
                            m.level_no = msg.data.level_no
                            -- 透传给答题接口的字段
                            local passBy = {}
                            passBy["round_id"] = m.round_id
                            passBy["book_id"] = msg.data.book_id
                            passBy["question_index"] = m.question_index
                            passBy["question_sort_no"] = m.question_sort_no
                            m.activeQuestionType = self.activeQuestionType
                            m.passBy = passBy
                            m.content = nil
                            -- if _ % 2 == 0 then
                            --     table.insert(evenElements, m)
                            -- else
                            --     table.insert(oddElements, m)
                            -- end
                            if not self.ReportArticle then
                                self.ReportArticle = true
                                ---如果第一道题是52类型 就是读课文模式
                                if tostring(m.style_id) == '52' then
                                    self:reportData("game_read_book_get_article_question", "读课文模式拉题", {},
                                        "0")
                                else
                                    self:reportData("game_read_book_get_article_question", "读句子模式拉题", {},
                                        "1")
                                end
                            end
                            table.insert(self.questionList[tostring(questionsType)], m)
                        end
                        -- for i, m in ipairs(oddElements) do
                        --     table.insert(self.questionList[tostring(questionsType)], m)
                        --     -- g_Log(TAG, table.dump(self.questionList[tostring(questionsType)]))
                        -- end
                        -- for i, m in ipairs(evenElements) do
                        --     table.insert(self.questionList[tostring(questionsType)], m)
                        -- end
                    end
                    if self.requestList and #self.requestList > 0 then
                        self:Print(string.format("success回调：准备处理requestList，当前长度: %d",
                            #self.requestList))
                        local loopCount = 0
                        local maxLoops = 100 -- 防止死循环的最大循环次数
                        while #self.requestList > 0 and loopCount < maxLoops do
                            loopCount = loopCount + 1
                            self:Print(string.format("while循环第 %d 次，requestList长度: %d", loopCount,
                                #self.requestList))
                            local requestData = table.remove(self.requestList, 1)
                            self:Print(string.format("移除一个请求后，requestList长度: %d", #self.requestList))
                            self:_doCallBackQuestion(requestData, {})
                        end
                        if loopCount >= maxLoops then
                            self:Print(string.format(
                                "警告：while循环达到最大次数限制(%d)，强制退出防止死循环",
                                maxLoops))
                            self.requestList = {} -- 清空列表防止问题持续
                        end
                        self:Print(
                            string.format("success回调：requestList处理完毕，循环次数: %d", loopCount))
                    elseif data then
                        self:Print("success回调：没有requestList，直接处理data")
                        self:_doCallBackQuestion(data, callBackQuestions)
                    end
                end
            else
                g_Log(TAG, "获取题目失败" .. (2 - self.reTryCount))
                local interval = 3
                if App.IsStudioClient then
                    interval = 0.1
                end
                self.commonService:DispatchAfter(interval, function()
                    self.reTryCount = self.reTryCount - 1
                    if self.reTryCount > 0 then
                        self:_getQuestions(questionsTypes, data, callBackQuestions)
                    else
                        self:_backQuestion()
                        if self.requestList and #self.requestList > 0 then
                            self:Print(string.format("fail回调：准备处理requestList，当前长度: %d",
                                #self.requestList))
                            local loopCount = 0
                            local maxLoops = 100 -- 防止死循环的最大循环次数
                            while #self.requestList > 0 and loopCount < maxLoops do
                                loopCount = loopCount + 1
                                self:Print(string.format("fail回调while循环第 %d 次，requestList长度: %d",
                                    loopCount, #self.requestList))
                                local requestData = table.remove(self.requestList, 1)
                                self:Print(string.format("fail回调移除一个请求后，requestList长度: %d",
                                    #self.requestList))
                                self:_doCallBackQuestion(requestData, {})
                            end
                            if loopCount >= maxLoops then
                                self:Print(string.format(
                                    "fail回调警告：while循环达到最大次数限制(%d)，强制退出防止死循环",
                                    maxLoops))
                                self.requestList = {} -- 清空列表防止问题持续
                            end
                            self:Print(string.format("fail回调：requestList处理完毕，循环次数: %d",
                                loopCount))
                        elseif data then
                            self:Print("fail回调：没有requestList，直接处理data")
                            self:_doCallBackQuestion(data, callBackQuestions)
                        end
                    end
                end)
            end
        end
    end
    local fail = function(err)
        self:Print("收到网络请求失败回调")
        self.requesting = false
        if not err then
            err = ""
        end
        if type(err) == "table" then
            err = table.dump(err)
        end
        g_Log(TAG, err .. " 获取题目失败 fail " .. (2 - self.reTryCount))

        local interval = 3
        if App.IsStudioClient then
            interval = 0.1
        end

        self.commonService:DispatchAfter(interval, function()
            if self.reTryCount > 0 then
                self:_getQuestions(questionsTypes, data, callBackQuestions)
            else
                self:_backQuestion()
                if self.requestList and #self.requestList > 0 then
                    self:Print(string.format("fail回调：准备处理requestList，当前长度: %d",
                        #self.requestList))
                    local loopCount = 0
                    local maxLoops = 100 -- 防止死循环的最大循环次数
                    while #self.requestList > 0 and loopCount < maxLoops do
                        loopCount = loopCount + 1
                        self:Print(string.format("fail回调while循环第 %d 次，requestList长度: %d", loopCount,
                            #self.requestList))
                        local requestData = table.remove(self.requestList, 1)
                        self:Print(string.format("fail回调移除一个请求后，requestList长度: %d",
                            #self.requestList))
                        self:_doCallBackQuestion(requestData, {})
                    end
                    if loopCount >= maxLoops then
                        self:Print(string.format(
                            "fail回调警告：while循环达到最大次数限制(%d)，强制退出防止死循环",
                            maxLoops))
                        self.requestList = {} -- 清空列表防止问题持续
                    end
                    self:Print(string.format("fail回调：requestList处理完毕，循环次数: %d", loopCount))
                elseif data then
                    self:Print("fail回调：没有requestList，直接处理data")
                    self:_doCallBackQuestion(data, callBackQuestions)
                end
            end
            self.reTryCount = self.reTryCount - 1
        end)
    end
    self.hasReport = true
    self:_HttpRequest(url, params, success, fail)
end

-- function QuestionManager:randomQuestions()
--     for i = self.questionIndex, #self.questionList do
--         local index = math.random(self.questionIndex, #self.questionList)
--         self.questionList[i], self.questionList[index] = self.questionList[index], self.questionList[i]
--     end
-- end

function QuestionManager:_HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

function QuestionManager:_backQuestion()
    self.businessNeedQuestion = false
    self.hasRequest = true
    self.reTryCount = 2
    g_Log(TAG, "使用备用题库")
    if not self.questionList["51"] then
        self.questionList["51"] = {}
    end

    local backupString =
        "[{\"id\":2582,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/how_old_are_you.mp3\",\"display\":\"How old are you?\\n你多大了？\",\"indexArray\":\"[[0, 2]]\",\"style\":51,\"text_cn\":\"你多大了？\",\"text_en\":\"How old are you?\",\"word\":\"how\",\"word_cn\":\"adv. 多少\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":302,\"question_index\":1,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19298,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/no_problem.mp3\",\"display\":\"No problem.\\n没问题。\",\"indexArray\":\"[[0, 1]]\",\"style\":51,\"text_cn\":\"没问题。\",\"text_en\":\"No problem.\",\"word\":\"no\",\"word_cn\":\"adv. 不，不是\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":9,\"question_index\":2,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19253,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/no_thanks.mp3\",\"display\":\"No, thanks.\\n不，谢谢。\",\"indexArray\":\"[[0, 1]]\",\"style\":51,\"text_cn\":\"不，谢谢。\",\"text_en\":\"No, thanks.\",\"word\":\"no\",\"word_cn\":\"adv. 不，不是\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":9,\"question_index\":3,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19290,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_yellow.mp3\",\"display\":\"It's yellow.\\n它是黄色的。\",\"indexArray\":\"[[5, 10]]\",\"style\":51,\"text_cn\":\"它是黄色的。\",\"text_en\":\"It's yellow.\",\"word\":\"yellow\",\"word_cn\":\"n. 黄色，adj. 黄色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":68,\"question_index\":4,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":18706,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_see_what.mp3\",\"display\":\"I see what.\\n我看到了什么。\",\"indexArray\":\"[[6, 9]]\",\"style\":51,\"text_cn\":\"我看到了什么。\",\"text_en\":\"I see what.\",\"word\":\"what\",\"word_cn\":\"pron. 什么\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":34,\"question_index\":5,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":8585,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/four_cats.mp3\",\"display\":\"Four cats.\\n四只猫。\",\"indexArray\":\"[[0, 3]]\",\"style\":51,\"text_cn\":\"四只猫。\",\"text_en\":\"Four cats.\",\"word\":\"four\",\"word_cn\":\"num. 四\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":102,\"question_index\":6,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19302,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_green.mp3\",\"display\":\"It's green.\\n它是绿色的。\",\"indexArray\":\"[[5, 9]]\",\"style\":51,\"text_cn\":\"它是绿色的。\",\"text_en\":\"It's green.\",\"word\":\"green\",\"word_cn\":\"n. 绿色 adj. 绿色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":58,\"question_index\":7,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":8700,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/yes_i_do.mp3\",\"display\":\"Yes, I do.\\n是的，我愿意。\",\"indexArray\":\"[[0, 2]]\",\"style\":51,\"text_cn\":\"是的，我愿意。\",\"text_en\":\"Yes, I do.\",\"word\":\"yes\",\"word_cn\":\"adv. 是，是的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":13,\"question_index\":8,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":8639,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_see_you.mp3\",\"display\":\"I see you.\\n我看见你了。\",\"indexArray\":\"[[6, 8]]\",\"style\":51,\"text_cn\":\"我看见你了。\",\"text_en\":\"I see you.\",\"word\":\"you\",\"word_cn\":\"pron. 你，你们\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":14,\"question_index\":9,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19281,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_blue.mp3\",\"display\":\"It's blue.\\n它是蓝色的。\",\"indexArray\":\"[[5, 8]]\",\"style\":51,\"text_cn\":\"它是蓝色的。\",\"text_en\":\"It's blue.\",\"word\":\"blue\",\"word_cn\":\"n. 蓝色，adj.蓝色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":54,\"question_index\":10,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":19255,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_monkey.mp3\",\"display\":\"A monkey.\\n一个猴子。\",\"indexArray\":\"[[2, 7]]\",\"style\":51,\"text_cn\":\"一个猴子。\",\"text_en\":\"A monkey.\",\"word\":\"monkey\",\"word_cn\":\"n. 猴子\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":91,\"question_index\":11,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":18661,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/are_you_happy.mp3\",\"display\":\"Are you happy?\\n你开心吗？\",\"indexArray\":\"[[0, 2]]\",\"style\":51,\"text_cn\":\"你开心吗？\",\"text_en\":\"Are you happy?\",\"word\":\"are\",\"word_cn\":\"aux. v. 是\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":115,\"question_index\":12,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19278,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_black.mp3\",\"display\":\"It's black.\\n它是黑色的。\",\"indexArray\":\"[[5, 9]]\",\"style\":51,\"text_cn\":\"它是黑色的。\",\"text_en\":\"It's black.\",\"word\":\"black\",\"word_cn\":\"n. 黑色; adj.黑色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":53,\"question_index\":13,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":18724,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/how_is_she.mp3\",\"display\":\"How is she?\\n她怎么样？\",\"indexArray\":\"[[0, 2]]\",\"style\":51,\"text_cn\":\"她怎么样？\",\"text_en\":\"How is she?\",\"word\":\"how\",\"word_cn\":\"adv. 多少\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":302,\"question_index\":14,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19292,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_tiger.mp3\",\"display\":\"A tiger.\\n一只老虎。\",\"indexArray\":\"[[2, 6]]\",\"style\":51,\"text_cn\":\"一只老虎。\",\"text_en\":\"A tiger.\",\"word\":\"tiger\",\"word_cn\":\"n. 老虎\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":199,\"question_index\":15,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":19236,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_blue_colour.mp3\",\"display\":\"It's blue colour.\\n它是蓝色的。\",\"indexArray\":\"[[10, 15]]\",\"style\":51,\"text_cn\":\"它是蓝色的。\",\"text_en\":\"It's blue colour.\",\"word\":\"colour\",\"word_cn\":\"n. 颜色\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":56,\"question_index\":16,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":18835,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/she_is_happy.mp3\",\"display\":\"She is happy.\\n她很高兴。\",\"indexArray\":\"[[4, 5]]\",\"style\":51,\"text_cn\":\"她很高兴。\",\"text_en\":\"She is happy.\",\"word\":\"is\",\"word_cn\":\"aux. v. 是（be的第三人称单数形式）\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":26,\"question_index\":17,\"level_no\":2,\"is_first\":0,\"book_id\":13},{\"id\":19274,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_pear.mp3\",\"display\":\"A pear.\\n一个梨。\",\"indexArray\":\"[[2, 5]]\",\"style\":51,\"text_cn\":\"一个梨。\",\"text_en\":\"A pear.\",\"word\":\"pear\",\"word_cn\":\"n. 梨\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":500,\"question_index\":18,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19319,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_a_monkey.mp3\",\"display\":\"It's a monkey.\\n这是一只猴子。\",\"indexArray\":\"[[7, 12]]\",\"style\":51,\"text_cn\":\"这是一只猴子。\",\"text_en\":\"It's a monkey.\",\"word\":\"monkey\",\"word_cn\":\"n. 猴子\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":91,\"question_index\":19,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":19295,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_banana.mp3\",\"display\":\"A banana.\\n一根香蕉。\",\"indexArray\":\"[[2, 7]]\",\"style\":51,\"text_cn\":\"一根香蕉。\",\"text_en\":\"A banana.\",\"word\":\"banana\",\"word_cn\":\"n. 香蕉\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":258,\"question_index\":20,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19247,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_apple.mp3\",\"display\":\"It's apple.\\n这是苹果。\",\"indexArray\":\"[[5, 9]]\",\"style\":51,\"text_cn\":\"这是苹果。\",\"text_en\":\"It's apple.\",\"word\":\"apple\",\"word_cn\":\"n. 苹果\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":257,\"question_index\":21,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19294,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/how_many_pencils.mp3\",\"display\":\"How many pencils?\\n有多少铅笔？\",\"indexArray\":\"[[4, 7]]\",\"style\":51,\"text_cn\":\"有多少铅笔？\",\"text_en\":\"How many pencils?\",\"word\":\"many\",\"word_cn\":\"adj. 多的，许多的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":104,\"question_index\":22,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19277,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/how_many_books.mp3\",\"display\":\"How many books?\\n多少本书？\",\"indexArray\":\"[[0, 2]]\",\"style\":51,\"text_cn\":\"多少本书？\",\"text_en\":\"How many books?\",\"word\":\"how\",\"word_cn\":\"adv. 多少\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":302,\"question_index\":23,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":8540,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_a_tiger.mp3\",\"display\":\"It's a tiger.\\n这是一只老虎。\",\"indexArray\":\"[[7, 11]]\",\"style\":51,\"text_cn\":\"这是一只老虎。\",\"text_en\":\"It's a tiger.\",\"word\":\"tiger\",\"word_cn\":\"n. 老虎\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":199,\"question_index\":24,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":19239,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_a_pear.mp3\",\"display\":\"It's a pear.\\n这是一个梨。\",\"indexArray\":\"[[7, 10]]\",\"style\":51,\"text_cn\":\"这是一个梨。\",\"text_en\":\"It's a pear.\",\"word\":\"pear\",\"word_cn\":\"n. 梨\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":500,\"question_index\":25,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19002,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/many_books.mp3\",\"display\":\"many books\\n许多书\",\"indexArray\":\"[[0, 3]]\",\"style\":51,\"text_cn\":\"许多书\",\"text_en\":\"many books\",\"word\":\"many\",\"word_cn\":\"adj. 多的，许多的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":104,\"question_index\":26,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19238,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_orange.mp3\",\"display\":\"It's orange.\\n它是橙色的。\",\"indexArray\":\"[[5, 10]]\",\"style\":51,\"text_cn\":\"它是橙色的。\",\"text_en\":\"It's orange.\",\"word\":\"orange\",\"word_cn\":\"n. 柑橘，橙\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":65,\"question_index\":27,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19310,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_a_banana.mp3\",\"display\":\"It's a banana.\\n这是一根香蕉。\",\"indexArray\":\"[[7, 12]]\",\"style\":51,\"text_cn\":\"这是一根香蕉。\",\"text_en\":\"It's a banana.\",\"word\":\"banana\",\"word_cn\":\"n. 香蕉\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":258,\"question_index\":28,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19234,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_happy_face.mp3\",\"display\":\"A happy face.\\n一张快乐的脸。\",\"indexArray\":\"[[8, 11]]\",\"style\":51,\"text_cn\":\"一张快乐的脸。\",\"text_en\":\"A happy face.\",\"word\":\"face\",\"word_cn\":\"n. 脸\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":165,\"question_index\":29,\"level_no\":2,\"is_first\":0,\"book_id\":13},{\"id\":19231,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_red.mp3\",\"display\":\"It's red.\\n它是红色的。\",\"indexArray\":\"[[5, 7]]\",\"style\":51,\"text_cn\":\"它是红色的。\",\"text_en\":\"It's red.\",\"word\":\"red\",\"word_cn\":\"n. 红色，adj.红色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":66,\"question_index\":30,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":19320,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/she_has_no_idea.mp3\",\"display\":\"She has no idea.\\n她毫无头绪。\",\"indexArray\":\"[[8, 9]]\",\"style\":51,\"text_cn\":\"她毫无头绪。\",\"text_en\":\"She has no idea.\",\"word\":\"no\",\"word_cn\":\"adv. 不，不是\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":9,\"question_index\":31,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19289,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_cat.mp3\",\"display\":\"A cat.\\n一只猫。\",\"indexArray\":\"[[2, 4]]\",\"style\":51,\"text_cn\":\"一只猫。\",\"text_en\":\"A cat.\",\"word\":\"cat\",\"word_cn\":\"n. 猫\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":55,\"question_index\":32,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":8516,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_a_nose.mp3\",\"display\":\"It's a nose.\\n这是一个鼻子。\",\"indexArray\":\"[[7, 10]]\",\"style\":51,\"text_cn\":\"这是一个鼻子。\",\"text_en\":\"It's a nose.\",\"word\":\"nose\",\"word_cn\":\"n. 鼻子\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":171,\"question_index\":33,\"level_no\":2,\"is_first\":0,\"book_id\":13},{\"id\":19340,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/ten_please.mp3\",\"display\":\"Ten, please.\\n请给我十个。\",\"indexArray\":\"[[0, 2]]\",\"style\":51,\"text_cn\":\"请给我十个。\",\"text_en\":\"Ten, please.\",\"word\":\"ten\",\"word_cn\":\"num. 十\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":110,\"question_index\":34,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19031,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_nine_pens.mp3\",\"display\":\"I have nine pens.\\n我有九支笔。\",\"indexArray\":\"[[7, 10]]\",\"style\":51,\"text_cn\":\"我有九支笔。\",\"text_en\":\"I have nine pens.\",\"word\":\"nine\",\"word_cn\":\"num.九\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":105,\"question_index\":35,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19215,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_four_books.mp3\",\"display\":\"I have four books.\\n我有四本书。\",\"indexArray\":\"[[7, 10]]\",\"style\":51,\"text_cn\":\"我有四本书。\",\"text_en\":\"I have four books.\",\"word\":\"four\",\"word_cn\":\"num. 四\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":102,\"question_index\":36,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19288,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_four_pencils.mp3\",\"display\":\"I have four pencils.\\n我有四支铅笔。\",\"indexArray\":\"[[7, 10]]\",\"style\":51,\"text_cn\":\"我有四支铅笔。\",\"text_en\":\"I have four pencils.\",\"word\":\"four\",\"word_cn\":\"num. 四\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":102,\"question_index\":37,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19202,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_like_blue_colour.mp3\",\"display\":\"I like blue colour.\\n我喜欢蓝色。\",\"indexArray\":\"[[12, 17]]\",\"style\":51,\"text_cn\":\"我喜欢蓝色。\",\"text_en\":\"I like blue colour.\",\"word\":\"colour\",\"word_cn\":\"n. 颜色\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":56,\"question_index\":38,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":18686,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/you_are_here.mp3\",\"display\":\"You are here.\\n你在这里。\",\"indexArray\":\"[[0, 2]]\",\"style\":51,\"text_cn\":\"你在这里。\",\"text_en\":\"You are here.\",\"word\":\"you\",\"word_cn\":\"pron. 你，你们\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":14,\"question_index\":39,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19269,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/nine_pencils.mp3\",\"display\":\"Nine pencils.\\n九支铅笔。\",\"indexArray\":\"[[0, 3]]\",\"style\":51,\"text_cn\":\"九支铅笔。\",\"text_en\":\"Nine pencils.\",\"word\":\"nine\",\"word_cn\":\"num.九\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":105,\"question_index\":40,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19249,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_teacher.mp3\",\"display\":\"A teacher.\\n一个老师。\",\"indexArray\":\"[[2, 8]]\",\"style\":51,\"text_cn\":\"一个老师。\",\"text_en\":\"A teacher.\",\"word\":\"teacher\",\"word_cn\":\"n. 教师\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":76,\"question_index\":41,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":19229,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_a_cat.mp3\",\"display\":\"It's a cat.\\n这是一只猫。\",\"indexArray\":\"[[7, 9]]\",\"style\":51,\"text_cn\":\"这是一只猫。\",\"text_en\":\"It's a cat.\",\"word\":\"cat\",\"word_cn\":\"n. 猫\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":55,\"question_index\":42,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":18921,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_two_dogs.mp3\",\"display\":\"I have two dogs.\\n我有两只狗。\",\"indexArray\":\"[[7, 9]]\",\"style\":51,\"text_cn\":\"我有两只狗。\",\"text_en\":\"I have two dogs.\",\"word\":\"two\",\"word_cn\":\"num.二\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":112,\"question_index\":43,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19257,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_my_mouth.mp3\",\"display\":\"It's my mouth.\\n这是我的嘴巴。\",\"indexArray\":\"[[8, 12]]\",\"style\":51,\"text_cn\":\"这是我的嘴巴。\",\"text_en\":\"It's my mouth.\",\"word\":\"mouth\",\"word_cn\":\"n. 嘴巴\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":170,\"question_index\":44,\"level_no\":2,\"is_first\":0,\"book_id\":13},{\"id\":19161,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_ten_cats.mp3\",\"display\":\"I have ten cats.\\n我有十只猫。\",\"indexArray\":\"[[7, 9]]\",\"style\":51,\"text_cn\":\"我有十只猫。\",\"text_en\":\"I have ten cats.\",\"word\":\"ten\",\"word_cn\":\"num. 十\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":110,\"question_index\":45,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":18636,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/is_the_flower_yellow.mp3\",\"display\":\"Is the flower yellow?\\n这朵花是黄色的吗？\",\"indexArray\":\"[[14, 19]]\",\"style\":51,\"text_cn\":\"这朵花是黄色的吗？\",\"text_en\":\"Is the flower yellow?\",\"word\":\"yellow\",\"word_cn\":\"n. 黄色，adj. 黄色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":68,\"question_index\":46,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":19316,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_six_pencils.mp3\",\"display\":\"I have six pencils.\\n我有六支铅笔。\",\"indexArray\":\"[[7, 9]]\",\"style\":51,\"text_cn\":\"我有六支铅笔。\",\"text_en\":\"I have six pencils.\",\"word\":\"six\",\"word_cn\":\"num.六\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":108,\"question_index\":47,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19258,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_black_cat.mp3\",\"display\":\"A black cat.\\n一只黑猫。\",\"indexArray\":\"[[2, 6]]\",\"style\":51,\"text_cn\":\"一只黑猫。\",\"text_en\":\"A black cat.\",\"word\":\"black\",\"word_cn\":\"n. 黑色; adj.黑色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":53,\"question_index\":48,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":19020,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/do_you_eat.mp3\",\"display\":\"Do you eat?\\n你吃饭了吗？\",\"indexArray\":\"[[0, 1]]\",\"style\":51,\"text_cn\":\"你吃饭了吗？\",\"text_en\":\"Do you eat?\",\"word\":\"do\",\"word_cn\":\"aux. v. 做（助动词）\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":372,\"question_index\":49,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":2465,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_like_apples.mp3\",\"display\":\"I like apples.\\n我喜欢苹果。\",\"indexArray\":\"[[0, 0]]\",\"style\":51,\"text_cn\":\"我喜欢苹果。\",\"text_en\":\"I like apples.\",\"word\":\"I\",\"word_cn\":\"pron. 我\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":7,\"question_index\":50,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":19150,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_like_apples.mp3\",\"display\":\"I like apples.\\n我喜欢苹果。\",\"indexArray\":\"[[7, 12]]\",\"style\":51,\"text_cn\":\"我喜欢苹果。\",\"text_en\":\"I like apples.\",\"word\":\"apple\",\"word_cn\":\"n. 苹果\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":257,\"question_index\":51,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19042,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_six_books.mp3\",\"display\":\"I have six books.\\n我有六本书。\",\"indexArray\":\"[[7, 9]]\",\"style\":51,\"text_cn\":\"我有六本书。\",\"text_en\":\"I have six books.\",\"word\":\"six\",\"word_cn\":\"num.六\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":108,\"question_index\":52,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":18764,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_a_dog.mp3\",\"display\":\"I have a dog.\\n我有一只狗。\",\"indexArray\":\"[[7, 7]]\",\"style\":51,\"text_cn\":\"我有一只狗。\",\"text_en\":\"I have a dog.\",\"word\":\"a\",\"word_cn\":\"一个\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":18,\"question_index\":53,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":19309,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/how_is_my_dog.mp3\",\"display\":\"How is my dog?\\n我的狗怎么样？\",\"indexArray\":\"[[0, 2]]\",\"style\":51,\"text_cn\":\"我的狗怎么样？\",\"text_en\":\"How is my dog?\",\"word\":\"how\",\"word_cn\":\"adv. 多少\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":302,\"question_index\":54,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19283,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_green_apple.mp3\",\"display\":\"A green apple.\\n一个绿色的苹果。\",\"indexArray\":\"[[2, 6]]\",\"style\":51,\"text_cn\":\"一个绿色的苹果。\",\"text_en\":\"A green apple.\",\"word\":\"green\",\"word_cn\":\"n. 绿色 adj. 绿色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":58,\"question_index\":55,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":19240,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_two_pencils.mp3\",\"display\":\"I have two pencils.\\n我有两支铅笔。\",\"indexArray\":\"[[7, 9]]\",\"style\":51,\"text_cn\":\"我有两支铅笔。\",\"text_en\":\"I have two pencils.\",\"word\":\"two\",\"word_cn\":\"num.二\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":112,\"question_index\":56,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19318,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_nine_books.mp3\",\"display\":\"I have nine books.\\n我有九本书。\",\"indexArray\":\"[[7, 10]]\",\"style\":51,\"text_cn\":\"我有九本书。\",\"text_en\":\"I have nine books.\",\"word\":\"nine\",\"word_cn\":\"num.九\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":105,\"question_index\":57,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19237,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_ten_pencils.mp3\",\"display\":\"I have ten pencils.\\n我有十支铅笔。\",\"indexArray\":\"[[7, 9]]\",\"style\":51,\"text_cn\":\"我有十支铅笔。\",\"text_en\":\"I have ten pencils.\",\"word\":\"ten\",\"word_cn\":\"num. 十\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":110,\"question_index\":58,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":18868,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/the_monkey_jumps.mp3\",\"display\":\"The monkey jumps.\\n猴子跳跃。\",\"indexArray\":\"[[4, 9]]\",\"style\":51,\"text_cn\":\"猴子跳跃。\",\"text_en\":\"The monkey jumps.\",\"word\":\"monkey\",\"word_cn\":\"n. 猴子\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":91,\"question_index\":59,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":19245,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_five_pencils.mp3\",\"display\":\"I have five pencils.\\n我有五支铅笔。\",\"indexArray\":\"[[7, 10]]\",\"style\":51,\"text_cn\":\"我有五支铅笔。\",\"text_en\":\"I have five pencils.\",\"word\":\"five\",\"word_cn\":\"num. 五\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":101,\"question_index\":60,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":18786,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_five_books.mp3\",\"display\":\"I have five books.\\n我有五本书。\",\"indexArray\":\"[[7, 10]]\",\"style\":51,\"text_cn\":\"我有五本书。\",\"text_en\":\"I have five books.\",\"word\":\"five\",\"word_cn\":\"num. 五\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":101,\"question_index\":61,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":19308,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/it_s_there.mp3\",\"display\":\"It's there.\\n它在那里。\",\"indexArray\":\"[[5, 9]]\",\"style\":51,\"text_cn\":\"它在那里。\",\"text_en\":\"It's there.\",\"word\":\"there\",\"word_cn\":\"n. （代替主语）那里\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":559,\"question_index\":62,\"level_no\":4,\"is_first\":0,\"book_id\":13},{\"id\":18873,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_like_bananas.mp3\",\"display\":\"I like bananas.\\n我喜欢香蕉。\",\"indexArray\":\"[[7, 13]]\",\"style\":51,\"text_cn\":\"我喜欢香蕉。\",\"text_en\":\"I like bananas.\",\"word\":\"banana\",\"word_cn\":\"n. 香蕉\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":258,\"question_index\":63,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":19300,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_my_pencil.mp3\",\"display\":\"I have my pencil.\\n我有我的铅笔。\",\"indexArray\":\"[[7, 8]]\",\"style\":51,\"text_cn\":\"我有我的铅笔。\",\"text_en\":\"I have my pencil.\",\"word\":\"my\",\"word_cn\":\"pron. 我的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":29,\"question_index\":64,\"level_no\":2,\"is_first\":0,\"book_id\":13},{\"id\":19305,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_a_book.mp3\",\"display\":\"I have a book.\\n我有一本书。\",\"indexArray\":\"[[2, 5]]\",\"style\":51,\"text_cn\":\"我有一本书。\",\"text_en\":\"I have a book.\",\"word\":\"have\",\"word_cn\":\"v.有\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":277,\"question_index\":65,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":19250,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_a_book.mp3\",\"display\":\"I have a book.\\n我有一本书。\",\"indexArray\":\"[[7, 7]]\",\"style\":51,\"text_cn\":\"我有一本书。\",\"text_en\":\"I have a book.\",\"word\":\"a\",\"word_cn\":\"一个\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":18,\"question_index\":66,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":19230,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_have_a_book.mp3\",\"display\":\"I have a book.\\n我有一本书。\",\"indexArray\":\"[[0, 0]]\",\"style\":51,\"text_cn\":\"我有一本书。\",\"text_en\":\"I have a book.\",\"word\":\"I\",\"word_cn\":\"pron. 我\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":7,\"question_index\":67,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":19271,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_red_colour.mp3\",\"display\":\"A red colour.\\n一个红色。\",\"indexArray\":\"[[6, 11]]\",\"style\":51,\"text_cn\":\"一个红色。\",\"text_en\":\"A red colour.\",\"word\":\"colour\",\"word_cn\":\"n. 颜色\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":56,\"question_index\":68,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":19254,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_big_nose.mp3\",\"display\":\"A big nose.\\n一个大鼻子。\",\"indexArray\":\"[[6, 9]]\",\"style\":51,\"text_cn\":\"一个大鼻子。\",\"text_en\":\"A big nose.\",\"word\":\"nose\",\"word_cn\":\"n. 鼻子\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":171,\"question_index\":69,\"level_no\":2,\"is_first\":0,\"book_id\":13},{\"id\":19178,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/is_your_ear_okay.mp3\",\"display\":\"Is your ear okay?\\n你的耳朵还好吗？\",\"indexArray\":\"[[8, 10]]\",\"style\":51,\"text_cn\":\"你的耳朵还好吗？\",\"text_en\":\"Is your ear okay?\",\"word\":\"ear\",\"word_cn\":\"n. 耳朵\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":163,\"question_index\":70,\"level_no\":2,\"is_first\":0,\"book_id\":13},{\"id\":19129,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/i_do_yoga.mp3\",\"display\":\"I do yoga.\\n我练瑜伽。\",\"indexArray\":\"[[2, 3]]\",\"style\":51,\"text_cn\":\"我练瑜伽。\",\"text_en\":\"I do yoga.\",\"word\":\"do\",\"word_cn\":\"aux. v. 做（助动词）\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":372,\"question_index\":71,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":18925,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/the_cat_is_yellow.mp3\",\"display\":\"The cat is yellow.\\n这只猫是黄色的。\",\"indexArray\":\"[[11, 16]]\",\"style\":51,\"text_cn\":\"这只猫是黄色的。\",\"text_en\":\"The cat is yellow.\",\"word\":\"yellow\",\"word_cn\":\"n. 黄色，adj. 黄色的\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":68,\"question_index\":72,\"level_no\":5,\"is_first\":0,\"book_id\":13},{\"id\":19265,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/do_you_like_apple.mp3\",\"display\":\"Do you like apple?\\n你喜欢苹果吗？\",\"indexArray\":\"[[0, 1]]\",\"style\":51,\"text_cn\":\"你喜欢苹果吗？\",\"text_en\":\"Do you like apple?\",\"word\":\"do\",\"word_cn\":\"aux. v. 做（助动词）\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":372,\"question_index\":73,\"level_no\":6,\"is_first\":0,\"book_id\":13},{\"id\":18699,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/she_is_a_teacher.mp3\",\"display\":\"She is a teacher.\\n她是一名教师。\",\"indexArray\":\"[[4, 5]]\",\"style\":51,\"text_cn\":\"她是一名教师。\",\"text_en\":\"She is a teacher.\",\"word\":\"is\",\"word_cn\":\"aux. v. 是（be的第三人称单数形式）\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":26,\"question_index\":74,\"level_no\":2,\"is_first\":0,\"book_id\":13},{\"id\":18862,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/she_is_a_teacher.mp3\",\"display\":\"She is a teacher.\\n她是一名教师。\",\"indexArray\":\"[[9, 15]]\",\"style\":51,\"text_cn\":\"她是一名教师。\",\"text_en\":\"She is a teacher.\",\"word\":\"teacher\",\"word_cn\":\"n. 教师\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":76,\"question_index\":75,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":18971,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/a_blue_ruler.mp3\",\"display\":\"A blue ruler.\\n一个蓝色的尺子。\",\"indexArray\":\"[[7, 11]]\",\"style\":51,\"text_cn\":\"一个蓝色的尺子。\",\"text_en\":\"A blue ruler.\",\"word\":\"ruler\",\"word_cn\":\"n. 尺子\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":85,\"question_index\":76,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":19199,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/what_are_you_doing_now.mp3\",\"display\":\"What are you doing now?\\n你现在在做什么？\",\"indexArray\":\"[[0, 3]]\",\"style\":51,\"text_cn\":\"你现在在做什么？\",\"text_en\":\"What are you doing now?\",\"word\":\"what\",\"word_cn\":\"pron. 什么\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":34,\"question_index\":77,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":19048,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/what_is_this.mp3\",\"display\":\"What is this?\\n这是什么？\",\"indexArray\":\"[[0, 3]]\",\"style\":51,\"text_cn\":\"这是什么？\",\"text_en\":\"What is this?\",\"word\":\"what\",\"word_cn\":\"pron. 什么\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":34,\"question_index\":78,\"level_no\":3,\"is_first\":0,\"book_id\":13},{\"id\":19268,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/have_a_pencil.mp3\",\"display\":\"Have a pencil.\\n拿一支铅笔。\",\"indexArray\":\"[[0, 3]]\",\"style\":51,\"text_cn\":\"拿一支铅笔。\",\"text_en\":\"Have a pencil.\",\"word\":\"have\",\"word_cn\":\"v.有\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":277,\"question_index\":79,\"level_no\":1,\"is_first\":0,\"book_id\":13},{\"id\":19330,\"style_id\":51,\"content\":{\"answer\":[],\"audio\":\"https://static0.xesimg.com/next-studio-pub/abc_zone/word/tts/amy/she_is_there.mp3\",\"display\":\"She is there.\\n她在那里。\",\"indexArray\":\"[[7, 11]]\",\"style\":51,\"text_cn\":\"她在那里。\",\"text_en\":\"She is there.\",\"word\":\"there\",\"word_cn\":\"n. （代替主语）那里\"},\"style_ch\":\"看文字，读出内容\",\"type\":\"\",\"kp_id\":559,\"question_index\":80,\"level_no\":4,\"is_first\":0,\"book_id\":13}]"
    local backupJson = self.jsonService:decode(backupString)

    local round_id = tostring(os.time()) .. App.Uuid
    round_id = CS.Com.Tal.Unity.Core.Utility.Md5Tools.ProcessMd5(round_id)
    -- g_Log(TAG, "获取题目成功" .. round_id)
    -- g_Log(TAG, "获取题目成功" .. table.dump(backupJson))
    for _, m in ipairs(backupJson) do
        for key, n in pairs(m.content) do
            m[key] = n
        end
        -- m.book_id = 1
        m.round_id = round_id
        -- 透传给答题接口的字段
        local passBy = {}
        passBy["book_id"] = 13
        passBy["round_id"] = round_id
        m.passBy = passBy
        m.content = nil
        table.insert(self.questionList["51"], m)
        -- g_Log(TAG, "获取题目成功" .. table.dump(m))
    end
    -- g_Log(TAG, "获取题目成功" .. table.dump(self.questionList["51"]))
end

function QuestionManager:reportData(event, label, value, action)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(event, "73562", "Special-Interaction", label,
            action, value)
    end
end

-- 脚本释放
function QuestionManager:Exit()
    QuestionManager.super.Exit(self)
end

return QuestionManager
