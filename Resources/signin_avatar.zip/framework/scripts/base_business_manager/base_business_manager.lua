local class = require("middleclass")

---@class BaseBusinessManager
---@field _businessMap table<string, WorldBaseElement> 业务管理器
local BaseBusinessManager = class("BaseBusinessManager")

--初始化构造
function BaseBusinessManager:initialize(gate)
    self._businessMap = {}
    self:_InitConstant()
    CourseEnv.BaseBusinessManager = self
    self:_InitBaseBusiness()
    self:_InitBusiness()
    self:_InitTestButton()
end

function BaseBusinessManager:_InitConstant()
    self._baseBusinessTypes = {
        ["SpeechAssessment"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/speech_assessment_business"),
        ["PageMonitorService"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/page_monitor_service"),
    }
    self._businessTypes = {
        ["QuestionPanel"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/question_panel"),
        ["QuestionManager"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/question_manager"),
        ["AntiAddictionManager"] = require(MAIN_SCRIPTS_LOC ..
            "base_business_manager/business/antiAddiction/antiaddiction_manager"),
        ["Parentalurging_manager"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/parental_urging_manager"),
        ["QuestionVideoPanel"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/question_video_panel"),
        ["QuestionSourceLeft"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/question_source_left"),
        ["MidWeekStateCheck"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/midweek_state_check"),
    }
    if App.modPlatformId == MOD_PLATFORM.ABCZone or App.modPlatformId == MOD_PLATFORM.Math or App.modPlatformId == MOD_PLATFORM.Chinese then
        self._businessTypes["SpeechMagic"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/speech_magic")
    end
    if App.modPlatformId == MOD_PLATFORM.ABCZone then
        self._businessTypes["DeepSeekTagService"] = require(MAIN_SCRIPTS_LOC ..
        "base_business_manager/business/deepseek_tag_service")
        ---英语天天练 支持系统截图
        self._businessTypes["ScreenshotHelper"] = require(MAIN_SCRIPTS_LOC .. "base_business_manager/business/screenshot_helper")
    end
    --语文主场景屏蔽 先这么写
    if App:IsChinese() then
        self._businessTypes["DeepSeekTagService"] = nil
        -- self._businessTypes["SpeechMagic"] = nil
        self._businessTypes["QuestionManager"] = nil
        self._businessTypes["QuestionPanel"] = nil
        self._businessTypes["QuestionSourceLeft"] = nil
        self._businessTypes["QuestionVideoPanel"] = nil
        self._businessTypes["Parentalurging_manager"] = nil
        self._businessTypes["SpeechAssessment"] = nil
        self._businessTypes["AntiAddictionManager"] = nil
        self._businessTypes["MidWeekStateCheck"] = nil
    end
end

---初始化基础业务，挂载到世界中
function BaseBusinessManager:_InitBaseBusiness()
    g_Log("BaseBusinessManager:InitBusiness()")
    for k, v in pairs(self._baseBusinessTypes) do
        xpcall(function()
            CourseEnv.ServicesManager.Gate:AddElementType(k, v)
            local dict = CS.Tal.framesync.VisualProperty();
            dict:Add("type", k)
            local ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.zero, Vector3.one,
                Vector3.zero, "WorldElement_" .. k)
            self._businessMap[k] = ret
        end, function(err)
            g_LogError(err)
        end)
    end
end

---初始化基础业务，挂载到世界中
function BaseBusinessManager:_InitBusiness()
    g_Log("BaseBusinessManager:InitBusiness()")
    for k, v in pairs(self._businessTypes) do
        if v then
            xpcall(function()
                CourseEnv.ServicesManager.Gate:AddElementType(k, v)
                local dict = CS.Tal.framesync.VisualProperty();
                dict:Add("type", k)
                local ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.zero, Vector3.one,
                    Vector3.zero, "WorldElement_" .. k)
                self._businessMap[k] = ret
            end, function(err)
                g_LogError(err)
            end)
        end
    end
end

---添加测试按钮
function BaseBusinessManager:_InitTestButton()
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.debugService:AddDebugActionWithTitleAndCategory("统计方法耗时开始", "性能测试"):connect(function()
        FUNCTION_TEST_LIST = {}
        self.observerService = CourseEnv.ServicesManager:GetObserverService()
        self.observerService:Fire("FUNCTION_TEST", { list = FUNCTION_TEST_LIST })
    end)
    self.debugService:AddDebugActionWithTitleAndCategory("统计方法耗时结束", "性能测试"):connect(function()
        if not FUNCTION_TEST_LIST then
            return
        end
        local path = CS.UnityEngine.Application.persistentDataPath .. "/耗时统计" .. os.date("%Y%m%d_%H%M") .. ".json"
        if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.IPhonePlayer then
            path = CS.UnityEngine.Application.persistentDataPath ..
                "/NTUnityRes/unity3dRes/" .. App.ModName .. "/耗时统计" .. os.date("%Y%m%d_%H%M") .. ".json"
        end

        -- g_Log("FUNCTION_TEST", self.jsonService:encode(FUNCTION_TEST_LIST))
        g_Log("FUNCTION_TEST", path)
        local file = io.open(path, "w+")
        if not file then
            local dir = string.match(path, "(.*[/\\])")
            if dir then
                os.execute("mkdir -p " .. dir)
            end
            file = io.open(path, "w+")
        end
        if file then
            g_Log("FUNCTION_TEST", "开始写入")
            file:write(self.jsonService:encode(FUNCTION_TEST_LIST))
            file:close()
        end
    end)
end

---获取语音评测业务
---@return SpeechAssessmentBusiness
function BaseBusinessManager:GetSpeechAssessmentBusiness()
    return self._businessMap["SpeechAssessment"]
end

---题目管理
---@return QuestionManager
function BaseBusinessManager:GetQuestionManager()
    return self._businessMap["QuestionManager"]
end

---页面性能监控服务
---@return PageMonitorService
function BaseBusinessManager:GetPageMonitorService()
    return self._businessMap["PageMonitorService"]
end

return BaseBusinessManager
