local class = require("middleclass")
local resourceManager = require("hotfix/resource_manager")
---@type Service
local Service = require("app/service")
---@class H5Service : Service
---@field ServiceName string 服务名称
---@field callBacks table<number, function> 回调函数表
---@field ApiBridge any API桥接对象
local H5Service = class("AssetServices", Service)

local ids = 0

---初始化
---@public
---@param serviceName string 服务名
---@return void
function H5Service:initialize(serviceName)
    self.ServiceName = serviceName
    self.callBacks = {}
end

---场景内打开H5 不会暂停游戏 https://mindoc.chuangjing.com/docs/mindoc/mindoc-1eavb7l9imlpe
---@public
---@param params table 打开H5的参数
---@param params.url string H5页面的URL地址
---@param params.normalizedPosition table|nil 位置参数 格式:{x,y,width,height} 不传默认全屏
---@param callback function 回调函数
---@return number ids唯一序号，用于关闭H5页面时使用
function H5Service:OpenH5OnRoom(params, callback)
    if not params.url then
        g_LogError("OpenH5OnRoom url is nil")
        return
    end
    if not self.ApiBridge then
        self:_CreateService()
    end
    ---没传默认全屏
    if not params.normalizedPosition then
        params.normalizedPosition = { 0, 0, 1, 1 } ---x,y,w,h
    end
    APIBridge.RequestAsync("app.buss.webview.open", params, function() end)
    ids = ids + 1
    if callback then
        self.callBacks[ids] = callback
    end
    return ids
end

---关闭H5
---@public
---@param ids number OpenH5OnRoom返回的唯一序号
---@return void
function H5Service:CloseH5OnRoom(ids)
    if not ids then
        return
    end
    local callback = self.callBacks[ids]
    if callback then
        callback({})
        self.callBacks[ids] = nil
        APIBridge.RequestAsync("app.buss.webview.close", {}, function() end)
    end
end

---场景外打开H5 scheme 会暂停游戏 "xesnext://xrsApp?m=browser&d={\"p\":{\"url\":\"url..token\"}}"
---@public
---@param scheme string scheme链接
---@param keepClass boolean|nil 是否保留当前页面，默认为true
---@return void
function H5Service:OpenH5OnExtBrowser(scheme, keepClass)
    if keepClass == nil then
        keepClass = true
    end
    APIBridge.RequestAsync("app.api.jump.scheme", {
        scheme = scheme,
        keepClass = keepClass
    })
end

---创建服务
---@private
---@return void
function H5Service:_CreateService()
    self.ApiBridge = APIBridge.CreateService('app.buss.webview.jssend', {}, function(res)
        ---回调给业务
        for k, v in pairs(self.callBacks) do
            v(res)
        end
        if res.event == "closeH5PageEvent" then
            --- 关闭H5
            APIBridge.RequestAsync("app.buss.webview.close", {}, function() end)
            ---清空回调
            self.callBacks = {}
        end
    end)
end

---退出服务
---@public
---@return void
function H5Service:Exit()
    H5Service.super.Exit(self)
    if self.ApiBridge then
        self.ApiBridge:UnBind()
        self.ApiBridge = nil
    end
    self.callBacks = {}
    ids = 0
end

return H5Service
