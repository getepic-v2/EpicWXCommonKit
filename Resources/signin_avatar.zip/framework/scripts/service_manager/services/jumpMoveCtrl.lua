-- 弹跳板控制逻辑
-- 用法如下：
-- 注册弹跳板
-- self.componentId = CourseEnv.ServicesManager:GetMoveService().jumpMoveCtrl:RegisterMover({
--     speedX = self.speedX,
--     speedY = self.speedY,
--     speedZ = self.speedZ,
--     move_object = self.move_object,
-- })

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local socket = require("socket")

-- 初始化buffer时间，可透支时间
local INITAL_BUFFER_TIME = 500
-- 最大buffer时间，超过此时间意味着太多远端帧没消费了，重置
local MAX_BUFFER_TIME = 1000

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local JumpCtrl = class("JumpCtrl_logic", WBElement)

---@param worldElement CS.Tal.framesync.WorldElement
function JumpCtrl:initialize(worldElement)
    JumpCtrl.super.initialize(self, worldElement)
    g_Log("初始化跳跃控制逻辑")
    self.componentId = 0
    self.movers = {}
end

function JumpCtrl:RegisterMover(config)
    if not config.move_object then
        g_LogError("注册弹簧板时没有找到运动目标")
        return
    end
    self.componentId = self.componentId + 1
    local id = self.componentId
    self.movers[self.componentId] = config
    self.movers[self.componentId].isActive = false
    local box = config.move_object.transform:Find("trigger").gameObject
    CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(box, function(other)
        if self.selfAvatar and self.movers[id] then
            if other.name == self.selfAvatar.VisElement.gameObject.name and self.movers[id].isActive == true then
                self:SuperJump(self.movers[id])
            end
        end
    end)

    CourseEnv.ServicesManager:GetColliderService():RegisterColliderExitListener(box, function(other)
        if self.selfAvatar and self.movers[id] then
            if other.name == self.selfAvatar.VisElement.gameObject.name then
                
            end
        end
    end)

    -- TODO 设置纵向最大速度
    if self.selfAvatar and config.speedY >  self.selfAvatar.characterCtrl.maxSpeedV then
        self.selfAvatar.characterCtrl.maxSpeedV = config.speedY
    end

    return self.componentId
end

function JumpCtrl:UnRegisterMover(id)
    if not id then
        return
    end
    -- 删除轨迹线
    local mover = self.movers[id]
    if mover and mover.line then
        CS.UnityEngine.Object.Destroy(mover.line.gameObject)
    end
    self.movers[id] = nil
end

function JumpCtrl:GetMover(id)
    return self.movers[id]
end

function JumpCtrl:startMover(id)
    if self.movers[id] and self.movers[id].isActive == false then
        self.movers[id].isActive = true
    end
end

function JumpCtrl:stopMover(id)
    if self.movers[id] and self.movers[id].isActive == true then
        self.movers[id].isActive = false
    end
end

function JumpCtrl:DrawMoveLine(id,drawLine)
    local mover = self.movers[id]
    if not mover then
        return
    end
    if drawLine then
        if mover.line then
            -- 删除mover.line及其子节点
            CS.UnityEngine.Object.Destroy(mover.line.gameObject)
        end
        local box = mover.move_object.transform:Find("trigger").gameObject
        local lineParent = CS.UnityEngine.GameObject("TrajectoryLine")
        lineParent.transform:SetParent(box.transform)
        lineParent.transform.localPosition = CS.UnityEngine.Vector3.zero
        lineParent.transform.localRotation = CS.UnityEngine.Quaternion.identity
        lineParent.transform.localScale = CS.UnityEngine.Vector3.one
        
        -- 根据是否有横向速度决定轨迹类型
        local hasHorizontalVelocity = (mover.speedX ~= 0 or mover.speedZ ~= 0)
        if hasHorizontalVelocity then
            -- 有横向速度，绘制抛物线轨迹
            g_Log("弹簧板轨迹：抛物线 - 横向速度(" .. mover.speedX .. ", " .. mover.speedZ .. "), 垂直速度(" .. mover.speedY .. ")")
            self:CreateParabolicTrajectory(lineParent, lineParent.transform.position, mover.speedY, {x = mover.speedX, z = mover.speedZ}, 0.5, 0.3)
        else
            -- 没有横向速度，绘制直线轨迹，根据物理公式计算最高高度
            local maxHeight = self:CalculateMaxHeight(mover.speedY)
            g_Log("弹簧板轨迹：直线 - 仅垂直速度(" .. mover.speedY .. ")，最高高度(" .. maxHeight .. "米)")
            self:CreateDashedLineWithMultipleRenderers(lineParent, lineParent.transform.position, lineParent.transform.position + CS.UnityEngine.Vector3.up * maxHeight, 0.5, 0.3)
        end

        mover.line = lineParent
    else
        if mover.line then
            mover.line.gameObject:SetActive(false)
        end
    end
end

function JumpCtrl:DrawAllMoveLine(drawLine)
    for id, _ in pairs(self.movers) do
        self:DrawMoveLine(id,drawLine)
    end
end

function JumpCtrl : SuperJump(mover)
    if self.selfAvatar and mover then
        self.selfAvatar.characterCtrl:DoSuperJump(mover.speedY,function()
            if self.selfAvatar and self.selfAvatar.characterCtrl then
                self.selfAvatar.characterCtrl:SetMoveOffset(0,0,0)
            end
        end)

        self.cor  = self.commonService:StartCoroutine(function()
            self.commonService:YieldEndFrame()
            self.selfAvatar.characterCtrl:SetMoveOffset(mover.speedX * Time.deltaTime, 0, mover.speedZ * Time.deltaTime)
        end)
    end
end

-- 计算垂直抛射运动的最高高度
-- @param verticalSpeed 垂直初始速度
-- @return 最高高度（米）
function JumpCtrl:CalculateMaxHeight(verticalSpeed)
    local gravity = 15  -- 重力加速度 m/s²
    -- 使用物理公式：h = v₀²/(2g)
    local maxHeight = (verticalSpeed * verticalSpeed) / (2 * gravity)
    return maxHeight
end

-- 创建抛物线轨迹（使用物理公式）
-- @param parent 父对象
-- @param startPos 起始位置
-- @param verticalSpeed 垂直初始速度
-- @param horizontalOffset 水平速度偏移
-- @param dashLength 虚线段长度
-- @param gapLength 空白段长度
function JumpCtrl:CreateParabolicTrajectory(parent, startPos, verticalSpeed, horizontalOffset, dashLength, gapLength)
    local gravity = 15  -- 重力加速度
    local maxTime = 5.0   -- 增加最大飞行时间
    
    -- 计算到达最高点的时间
    local timeToMaxHeight = verticalSpeed / gravity
    -- 计算总飞行时间（考虑到可能需要更长时间到达地面）
    local totalTime = timeToMaxHeight * 2.5  -- 增加飞行时间
    
    g_Log("弹簧板轨迹：抛物线总飞行时间: " .. totalTime .. "秒，到达最高点时间: " .. timeToMaxHeight .. "秒")
    
    -- 使用新的均匀虚线生成方法
    self:CreateUniformDashedParabola(parent, startPos, verticalSpeed, horizontalOffset, totalTime, gravity, dashLength, gapLength)
end

-- 创建均匀的抛物线虚线
-- @param parent 父对象
-- @param startPos 起始位置
-- @param verticalSpeed 垂直初始速度
-- @param horizontalOffset 水平速度偏移
-- @param totalTime 总飞行时间
-- @param gravity 重力加速度
-- @param dashLength 虚线段长度
-- @param gapLength 空白段长度
function JumpCtrl:CreateUniformDashedParabola(parent, startPos, verticalSpeed, horizontalOffset, totalTime, gravity, dashLength, gapLength)
    -- 生成密集的轨迹点用于计算弧长
    local timeStep = 0.02  -- 更小的时间步长，生成更密集的点
    local trajectoryPoints = {}
    
    for t = 0, totalTime, timeStep do
        local x = startPos.x + horizontalOffset.x * t
        local y = startPos.y + verticalSpeed * t - 0.5 * gravity * t * t
        local z = startPos.z + horizontalOffset.z * t
        
        table.insert(trajectoryPoints, CS.UnityEngine.Vector3(x, y, z))
        
        -- 如果高度低于起始高度很多，且已经过了最高点，可以停止计算
        if t > (verticalSpeed / gravity) and y < startPos.y then
            break
        end
    end
    
    if #trajectoryPoints < 2 then
        g_Log("弹簧板轨迹：轨迹点数不足，无法生成抛物线")
        return
    end
    
    -- 显示轨迹边界信息
    local firstPoint = trajectoryPoints[1]
    local lastPoint = trajectoryPoints[#trajectoryPoints]
    g_Log("弹簧板轨迹：起始点(" .. firstPoint.x .. ", " .. firstPoint.y .. ", " .. firstPoint.z .. ") 结束点(" .. lastPoint.x .. ", " .. lastPoint.y .. ", " .. lastPoint.z .. ")")
    
    -- 计算累积弧长
    local arcLengths = {0}  -- 第一个点的弧长为0
    local totalArcLength = 0
    
    for i = 2, #trajectoryPoints do
        local segmentLength = (trajectoryPoints[i] - trajectoryPoints[i-1]).magnitude
        totalArcLength = totalArcLength + segmentLength
        table.insert(arcLengths, totalArcLength)
    end
    
    -- 按照弧长均匀创建虚线段
    local segmentIndex = 0
    local currentArcLength = 0
    local isDash = true
    local cycleLength = dashLength + gapLength
    
    while currentArcLength < totalArcLength do
        local nextArcLength = math.min(currentArcLength + (isDash and dashLength or gapLength), totalArcLength)
        
        if isDash then
            -- 找到对应弧长的位置点
            local startPos = self:GetPositionAtArcLength(trajectoryPoints, arcLengths, currentArcLength)
            local endPos = self:GetPositionAtArcLength(trajectoryPoints, arcLengths, nextArcLength)
            
            -- 创建虚线段
            segmentIndex = segmentIndex + 1
            local segment = CS.UnityEngine.GameObject("UniformTrajectorySegment_" .. segmentIndex)
            
            segment.transform.localPosition = CS.UnityEngine.Vector3.zero
            segment.transform.localRotation = CS.UnityEngine.Quaternion.identity
            segment.transform.localScale = CS.UnityEngine.Vector3.one
            
            local lineRenderer = segment:AddComponent(typeof(CS.UnityEngine.LineRenderer))
            lineRenderer.material = CS.UnityEngine.Material(CS.UnityEngine.Shader.Find("Sprites/Default"))
            lineRenderer.startColor = CS.UnityEngine.Color.red  -- 抛物线轨迹使用蓝色
            lineRenderer.endColor = CS.UnityEngine.Color.red
            lineRenderer.startWidth = 0.05
            lineRenderer.endWidth = 0.05
            lineRenderer.positionCount = 2
            lineRenderer.useWorldSpace = false
            
            -- 设置虚线段的起点和终点
            lineRenderer:SetPosition(0, startPos)
            lineRenderer:SetPosition(1, endPos)

            segment.transform:SetParent(parent.transform)
        end
        
        currentArcLength = nextArcLength
        isDash = not isDash
    end
    
    g_Log("弹簧板轨迹：创建了 " .. segmentIndex .. " 个均匀虚线段，总弧长: " .. totalArcLength .. "米，轨迹点数: " .. #trajectoryPoints)
end

-- 根据弧长获取轨迹上的位置
-- @param trajectoryPoints 轨迹点数组
-- @param arcLengths 累积弧长数组
-- @param targetArcLength 目标弧长
-- @return 对应位置的Vector3
function JumpCtrl:GetPositionAtArcLength(trajectoryPoints, arcLengths, targetArcLength)
    -- 边界情况处理
    if targetArcLength <= 0 then
        return trajectoryPoints[1]
    end
    
    if targetArcLength >= arcLengths[#arcLengths] then
        return trajectoryPoints[#trajectoryPoints]
    end
    
    -- 二分查找找到目标弧长对应的线段
    for i = 1, #arcLengths - 1 do
        if targetArcLength >= arcLengths[i] and targetArcLength <= arcLengths[i + 1] then
            -- 在这个线段内进行线性插值
            local segmentStartLength = arcLengths[i]
            local segmentEndLength = arcLengths[i + 1]
            local segmentLength = segmentEndLength - segmentStartLength
            
            if segmentLength > 0 then
                local t = (targetArcLength - segmentStartLength) / segmentLength
                return CS.UnityEngine.Vector3.Lerp(trajectoryPoints[i], trajectoryPoints[i + 1], t)
            else
                return trajectoryPoints[i]
            end
        end
    end
    
    -- 如果没有找到，返回最后一个点
    return trajectoryPoints[#trajectoryPoints]
end

-- 创建虚线效果（使用多个独立的LineRenderer）
-- @param parent 父对象
-- @param startPos 起始位置
-- @param endPos 结束位置
-- @param dashLength 虚线段长度
-- @param gapLength 空白段长度
function JumpCtrl:CreateDashedLineWithMultipleRenderers(parent, startPos, endPos, dashLength, gapLength)
    local direction = endPos - startPos
    local totalDistance = direction.magnitude
    local normalizedDirection = direction.normalized
    
    local currentDistance = 0
    local isDash = true  -- 开始是虚线段
    local segmentIndex = 0
    
    while currentDistance < totalDistance do
        local segmentLength = isDash and dashLength or gapLength
        local nextDistance = math.min(currentDistance + segmentLength, totalDistance)
        
        if isDash then
            -- 创建虚线段
            segmentIndex = segmentIndex + 1
            local segment = CS.UnityEngine.GameObject("DashSegment_" .. segmentIndex)
            
            segment.transform.localPosition = CS.UnityEngine.Vector3.zero
            segment.transform.localRotation = CS.UnityEngine.Quaternion.identity
            segment.transform.localScale = CS.UnityEngine.Vector3.one
            
            local lineRenderer = segment:AddComponent(typeof(CS.UnityEngine.LineRenderer))
            lineRenderer.material = CS.UnityEngine.Material(CS.UnityEngine.Shader.Find("Sprites/Default"))
            lineRenderer.startColor = CS.UnityEngine.Color.red
            lineRenderer.endColor = CS.UnityEngine.Color.red
            lineRenderer.startWidth = 0.05
            lineRenderer.endWidth = 0.05
            lineRenderer.positionCount = 2
            lineRenderer.useWorldSpace = false
            
            -- 设置虚线段的起点和终点
            lineRenderer:SetPosition(0, startPos + normalizedDirection * currentDistance)
            lineRenderer:SetPosition(1, startPos + normalizedDirection * nextDistance)

            segment.transform:SetParent(parent.transform)
        end
        
        currentDistance = nextDistance
        isDash = not isDash  -- 切换虚线段和空白段
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function JumpCtrl:ReceiveMessage(key, value, isResume)
    
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function JumpCtrl:SendCustomMessage(key, body)
    
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function JumpCtrl:SelfAvatarCreated(avatar)
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function JumpCtrl:SelfAvatarPrefabLoaded(avatar)
    self.selfAvatar = avatar
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function JumpCtrl:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function JumpCtrl:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function JumpCtrl:LogicMapStartRecover()
    JumpCtrl.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function JumpCtrl:LogicMapEndRecover()
    JumpCtrl.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function JumpCtrl:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

--收到Trigger事件
function JumpCtrl : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function JumpCtrl : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function JumpCtrl:Exit()
    g_Log("客户端:退出跳跃运动服务")
    if self.cor then
        self.cor:Stop()
    end

    JumpCtrl.super.Exit(self)
end

return JumpCtrl
 

