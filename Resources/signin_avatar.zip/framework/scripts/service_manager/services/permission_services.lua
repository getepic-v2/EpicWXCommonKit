---
---  Author: 【樊晓泽】
---  AuthorID: 【V0015434】
---  CreateTime: 【2022-10-20 21:42:12】
--- 【FSync】
--- 【权限申请】
---
local class = require("middleclass")
local Service = require("app/service")
local PermissionUI = require("ui/permission_ui")


local PermissionServices = class("PermissionServices",Service)

function PermissionServices:initialize(serviceName)
    self.ServiceName = serviceName
end

---传入的权限名称
------@param loadCallback fun():void
function PermissionServices:GetPermission(PermissionString,loadCallback)
    self.PermissionNumber=PermissionString
    self.tempFalseRecord = {}
    PermissionNumber=#self.PermissionNumber
    self.tempLoadCallBack=loadCallback
    self.isBool = false
    isNext = false
    falseTemp = 1
    index = 1
    self.tempMicroph = 0
    self.tempCamera = 0
    self.tempPhoto = 0
    self:callbackJudgment(index)
end
---@param tempindex number
function PermissionServices:callbackJudgment(tempindex)
    if #self.PermissionNumber ~= 0 then
        if self.PermissionNumber[tempindex] == "microphone" then
            self:checkAuth("microphoneAuth")
        elseif self.PermissionNumber[tempindex] == "camera" then
            self:checkAuth("cameraAuth")
        elseif self.PermissionNumber[tempindex] == "photo" then
            self:checkAuth("photoAuth")
        else
            g_LogError("获取权限失败,请检查申请权限名称")
        end
    else
        g_LogError("输入权限为空,请检查输入权限")
    end
end

---@param tempauth string
function PermissionServices:checkAuth(tempauth)
    local data = {}
    if tempauth == "microphoneAuth" then
        data = {
            microphoneAuth = true
        }
    elseif tempauth == "cameraAuth" then
        data = {
            cameraAuth = true
        }
    elseif tempauth == "photoAuth" then
        data = {
            photoAuth = true
        }
    end
    -- 弹窗
    APIBridge.RequestAsync("app.auth.requestAuth", data, function(params)
        local tempmicAuth = false
        if tempauth == "microphoneAuth" then
            tempmicAuth = params.microphoneAuth
        elseif tempauth == "cameraAuth" then
            tempmicAuth = params.cameraAuth
        elseif tempauth == "photoAuth" then
            tempmicAuth = params.photoAuth
        end
        if (tempmicAuth) then
            if isNext then
                -- 将上一次失败的权限移除出tempFalseRecord
                if tempauth == "microphoneAuth" then
                    if self.tempMicroph > 0 then
                        table.remove(self.tempFalseRecord, self.tempMicroph)
                        self.tempCamera = self.tempCamera - 1
                        self.tempPhoto = self.tempPhoto - 1
                    end
                elseif tempauth == "cameraAuth" then
                    if self.tempCamera > 0 then
                        table.remove(self.tempFalseRecord, self.tempCamera)
                        self.tempMicroph = self.tempMicroph - 1
                        self.tempPhoto = self.tempPhoto - 1
                    end
                elseif tempauth == "photoAuth" then
                    if self.tempPhoto > 0 then
                        table.remove(self.tempFalseRecord, self.tempPhoto)
                        self.tempMicroph = self.tempMicroph - 1
                        self.tempCamera = self.tempCamera - 1
                    end
                end
            end
        else
            if not isNext then
                if tempauth == "microphoneAuth" then
                    self.tempFalseRecord[falseTemp] = "麦克风"
                    self.tempMicroph = falseTemp
                elseif tempauth == "cameraAuth" then
                    self.tempFalseRecord[falseTemp] = "摄像头"
                    self.tempCamera = falseTemp
                elseif tempauth == "photoAuth" then
                    self.tempFalseRecord[falseTemp] = "存储"
                    self.tempPhoto = falseTemp 
                end
                falseTemp = falseTemp + 1
            end
        end
        index = index + 1
        if index <= PermissionNumber then
            self:callbackJudgment(index)
        else
            if #self.tempFalseRecord == 0 then
                if self.tempLoadCallBack ~= nil then
                    self.isBool=true
                    self.tempLoadCallBack(self.isBool)
                end               
            else
                if not isNext then
                    if (self.permissionUI == nil) then
                        self.permissionUI = PermissionUI:new()
                    end
                    self.permissionUI:falseConnect(self:connectFalseString(), self.tempLoadCallBack, function()
                        self:callbackJudgment(index)
                    end)
                else
                    if self.tempLoadCallBack ~= nil then
                        self.tempLoadCallBack(self.isBool)
                    end
                end
            end
        end
    end)
end

function  PermissionServices:connectFalseString()
    self.connectString = ""
    for i = 1, #self.tempFalseRecord, 1 do
        if i <= #self.tempFalseRecord - 1 then
            self.connectString = self.connectString .. self.tempFalseRecord[i] .. "、"
        else
            self.connectString = self.connectString .. self.tempFalseRecord[i]
        end
    end
    return self.connectString
end

return PermissionServices
