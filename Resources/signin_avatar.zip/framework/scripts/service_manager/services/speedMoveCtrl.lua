-- 加速器控制逻辑
-- 用法如下：
-- 注册加速器
-- self.componentId = CourseEnv.ServicesManager:GetMoveService().speedMoveCtrl:RegisterMover({
--     speed = self.speed
--     speedTime = self.speedTime,
--     cd = self.cd,
--     move_object = self.move_object,
-- })

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local SpeedCtrl = class("SpeedCtrl_logic", WBElement)

---@param worldElement CS.Tal.framesync.WorldElement
function SpeedCtrl:initialize(worldElement)
    SpeedCtrl.super.initialize(self, worldElement)
    g_Log("初始化加速器控制逻辑")
    self.componentId = 0
    self.movers = {}
    self.remainSpeedTimeTable = {}
    self.cdTable = {}
end

function SpeedCtrl:RegisterMover(config)
    if not config.move_object then
        g_LogError("注册加速器时没有找到运动目标")
        return
    end
    self.componentId = self.componentId + 1
    self.movers[self.componentId] = config
    self.movers[self.componentId].isActive = false
    local id = self.componentId
    local box = config.move_object.transform:Find("trigger").gameObject
    CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(box, function(other)
        if self.selfAvatar and self.movers[id] then
            if other.name == self.selfAvatar.VisElement.gameObject.name and self.movers[id].isActive == true then
                config.move_object.gameObject:SetActive(false)
                self.remainSpeedTimeTable[id] = {speedTime = config.speedTime, speed = config.speed}
                self.cdTable[id] = {move_object = config.move_object, cd = config.cd}
            end
        end
    end)

    return self.componentId
end

function SpeedCtrl:GetMover(id)
    return self.movers[id]
end

function SpeedCtrl:UnRegisterMover(id)
    if not id then
        return
    end
    self.movers[id] = nil
end

function SpeedCtrl:startMover(id)
    if self.movers[id] and self.movers[id].isActive == false then
        self.movers[id].isActive = true
    end
end

function SpeedCtrl:stopMover(id)
    if self.movers[id] and self.movers[id].isActive == true then
        self.movers[id].isActive = false
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function SpeedCtrl:ReceiveMessage(key, value, isResume)
    
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function SpeedCtrl:SendCustomMessage(key, body)
    
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function SpeedCtrl:SelfAvatarCreated(avatar)
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function SpeedCtrl:SelfAvatarPrefabLoaded(avatar)
    self.selfAvatar = avatar
    
    self.globalShoeTimer = self.commonService:RegisterGlobalTimer(0.1, function()
        -- 遍历所有cd表，如果cd大于0，则减1，如果cd小于0，则激活加速器，同时移除表
        for id, cd in pairs(self.cdTable) do
            if cd.cd > 0 then
                cd.cd = cd.cd - 0.1
            else
                cd.move_object.gameObject:SetActive(true)
                self.cdTable[id] = nil
            end
        end

        -- 遍历所有remainSpeedTime表，如果remainSpeedTime大于0，则减1，如果remainSpeedTime小于0，则移除表
        local speed = 1
        for id, remainSpeedTime in pairs(self.remainSpeedTimeTable) do
            if remainSpeedTime.speedTime > 0 then
                remainSpeedTime.speedTime = remainSpeedTime.speedTime - 0.1
                speed = math.max(speed, remainSpeedTime.speed)
            else
                self.remainSpeedTimeTable[id] = nil
            end
            if self.selfAvatar and self.selfAvatar.characterCtrl then
                self.selfAvatar.characterCtrl:SetSpeedFactor(speed)
            end
        end

    end, false)
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function SpeedCtrl:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function SpeedCtrl:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function SpeedCtrl:LogicMapStartRecover()
    SpeedCtrl.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function SpeedCtrl:LogicMapEndRecover()
    SpeedCtrl.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function SpeedCtrl:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

--收到Trigger事件
function SpeedCtrl : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function SpeedCtrl : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function SpeedCtrl:Exit()
    g_Log("客户端:退出加速器运动服务")
    
    if  self.globalShoeTimer  then
        self.commonService:UnregisterGlobalTimer(self.globalShoeTimer)
        self.globalShoeTimer = nil
    end

    SpeedCtrl.super.Exit(self)
end

return SpeedCtrl
 

