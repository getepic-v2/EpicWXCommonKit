-- 圆周运动控制逻辑
-- 用法如下：
-- 注册直线运动器
-- self.componentId = CourseEnv.ServicesManager:GetLinearMoveService():RegisterMover({
--     totalFrame = self.totalFrame,
--     totalTimeInMS = self.totalTimeInMS,
--     state = self.state,
--     originLocalPos = self.originLocalPos,
--     originPos = self.originPos,
--     tarLocalPos = self.tarLocalPos,
--     tarPos = self.tarPos,
--     finLocalPos = self.finLocalPos,
--     finPos = self.finPos,
--     move_object = self.move_object,
--     disableTime = self.disableTime,
--     speedX = self.speedX,
--     speedY = self.speedY,
--     speedZ = self.speedZ,
--     relativeSpace = self.relativeSpace,
--     startDelayTime = self.startDelayTime,
--     isRepeat = self.isRepeat,
--     isReturn = self.isReturn,
--     singleMoveTime = self.singleMoveTime,
--     arriveStayTime = self.arriveStayTime,
--     returnStayTime = self.returnStayTime,
--     isStartAnim = self.isStartAnim,
-- })

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local socket = require("socket")

-- 初始化buffer时间，可透支时间
local INITAL_BUFFER_TIME = 500
-- 最大buffer时间，超过此时间意味着太多远端帧没消费了，重置
local MAX_BUFFER_TIME = 1000

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local CircleCtrl = class("CircleCtrl_logic", WBElement)

function  CircleCtrl:getMSTime()
    return socket.gettime() * 1000
end
function CircleCtrl:Round(num)
    return math.floor(num + 0.5)
end

---@param worldElement CS.Tal.framesync.WorldElement
function CircleCtrl:initialize(worldElement)
    CircleCtrl.super.initialize(self, worldElement)
    g_Log("初始化圆周运动控制逻辑")
    self.componentId = 0
    self.movers = {}
    -- 获取帧率
    self.fps = App.Info.configMap.frame_num
    self.fps = tonumber(self.fps)
    if self.fps == nil then
        self.fps = 15
    end
    g_Log("圆周运动器: 帧率",self.fps)
    self.useNewRemoteTick = App:GetService("CommonService").gate.worldController.World.OnUpdateServerFrame ~= nil
    g_Log("圆周运动器: 判定使用新老回调",self.useNewRemoteTick)
    self.oldRemoteTickInterval = self:Round(1000 / self.fps)
    g_Log("圆周运动器: 老回调tick时长",self.oldRemoteTickInterval)
    self.currentOffsetTime = 0
end

function CircleCtrl:RegisterMover(config)
    if not config.move_object then
        return
    end
    self.componentId = self.componentId + 1
    self.movers[self.componentId] = config
    self.movers[self.componentId].totalResumeTime = 0
    self:ResetBufferStatus(self.movers[self.componentId])
    return self.componentId
end

function CircleCtrl:UnRegisterMover(id)
    if not id then
        return
    end
    self.movers[id] = nil
end

function CircleCtrl:startMover(id,frameIndex)
    if self.movers[id] and self.movers[id].isActive == false then
        self.movers[id].state = 0
        self.movers[id].isActive = true
        self.movers[id].lastStartTime = self.currentOffsetTime
        -- 添加暂停逻辑
        if self.movers[id].lastStopTime and self.movers[id].lastStartTime then
            local resumeTime = self.movers[id].lastStartTime - self.movers[id].lastStopTime
            if resumeTime > 0 then
                self.movers[id].totalResumeTime = (self.movers[id].totalResumeTime + resumeTime) --% self.movers[id].totalFrame
                if id == 1 then
                    g_Log("圆周运动器：继续运动" .. self.movers[id].lastStartTime .. "-" .. self.movers[id].lastStopTime)
                end
            end
        elseif self.movers[id].lastStartTime and not self.movers[id].lastStopTime then
            if self.movers[id].isStartAnim == "True" then
                self.movers[id].totalResumeTime = 0
            else
                self.movers[id].totalResumeTime = self.movers[id].lastStartTime
            end
                if id == 1 then
                    g_Log("圆周运动器：初次开始运动" .. self.movers[id].lastStartTime)
                end
        end
    end
end

function CircleCtrl:stopMover(id,frameIndex)
    if self.movers[id] and self.movers[id].isActive == true then
        self.movers[id].state = 6
        self.movers[id].isActive = false
        self.movers[id].lastStopTime = self.currentOffsetTime
    end
end

function CircleCtrl:getSpeedByName(name)
    local obj = GameObject.Find(name)
    if not obj then
        return nil
    end
    local objTrans = obj.transform
    if not objTrans then
        return nil
    end
    for _, mover in pairs(self.movers) do
        if mover then
            if mover.realMove_object.gameObject.name == name or objTrans:IsChildOf(mover.realMove_object.transform) then
                if mover.state == 1 then
                    local v = Vector3(mover.speedX, mover.speedY, mover.speedZ)
                    local dir = CourseEnv.ServicesManager:GetAvatarService():GetAvatarByUUID(App.Uuid).VisElement.transform.position - mover.move_object.gameObject.transform.position
                    local s = v/CS.UnityEngine.Application.targetFrameRate
                    v = Vector3.Cross(dir.normalized, s) * -1.5
                    return v,mover.hitAngle,mover.hitSpeed
                elseif mover.state == 3 then
                    local v = Vector3(-mover.speedX, -mover.speedY, -mover.speedZ)
                    local dir = CourseEnv.ServicesManager:GetAvatarService():GetAvatarByUUID(App.Uuid).VisElement.transform.position - mover.move_object.gameObject.transform.position
                    local s = v/CS.UnityEngine.Application.targetFrameRate
                    v = Vector3.Cross(dir.normalized, s) * -1.5
                    return v,mover.hitAngle,mover.hitSpeed
                else
                    return Vector3(0, 0, 0),mover.hitAngle,mover.hitSpeed
                end
            end
        end
    end
    return nil
end

function CircleCtrl:InitColliderLogic(obj)
    local box = obj.transform:Find("碰撞器").gameObject
    box.layer = CS.UnityEngine.LayerMask.NameToLayer("NPC")
    CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(box, function(other)
        if self.selfAvatar then
            if other.name == self.selfAvatar.VisElement.gameObject.name then
                self.objCollider = obj
                self:colliderTick()
            end
        end
    end)

    CourseEnv.ServicesManager:GetColliderService():RegisterColliderExitListener(box, function(other)
        if self.selfAvatar then
            if other.name == self.selfAvatar.VisElement.gameObject.name then
                self.objCollider = nil
                g_Log("主角离开板子")
                local curParent = self.selfAvatar.VisElement.transform.parent
                if curParent == obj.transform then
                    self.selfAvatar.VisElement.transform:SetParent(self.oriParent)
                end
            end
        end
    end)
end

function CircleCtrl:Tick()
    for id, mover in pairs(self.movers) do
        self:moveTick(id,mover)
    end

    self:colliderTick()
end

function CircleCtrl:colliderTick()
    if not self.objCollider then
        return
    end
    if not self.selfAvatar then
        return
    end
    if self.selfAvatar.characterCtrl.characterCtrl.isGrounded or self.selfAvatar.characterCtrl.isGrounded then
        g_Log("主角处在板子上")
        self.selfAvatar.VisElement.transform:SetParent(self.objCollider.transform)
        self.objCollider = nil
    end
end

function CircleCtrl:moveTick(id,mover)
    if mover then
        local current = self:getMSTime()
        if mover.lastLocalFrameTime < 0 then
            mover.lastLocalFrameTime = current
            return
        end

        if mover.currentBufferStatus < 2 or mover.currentConsumeTime < 0 then
            -- 无效数据
            mover.lastLocalFrameTime = current
            mover.currentBufferStatus = 1
            return
        end


        if mover.currentBufferStatus == 2 then
            -- 首次运动
            local delta = current - mover.startUpLocalTime
            mover.currentConsumeTime = mover.currentConsumeTime + delta
            self:DispatchFrameIndex(mover,mover.currentConsumeTime)
            mover.currentBufferStatus = 3
            if id == 1 then
                g_Log("圆周运动器: buffer就绪，开始消费,启动偏移|总时长",mover.currentConsumeTime,mover.totalTimeInMS)
            end
        else
            -- 正常运动
            local delta = current - mover.lastLocalFrameTime
            mover.currentConsumeTime = mover.currentConsumeTime + delta
            if mover.currentBufferTime > delta then
                -- 够消费
                self:DispatchFrameIndex(mover,mover.currentConsumeTime)
                mover.currentBufferTime = mover.currentBufferTime - delta
                -- g_Log("运动器: buffer消费",delta,"余量",self.currentBufferTime)
            else
                -- 进入等待状态 等远端帧驱动重置
                mover.currentBufferStatus = 1
                if id == 1 then
                    g_Log("圆周运动器: buffer用尽无法消费，开始等待")
                end
            end
        end

        mover.lastLocalFrameTime = current
    end
end

function CircleCtrl:ResetBufferStatus(mover)
    -- 总Buffer时间500ms（可透支500）
    mover.currentBufferTime = INITAL_BUFFER_TIME
    -- 上一次帧号
    mover.lastRemoteFrameIndex = -2
    -- 上一次帧号对应时间
    mover.lastRemoteFrameTime = -1
    -- 当前消费的时间
    mover.currentConsumeTime = -1
    -- 上一帧的本地时间
    mover.lastLocalFrameTime = -1

    -- 当前状态 
    -- Init = 0  
    -- waiting = 1 --等待状态：等待收到一个远端帧进入准备运动状态
    -- ready = 2 准备就绪 等待开始
    -- moving = 3 --正常运动状态
    mover.currentBufferStatus = 0
end
function CircleCtrl:WhenBufferStatusIsWaiting(mover, sendTime)
    -- 重置所有变量
    self:ResetBufferStatus(mover)
    -- g_Log("运动器 buffer重置500")
    -- 进入就绪状态
    -- 记录启动偏移，保证同一个网络帧，大家动的是一样的
    mover.currentConsumeTime = sendTime -- % mover.totalTimeInMS
    mover.currentBufferStatus = 2
    mover.startUpLocalTime = self:getMSTime()
end

function CircleCtrl:UpdateServerFrame(frameIndex,sendtime,aftertime)
    self.currentOffsetTime = aftertime
    local sendTime = aftertime --frameIndex * self.oldRemoteTickInterval
    self:_OnReceiveRemoteTime(frameIndex,sendTime)
end

function CircleCtrl:_OnReceiveRemoteTime(index,sendTime)
    for id, mover in pairs(self.movers) do
        if mover then
            --起始运动时间
            if index > mover.startDelayTime * self.fps then
                if index - mover.lastRemoteFrameIndex > 1 or mover.currentBufferStatus == 1 then
                    if id == 1 then
                        g_Log("圆周运动器: 帧丢失，闪现处理，当前帧：", index, "，上一帧：", mover.lastRemoteFrameIndex)
                    end
                    self:WhenBufferStatusIsWaiting(mover,sendTime)
                else
                    --正常往buffer里加时间
                    mover.currentBufferTime = mover.currentBufferTime + (sendTime - mover.lastRemoteFrameTime)
                    -- g_Log("运动器 buffer增加",sendTime - self.lastRemoteFrameTime)
                    if mover.currentBufferTime > MAX_BUFFER_TIME then
                        -- 重置
                        if id == 1 then
                            g_Log("圆周运动器: buffer时间太长，落后太多，重置")
                        end
                        self:WhenBufferStatusIsWaiting(mover, sendTime)
                    end
                end
    
                mover.lastRemoteFrameTime = sendTime
                mover.lastRemoteFrameIndex = index
            end
        end
    end
end

function CircleCtrl:UpdateFrameIndex(index)
    if self.useNewRemoteTick then
        return
    end

    self.currentOffsetTime = index * self.oldRemoteTickInterval
    local sendTime = index * self.oldRemoteTickInterval
    self:_OnReceiveRemoteTime(index, sendTime)
end

function CircleCtrl:DispatchFrameIndex(mover,curConsumedTime)
    local index = curConsumedTime / 1000 * self.fps
    local resumeFrame = mover.totalResumeTime * self.fps / 1000
    if mover then
        if mover.state == -1 or mover.state >= 5 then
            return
        end
    
        -- 延迟启动逻辑
        if index < mover.startDelayTime * self.fps + resumeFrame then
            -- mover.state = -1
            return
        else
            -- 过了延迟启动时间，开始运动逻辑
            -- 是否过了失效时间
            if mover.disableTime > 0 and index > (mover.startDelayTime + mover.disableTime) * self.fps + resumeFrame then
                -- 超时失效
                mover.state = 5
                return
            end
            -- 是否单次运动后不停留
            if mover.isRepeat ~= "True" and index >= (mover.startDelayTime * self.fps + mover.totalFrame + resumeFrame) then
                mover.state = 5
                return
            end
    
            -- 添加暂停逻辑
            index = index - resumeFrame

            if mover.isReturn == "True" then
                -- 单次运动帧号值
                local moveIndex = (index - mover.startDelayTime * self.fps) % mover.totalFrame
                if moveIndex <= mover.singleMoveTime * self.fps then
                    -- 兼容单程帧数不为整数的情况
                    local frameDiff = mover.singleMoveTime * self.fps - moveIndex
                    if frameDiff > 0 and frameDiff < 1 and mover.arriveStayTime > 0 then
                        moveIndex = mover.singleMoveTime * self.fps
                    end
                    mover.tarLocalRotation = Vector3(mover.originLocalRotation.x + mover.speedX * moveIndex / self.fps,
                    mover.originLocalRotation.y + mover.speedY * moveIndex / self.fps,
                    mover.originLocalRotation.z + mover.speedZ * moveIndex / self.fps)
                    mover.tarRotation = Vector3(mover.originRotation.x + mover.speedX * moveIndex / self.fps,
                    mover.originRotation.y + mover.speedY * moveIndex / self.fps,
                    mover.originRotation.z + mover.speedZ * moveIndex / self.fps)
                    mover.finLocalRotation = mover.tarLocalRotation
                    mover.finRotation = mover.tarRotation
                    mover.state = 1
                elseif moveIndex <= (mover.singleMoveTime + mover.arriveStayTime) * self.fps then
                    mover.state = 2
                elseif moveIndex <= (mover.singleMoveTime + mover.arriveStayTime + mover.singleMoveTime) * self.fps then
                    -- 兼容单程帧数不为整数的情况
                    local frameDiff = (mover.singleMoveTime + mover.arriveStayTime + mover.singleMoveTime) * self.fps - moveIndex
                    if frameDiff > 0 and frameDiff < 1 and mover.returnStayTime > 0 then
                        moveIndex = (mover.singleMoveTime + mover.arriveStayTime + mover.singleMoveTime) * self.fps
                    end
                    local time = moveIndex / self.fps - (mover.singleMoveTime + mover.arriveStayTime)
                    mover.tarLocalRotation = Vector3(mover.finLocalRotation.x - mover.speedX * time,
                    mover.finLocalRotation.y - mover.speedY * time, mover.finLocalRotation.z - mover.speedZ * time)
                    mover.tarRotation = Vector3(mover.finRotation.x - mover.speedX * time, mover.finRotation.y - mover.speedY * time,
                    mover.finRotation.z - mover.speedZ * time)
                    mover.state = 3
                elseif moveIndex <= (mover.singleMoveTime + mover.arriveStayTime + mover.singleMoveTime + mover.returnStayTime) *
                    self.fps then
                        mover.state = 4
                end
            else
                -- 单次运动帧号值
                local moveIndex = (index - mover.startDelayTime * self.fps) % mover.totalFrame
                -- 第几次重复运动
                local repeatIndex = math.floor((index - mover.startDelayTime * self.fps) / mover.totalFrame)
                repeatIndex = repeatIndex % 360
    
                if moveIndex <= mover.singleMoveTime * self.fps then
                    -- 兼容单程帧数不为整数的情况
                    local frameDiff = mover.singleMoveTime * self.fps - moveIndex
                    if frameDiff > 0 and frameDiff < 1 and mover.arriveStayTime > 0 then
                        moveIndex = mover.singleMoveTime * self.fps
                    end
                    mover.tarLocalRotation = Vector3(mover.originLocalRotation.x + mover.speedX *
                                                        (moveIndex / self.fps + repeatIndex * mover.singleMoveTime),
                        mover.originLocalRotation.y + mover.speedY * (moveIndex / self.fps + repeatIndex * mover.singleMoveTime),
                        mover.originLocalRotation.z + mover.speedZ * (moveIndex / self.fps + repeatIndex * mover.singleMoveTime))
                        mover.tarRotation = Vector3(mover.originRotation.x + mover.speedX *
                                                   (moveIndex / self.fps + repeatIndex * mover.singleMoveTime),
                                                   mover.originRotation.y + mover.speedY * (moveIndex / self.fps + repeatIndex * mover.singleMoveTime),
                                                   mover.originRotation.z + mover.speedZ * (moveIndex / self.fps + repeatIndex * mover.singleMoveTime))
                                                   mover.state = 1
                elseif moveIndex <= (mover.singleMoveTime + mover.arriveStayTime) * self.fps then
                    mover.state = 2
                end
            end
    
            local quarternion = Quaternion.Euler(mover.tarLocalRotation.x - mover.originLocalRotation.x,
            mover.tarLocalRotation.y - mover.originLocalRotation.y, 
            mover.tarLocalRotation.z - mover.originLocalRotation.z)
            mover.move_object.localRotation = quarternion *  mover.originRotationQuarternion
        end
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function CircleCtrl:ReceiveMessage(key, value, isResume)
    
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function CircleCtrl:SendCustomMessage(key, body)
    
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function CircleCtrl:SelfAvatarCreated(avatar)
    local AvatarService = App:GetService("Avatar")
    ---@type FSyncAvatarCtrl
    self.selfAvatar = AvatarService:GetAvatarByUUID(App.Uuid)
    self.oriParent = self.selfAvatar.VisElement.transform.parent
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function CircleCtrl:SelfAvatarPrefabLoaded(avatar)
    
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function CircleCtrl:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function CircleCtrl:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function CircleCtrl:LogicMapStartRecover()
    CircleCtrl.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function CircleCtrl:LogicMapEndRecover()
    CircleCtrl.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function CircleCtrl:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

--收到Trigger事件
function CircleCtrl : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function CircleCtrl : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function CircleCtrl:Exit()
    g_Log("客户端:退出圆周运动服务")
    CircleCtrl.super.Exit(self)
end

return CircleCtrl
 

