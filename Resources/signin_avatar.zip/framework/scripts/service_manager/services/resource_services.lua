local class = require("middleclass")
local json = require("nextjson")

---@type Service
local Service = require("app/service")
local abcLoadingPanel = require("scripts/frameSync/common/ABCZone/abc_download_panel")
local eventSubscribe = require("event_subscribe")

local TAG = "资源预加载"

---@class ResourceService : Service
local ResourceService = class("ResourceService", Service)

local Object_Type = {
    Unknown = 0,
    GameObject = 1,
    Texture = 2,
    Sprite = 3,
    AudioClip = 4,
    Scene = 5
}

---@class Download_Priority 资源加载优先级
Download_Priority = {
    High = 1,
    Normal = 2,
    Low = 3
}

function ResourceService:initialize(serviceName)
    self.ServiceName = serviceName

    self.PreloadMap = {}
    self.PreloadList = {}

    self.AvatarComplete = false
    -- CourseEnv.ServicesManager.Gate.OnCreateElement:connect(function(element)

    --     if element:GetType() == 'avatar' then

    --         if element:GetProperty('uuid') == App.Uuid then
    --             -- self:SelfAvatarCreated(element)

    --             element.OnLoadAvatarComplete:connect(function(go)
    --                 if not self.AvatarComplete and not self.registerEvent then
    --                     self.AvatarComplete = true
    --                     self:SelfAvatarPrefabLoaded(element)
    --                 end
    --             end)

    --         end
    --     end
    -- end)

    App.OnSceneDidLoaded:connect(function()
        if not self.AvatarComplete then
            self.AvatarComplete = true
            -- 放在loading隐藏后
            self:StartPreloadResource()
        end
    end)

    self.IsDownloading = false

    self.progressHandler = function(progress, size)
        -- 四舍五入保留两位小数
        progress = math.floor(progress * 100) / 100
        -- g_Log(TAG,"回调下载进度",progress)

        self.loadingPanel:UpdateProgress(progress, size)
    end

    self.loadingPanel = abcLoadingPanel:new()
    self.loadingPanel.OnClosed:connect(function()

        -- 当前下载任务继续 但是不再回调业务callback
        if self.ShowLoadingUrl then
            g_Log(TAG, "手动取消", self.ShowLoadingUrl)
            local data = self.PreloadMap[self.ShowLoadingUrl]
            if data then

                for _, callback in ipairs(data.callbacks) do
                    callback(false, nil)
                end

                data.callbacks = {}
                return
            end
        end

    end)

    self:InitListener()

    self.ImportCallbacks = {}
end

function ResourceService:InitListener()

    self.urlSizeMap = {}

    APIBridge.CreateService('unity.api.storage.downloadprogress', {}, function(res)

        if res.progress and res.fileSize and res.url and self.ShowLoadingUrl == res.url then
            self.progressHandler(res.progress, res.fileSize)

            if not self.urlSizeMap[res.url] then
                self.urlSizeMap[res.url] = res.fileSize
                local m = tonumber(res.fileSize) / 1024 / 1024
                -- g_Log(TAG, "收到进度回调", res.url, m)
            end
        end

    end)
end

---@public
---注册预加载资源
---@param uaddress string
---@param priority Download_Priority 下载优先级
---@param callback function 资源静默加载完成的回调
function ResourceService:RegisterPreDownloadResourceByUaddress(uaddress, priority, callback)

    if uaddress == nil or uaddress == '' then
        g_LogError("错误的地址0 ", uaddress)
        return
    end

    local url, package = self:GetUrlAndPackageByUaddress(uaddress)
    if not url then
        g_LogError("错误的地址1 ", uaddress)
        return
    end

    if not package then
        g_LogError("错误的地址2 ", uaddress)
        return
    end

    if self.AvatarComplete then
        g_LogError("请在初始化的时候注册！！ ", uaddress)
        return
    end

    if self.PreloadMap[url] then
        return
    end

    if not priority then
        priority = Download_Priority.Low
    end

    local data = {
        uaddress = uaddress,
        url = url,
        package = package,
        callbacks = {}, -- 可以添加多个回调 这里是个数组
        progressCallback = nil,
        priority = priority
    }
    if callback then
        table.insert(data.callbacks, callback)
    end

    self.PreloadMap[url] = data

    if priority == Download_Priority.Normal then
        -- 插在所有high之后 所有low之前
        local insertIndex = 1
        -- 找到最后一个High优先级的位置
        for i, v in ipairs(self.PreloadList) do
            if v.priority == Download_Priority.High then
                insertIndex = i + 1
            end
        end
        table.insert(self.PreloadList, insertIndex, data)
    elseif priority == Download_Priority.High then
        table.insert(self.PreloadList, 1, data)
    else
        table.insert(self.PreloadList, data)
    end

end

function ResourceService:ChangeTaskToHighPriority(task)
    -- 在self.PreloadList中找到task 并且移动到第一个
    for i, v in ipairs(self.PreloadList) do
        if v == task and i ~= 1 then
            table.remove(self.PreloadList, i)
            table.insert(self.PreloadList, 1, task)
            return
        end
    end
end

function ResourceService:PackageExist(pkgName)

    return ResourceManager:PackageExist(pkgName)
end

---@public
---加载远程资源
---@param uaddress string
---@param callback function(success,gameObject)_
---@param showLoading boolean 是否显示loading  如果显示，主动关闭后不再回调callback
function ResourceService:LoadRemoteResourceByUaddress(uaddress, callback, showLoading)

    -- local uAddress = "modules/" .. uaddress

    if uaddress == nil or uaddress == '' then
        g_LogError("错误的地址0 ", uaddress)
        return
    end

    local url, package = self:GetUrlAndPackageByUaddress(uaddress)
    if not url then
        g_LogError("错误的地址1 ", uaddress)
        return
    end

    if not callback then
        g_LogError("未注册回调 ", uaddress)
        return
    end

    local exist = false
    if self:PackageExist(package) then
        exist = true
    end

    if not exist and showLoading == true then
        self.ShowLoadingUrl = url
        self.loadingPanel:ShowLoading(true)
    end

    local cb = function(success)

        --  g_Log(TAG, "开始加载", uaddress)
        if success then
            
            local uAddress = "modules/" .. uaddress
            --防双击  只回调最后一次
            if showLoading then
                self.ImportCallbacks[uAddress] = callback
            end
            ImportAsync(package, function(p)
                self:LoadObjectByUaddress(uAddress, function(gameGo)
                    -- g_Log(TAG, "加载完成0~", package, url, gameGo)
                    xpcall(function()
                        
                        if showLoading then
                            local cb = self.ImportCallbacks[uAddress]
                            if cb then
                                self.ImportCallbacks[uAddress]  = nil
                                cb(true, gameGo)   
                            end
                        else
                            callback(true, gameGo)  
                        end
                        
                    end, function(err)
                        g_LogError(err)
                    end)
                end)
            end)
        else
            callback(false, nil)
        end

    end

    if exist then
        -- g_Log(TAG, "已存在文件，直接加载！")
        cb(true)
        return
    end

    local data = self.PreloadMap[url]

    if showLoading and App.Info.configMap.env ~= "online" then
        --
        local param = {}
        param["eventId"] = "LoadingResource"
        param["param_one"] = uaddress
        APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
    end

    if data and self:IsExistTask(data) then

        -- g_Log(TAG, "已存在的任务 插队！", table.dump(data))

        -- 如果已经在预加载列表里 提到到最前面
        self:ChangeTaskToHighPriority(data)

        -- TODO:先改成单个回调
        if showLoading then
            --带loading的只回调最后一次调用
            data.callbacks = {}
            table.insert(data.callbacks, cb)
        else
            table.insert(data.callbacks, cb)
        end

        
        return
    end

    -- 插到最前面一个任务
    data = {
        uaddress = uaddress,
        url = url,
        package = package,
        callbacks = {},
        progressCallback = nil
    }

    data.callbacks = {}
    table.insert(data.callbacks, cb)

    self.PreloadMap[url] = data
    table.insert(self.PreloadList, 1, data)

    if #self.PreloadList == 1 then
        self:StartPreloadResource()
    end

end

function ResourceService:IsExistTask(data)
    for _, v in ipairs(self.PreloadList) do
        if v.url == data.url then
            return true
        end
    end
    return false
end

function ResourceService:GetObjectType(uaddress)
    if string.endswith(uaddress, ".prefab") then
        return Object_Type.GameObject
    elseif string.endswith(uaddress, ".mp3") then
        return Object_Type.AudioClip
    elseif string.endswith(uaddress, ".png") then
        return Object_Type.Sprite
    elseif string.endswith(uaddress, ".unity") then
        return Object_Type.Scene
    end

    return Object_Type.Unknown
end

function ResourceService:LoadObjectByUaddress(uaddress, callback)
    -- g_Log(TAG, "加载", uaddress)
    if not self.tLoadingObj then
        self.tLoadingObj = {}
    end

    if self.tLoadingObj[uaddress] then
        table.insert(self.tLoadingObj[uaddress], callback)
        return
    else
        self.tLoadingObj[uaddress] = {callback}
    end

    local type = self:GetObjectType(uaddress)
    if type == Object_Type.GameObject then
        ResourceManager:LoadGameObjectWithExName(uaddress, function(gameGo)
            for _, cb in ipairs(self.tLoadingObj[uaddress]) do
                cb(gameGo)
            end
            self.tLoadingObj[uaddress] = nil
        end)
    elseif type == Object_Type.AudioClip then
        ResourceManager:LoadAudioClipWithExName(uaddress, function(audioClip)
            for _, cb in ipairs(self.tLoadingObj[uaddress]) do
                cb(audioClip)
            end
            self.tLoadingObj[uaddress] = nil
        end)
    elseif type == Object_Type.Sprite then
        ResourceManager:LoadSpriteWithExName(uaddress, function(sprite)
            for _, cb in ipairs(self.tLoadingObj[uaddress]) do
                cb(sprite)
            end
            self.tLoadingObj[uaddress] = nil
        end)
    elseif type == Object_Type.Scene then
        ResourceManager:LoadSceneAsyncAdditive(uaddress)
    else
        g_LogError(TAG .. ":未知类型", uaddress)
        callback(nil)
    end

end

function ResourceService:StartPreloadResource()

    if #self.PreloadList == 0 then
        return
    end

    self:_Next()
end

function ResourceService:_Next()

    if #self.PreloadList == 0 then
        self.downloadingUrl = nil
        self.IsDownloading = false
        return
    end

    local data = self.PreloadList[1]
    local uaddress = data.uaddress
    local url = data.url
    local package = data.package

    self.downloadingUrl = url
    self.IsDownloading = true
    -- g_Log(TAG, "开始下载", url, package)
    App:GetService("Avatar"):LoadAvatarSkin(package, url, "", 1000, function(status, pkgName)
        if status == "success" and self:PackageValid(pkgName) then
            -- g_Log(TAG, "下载成功", status, package)
            xpcall(function()
                for _, callback in ipairs(data.callbacks) do
                    callback(true, pkgName)
                end
            end, function(err)
                g_LogError(err)
            end)
        else
            g_Log(TAG, "下载失败", status, package)
            xpcall(function()
                for _, callback in ipairs(data.callbacks) do
                    callback(false, pkgName)
                end
            end, function(err)
                g_LogError(err)
            end)

            local param = {}
            param["eventId"] = " ResLoadFailed"
            param["param_one"] = uaddress
            param["param_two"] = url
            APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)

        end

        -- table.remove(self.PreloadList, 1)
        -- 下载完后可能被插队在队列里索引变了 不直接移除第1个
        local idx = 1
        for i, v in ipairs(self.PreloadList) do
            if v == data then
                idx = i
                break
            end
        end
        table.remove(self.PreloadList, idx)

        self.PreloadMap[url] = nil

        if url == self.ShowLoadingUrl then
            self.ShowLoadingUrl = nil
            self.loadingPanel:ShowLoading(false)
        end

        self:_Next()
    end)

end

function ResourceService:PackageValid(packageName)
    local exist = false
    local LocalDir = App:GetPackageCachePath(packageName)
    if CS.System.IO.Directory.Exists(LocalDir) then
        local pkgJson = LocalDir .. "/package.json"
        local assetCatalog = LocalDir .. "/assets/catalog.json"
        if ResourceManager:IsPathExist(pkgJson) and ResourceManager:IsPathExist(assetCatalog) then
            exist = true
        else
            exist = false
        end
    end

    return exist
end

---@private
---获取下载地址和包名
-- 854841713252075/assets/Prefabs/CZ.prefab
function ResourceService:GetUrlAndPackageByUaddress(uaddress)
    local list = string.split(uaddress, "/")
    if #list == 0 then
        return nil
    end
    local packageName = list[1]
    local urlPrefix = "https://static0.xesimg.com/next-studio-pub/"
    local url = ""
    if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.Android then
        url = urlPrefix .. "android_bundle/"
    elseif CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.IPhonePlayer then
        url = urlPrefix .. "ios_bundle/"
    else
        url = urlPrefix .. "openharmony_bundle/"
    end

    

    if App.IsStudioClient then
        if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.WindowsEditor or
           CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.WindowsPlayer then
            url = urlPrefix .. "windows_bundle/"
        else
            url = urlPrefix .. "mac_bundle/"
        end
    end

    url = url .. packageName .. ".zip"

    return url, packageName
end

---@private
function ResourceService:SelfAvatarPrefabLoaded(avatar)
    -- self:StartPreloadResource()
end

return ResourceService
