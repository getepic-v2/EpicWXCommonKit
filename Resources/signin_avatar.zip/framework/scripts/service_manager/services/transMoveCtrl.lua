-- 传送带控制逻辑
-- 用法如下：
-- 注册传送带
-- self.componentId = CourseEnv.ServicesManager:GetMoveService().transMoveCtrl:RegisterMover({
--     speedX = self.speedX,
--     speedY = self.speedY,
--     speedZ = self.speedZ,
--     move_object = self.move_object,
-- })

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local TransCtrl = class("TransCtrl_logic", WBElement)

---@param worldElement CS.Tal.framesync.WorldElement
function TransCtrl:initialize(worldElement)
    TransCtrl.super.initialize(self, worldElement)
    g_Log("初始化传送带控制逻辑")
    self.componentId = 0
    self.movers = {}
end

function TransCtrl:RegisterMover(config)
    if not config.move_object then
        g_LogError("注册传送带时没有找到运动目标")
        return
    end
    self.componentId = self.componentId + 1
    self.movers[self.componentId] = config
    self.movers[self.componentId].isActive = false
    local id = self.componentId
    local box = config.move_object.transform:Find("trigger").gameObject
    CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(box, function(other)
        if self.selfAvatar and self.movers[id] then
            if other.name == self.selfAvatar.VisElement.gameObject.name and self.movers[id].isActive == true then

                if self.willExitCor then
                    self.commonService:StopCoroutineSafely(self.willExitCor)
                    self.willExitCor = nil
                end

                if self.cor then
                    self.commonService:StopCoroutineSafely(self.cor)
                    self.cor = nil
                end

                self.cor  = self.commonService:StartCoroutine(function()
                    self.commonService:YieldFixedUpdate()
                    while self.cor do
                        self.commonService:YieldFixedUpdate()
                        self.selfAvatar.VisElement.transform.position = self.selfAvatar.VisElement.transform.position + Vector3(self.movers[id].speedX * Time.deltaTime, 0, self.movers[id].speedZ * Time.deltaTime)
                    end
            
                end)
            end
        end
    end)

    CourseEnv.ServicesManager:GetColliderService():RegisterColliderExitListener(box, function(other)
        if self.selfAvatar and self.movers[id] then
            if other.name == self.selfAvatar.VisElement.gameObject.name then
                if self.cor then

                    self.willExitCor = self.commonService:StartCoroutine(function()
                        self.commonService:StopCoroutineSafely(self.cor)
                        self.cor = nil

                        local jump = self.selfAvatar.characterCtrl.upping or self.selfAvatar.characterCtrl.falling
                        local i = 10
                        --再保持10帧衰减的移动
                        while i > 0  do
                            self.commonService:YieldFixedUpdate()
                            local scale = i/10;
                            if jump then
                                scale = 1
                            end
                            local offset = Vector3(self.movers[id].speedX * Time.deltaTime, 0, self.movers[id].speedZ * Time.deltaTime) * scale
                            self.selfAvatar.VisElement.transform.position = self.selfAvatar.VisElement.transform.position + offset
                            i = i - 1
                        end

                    end)
                end
            end
        end
    end)

    return self.componentId
end

function TransCtrl:UnRegisterMover(id)
    if not id then
        return
    end
    self.movers[id] = nil
end

function TransCtrl:GetMover(id)
    return self.movers[id]
end

function TransCtrl:startMover(id)
    if self.movers[id] and self.movers[id].isActive == false then
        self.movers[id].isActive = true
    end
end

function TransCtrl:stopMover(id)
    if self.movers[id] and self.movers[id].isActive == true then
        self.movers[id].isActive = false
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function TransCtrl:ReceiveMessage(key, value, isResume)
    
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function TransCtrl:SendCustomMessage(key, body)
    
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function TransCtrl:SelfAvatarCreated(avatar)
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function TransCtrl:SelfAvatarPrefabLoaded(avatar)
    self.selfAvatar = avatar
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function TransCtrl:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function TransCtrl:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function TransCtrl:LogicMapStartRecover()
    TransCtrl.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function TransCtrl:LogicMapEndRecover()
    TransCtrl.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function TransCtrl:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

--收到Trigger事件
function TransCtrl : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function TransCtrl : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function TransCtrl:Exit()
    g_Log("客户端:退出传送带运动服务")
    if self.cor then
        self.commonService:StopCoroutineSafely(self.cor)
        self.cor = nil
    end

    if self.willExitCor then
        self.commonService:StopCoroutineSafely(self.willExitCor)
        self.willExitCor = nil
    end

    TransCtrl.super.Exit(self)
end

return TransCtrl
 

