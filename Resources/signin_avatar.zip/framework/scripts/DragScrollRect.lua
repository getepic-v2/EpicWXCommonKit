-- DragScrollRect.lua
local class = require('middleclass')
local UnityEngine = CS.UnityEngine
local Vector2 = UnityEngine.Vector2

---@class DragScrollRect
local DragScrollRect = class('DragScrollRect')
local Util = require(MAIN_SCRIPTS_LOC .. "common/util")
-- 构造函数
function DragScrollRect:initialize(scrollRect)
    self.scrollRect = scrollRect
    self.isDragging = false
    self.startDragPosition = 0
    self.pageSize = 0  -- 每页大小，0表示自动计算
    self.pageTurnThreshold = 0.02  -- 翻页阈值
    self.currentPage = 0
    self.totalPages = 0
    self.realPageCount = 0  -- 实际页面数量（不包括复制的页面）
    self.realPageTurnThreshold = 0.4  -- 拖动距离超过这个值才翻页
    -- 自动滚动相关属性
    self.autoScroll = true  -- 是否开启自动滚动
    self.autoScrollInterval = 3.0  -- 自动滚动间隔时间（秒）
    self.autoScrollTimerName = "Banner_AutoScroll_" .. tostring(self.scrollRect:GetInstanceID())
    self.isPaused = false  -- 是否暂停自动滚动
    
    -- 循环滚动相关
    self.isInfinite = true  -- 是否开启循环滚动
    self.isJumping = false  -- 是否正在执行无动画跳转

    -- 拖动方向控制相关
    self.dragDirection = nil  -- 当前拖动方向：'horizontal' 或 'vertical'
    self.isHorizontalLocked = false  -- 是否锁定横向拖动
    self.isVerticalLocked = false  -- 是否锁定纵向拖动
    self.originalHorizontalScroll = true  -- 保存原始横向滚动状态
    self.originalVerticalScroll = true  -- 保存原始纵向滚动状态

    self.scrollDidToPageCallBack = nil
    self.verticalDragCallBack = nil
    
    -- 获取 CommonService 实例
    self.commonService = App:GetService("CommonService")

    -- self.scrollRect:StopMovement()
    self.scrollRect.scrollSensitivity = 1.5 -- 提高灵敏度
    
    -- 初始化
    self:Init()
end

function DragScrollRect:Init()
    -- 获取必要组件
    self.viewport = self.scrollRect.viewport
    self.content = self.scrollRect.content
    
    -- 检查组件是否存在
    if not self.viewport or not self.content then
        g_LogError("DragScrollRect:Init - viewport or content is nil")
        return
    end
    
    -- 计算页面大小
    self.pageWidth = self.pageSize > 0 and self.pageSize or self.viewport.rect.width
    
    -- 记录实际页面数量（在设置无限滚动之前）
    self.realPageCount = self.content.childCount
    
    -- 确保页面数量正确
    if self.realPageCount <= 0 then
        print("警告: 没有子对象，无法创建滚动视图")
        return
    end
    
    -- 页面索引从0开始，所以实际可见的页码范围是[0, realPageCount-1]
    print("实际页面数量: " .. tostring(self.realPageCount) .. ", 页面索引范围: 0-" .. tostring(self.realPageCount - 1))
    
    if self.isInfinite and self.realPageCount > 1 then
        self:SetupInfiniteScroll()
    else
        -- 非循环模式下，总页数等于实际页数
        self.totalPages = self.realPageCount
    end
    
    -- 注册拖拽事件
    self:RegisterDragEvents()
    
    -- 启动自动滚动
    if self.autoScroll and self.totalPages > 1 then
        self:StartAutoScroll()
    end
end

-- 设置循环滚动
function DragScrollRect:SetupInfiniteScroll()
    -- 复制第一个和最后一个页面
    local firstChild = self.content:GetChild(0)
    local lastChild = self.content:GetChild(self.realPageCount - 1)
    
    print("SetupInfiniteScroll: 第一个子对象: " .. firstChild.name .. ", 最后一个子对象: " .. lastChild.name)
    
    -- 在末尾添加第一个页面的复制
    local firstClone = CS.UnityEngine.GameObject.Instantiate(firstChild, self.content)
    firstClone.name = firstChild.name .. "_clone"
    self.firstClone = firstClone
    -- 在开头添加最后一个页面的复制
    local lastClone = CS.UnityEngine.GameObject.Instantiate(lastChild, self.content)
    lastClone.name = lastChild.name .. "_clone"
    lastClone:SetAsFirstSibling()
    self.lastClone = lastClone
    -- 调整 Content 大小
    local contentWidth = self.pageWidth * (self.realPageCount + 2)
    local contentRT = self.content:GetComponent(typeof(CS.UnityEngine.RectTransform))
    contentRT.sizeDelta = Vector2(contentWidth, contentRT.sizeDelta.y)
    
    -- 更新总页数（包括复制的页面）
    self.totalPages = self.content.childCount
    print("循环滚动设置完成: 实际页面数 = " .. tostring(self.realPageCount) .. ", 总页面数(含复制页) = " .. tostring(self.totalPages))
    
    -- 初始位置设置到第一个真实页面
    if self.totalPages > 1 then
        self:ScrollToPage(1, false)
    else
        self:ScrollToPage(0, false)
    end
end


-- 注册拖拽事件
function DragScrollRect:RegisterDragEvents()
    -- 获取或添加事件触发器组件
    local trigger = self.scrollRect.gameObject:GetComponent(typeof(CS.UnityEngine.EventSystems.EventTrigger))
    if not trigger then
        trigger = self.scrollRect.gameObject:AddComponent(typeof(CS.UnityEngine.EventSystems.EventTrigger))
    end
    
    -- 开始拖拽事件
    local beginDrag = CS.UnityEngine.EventSystems.EventTrigger.Entry()
    beginDrag.eventID = CS.UnityEngine.EventSystems.EventTriggerType.BeginDrag
    beginDrag.callback:AddListener(function(data)
        print("---gyz 开始拖拽--")
        self:OnBeginDrag(data)
    end)
    trigger.triggers:Add(beginDrag)

    -- 拖拽事件
    local drag = CS.UnityEngine.EventSystems.EventTrigger.Entry()
    drag.eventID = CS.UnityEngine.EventSystems.EventTriggerType.Drag
    drag.callback:AddListener(function(data)
        print("---gyz 拖拽--")
        self:OnDrag(data)
    end)
    trigger.triggers:Add(drag)
    -- 结束拖拽事件
    local endDrag = CS.UnityEngine.EventSystems.EventTrigger.Entry()
    endDrag.eventID = CS.UnityEngine.EventSystems.EventTriggerType.EndDrag
    endDrag.callback:AddListener(function(data)
        print("---gyz 结束拖拽--")
        self:OnEndDrag(data)
    end)
    trigger.triggers:Add(endDrag)
end

-- 开始拖拽
function DragScrollRect:OnBeginDrag(eventData)
    if Util:IsNil(self.scrollRect) then
        return
    end
    self.isDragging = true
    self.startDragPosition = self.scrollRect.horizontalNormalizedPosition
    self.dragDirection = nil  -- 重置拖动方向
    self.isHorizontalLocked = false  -- 重置锁定状态
    self.isVerticalLocked = false  -- 重置锁定状态
    
    -- 保存原始滚动状态
    self.originalHorizontalScroll = self.scrollRect.horizontal
    self.originalVerticalScroll = self.scrollRect.vertical
    
    self:StopAutoScroll()
end

-- 拖拽
function DragScrollRect:OnDrag(eventData)
    print("---gyz 拖拽--")
    if Util:IsNil(self.scrollRect) then
        return
    end
    -- 判断拖动方向
    local deltaX = math.abs(eventData.delta.x)
    local deltaY = math.abs(eventData.delta.y)
    
    -- 如果还没有确定拖动方向，则判断方向
    if not self.dragDirection then
        if deltaY > deltaX then
            -- 纵向拖动距离大于横向
            self.dragDirection = 'vertical'
            self.isHorizontalLocked = true
            self.isVerticalLocked = false
            print("---gyz 确定纵向拖动，锁定横向拖动--")
        else
            -- 横向拖动距离大于纵向
            self.dragDirection = 'horizontal'
            self.isHorizontalLocked = false
            self.isVerticalLocked = true
            print("---gyz 确定横向拖动，锁定纵向拖动--")
        end
    end
    
    -- 根据锁定的方向执行相应的逻辑
    if self.dragDirection == 'vertical' then
        -- 纵向拖动，禁用横向滚动
        if self.isHorizontalLocked then
            self.scrollRect.horizontal = false
        end
        print("---gyz 垂直方向拖拽--")
        if self.verticalDragCallBack then
            self.verticalDragCallBack(eventData)
        end
    elseif self.dragDirection == 'horizontal' then
        -- 横向拖动，禁用纵向滚动
        if self.isVerticalLocked then
            self.scrollRect.vertical = false
        end
        print("---gyz 水平方向拖拽--")
    end
end

-- 结束拖拽
function DragScrollRect:OnEndDrag(eventData)
    if Util:IsNil(self.scrollRect) then
        return
    end
    -- 恢复原始滚动状态
    self.scrollRect.horizontal = self.originalHorizontalScroll
    self.scrollRect.vertical = self.originalVerticalScroll
    
    -- 重置拖动方向相关状态
    self.dragDirection = nil
    self.isHorizontalLocked = false
    self.isVerticalLocked = false
    
    -- 计算拖动距离
    local dragDistance = self.scrollRect.horizontalNormalizedPosition - self.startDragPosition
    
    -- 获取当前位置对应的页面索引
    local currentPosition = self.scrollRect.horizontalNormalizedPosition
    local totalWidth = self.content.rect.width
    local viewportWidth = self.viewport.rect.width
    local currentOffset = currentPosition * (totalWidth - viewportWidth)
    local estimatedPage = self.currentPage -- math.floor((currentOffset + self.pageWidth * 0.6) / self.pageWidth)
    if dragDistance > 0 then
        estimatedPage = math.floor((currentOffset + self.pageWidth * (1 - self.realPageTurnThreshold)) / self.pageWidth)
    else
        estimatedPage = math.ceil((currentOffset - self.pageWidth * (1 - self.realPageTurnThreshold)) / self.pageWidth)
    end
    -- 确保页面索引在有效范围内
    estimatedPage = math.max(0, math.min(estimatedPage, self.totalPages - 1))
    
    -- 判断是否需要翻页
    if math.abs(dragDistance) > self.pageTurnThreshold then
        -- 根据拖动方向调整页面
        if dragDistance > 0 then
            -- 向右拖动，页码减小
            estimatedPage = math.max(0, estimatedPage)
        else
            -- 向左拖动，页码增加
            estimatedPage = math.min(self.totalPages - 1, estimatedPage)
        end
    end
    
    -- 滚动到目标页面
    self:ScrollToPage(estimatedPage, true)
    
    self.isDragging = false
    self:StartAutoScroll()
end

function DragScrollRect:SetRealPageTurnThreshold(threshold)
    self.realPageTurnThreshold = threshold
end

-- 开始自动滚动
function DragScrollRect:StartAutoScroll()
    -- 先停止之前的计时器
    self:StopAutoScroll()
    
    -- 重新注册计时器
    if self.totalPages > 1 then
        self.timerId = self.commonService:RegisterGlobalTimer(self.autoScrollInterval, function()
            if not self.isDragging and not self.isPaused then
                -- 计算下一页索引
                local nextPage = self.currentPage + 1
                -- 如果是无限滚动，且当前在最后一个真实页面，直接跳到第一个真实页面
                if self.isInfinite and nextPage > self.totalPages - 1 then
                    nextPage = 1
                end
                -- 执行滚动
                self:ScrollToPage(nextPage, true)
            end
        end, false)  -- 不立即执行，等待间隔时间后再开始自动滚动
    end
end

-- 停止自动滚动
function DragScrollRect:StopAutoScroll()
    if self.timerId then
        self.commonService:UnregisterGlobalTimer(self.timerId)
        self.timerId = nil
    end
end

-- 平滑滚动
function DragScrollRect:StartSmoothScroll(targetPosition, scorllFinishCallBack)
    if self.scrollCoroutine then
        self.commonService:StopCoroutineSafely(self.scrollCoroutine)
        self.scrollCoroutine = nil
    end
    
    self.scrollCoroutine = self.commonService:StartCoroutine(function()
        if Util:IsNil(self.scrollRect) then
            return
        end
        local startPosition = self.scrollRect.horizontalNormalizedPosition
        local elapsedTime = 0
        local duration = 0.3  -- 动画持续时间
        
        while elapsedTime < duration do
            elapsedTime = elapsedTime + UnityEngine.Time.deltaTime
            local t = elapsedTime / duration
            
            -- 使用缓动函数使动画更平滑
            t = 1 - math.cos(t * math.pi * 0.5)
            if not Util:IsNil(self.scrollRect) then
                self.scrollRect.horizontalNormalizedPosition = self:Lerp(startPosition, targetPosition, t)
            end
            self.commonService:YieldEndFrame()
        end
        
        if not Util:IsNil(self.scrollRect) then
            self.scrollRect.horizontalNormalizedPosition = targetPosition
        end
        if scorllFinishCallBack then
            scorllFinishCallBack()
        end
    end)
end

-- 工具函数：线性插值
function DragScrollRect:Lerp(start, target, t)
    return start + (target - start) * t
end

-- 停止当前滚动协程
function DragScrollRect:StopScrollCoroutine()
    if self.scrollCoroutine then
        self.commonService:StopCoroutineSafely(self.scrollCoroutine)
        self.scrollCoroutine = nil
    end
end

-- 获取当前页码
function DragScrollRect:GetCurrentPage()
    return self.currentPage
end

-- 获取总页数
function DragScrollRect:GetTotalPages()
    return self.totalPages
end

-- 下一页
function DragScrollRect:NextPage()
    if self.totalPages <= 1 then return end
    
    -- 计算下一页索引，注意索引范围是[0, realPageCount-1]
    local nextPage = (self.currentPage + 1) % self.realPageCount
    
    -- 如果要显示从1开始的页码，可以在打印时加1
    local currentPageDisplay = self.currentPage + 1
    local nextPageDisplay = nextPage + 1
    
    print("下一页: " .. tostring(currentPageDisplay) .. " -> " .. tostring(nextPageDisplay) .. 
          " (索引: " .. tostring(self.currentPage) .. " -> " .. tostring(nextPage) .. 
          "), 总页数 = " .. tostring(self.realPageCount))
    
    self:ScrollToPage(nextPage)
end

-- 上一页
function DragScrollRect:PreviousPage()
    if self.totalPages <= 1 then return end
    
    -- 计算上一页索引，注意索引范围是[0, realPageCount-1]
    local prevPage = (self.currentPage - 1 + self.realPageCount) % self.realPageCount
    
    -- 如果要显示从1开始的页码，可以在打印时加1
    local currentPageDisplay = self.currentPage + 1
    local prevPageDisplay = prevPage + 1
    
    print("上一页: " .. tostring(currentPageDisplay) .. " -> " .. tostring(prevPageDisplay) .. 
          " (索引: " .. tostring(self.currentPage) .. " -> " .. tostring(prevPage) .. 
          "), 总页数 = " .. tostring(self.realPageCount))
    
    self:ScrollToPage(prevPage)
end

-- 设置自动滚动
function DragScrollRect:SetAutoScroll(enable)
    self.autoScroll = enable
    if enable then
        self:StartAutoScroll()
    else
        self:StopAutoScroll()
    end
end

-- 设置自动滚动间隔
function DragScrollRect:SetAutoScrollInterval(interval)
    self.autoScrollInterval = interval
    if self.autoScroll then
        self:StopAutoScroll()
        self:StartAutoScroll()
    end
end

-- 暂停自动滚动
function DragScrollRect:PauseAutoScroll()
    self.isPaused = true
end

-- 恢复自动滚动
function DragScrollRect:ResumeAutoScroll()
    self.isPaused = false
    self:ScrollToPage(self.currentPage)
end

-- 清理资源
function DragScrollRect:Exit()

    if not Util:IsNil(self.lastClone) then
        self.lastClone.transform:SetParent(nil)
        GameObject.Destroy(self.lastClone.gameObject)
        self.lastClone = nil
    end
    if not Util:IsNil(self.firstClone) then
        self.firstClone.transform:SetParent(nil)
        GameObject.Destroy(self.firstClone.gameObject)
        self.firstClone = nil
    end

    self:StopAutoScroll()
    self:StopScrollCoroutine()
    
    -- 恢复原始滚动状态
    if not Util:IsNil(self.scrollRect) then
        self.scrollRect.horizontal = self.originalHorizontalScroll
        self.scrollRect.vertical = self.originalVerticalScroll
    end
    
    -- 释放拖拽事件
    self:UnregisterDragEvents()
    
    self.scrollRect = nil
    self.viewport = nil
    self.content = nil
    self.commonService = nil
    
    -- 清理拖动方向相关状态
    self.dragDirection = nil
    self.isHorizontalLocked = false
    self.isVerticalLocked = false
end

function DragScrollRect:ReleaseInstance()
    self:Exit()
end

-- 释放拖拽事件
function DragScrollRect:UnregisterDragEvents()
    if not Util:IsNil(self.scrollRect) and not Util:IsNil(self.scrollRect.gameObject) then
        local trigger = self.scrollRect.gameObject:GetComponent(typeof(CS.UnityEngine.EventSystems.EventTrigger))
        if trigger then
            trigger.triggers:Clear()
        end
    end
end

-- 滚动到指定页面
function DragScrollRect:ScrollToPage(pageIndex, withAnimation, scorllFinishCallBack)
    if Util:IsNil(self.scrollRect) or Util:IsNil(self.content) or Util:IsNil(self.viewport) then
        return
    end
    if self.totalPages <= 0 then return end
    
    -- 设置默认值
    if withAnimation == nil then
        withAnimation = true
    end
    
    -- 确保页面索引在有效范围内
    local targetIndex = math.max(0, math.min(pageIndex, self.totalPages - 1))
    
    -- 更新当前页面索引
    self.currentPage = targetIndex
    
    -- 计算目标位置
    local totalWidth = self.content.rect.width
    local viewportWidth = self.viewport.rect.width
    local pageWidth = self.pageWidth
    local targetPosition = (targetIndex * pageWidth) / (totalWidth - viewportWidth)
    
    -- 确保目标位置在0-1之间
    targetPosition = math.max(0, math.min(1, targetPosition))
    
    -- 执行滚动
    if withAnimation then
        self:StartSmoothScroll(targetPosition, function()
            if scorllFinishCallBack then
                scorllFinishCallBack()
            end
            
            -- 处理边界情况
            if self.isInfinite then
                if targetIndex == self.totalPages - 1 then
                    -- 如果滚动到最后一个克隆页(索引4)，静默跳转到对应的真实页(索引1)
                    self:ScrollToPage(1, false)
                elseif targetIndex == 0 then
                    -- 如果滚动到第一个克隆页(索引0)，静默跳转到对应的真实页(索引3)
                    self:ScrollToPage(self.totalPages - 2, false)
                end
            end
        end)
    else
        self.scrollRect.horizontalNormalizedPosition = targetPosition
    end

    if self.scrollDidToPageCallBack then
        self.scrollDidToPageCallBack(targetIndex)
    end
end

return DragScrollRect