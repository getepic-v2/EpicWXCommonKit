local class = require("middleclass")
local json = require("nextjson")
local IPCChannel = require(MAIN_SCRIPTS_LOC.."ipc")
local AudioExposeLoader =require(MAIN_SCRIPTS_LOC.."audio/audio_expose_loader")
local cs_coroutine = require("common/cs_coroutine")
local Util = require(MAIN_SCRIPTS_LOC.."common/util")
local LogBridge = require(MAIN_SCRIPTS_LOC.."common/log_bridge")
local SceneManager = require(MAIN_SCRIPTS_LOC.."scene/scene_manager")
local ipcLog = require(MAIN_SCRIPTS_LOC.."IPC_log")
local AudioPoolManager = require(MAIN_SCRIPTS_LOC.."audio/audio_pool_manager")

local AvatarDiscuss = class("AvatarDiscuss")
Quaternion = CS.UnityEngine.Quaternion
local ANZHUFAYAN = 123451 --用于按钮按下启动，收到
local CHANGESTATE = 123452 --用于状态转换切换按钮UI，发出
local HIDENTOAST = 123453
function AvatarDiscuss:initialize(avatar)
    print("wwww avatar discuss init")
    self.audioList = {}
    self.AudioPlayer = AudioExposeLoader:new()
    -- self.isDiscussing = false
    self.isRecording = false
    self.isPlaying = false
    self.Banned = false--禁言状态
    self.collectiveSpeech = false--集体发言状态
    self.currentIndex = 0
    self.avatar = avatar
    self.teacherService = App:GetService("TeacherService")
    self:LoadAssets()
    self:RegisterEvents()
    self.isLecture = false --演讲状态
    self.hidenstate = false --被隐藏状态
    self.avatar.OnReLoadAvatarComplete:connect(function(firstLoad, go)
        if not firstLoad then
            --人物预制体换了重新加载资源
            print("wwww 人物预制体替换")
            self:destroyOldAssets()
            self:LoadAssets()
        end
    end)
    APIBridge.RequestAsync("buss.menu.chatlist",{isShow = true,type = "normal"},nil)
    --通知外部模式聊天区模式切换
    self.teacherService.changeChatType("normal")
end

function AvatarDiscuss:destroyOldAssets()
    if self.recordingItem and not self.recordingItem:Equals(nil) then
        print("wwww destroy recordingItem")
        GameObject.Destroy(self.recordingItem)
    end

    if self.playingItem and not self.playingItem:Equals(nil) then
        print("wwww destroy playingItem")
        GameObject.Destroy(self.playingItem)
    end

    if self.recordtimeItem and not self.recordtimeItem:Equals(nil) then
        print("wwww destroy recordtimeItem")
        GameObject.Destroy(self.recordtimeItem)
    end
end

function AvatarDiscuss:LoadAssets()
    print("wwww LoadAssets",self.avatar.character.transform:Find("RoleCanvas"))
    --local root = self.avatar.Body.transform:Find("Character/RoleCanvas")
    local path = "modules/"..RESOURCE_LOC.."/assets/prefabs/avatar_canvas/RolePlayAudioItem.prefab"--头上录音条
    local path2 = "modules/"..RESOURCE_LOC.."/assets/prefabs/avatar_canvas/RoleRecordingItem.prefab"--录音中
    local path3 = "modules/"..RESOURCE_LOC.."/assets/prefabs/avatar_canvas/RoleRecordtimeItem.prefab"--倒计时

    ResourceManager:LoadGameObjectWithExName(path2, function(asset)
        local root = self.avatar.character.transform:Find("RoleCanvas")
        print("wwww LoadAssets root",root)
        local t = GameObject.Instantiate(asset).transform
        t:SetParent(root)
        t.localScale = Vector3.one
        t.localPosition = Vector3(0, 30, 0)
        t.localRotation = Quaternion.Euler(Vector3(0, 180, 0))
        if t.gameObject and not t.gameObject:Equals(nil) then
            t.gameObject:SetActive(false)
        end
        self.recordingItem = t.gameObject
    end)
    ResourceManager:LoadGameObjectWithExName(path, function(asset)
        self.playingItem = GameObject.Instantiate(asset)
        if self.playingItem and not self.playingItem:Equals(nil) then
            self.playingItem:SetActive(false)
        end
    end)
    ResourceManager:LoadGameObjectWithExName(path3, function(asset)
        local root = self.avatar.character.transform:Find("RoleCanvas")
        local t = GameObject.Instantiate(asset).transform
        t:SetParent(root)
        t.localScale = Vector3.one
        t.localPosition = Vector3(0, 30, 0)
        t.localRotation = Quaternion.Euler(Vector3(0, 180, 0))
        self.recordtimeItem = t.gameObject
        self.recordtimeItemText = t:Find("recordtimeItemText"):GetComponent(typeof(CS.UnityEngine.UI.Text))
        if t.gameObject and not t.gameObject:Equals(nil) then
            t.gameObject:SetActive(false)
        end
    end)
end

---自身avatar注册播放音频事件
---录音事件
---播放事件
---新增音频事件
function AvatarDiscuss:RegisterEvents()
    print("wwww discuss register 0")
    --IPCChannel.createIpcChanel()
    if App.Info.role ~= 0 then
        --监听老师avatar
        self:connectTeacherAvatar()
        local currentAvatar = App:GetService("Avatar")
        currentAvatar.OnAvatarStateChanged:connect(function(newState, oldState)
            print("wwww avatar -> 状态改变", newState, oldState)
            if newState == 'ConditionLecture'  then
                --演讲状态不能录音、不能播
                self.isLecture = true
                self:OnDiscussStop()
                self:changeStatus(2)
            else
                self.isLecture = false
                self:changeStatus(0)
            end
        end)
    end

    if self.avatar:isTeacher() then
        IPCChannel.OnIpcCallCompleted:connect(function(res)
            print("wwww ipc channel "..table.dump(res))
            local active_id = tonumber(res.activeid)
            local type = tonumber(res.type)
            if active_id == 300002 then
                LogBridge.SNoStatisticsWithParam("qz_teacher_pc",{eventtype = "qz_teacher_pc",
                                                                  sno = "199",
                                                                  logtype = "command",
                                                                  command_id = "009",
                                                                  command_name = "全员禁言",
                                                                  command_status = tostring(type),
                                                                  identify_id = tostring(os.time())},function() end)
                if type == 0 then
                    --关闭禁言、按钮恢复
                    self:StartDiscuss()
                else
                    --开启禁言、按钮置灰
                    self:StopDiscuss()
                end
            end
        end)
    end

    --liulin
    --退出重进获取禁言状态
    local forbidenState = self.avatar:GetProperty("discuss_status")
    if App.Info.role ~= 0 then
        --学生恢复
        cs_coroutine.start(function()
            coroutine.yield(CS.UnityEngine.WaitForSeconds(2))
            self:studentresume()
        end)
    else
        --老师恢复
        local statusService = App:GetService("StatusManagerService")
        if statusService then
            --local time = os.time()
            --local startTime = self.avatar:GetProperty("discuss_starttime") or "0"
            print("wwww set status "..tostring(statusService))
            statusService:setStatus(300002, tonumber(forbidenState))
        end
    end

    self.teacherService.recordAudio:connect(function(msg)
        local code = tonumber(msg.code)
        local type_ = tonumber(msg.type)
        if code == ANZHUFAYAN then
            if type_ == 1 then
                self:OnDiscussStart()
            else
                LogBridge.SNoStatisticsWithParam("qz_student_client",{eventtype = "qz_student_client",
                                                                      sno = "199",
                                                                      logtype = "voice_message",
                                                                      voice_status = 2,
                                                                      identify_id = tostring(os.time())},function() end)
                self:OnDiscussStopSelf()
            end
        elseif code == HIDENTOAST then
            if type_ == 1 then
                if self.recordingItem  and not self.recordingItem:Equals(nil) then
                    self.recordingItem:SetActive(false)
                end
                self.hidenstate = true
                self:OnDiscussStop()
            else
                self.hidenstate = false
            end

        end
    end)
    

    print("wwww discuss register ")
  
    APIBridge.CreateService("buss.menu.chat", "", function(res)
        print("wwww 收到集体发言消息 "..table.dump(res))
        if res.status then
            if res.status == "gone" then
                self.collectiveSpeech = true
                self:OnDiscussStop()
                self:changeStatus(2)
            elseif res.status == "visible" then
                self.collectiveSpeech = false
                self:changeStatus(0)
            end
        end
    end)
    --传URL
    APIBridge.CreateService("buss.menu.audiochat", "", function(res)
        print("wwww native notify record url "..table.dump(res))
        if res.url and res.url ~= "" then
            self.avatar:SyncSetProperty("discuss_url", res.url)
        end
    end)
    APIBridge.CreateService("buss.audiorecord.status", "", function(res)
        print("wwww native notify state"..table.dump(res))
        local status = tonumber(res.status)
        if status == 0 then
            print("wwww 录音未开始或者未知")
        elseif status == 1 then
            print("wwww 录音开始")
            self:OnRecordStart()
            --self:timeStart()
        elseif status == 2 then
            print("wwww 录音结束")
            self:OnRecordStop()
        end
    end)

    local service = App:GetService("CommonService")
    -- local service = App:GetService("WorldService") ---@type WorldState
    service.gate.OnExitGate:connect(
            function()
                self:OnDestroy()
            end
    )

    local elements = App:GetService("Avatar"):GetAllAvatar()
    self.registerAvatarList = {}
    for i = 1,#elements do
        local avatar = elements[i]
        local targetId = avatar:GetProperty("uuid")
        table.insert(self.registerAvatarList, targetId)
        avatar.OnLocalPropertyChanged:connect(function(k, v)
            --if self.isDiscussing and k == "discuss_url" and v ~= "" then
            if k == "discuss_url" and v ~= "" and avatar.loadedFromHistory == true then
                self:AddAudioItem(targetId, v)
            end
        end)
    end

    local avatarservice = App:GetService("Avatar")
    avatarservice.OnAvatarJoinEvent:connect(function(avatar)
        if avatar:isTeacher() then
            print("wwww 老师后进")
            self:connectTeacherAvatar()
        else
            local targetId = avatar:GetProperty("uuid")
            if self:IsNewAvatar(targetId) then
                avatar.OnLocalPropertyChanged:connect(function(k, v)
                    --if self.isDiscussing and k == "discuss_url" and v ~= "" then
                    if k == "discuss_url" and v ~= "" and avatar.loadedFromHistory == true then
                        self:AddAudioItem(targetId, v)
                    end
                end)
            end
        end
    end)
    --[[self.avatar.Block.OnLocalCreateElement:connect(function(el,_b)
        local element = el
        if element:GetType() == 'avatar' then
            --if element:isTeacher() then
            --    self:connectTeacherAvatar()
            --end
            local targetId = element:GetProperty("uuid")
            if self:IsNewAvatar(targetId) then
                element.OnLocalPropertyChanged:connect(function(k, v)
                    --if self.isDiscussing and k == "discuss_url" and v ~= "" then
                    if k == "discuss_url" and v ~= "" then
                        self:AddAudioItem(targetId, v)
                    end
                end)
            end
        end
    end)]]
  
end
--学生恢复
function AvatarDiscuss:studentresume()
    --self.avatar:SetProperty(k,v)avatar:GetProperty("discuss_status")
    local elements = App:GetService("Avatar"):GetAllAvatar()
    print("wwww elements count "..#elements)
    for i = 1,#elements do
        local avatar = elements[i]
        if avatar:isTeacher() then
            local forbidenState =  avatar:GetProperty("discuss_status")
            print("wwww 恢复禁言---"..forbidenState)
            if forbidenState == "" or forbidenState == nil then
                print("wwww 恢复禁言---nil--")
                self.Banned = false
                self:changeStatus(0)
                return
            end
            if tonumber(forbidenState) == 0 then
                print("wwww 恢复禁言---关闭禁言--")
                --关闭禁言、按钮恢复
                self.Banned = false
                self:changeStatus(0)
            else
                print("wwww 恢复禁言---开启禁言--")
                --开启禁言、按钮置灰
                self.Banned = true
                self:changeStatus(2)
                --self:StopDiscuss()
            end
        end
    end
end
--学生监听老师avatar
function AvatarDiscuss:connectTeacherAvatar()
    local elements = App:GetService("Avatar"):GetAllAvatar()
    print("wwww elements count "..#elements)
    for i = 1,#elements do
        local avatar = elements[i]
        if avatar:isTeacher() then
            --todo:老师后进有问题？
            avatar.OnLocalPropertyChanged:connect(function(k,v)
                if k == "discuss_status" then
                    LogBridge.SNoStatisticsWithParam("qz_student_client",{eventtype = "qz_student_client",
                                                                          sno = "107",
                                                                          logtype = "command",
                                                                          command_id = "009",
                                                                          command_name = "全员禁言",
                                                                          command_status = tostring(v),
                                                                          identify_id = tostring(os.time())},function() end)
                    self.avatar:SyncSetProperty(k,v)
                    if v == "1" then
                        --老师开启禁言，学生收到消息，按钮置灰
                        print("wwww 学生收到禁言")
                        self:OnDiscussStop()
                        self.Banned = true--开启禁言
                        self:changeStatus(2)
                    else
                        self.Banned = false--
                        self:changeStatus(0)
                    end
                end
            end)
        end
    end
end
function AvatarDiscuss:IsNewAvatar(uuid)
    for i = 1,#self.registerAvatarList do
        if self.registerAvatarList[i] == uuid then
            return false
        end
    end
    table.insert(self.registerAvatarList, uuid)
    return true
end

function AvatarDiscuss:AddAudioItem(uuid, url)
    print("wwww add audio item "..url.." target uuid "..uuid)
    if url ~= "" and not self.avatar:isTeacher() then
        -- for i = self.currentIndex, #self.audioList do
        --     if self.audioList[i].URL == url then
        --         return
        --     end
        -- end
        string.gsub(url, "\\", "")
        if self.isLecture == false and self.Banned == false and self.hidenstate == false then
            --演讲、禁言状态不播放
            table.insert(self.audioList, {UUID = uuid, URL = url})
        end
    end
    --{"url:"", "filepath":"", "status":"",  "errCode":"", "errInfo":"",}
    self:TryPlayAudio()
end

--播放角色的音频
function AvatarDiscuss:TryPlayAudio()
    --if not self.isDiscussing or self.isRecording or self.playingItem == nil or self.isPlaying then
    if self.isRecording or self.playingItem == nil or self.isPlaying then
        return
    end
    print("wwww try play audio index-1= "..self.currentIndex)
    if self.currentIndex + 1 > #self.audioList then
        print("wwww try play audio out of range "..table.dump(self.audioList))
        return
    end
    self.isPlaying = true
    self.currentIndex = self.currentIndex + 1
    print("wwww find play target uuid "..self.audioList[self.currentIndex].UUID)
    local target = App:GetService("Avatar"):GetAvatarByUUID(self.audioList[self.currentIndex].UUID)
    if not target then
        self.isPlaying = false
        self:OnAudioPlayFinish()
        return
    end
    if self.playingItem == nil or self.playingItem:Equals(nil) then
        error("wwww 资源丢失")
    end
    local t = self.playingItem.transform
    t:SetParent(target.character.transform:Find("RoleCanvas"))
    t.localScale = Vector3.one
    t.localPosition = Vector3(0, 30, 0)
    t.localRotation = Quaternion.Euler(Vector3(0, 180, 0))
    --t.gameObject:SetActive(true)
    self.LabelPlay = t:Find("text"):GetComponent("Text")
    if self.LabelPlay and self.LabelPlay.gameObject  and not self.LabelPlay.gameObject:Equals(nil) then
        self.LabelPlay.gameObject:SetActive(false)
    end
    --TODO play audio with url, and callback 
    self.AudioPlayer:LoadPlayAudio(self.audioList[self.currentIndex].URL, target.VisElement.gameObject,
            function(duration)
                if 0 == #self.audioList or 0 == self.currentIndex then
                    print("wwww donwload "..table.dump(self.audioList))
                    return
                end
                print("wwww 下载完成 url:"..self.audioList[self.currentIndex].URL.."--uuid:"..self.audioList[self.currentIndex].UUID)
                if t.gameObject and not t.gameObject:Equals(nil) then
                    t.gameObject:SetActive(true)
                end
                self:ReportAudioPlay(self.audioList[self.currentIndex].UUID, self.audioList[self.currentIndex].URL, duration)
                self.audioDuration = math.ceil(duration)
                self.LabelPlay.text = self.audioDuration.."s"
                if self.LabelPlay and not self.LabelPlay.gameObject:Equals(nil) then
                    self.LabelPlay.gameObject:SetActive(true)
                end
                if self.playCor then
                    cs_coroutine.stop(self.playCor)
                end
                self.playCor = cs_coroutine.start(function()
                    while self.audioDuration >= 0 do
                        self.LabelPlay.text = self.audioDuration.."s"
                        coroutine.yield(CS.UnityEngine.WaitForSeconds(1))
                        self.audioDuration = self.audioDuration - 1
                    end
                    self:OnAudioPlayFinish()
                end)
            end)
end

function AvatarDiscuss:StopAudio()
    if not self.isPlaying then
        return
    end
    self.AudioPlayer:StopAudio()
    self.isPlaying = false
    if self.playingItem and not self.playingItem:Equals(nil) then
        self.playingItem:SetActive(false)
    end
    if self.recordtimeItem and not self.recordtimeItem:Equals(nil) then
        self.recordtimeItem:SetActive(false)
    end
    if self.playCor then
        cs_coroutine.stop(self.playCor)
    end
end

function AvatarDiscuss:OnAudioPlayFinish()
    self.isPlaying = false
    if self.playingItem and not self.playingItem:Equals(nil) then
        self.playingItem:SetActive(false)
    end
    if self.playCor then
        cs_coroutine.stop(self.playCor)
    end
    self:TryPlayAudio()
end

---客户端通知录音开始
function AvatarDiscuss:OnRecordStart()
    print("wwww on record start ", self.recordingItem)
    AudioPoolManager:getInstance():ControlMixerVolume("master_volume", -80)
    self.isRecording = true
    self:StopAudio()
    if self.recordingItem and not self.recordingItem:Equals(nil) then
        self.recordingItem:SetActive(true)
    end
    if self.recordtimeItem and not self.recordtimeItem:Equals(nil) then
        self.recordtimeItem:SetActive(false)
    end
    --按钮变绿
    self:changeStatus(1)
    self:timeStart()
end
function AvatarDiscuss:changeStatus(status)
    if status == 0 and self.Banned == false and self.collectiveSpeech == false and self.isLecture == false then
        self.teacherService.recordAudio({ code = CHANGESTATE ,type = status})
    end
    if status ~= 0 then
        self.teacherService.recordAudio({ code = CHANGESTATE ,type = status})
    end
end

function AvatarDiscuss:timeStart()
    ----起个计时器30s，剩五秒弹toast
    local flag = true
    local count = 14
    cs_coroutine.start(function()
        while flag do
            coroutine.yield(CS.UnityEngine.WaitForSeconds(1))
            count = count -1
            if self.isRecording then
                if count == 5 then
                    --  切换 录制中/倒计时 UI
                    if self.recordingItem and not self.recordingItem:Equals(nil) then
                        self.recordingItem:SetActive(false)
                    end
                    if self.recordtimeItem and not self.recordtimeItem:Equals(nil) then
                        self.recordtimeItem:SetActive(true)
                    end

                end
                if count <= 5 and count > 0 then
                    --25s后还没结束
                    self:showTimeTips(count)
                elseif count <= 0 then
                    --通知native结束录制
                    self:OnDiscussStopSelf()
                    --self.recordtimeItem:SetActive(false)
                    flag = false
                    --todo:按钮置灰
                end
            else
                if self.recordingItem and not self.recordingItem:Equals(nil) then
                    self.recordingItem:SetActive(false)
                end
                if self.recordtimeItem and not self.recordtimeItem:Equals(nil) then
                    self.recordtimeItem:SetActive(false)
                end
                flag = false
            end
        end
    end)
end
function AvatarDiscuss:showTimeTips(count)
    if count > 5 or count <= 0  then
        return
    end
    self.recordtimeItemText.text = tostring(count).."s后结束录制"
end
---客户端通知录音结束
function AvatarDiscuss:OnRecordStop()
    print("wwww on record stop")
    --抬起埋点
    AudioPoolManager:getInstance():ControlMixerVolume("master_volume", 0)
    self.isRecording = false
    self:TryPlayAudio()
    if self.recordingItem and not self.recordingItem:Equals(nil) then
        self.recordingItem:SetActive(false)
    end
    if self.recordtimeItem and not self.recordtimeItem:Equals(nil) then
        self.recordtimeItem:SetActive(false)
    end
    --按钮恢复正常
    self:changeStatus(0)
end
---教师端开始分组讨论,通知客户端以及学生端
function AvatarDiscuss:StartDiscuss()
    if self.avatar  then
        self.avatar:SyncSetProperty("discuss_status", "0")
    end
end

---教师端停止分组讨论，通知客户端以及学生端
function AvatarDiscuss:StopDiscuss()
    if self.avatar then
        self.avatar:SyncSetProperty("discuss_status", "1")
    end
end

function AvatarDiscuss:OnDiscussStart()
    print("wwww on discuss start")
    --按下埋点
    LogBridge.SNoStatisticsWithParam("qz_student_client",{eventtype = "qz_student_client",
                                                          sno = "199",
                                                          logtype = "voice_message",
                                                          voice_status = 1,
                                                          identify_id = tostring(os.time())},function() end)
    APIBridge.RequestAsync("buss.menu.audiochat", {action = "press_down",recordType = "normal"}, nil)
end
function AvatarDiscuss:OnDiscussStopSelf()
    --关闭录音UI
    APIBridge.RequestAsync("buss.menu.audiochat", {action = "press_up",recordType = "normal"}, nil)
    if self.recordingItem and not self.recordingItem:Equals(nil) then
        self.recordingItem:SetActive(false)
    end
    if self.recordtimeItem and not self.recordtimeItem:Equals(nil) then
        self.recordtimeItem:SetActive(false)
    end

end
function AvatarDiscuss:OnDiscussStop()
    print("wwww on discuss stop")
    --self.isDiscussing = false
    print("wangde exit 1")
    self:StopAudio()
    self.audioList = {}
    self.currentIndex = 0
    print("wangde exit 2")
    self:OnRecordStop()
    self:OnDiscussStopSelf()
    print("wangde exit 3")
    
end

function AvatarDiscuss:OnDestroy()
    self:OnDiscussStop()
end

function AvatarDiscuss:ReportAudioPlay(id, url, duration)
    local commonInfo = {
        scene_id="0",	          --所在场景ID
        role_position="position_x:0,position_y:0,position_z:0",        --角色位置
        --摄像头位置
        camera_position="position_x:0,\
                         position_y:0,\
                         position_z:0,\
                         rotation_x,\
                         rotation_y:0,\
                         rotation_z:0",
        sno="-1"
    }
    --填充场景id
    commonInfo.scene_id = SceneManager:getInstance():GetCurrentSceneId()
    --人物坐标和角度
    local selfAvatar = Util:getSelfAvatar()
    if selfAvatar then
        local position = selfAvatar.VisElement.gameObject.transform.position
        local rotation = selfAvatar.VisElement.gameObject.transform.rotation
        commonInfo.role_position = "position_x:"..position.x..","..
                "position_y:"..position.y..","..
                "position_z:"..position.z..","..
                "rotation_x:"..rotation.x..","..
                "rotation_y:"..rotation.y..","..
                "rotation_z:"..rotation.z
    end

    --摄像机坐标和角度
    local mainCam = GameObject.FindWithTag('MainCamera')
    if mainCam then
        local camTrans = mainCam.transform

        local position = camTrans.position
        local rotation = camTrans.rotation
        commonInfo.camera_position = "position_x:"..position.x..","..
                "position_y:"..position.y..","..
                "position_z:"..position.z..","..
                "rotation_x:"..rotation.x..","..
                "rotation_y:"..rotation.y..","..
                "rotation_z:"..rotation.z
    end

    --判断学生端还是老师端，填充eventType
    local uuid = App.Uuid
    local _uuidFlag = string.sub(uuid,1,2)
    local isTeacher = false
    if(_uuidFlag == "t_") then
        isTeacher = true
    end
    --local eventType = "qz_student_client"
    -- commonInfo.eventtype = eventType
    --commonInfo.logtype = "play_record"
    --commonInfo.sno = "108"
    --commonInfo.actiontype = "2"
    --commonInfo.record_userid = id
    --commonInfo.url = url
    --commonInfo.record_time = duration
    print("wwww play_record埋点---isTeacher--"..tostring(isTeacher))
    if not isTeacher then
        print("wwww play_record埋点---打成功")
        LogBridge.SNoStatisticsWithParam("qz_student_client",{eventtype = "qz_student_client",
                                                              sno = "108",
                                                              logtype = "play_record",
                                                              url = url,
                                                              record_time = duration,
                                                              record_userid = id,
                                                              identify_id = tostring(os.time())},function() end)
    end
end

return AvatarDiscuss

