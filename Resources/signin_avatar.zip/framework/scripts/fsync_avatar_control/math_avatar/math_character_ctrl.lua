
local class = require('middleclass')
local FSyncCharacterCtrl = require("scripts/fsync_avatar_control/fsync_character_ctrl")

local MathCharacterCtrl = class("AbcCharacterCtrl ", FSyncCharacterCtrl)

function MathCharacterCtrl:initialize(avatarCtrl, checkGround)
    MathCharacterCtrl.super.initialize(self,avatarCtrl,checkGround)
end
function MathCharacterCtrl:SetInfo(data)
    self.oriSpeed = data.speed
    if self.speed ~= 0 then
        self.speed = data.speed
    end
    self.saveGravity = data.gravity
    self.gravity = data.gravity
    self.jumpHeight = data.jumpHeight
    self.slopeLimit = data.slopeLimit
    self.stepOffset = data.stepOffset
    self.height = data.height
    -- self.radius = data.radius
    self.radius = data.abcRadius
    self.center = Vector3(data.center.x, data.center.y, data.center.z)
    self.skinWidth = data.skinWidth
    self:_SetCharacterInfo()
    self.jumpSpeed = math.sqrt(self.jumpHeight * -2 * self.gravity);
    self.bombedSpeedV = self.jumpSpeed * 2
    self.bombedSpeedH = data.speed * 2
end


--- overide super Method
function MathCharacterCtrl:ChangeToSwimState()
    
    self.switchGravity = false
    self:ClearActioin()

    if self.canSend then
        g_Log("切游泳 ---- ChangeToSwimState 关掉重力",self.switchGravity)
    end
end

--- overide super Method
function MathCharacterCtrl:ChangeToNormalState()
    
    self.switchGravity = true
    if self.canSend then
        g_Log("切游泳 ---- ChangeToNormalState 开重力",self.switchGravity)
    end
end


return MathCharacterCtrl