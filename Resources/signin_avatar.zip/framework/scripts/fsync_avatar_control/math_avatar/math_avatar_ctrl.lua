local class = require('middleclass')
local FsyncAvatarCtrl = require("scripts/fsync_avatar_control/fsync_avatar_ctrl")
local ENUM = require("scripts/avatar_control/avatar_consts")
local EventSubscribe = require('event_subscribe')
---@class NextAvatar : Avatar
local MathAvatar = class("MathAvatar ", FsyncAvatarCtrl)
local Util = require(MAIN_SCRIPTS_LOC .. "common/util")
local json = require("nextjson")
local FSyncCharacterCtrl = require("scripts/fsync_avatar_control/math_avatar/math_character_ctrl")
local cs_coroutine = require("common/cs_coroutine")

local rushWindPath = "modules/Math_Main/assets/prefabs/rushPoFeng/assets/Prefabs/PoFeng.prefab"
local rushTrailPath = "modules/Math_Main/assets/prefabs/rushTrail/assets/Prefabs/RushTrail.prefab"
local bigTrailPath = "modules/Math_Main/assets/0smoke/assets/Prefabs/Smoke_Along.prefab"
---@param element  CS.Tal.CourseEnv.MWorld.MElement
function MathAvatar:initialize(element)
    MathAvatar.super.initialize(self, element, nil, ENUM.AVATAR_CTRL_TYPE.CHARACTER_CTRL_TYPE)
    self.lastAnimatorLayer = 0 -- 上一个状态机层级
    self.tableLayerWeight = {}
    for k, v in pairs(self.AVATAR_ENUM_ANIMATOR) do
        if v == self.AVATAR_ENUM_ANIMATOR.BASELAYER1 or v == self.AVATAR_ENUM_ANIMATOR.COMMONLAYER then
            self.tableLayerWeight[v] = 1
        else
            self.tableLayerWeight[v] = 0
        end
    end
    g_Log("创建MathAvatar",self:GetProperty("AvatarName"))
    self.commonService = App:GetService("CommonService")
    -- self.OnChangeClothComplete:connect(function ()
    --     if self.state == "weak" then
    --         self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "weak", true, true)
    --     end
    -- end)
    self:SubscribeMsgKey(AVATAR_ENUM.MESSAGE_KEY.CHANGESPORTMODEL)
    self:SubscribeMsgKey(AVATAR_ENUM.MESSAGE_KEY.BEHITFLYING)
    -- 层级变动回调
    self.OnChangeAnimatorLayerEvent = EventSubscribe:new()
end

function MathAvatar:InitCharacterControl(checkGround)
    self.characterCtrl = FSyncCharacterCtrl:new(self, checkGround)
end

--- func 设置动画机layer
---@param layer number 使用枚举：AVATAR_ENUM.ANIMATOR
function MathAvatar:SetAnimatorLayer(layer, notSync)
    if self.canSend then
        g_Log("ChangeMoveState 设置动画机层级：" .. tostring(layer))
    end
    if layer > self.AVATAR_ENUM_ANIMATOR.DetectLayer then
        g_LogError("layer 超出范围：" .. tostring(layer))
        return
    end
    if layer == nil then
        return
    end
    -- 如果当前层级已经设置过，则不重复设置
    if self.tableLayerWeight[layer] ~= 1 then
        if self.Animator then
            self.Animator:SetLayerWeight(layer, 1)
        end
    
        self.tableLayerWeight[layer] = 1
    
        if layer == self.AVATAR_ENUM_ANIMATOR.CARRYLAYER then
            if self.Animator then
                self.Animator:SetLayerWeight(self.AVATAR_ENUM_ANIMATOR.COVERUPERBODY, 1)
            end
    
            self.tableLayerWeight[self.AVATAR_ENUM_ANIMATOR.COVERUPERBODY] = 1
        elseif layer == self.AVATAR_ENUM_ANIMATOR.PICKLAYER then
            if self.Animator then
                self.Animator:SetLayerWeight(self.AVATAR_ENUM_ANIMATOR.COVERUPERBODY, 1)
            end
    
            self.tableLayerWeight[self.AVATAR_ENUM_ANIMATOR.COVERUPERBODY] = 1
        end
    end
    
    self:OnChangeAnimatorLayer()
    if not notSync then
        self:SyncAnimatorLayer()
    end
end

--- func 设置动画机layer权重为0
function MathAvatar:DisableAnimatorLayer(layer, notSync)
    if layer > self.AVATAR_ENUM_ANIMATOR.DetectLayer then
        g_LogError("layer 超出范围：" .. tostring(layer))
        return
    end
    if self.tableLayerWeight[layer] ~= 0 then
        if self.Animator then
            self.Animator:SetLayerWeight(layer, 0)
        end
    
        if layer == self.AVATAR_ENUM_ANIMATOR.CARRYLAYER or layer == self.AVATAR_ENUM_ANIMATOR.PICKLAYER then
            if self.Animator then
                self.Animator:SetLayerWeight(self.AVATAR_ENUM_ANIMATOR.COVERUPERBODY, 0)
            end
            self.tableLayerWeight[self.AVATAR_ENUM_ANIMATOR.COVERUPERBODY] = 0
        end
        self.tableLayerWeight[layer] = 0
    end
    if not notSync then
        self:SyncAnimatorLayer()
    end
    self:OnChangeAnimatorLayer()

end

function MathAvatar:OnChangeAnimatorLayer()
    if not self.Animator then
        return
    end
    local max = self.AVATAR_ENUM_ANIMATOR.BASELAYER
    for k, v in pairs(self.AVATAR_ENUM_ANIMATOR) do
        if self.AVATAR_ENUM_ANIMATOR.COMMONLAYER ~= v and self.tableLayerWeight[v] == 1 then
            max = math.max(max, v)
        end
    end
    for i = 2, self.AVATAR_ENUM_ANIMATOR.COMMONLAYER - 1, 1 do
        if i < max then
            self.Animator:SetLayerWeight(i, 0)
        end
    end
    -- 传说皮肤不用基础层级，手持、被炸弹、举人用基础层级
    if max < self.AVATAR_ENUM_ANIMATOR.COMMONLAYER and max > self.AVATAR_ENUM_ANIMATOR.BASELAYER1 then
        self.Animator:SetLayerWeight(self.AVATAR_ENUM_ANIMATOR.BASELAYER1, 0)
        self.Animator:SetLayerWeight(max, 1)
    else
        self.Animator:SetLayerWeight(self.AVATAR_ENUM_ANIMATOR.BASELAYER1, 1)
    end
    -- COMMONLAYER权重总为1
    self.Animator:SetLayerWeight(self.AVATAR_ENUM_ANIMATOR.COMMONLAYER, 1)
    self.OnChangeAnimatorLayerEvent(self:ConvertLayerTableToSync(self.tableLayerWeight))
end

function MathAvatar:RecoverAnimatorLayer(historyTableLayerWeight)
    if not self.Animator then
        return
    end
    local layerCount = 0
    for k, v in pairs(self.AVATAR_ENUM_ANIMATOR) do
        layerCount = layerCount + 1
    end
    for i = 1, layerCount - 1, 1 do
        if historyTableLayerWeight then
            self.tableLayerWeight[i] = historyTableLayerWeight[i] or 0
        end
        self.Animator:SetLayerWeight(i, self.tableLayerWeight[i])
    end
end

--- 状态机切换为基础层
function MathAvatar:_resetAnimatorLayer()
    g_LogError("禁止调用 _resetAnimatorLayer，请去除！！！")

    -- local layerCount = 0
    -- for k, v in pairs(self.AVATAR_ENUM_ANIMATOR) do
    --     layerCount = layerCount + 1
    -- end

    -- for i = 1, layerCount - 1, 1 do
    --     if self.Animator then
    --         self.Animator:SetLayerWeight(i, 0)
    --     end
    --     self.tableLayerWeight[i] = 0
    -- end
end

function MathAvatar:SetBombed(bombPos, speedv, speedh)
    if self.characterCtrl then
        self.characterCtrl:SetBombed(bombPos, speedv, speedh)
    end
end

--- func desc
---@param finalPos Vector3 最终位置
---@param speedv number 垂直速度
function MathAvatar:SetBombedWithFinalPos(finalPos, speedv)
    if self.characterCtrl then
        self.characterCtrl:SetBombedWithFinalPos(finalPos, speedv)
    end
end

--- func desc 被击飞
---@param hiterPos CS.UnityEngine.Vector3 打人者的世界坐标
---@param disV number 垂直击飞距离
---@param disH number 水平击飞距离
function MathAvatar:SetHitedWithHiterPos(hiterPos, disV, disH)
    if self.characterCtrl then
        self.characterCtrl:SetHited(hiterPos, disV, disH)
    end
end

function MathAvatar:PlayHitAni(finishCallBack)
    if not self.Animator then
        if finishCallBack then
            finishCallBack()
        end
        return
    end
    self:TriggerAndNotifyAnimation("hit")
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(0.333)
        if finishCallBack then
            finishCallBack()
        end
    end)
end

-- 开始倒地
function MathAvatar:PlayDaoDiAni(finishCallBack, notify)
    if not self.Animator then
        if finishCallBack then
            finishCallBack()
        end
        return
    end
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "daodi_start", nil, notify, false)
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(24 / 30)
        if finishCallBack then
            finishCallBack()
        end
    end)
end

-- 倒地idel
function MathAvatar:PlayDaoDiIdelAni(finishCallBack, notify)
    if not self.Animator then
        if finishCallBack then
            finishCallBack()
        end
        return
    end
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "daodi_idle", nil, notify, false)
    -- self.commonService:StartCoroutine(function()
    --     self.commonService:YieldSeconds(115/30)
    --     if finishCallBack then
    --         finishCallBack()
    --     end
    -- end)
end

-- 倒地idel
function MathAvatar:PlayStandUpAni(notify, finishCallBack)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "stand_up", nil, notify, false)
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(21 / 30)
        if finishCallBack then
            finishCallBack()
        end
    end)
end

function MathAvatar:PlayJumpHitAni1(finishCallBack, notify)
    if not self.Animator then
        if finishCallBack then
            finishCallBack()
        end
        return
    end
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "jump_hit1", nil, notify, false)
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(58 / 30)
        if finishCallBack then
            finishCallBack()
        end
    end)
end

function MathAvatar:PlayJumpHitAni2(finishCallBack, notify)
    if not self.Animator then
        if finishCallBack then
            finishCallBack()
        end
        return
    end
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "jump_hit2", nil, notify, false)
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(0.36)
        if finishCallBack then
            finishCallBack()
        end
    end)
end

function MathAvatar:PlayThrowStickAni(finishCallBack)
    if not self.Animator then
        if finishCallBack then
            finishCallBack()
        end
        return
    end

    self:TriggerAndNotifyAnimation("throwStick")
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(0.5)
        if finishCallBack then
            finishCallBack()
        end
    end)
end

function MathAvatar:PlayThrowBombAni(finishCallBack)
    if not self.Animator then
        if finishCallBack then
            finishCallBack()
        end
        return
    end
    self:TriggerAndNotifyAnimation("throwBomb")
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(0.4)
        if finishCallBack then
            finishCallBack()
        end
    end)
end

function MathAvatar:PlayBeHitAni(finishCallBack)
    if not self.Animator then
        if finishCallBack then
            finishCallBack()
        end
        return
    end
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "abc_be_hit", nil, true, false)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitSeconds(1))
        if finishCallBack then
            finishCallBack()
        end
    end)
end

---举人

-- 举人前摇动画
function MathAvatar:PlayPreCarry(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_pre_juqi", nil, notify, false)
end

-- 切层级取消举人动画
function MathAvatar:StopAllCarryAnimation(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 0, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 0, true)
    self:SetAvatarAnimatorBool("stop_juren", true, notify)
    self:SetAvatarAnimatorBool("stop_beiju", true, notify)
    self.commonService:DispatchNextFrame(function()
        self:SetAvatarAnimatorBool("stop_juren", false, notify)
        self:SetAvatarAnimatorBool("stop_beiju", false, notify)
    end)
end

-- 举人动画
-- layer, notify, history, weight, notReset
function MathAvatar:PlayCarryUp(finishCallBack, notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_juqi", nil, notify, false)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitSeconds(49 / 30))
        if finishCallBack then
            finishCallBack()
        end
    end)
end

-- 单手抛人动画
function MathAvatar:PlayCarryUpSingle(finishCallBack, notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_juren_single", nil, notify, false)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitSeconds(40 / 30))
        if finishCallBack then
            finishCallBack()
        end
    end)
end

-- 被抛起来动画阶段1 地下变成滚
function MathAvatar:PlayBeThrownBottom(finishCallBack, notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_paoqi1", nil, notify, false)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitSeconds(8 / 30))
        if finishCallBack then
            finishCallBack()
        end
    end)
end

-- 被抛起来动画阶段2 空中滚
function MathAvatar:PlayBeThrownMiddle(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_paoqi2", nil, notify, false)
end

-- 被抛起来动画阶段3 到顶部从滚变躺
function MathAvatar:PlayBeThrownTop(finishCallBack, notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_paoqi3", nil, notify, false)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitSeconds(20 / 30))
        if finishCallBack then
            finishCallBack()
        end
    end)
end

-- 停止举人
function MathAvatar:StopCarry(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 0, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 0, true)
    self:SetAvatarAnimatorBool("stop_juren", true, notify)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitEndFrame())
        self:SetAvatarAnimatorBool("stop_juren", false, notify)
    end)
end

-- 播放举人的idle
function MathAvatar:PlayCarryIdle(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "juqi_idle", nil, notify, false)
end

-- 被举到顶端的idle
function MathAvatar:PlayBeCarriedIdle(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_beiju", nil, notify, false)
end

-- 被举到中间的idle
function MathAvatar:PlayBeCarriedIdleMiddle(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 1, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_beiju_middle", nil, notify, false)
end

-- 播放放下
function MathAvatar:PlayPutDown(finishCallBack, notify)
    -- 放下把nouseLayer切回去 用base的ide
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.NOUSEYLAYER, notify, false, 0, true)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.CARRYPLAYERLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_rengren", nil, notify, false)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitSeconds(29 / 30))
        if finishCallBack then
            finishCallBack()
        end
    end)
end

-- 侦探踉跄
function MathAvatar:PlayDetectStumble(notify)
    -- g_Log("设置踉跄",table.dump(self.AVATAR_ENUM_ANIMATOR),App.modPlatform)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.DetectLayer, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "zhentan_daodi", false, notify,false)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "weak", false, notify,false)
end

--侦探倒地
function MathAvatar:PlayDetectDaoDi(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.DetectLayer, notify, false, 1, true)

    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "weak", false, notify,false)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "zhentan_daodi", true, notify,false)
    
end

--侦探虚弱
function MathAvatar:PlayDetectWeak(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.DetectLayer, notify, false, 1, true)
    
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "zhentan_daodi", false, notify,false)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "weak", true, notify,false)
end

--侦探正常
function MathAvatar:PlayDetectNormal(notify)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "zhentan_daodi", false, notify,false)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "weak", false, notify,false)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.DetectLayer, notify, false, 0, true)
end
--- 钓鱼idle
---@param finishCallBack any
---@param notify any
function MathAvatar:PlayFishingIdle(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.GOFISHINGLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "fishing_idle", nil, notify, false)
end

--- 钓鱼抛竿
---@param finishCallBack any
---@param notify any
function MathAvatar:PlayFishingStart(finishCallBack, notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.GOFISHINGLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "fishing_start", nil, notify, false)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitSeconds(64 / 30))
        if finishCallBack then
            finishCallBack()
        end
    end)
end

--- 钓鱼等待
---@param notify any
function MathAvatar:PlayFishingWait(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.GOFISHINGLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "fishing_wait", nil, notify, false)
end

--- 钓鱼上钩
---@param finishCallBack any
---@param notify any
function MathAvatar:PlayFishingCatch(notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.GOFISHINGLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "fishing_catch", nil, notify, false)
end

--- 钓鱼起竿
---@param finishCallBack any
---@param notify any
function MathAvatar:PlayFishingLiftRod(finishCallBack, notify)
    self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.GOFISHINGLAYER, notify, false, 1, true)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "fishing_lit_rod", nil, notify, false)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:GetWaitSeconds(45 / 30))
        if finishCallBack then
            finishCallBack()
        end
    end)
end

function MathAvatar:TriggerAndNotifyAnimation(aniName)
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, aniName, true, true)
end
function MathAvatar:SetAvatarAnimatorBool(param, b, notify)
    if notify == nil then
        notify = true
    end
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, param, b, notify, false)
end

function MathAvatar:SyncAnimatorLayer()
    if App.Uuid ~= self:GetProperty("uuid") then
        return
    end
    self:SendMessage(AVATAR_ENUM.MESSAGE_KEY.ANIMATORLAYER, {
        layer = self:ConvertLayerTableToSync(self.tableLayerWeight)
    })
end


-- 密码本:发送版本转本地版本
function MathAvatar:ConvertLayerTableToLocal(layerTable)
    if not self.enableAnimatorOverride then
        return layerTable
    end
    local newTable = {}
    for k, v in pairs(AVATAR_ENUM.Math_Animator_Layer_Override) do
        if v == AVATAR_ENUM.Math_Animator_Layer_Override.BASELAYER1 or v == AVATAR_ENUM.Math_Animator_Layer_Override.COMMONLAYER then
            newTable[v] = 1
        else
            newTable[v] = 0
        end
    end
    for oriLayer, weight in pairs(layerTable) do
        -- common层级及以上
        if oriLayer >= AVATAR_ENUM.Math_Animator_Layer.COMMONLAYER then
            local index = oriLayer - AVATAR_ENUM.Math_Animator_Layer.COMMONLAYER +
                              AVATAR_ENUM.Math_Animator_Layer_Override.COMMONLAYER
            newTable[index] = weight
            -- 传说皮肤层级
        elseif oriLayer > AVATAR_ENUM.Math_Animator_Layer.BASELAYER1 then
            if weight > 0 then
                newTable[AVATAR_ENUM.Math_Animator_Layer_Override.LEGENDLAYER] = 1
                newTable[AVATAR_ENUM.Math_Animator_Layer_Override.BASELAYER1] = 0
            end
        end
    end
    return newTable
end

-- 密码本:本地版本转发送版本
function MathAvatar:ConvertLayerTableToSync(layerTable)
    if not self.enableAnimatorOverride then
        return layerTable
    end
    local newTable = {}
    for k, v in pairs(AVATAR_ENUM.Math_Animator_Layer) do
        if v == AVATAR_ENUM.Math_Animator_Layer.BASELAYER1 or v == AVATAR_ENUM.Math_Animator_Layer.COMMONLAYER then
            newTable[v] = 1
        else
            newTable[v] = 0
        end
    end
    for oriLayer, weight in pairs(layerTable) do
        if oriLayer >= AVATAR_ENUM.Math_Animator_Layer_Override.COMMONLAYER then
            local index = oriLayer + AVATAR_ENUM.Math_Animator_Layer.COMMONLAYER - AVATAR_ENUM.Math_Animator_Layer_Override.COMMONLAYER
            newTable[index] = weight
        end
    end
    newTable[1] = layerTable[1]
    if layerTable[AVATAR_ENUM.Math_Animator_Layer_Override.LEGENDLAYER] == 1 then
        if self.pkgName then
            local layer = App.SkinAnimatorPair[tostring(self.pkgName)]
            if layer then
                newTable[layer] = 1
            end
        end
    end
    return newTable
end


--- 设置是否开车, 不同步
function MathAvatar:SetDriving(driving)
    self.driving = driving == true

    if self.driving then
        self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.FLYPLANE, false, false, 1, true)
        self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "start_drive", nil, false)
    else
        self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.FLYPLANE, false, false, 0, true)
        self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Trigger, "stop_drive", nil, false)
    end

end

--- 开始冲刺
---@param speedFactor any
function MathAvatar:SetRushState()
    if self.state == "rushing" then
        return
    end
    self:PlayRushAudio()
    if self.state == "weak" then
        self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "weak", false, true)
    end
    self.state = "rushing"
    self:SetRushEffect(true)
    if self.canSend then
        self:SendMessage("rush", {
            state = 2
        })
    end
end

--- 展示/隐藏 冲刺效果
---@param show any
function MathAvatar:SetRushEffect(show)
    self.showRushEffect = show
    if not Util:IsNil(self.transRushTrail) and not Util:IsNil(self.transRushWind) then
        self.transRushTrail.gameObject:SetActive(self.showRushEffect)
        self.transRushWind.gameObject:SetActive(self.showRushEffect)
        return
    end

    if Util:IsNil(self.avatarBase) then
        self.avatarBase = self.BodyTrans:Find("Character")
    end
    if Util:IsNil(self.avatarBase) then
        return
    end
    if self.showRushEffect then
        if Util:IsNil(self.transHips) then
            self.transHips = self.avatarBase:FindInAll("Character_Hips")
        end
        if not self.transHips then
            return
        end
        -- wind
        ResourceManager:LoadGameObjectWithExName(rushWindPath, function(prefab)
            if Util:IsNil(self.transRushWind) then
                local goWind = GameObject.Instantiate(prefab)
                self.transRushWind = goWind.transform
                self.transRushWind:SetParent(self.avatarBase)
                self.transRushWind.localScale = Vector3.one
                self.transRushWind.localPosition = Vector3.zero
                self.transRushWind.localRotation = CS.UnityEngine.Quaternion.identity
            end
            self.transRushWind.gameObject:SetActive(self.showRushEffect)
        end)
        -- trail
        ResourceManager:LoadGameObjectWithExName(rushTrailPath, function(prefab)
            if Util:IsNil(self.transRushTrail) then
                local goWind = GameObject.Instantiate(prefab)
                self.transRushTrail = goWind.transform
                self.transRushTrail:SetParent(self.transHips)
                self.transRushTrail.localScale = Vector3.one
                self.transRushTrail.localPosition = Vector3.zero
                self.transRushTrail.localRotation = CS.UnityEngine.Quaternion.identity
            end
            self.transRushTrail.gameObject:SetActive(self.showRushEffect)
        end)
    end
end

--- 展示/隐藏 冲刺效果
---@param show any
function MathAvatar:SetBigEffect(show)
    self.showBigEffect = show
    if not Util:IsNil(self.transBigTrail) then
        self.transBigTrail.gameObject:SetActive(self.showBigEffect)
        return
    end
    if Util:IsNil(self.avatarBase) then
        self.avatarBase = self.BodyTrans:Find("Character")
    end
    if Util:IsNil(self.avatarBase) then
        return
    end
    if self.showBigEffect then
        if Util:IsNil(self.transHips) then
            self.transHips = self.avatarBase:FindInAll("Character_Hips")
        end
        if not self.transHips then
            return
        end

        -- trail
        ResourceManager:LoadGameObjectWithExName(bigTrailPath, function(prefab)
            if Util:IsNil(self.transBigTrail) then
                local goWind = GameObject.Instantiate(prefab)
                self.transBigTrail = goWind.transform
                self.transBigTrail:SetParent(self.transHips)
                self.transBigTrail.localScale = Vector3.one
                self.transBigTrail.localPosition = Vector3(0.392, -0.005, 0)
                self.transBigTrail.localRotation = Quaternion.Euler(-84.746, 172.054, -171.293);
            end
            self.transBigTrail.gameObject:SetActive(self.showBigEffect)
        end)
    end
end

function MathAvatar:SetWeakState()
    if self.state == "weak" then
        return
    end
    if self.state == "rushing" then
        self:SetRushEffect(false)
    end
    self.state = "weak"
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "weak", true, true)
    if self.canSend then
        self:SendMessage("rush", {
            state = 3
        })
    end
end

function MathAvatar:SetNormalState()
    self:commitAnimationAction(AVATAR_ENUM.ANIMATION.Bool, "weak", false, true)
    self:SetRushEffect(false)
    self.state = "normal"
    if self.canSend then
        self:SendMessage("rush", {
            state = 1
        })
    end
end

--- overide super Method
function MathAvatar:_PlayAnim(msgType)

end

--- overide super Method
function MathAvatar:ReceiveMessage(msgkey, action, historyMsg)
    local uuid = self:GetProperty("uuid")
    local key = string.sub(msgkey, 1, string.len(msgkey) - string.len(uuid))
    MathAvatar.super.ReceiveMessage(self, msgkey, action, historyMsg)

    if key == AVATAR_ENUM.MESSAGE_KEY.CHANGESPORTMODEL then
        if (self.canSend and historyMsg) or not self.canSend then
            -- 自己的实时消息不处理
            local last = json.decode(action[#action])
            self:CommitChangeSportTypeAction(last.Type, false)

            if self.canSend and historyMsg and last.Type ~= AVATAR_ENUM.MOVE_TYPE.WALK then
                self:CommitChangeSportTypeAction(AVATAR_ENUM.MOVE_TYPE.WALK, true)
            end
        end
    elseif key == AVATAR_ENUM.MESSAGE_KEY.BEHITFLYING and not historyMsg and not self.canSend then
        local last = json.decode(action[#action])
        self.characterCtrl:SetBombedWithFinalPos(last.finalPos, last.speedv)
    end

end

function MathAvatar:RemoteUserTopicRemoved(uuid, msgkey)

    local uuid = self:GetProperty("uuid")
    local key = string.sub(msgkey, 1, string.len(msgkey) - string.len(uuid))

    -- 远端用户的topic被清除 切回走路
    if key == AVATAR_ENUM.MESSAGE_KEY.CHANGESPORTMODEL then
        self:CommitChangeSportTypeAction(AVATAR_ENUM.MOVE_TYPE.WALK, false)
    end
end

----切换移动模式  走路 游泳 潜水
----@param AVATAR_ENUM.MOVE_TYPE
function MathAvatar:CommitChangeSportTypeAction(type, syncRemote)

    -- if self.canSend then
    --     g_Log("Commit ChangeMoveState ",self.moveState,type,debug.traceback())
    -- end

    local action = {
        ["ActionType"] = AVATARACTION.CHANGE_SPORT_MODE,
        ["Type"] = type,
        ["notify"] = syncRemote
    }

    self.actionQueue:commitAction(action)

end

----@param AVATAR_ENUM.MOVE_TYPE
function MathAvatar:ChangeMoveState(state, syncRemote)

    if self.canSend then
        g_Log("ChangeMoveState 1", self.moveState, table.dump(self.tableLayerWeight), state)
    end

    if self.moveState == state then
        return
    end

    if syncRemote and self.canSend then

        self:SendMessage(AVATAR_ENUM.MESSAGE_KEY.CHANGESPORTMODEL, {
            Type = state
        })
    end

    self.moveState = state

    if state == AVATAR_ENUM.MOVE_TYPE.WALK then
        self.muteMoveAudio = false
        self.characterCtrl:ChangeToNormalState()
        if self.canSend then
            self.verticalFlag = 0
            self.joystick:ChangeToNormalState()
        end
        -- layer, notify, history, weight, notReset
        -- self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.BASELAYER, false)
        self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.SWIMLAYER, true, false, 0, true)
        self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.DIVELAYER, true, false, 0, true)
    elseif state == AVATAR_ENUM.MOVE_TYPE.SWIM then
        self.muteMoveAudio = true
        self.characterCtrl:ChangeToNormalState()
        if self.canSend then
            self.verticalFlag = 0
            self.joystick:ChangeToNormalState(true)
        end
        self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.SWIMLAYER, true, false, 1, true)
        self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.DIVELAYER, true, false, 0, true)
    elseif state == AVATAR_ENUM.MOVE_TYPE.DIVE then
        self.muteMoveAudio = true
        self.characterCtrl:ChangeToSwimState()
        if self.canSend then
            self.joystick:ChangeToSwimState()
        end
        self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.SWIMLAYER, true, false, 0, true)
        self:commitAnimatiorLayerAction(self.AVATAR_ENUM_ANIMATOR.DIVELAYER, true, false, 1, true)
    end
end

function MathAvatar:IsNewSkin()
    for i, skinPackages in pairs(self.skinInfoMap) do
        if self.decorateService:CheckNewSkin(skinPackages) then
            return true
        end
    end
    return false
end

--- 滑板设置上坡角度，范围-50~50
function MathAvatar:SetRoadAngle(angle)
    self.Animator:SetFloat("rate", angle)
end

function MathAvatar:RegisterColliderListener()

    cs_coroutine.start(function()

        coroutine.yield(App:GetService("CommonService"):WaitUntil(function()
            return self.changeClothComplete == true
        end))

        self.VisElement.gameObject.layer = CS.UnityEngine.LayerMask.NameToLayer("areaTrigger")
        self:_RegisterColliderListener()

    end)

end

function MathAvatar:_RegisterColliderListener()
    if Util:IsNil(self.character) then
        return
    end

    if self.hasRegisterListener then
        return
    end

    self.hasRegisterListener = true

    self.character.gameObject.layer = 25

    local capCollider = self.character:GetComponent(typeof(CS.UnityEngine.CapsuleCollider))
    if Util:IsNil(capCollider) then
        capCollider = self.character.gameObject:AddComponent(typeof(CS.UnityEngine.CapsuleCollider))
        capCollider.height = self.characterCtrl.characterCtrl.height
        capCollider.radius = self.characterCtrl.characterCtrl.radius
        capCollider.center = self.characterCtrl.characterCtrl.center
    end

    local colliderListener = self.character:GetComponent(typeof(CS.ColliderListener))
    if colliderListener == nil then
        colliderListener = self.character:AddComponent(typeof(CS.ColliderListener))
        self.colliderListener = colliderListener
    end

    App:GetService("CommonService"):RegisterGlobalTimer(0, function()
        local topPos = self.characterCtrl.characterCtrl.transform.position + Vector3.up *
                           self.characterCtrl.characterCtrl.height
        local bottomPos = self.characterCtrl.characterCtrl.transform.position
        -- g_Log("碰撞器进入",topPos,bottomPos,self.characterCtrl.characterCtrl.transform.position)
        local hits = CS.UnityEngine.Physics.OverlapCapsule(topPos, bottomPos, capCollider.radius, 25)
        if hits.Length == 0 then
            return
        end
        for i = 0, hits.Length - 1, 1 do
            local gm = hits[i].gameObject
            if gm.layer == 25 and gm ~= self.character then
                -- g_Log("碰撞器进入",gm)  
                self:ColliderEnter(hits[i])
            end
        end

    end, false)

    -- 获取刚体
    local rb = self.character:GetComponent(typeof(CS.UnityEngine.Rigidbody))
    if rb == nil then
        rb = self.character:AddComponent(typeof(CS.UnityEngine.Rigidbody))
        rb.constraints = CS.UnityEngine.RigidbodyConstraints.FreezeAll
    end
    rb.collisionDetectionMode = 1

    self.colliderDic = {}

    colliderListener.onCollisionEnterEvent = colliderListener.onCollisionEnterEvent + function(other)

        self:ColliderEnter(other)

    end
end

function MathAvatar:ColliderEnter(other)
    if other.gameObject == self.VisElement.gameObject then
        return
    end

    if self.playing then
        return
    end

    -- g_Log("碰撞器进入",other.gameObject.name)

    self.playing = true

    -- 根据layer输出名字

    local name = self:FindSportGmName(other.gameObject)

    -- CS.UnityEngine.Time.fixedDeltaTime = 0.01;
    local speed, hitAngle, hitSpeed = CourseEnv.ServicesManager:GetMoveService():getSpeedByName(name)
    if not hitAngle then
        hitAngle = 60
    end
    if not hitSpeed then
        hitSpeed = 1.2
    end

    if not speed then
        self.playing = false
        return
    end

    if speed.x == 0 and speed.y == 0 and speed.z == 0 then
        self.playing = false
        return
    end

    -- g_Log("碰撞器进入",speed)

    local dir = nil

    if other.contacts then
        dir = other.contacts[0].normal
    else
        dir = (self.VisElement.transform.position - other.gameObject.transform.position).normalized
    end

    dir.y = 0
    speed.y = 0

    local dotProduct = Vector3.Dot(dir.normalized, speed.normalized);

    if dotProduct <= 0 then
        self.playing = false
        return
    end

    local angle = Vector3.Angle(dir.normalized, speed.normalized);
    if angle >= hitAngle then
        self.playing = false
        return
    end

    local scale = hitSpeed
    local v0 = 3
    local t = v0 / 15 * 2
    local length = speed.magnitude * t
    local target = dir * length * scale

    local final = self.VisElement.transform.position + target

    -- self.VisElement.transform.position = final
    -- g_Log("碰撞器进入",target)

    -- [15]="Player",
    self.VisElement.gameObject.layer = 15
    self.characterCtrl:SetBombedWithFinalPos(final, v0, function()
        self.playing = false
        -- [14]="areaTrigger",
        self.VisElement.gameObject.layer = 14
    end)

    self:SendMessage(AVATAR_ENUM.MESSAGE_KEY.BEHITFLYING, {
        finalPos = {
            x = final.x,
            y = final.y,
            z = final.z
        },
        speedv = v0
    })
end

--- func desc
---@param scale 缩放大小
---@param callback 完成回调
function MathAvatar:SetAvatarScale(scale, callback)
    self.VisElement.transform:DOScale(Vector3.one * scale, 1)
    self.isBig = scale ~= 1
    if self.isBig then
        self:TriggerAndNotifyAnimation("start_big")
    end
    self.commonService:DispatchAfter(1, function()
        -- self:SetBigEffect(self.isBig)
        if callback then
            callback()
        end
    end)

end

function MathAvatar:FindSportGmName(gm)
    local parent = gm

    while parent ~= nil and parent.transform.parent do
        if parent.transform.name == 'Asset' and parent.transform.parent then
            parent = parent.transform.parent
            break
        end

        if parent.transform.parent.name == 'Workspace' then
            break
        end

        parent = parent.transform.parent
    end

    return parent.name
end

function MathAvatar:Exit()

    if self.colliderListener then
        self.colliderListener:Clear()
    end

    MathAvatar.super.Exit(self)

end
function MathAvatar:Tick()
    MathAvatar.super.Tick(self)
    
end

function MathAvatar:ChangeAnimatorController(layer, callback)
    local overrideName = AVATAR_ENUM.Math_Animator_Layer_To_Override_Name[layer]
    if not overrideName then
        g_LogError("ChangeAnimatorController : not overrideName layer = " .. layer)
        -- if callback then
        --     callback(false, nil)
        -- end
        -- return
        layer = 1
        overrideName = AVATAR_ENUM.Math_Animator_Layer_To_Override_Name[layer]
    end
    local subfix = "overrideController"
    if layer == 1 then
        subfix = "controller"
    end
    local fullPath = self.overrideAnimatorPath .. overrideName .. "." .. subfix
    ResourceManager:LoadRuntimeAnimatorControllerWithPath(fullPath, function(overrideController)
        if not overrideController then
            g_LogError("ChangeAnimatorController : not prefab layer = " .. layer)
            if callback then
                callback(false, nil)
            end
            return
        end
        g_Log("ChangeAnimatorController : prefab layer = " .. layer, overrideController)

        if not overrideController then
            g_LogError("ChangeAnimatorController : not overrideController layer = " .. layer)
            if callback then
                callback(false, nil)
            end
            return
        end

        if callback then
            callback(true, overrideController)
        end
    end)
end
return MathAvatar
