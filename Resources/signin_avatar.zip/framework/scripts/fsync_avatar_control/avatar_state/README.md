# 道具和状态同步文档2.0

## 1. 配置文件

###道具配置文件示例
```
[
  {
    "id": 1000,     -道具ID，唯一索引值
    "prop_name": "爆竹",  -道具名称
    "prop_describe": "爆竹描述",  -道具描述
    "use_mod_path" = 0, --使用mod路径,一般用不到
    "model_path": "modules/dynasty/assets/prefabs/prop/prop.prefab",  -道具具体预设位置
    "parent_point": "joint_LeftWrist_001", -道具附加的对象节点名称
    "prop_pos": "0,0,0",  -设置道具局部位置 x,y,z
    "prop_rot": "0,0,0",  -设置道具局部旋转
    "prop_scale": "0.3,0.3,0.3" -设置道具缩放值
    "place_id": 道具位置，同位置道具互斥
  }
]
```

## 2. lua各文件说明
```
fsync_avatar_prop:道具同步
fsync_avatar_state:avatar状态同步基类(子类需继承)
fsync_avatar_state_machine:状态同步管理
fsync_prop_info.config:道具配置管理
fsync_prop_manager:佩戴道具
```

## 3. 使用示例

#### 道具同步
```
--佩戴道具
--propId string 道具Id
--function 完成回调function(result) result:是否成功
App:GetService("Avatar"):AddAvatarPropById("1000001", function(result)

end)

--卸载道具
--propId string 道具Id
--function 完成回调function(result) result:是否成功
App:GetService("Avatar"):RemoveAvatarPropById("1000001", function(result)

end)

--卸载所有道具
--function 完成回调function(result) result:是否成功
App:GetService("Avatar"):ResetAvatarProp(function(result)

end)

```

#### 同步状态(只保留最新的状态)

```
--同步状态
--stateId string 状态Id
--param table 参数
--function 完成回调function(result) result:是否成功
App:GetService("Avatar"):UpdateAvatarState(stateId, param, function(result)

end)

--重置状态
--function 完成回调function(result) result:是否成功
App:GetService("Avatar"):ResetState(function(result)

end)
```

------------
```
--注册自定义的子类state (import或require都可以)
self.stateMachine:RegisterState("jumi", import("avatar_state_jumi"))

--状态变化通知
self.stateMachine.OnChangeAvatarState:connect(function(currentState)
end)

```


