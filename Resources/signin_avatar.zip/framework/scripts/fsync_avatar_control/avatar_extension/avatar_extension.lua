--avatar类扩展方法
local avatar_extension = require("scripts/fsync_avatar_control/fsync_avatar_ctrl")

function avatar_extension:ExtendMethod()
    --TODO: 扩展方法
end