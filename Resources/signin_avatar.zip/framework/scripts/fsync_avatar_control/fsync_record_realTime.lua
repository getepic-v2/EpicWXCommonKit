local class = require("middleclass")
local AudioExposeLoader =require(MAIN_SCRIPTS_LOC.."audio/audio_expose_loader")
local LogBridge = require(MAIN_SCRIPTS_LOC.."common/log_bridge")


local AvatarDiscuss = class("AvatarDiscuss")
Quaternion = CS.UnityEngine.Quaternion
local ANZHUFAYAN = 123451 --用于按钮按下启动，收到
local CHANGESTATE = 123452 --用于状态转换切换按钮UI，发出
local HIDENTOAST = 123453
function AvatarDiscuss:initialize(avatar)
    g_Log("wwwww avatar discuss init")
    self.audioList = {}
    self.audioChangedList = {}
    self.AudioPlayer = AudioExposeLoader:new()
    -- self.isDiscussing = false
    self.isRecording = false
    self.isPlaying = false
    self.Banned = false--禁言状态
    self.collectiveSpeech = false--集体发言状态
    self.currentIndex = 0
    self.avatar = avatar
    self.teacherService = App:GetService("TeacherService")
    
    self:RegisterEvents()
    self.isLecture = false --演讲状态
    
    APIBridge.RequestAsync("buss.menu.chatlist",{isShow = true,type = "normal"},nil)
    --通知外部模式聊天区模式切换
    self.teacherService.changeChatType("system")
    APIBridge.RequestAsync("api.rtc.userlist",{enable = true,noticeType = "changed"},nil)
    
end



---自身avatar注册播放音频事件
---录音事件
---播放事件
---新增音频事件
function AvatarDiscuss:RegisterEvents()
    
    self.teacherService.recordAudio:connect(function(msg)
        local code = tonumber(msg.code)
        local type_ = tonumber(msg.type)
        if code == ANZHUFAYAN then
            if type_ == 1 then
                self:OnDiscussStart()  --按住说话开始
            else
                LogBridge.SNoStatisticsWithParam("qz_student_client",{eventtype = "qz_student_client",
                                                                      sno = "199",
                                                                      logtype = "voice_message",
                                                                      voice_status = 2,
                                                                      identify_id = tostring(os.time())},function() end)
                self:OnDiscussStopSelf()  --按住说话结束
            end
        end
    end)
    
    
    local service = App:GetService("CommonService")
    service.gate.OnExitGate:connect(function()
            self:OnDestroy()
    end)

end



function AvatarDiscuss:OnDiscussStart()
    g_Log("wwww on discuss start")
    --按下埋点
    LogBridge.SNoStatisticsWithParam("qz_student_client",{eventtype = "qz_student_client",
                                                          sno = "199",
                                                          logtype = "voice_message",
                                                          voice_status = 1,
                                                        identify_id = tostring(os.time())},function() end)
    APIBridge.RequestAsync("buss.menu.audiochat", {action = "press_down",recordType = "rtc",showMode = "voice_to_text"}, nil)
    
end
function AvatarDiscuss:OnDiscussStopSelf()
    --关闭录音UI
    APIBridge.RequestAsync("buss.menu.audiochat", {action = "press_up",recordType = "rtc",showMode = "voice_to_text"}, nil)
    
end


function AvatarDiscuss:OnDestroy()
    self:OnDiscussStopSelf()
end



return AvatarDiscuss

