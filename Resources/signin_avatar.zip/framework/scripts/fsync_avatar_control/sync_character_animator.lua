---
--- 角色动画同步控制器
--- 用于控制独立角色的走跑跳动画与主角色保持同步
--- Created by AI Assistant
--- DateTime: 2024/12/19
local class = require("middleclass")
local ENUM = require("scripts/avatar_control/avatar_consts")
local Util = require(MAIN_SCRIPTS_LOC .. "common/util")

---@class SyncCharacterAnimator
local SyncCharacterAnimator = class("SyncCharacterAnimator")

---初始化动画同步控制器
---@param targetAnimator CS.UnityEngine.Animator 目标角色的Animator组件
---@param avatarCtrl table 主角色控制器引用
function SyncCharacterAnimator:initialize(targetAnimator, avatarCtrl)
    self.targetAnimator = targetAnimator
    self.avatarCtrl = avatarCtrl
    
    -- 动画参数名称
    self.animParams = {
        grounded = "grounded",
        freeFall = "freeFall", 
        jumpStart = "jumpStart",
        jump_start2 = "jump_start2",
        speed = "speed",           -- 新增：移动速度参数
        isWalking = "isWalking"    -- 新增：行走状态参数
    }
    
    -- 获取动画参数哈希值
    self.animHashes = {}
    for name, paramName in pairs(self.animParams) do
        self.animHashes[name] = self:NameToHash(paramName)
    end
    
    -- 移动状态相关
    self.isMoving = false
    self.currentSpeed = 0
    self.lastSpeed = 0
end

---获取动画参数哈希值
---@param paramName string 参数名称
---@return number 哈希值
function SyncCharacterAnimator:NameToHash(paramName)
    if self.avatarCtrl and self.avatarCtrl.NameToHash then
        return self.avatarCtrl:NameToHash(paramName)
    else
        -- 如果没有NameToHash方法，直接使用字符串
        return paramName
    end
end

---设置动画参数
---@param paramName string 参数名称
---@param value boolean 参数值
function SyncCharacterAnimator:SetAnimBool(paramName, value)
    if not self.targetAnimator or Util:IsNil(self.targetAnimator) then
        return
    end
    
    local hash = self.animHashes[paramName] or paramName
    self.targetAnimator:SetBool(hash, value)
end

---设置动画浮点参数
---@param paramName string 参数名称
---@param value number 参数值
function SyncCharacterAnimator:SetAnimFloat(paramName, value)
    if not self.targetAnimator or Util:IsNil(self.targetAnimator) then
        return
    end
    
    local hash = self.animHashes[paramName] or paramName
    self.targetAnimator:SetFloat(hash, value)
end

---设置移动状态
---@param isMoving boolean 是否在移动
---@param speed number 移动速度（可选，如果不提供则根据isMoving自动计算）
function SyncCharacterAnimator:SetMoveState(isMoving, speed)
    if self.isMoving == isMoving and not speed then
        return -- 状态没有变化且没有提供速度参数
    end
    
    self.isMoving = isMoving
    
    -- 计算移动速度
    if speed then
        self.currentSpeed = speed
    else
        -- 根据移动状态自动计算速度
        if isMoving then
            -- 默认移动速度，可以根据需要调整
            self.currentSpeed = 3.5
        else
            self.currentSpeed = 0
        end
    end
    
    -- 设置速度参数
    if self.currentSpeed ~= self.lastSpeed then

        self:SetAnimFloat("speed", self.currentSpeed)
        self.lastSpeed = self.currentSpeed
    end
    
    -- 设置行走状态参数（可选，如果动画器支持）
    if self.animHashes.isWalking then
        local isWalking = self.currentSpeed > 0 and self.currentSpeed <= 2.25
        self:SetAnimBool("isWalking", isWalking)
    end
end

---设置跳跃状态
---@param isJumping boolean 是否在跳跃
---@param isSecondJump boolean 是否为二段跳
function SyncCharacterAnimator:SetJumpState(isJumping, isSecondJump)
    if isJumping then
        if isSecondJump then
            self:SetAnimBool("jump_start2", true)
            self:SetAnimBool("jumpStart", false)
        else
            self:SetAnimBool("jumpStart", true)
            self:SetAnimBool("jump_start2", false)
        end
    else
        self:SetAnimBool("jumpStart", false)
        self:SetAnimBool("jump_start2", false)
    end
end

---设置下落状态
---@param isFalling boolean 是否在下落
function SyncCharacterAnimator:SetFallState(isFalling)
    self:SetAnimBool("freeFall", isFalling)
end

---设置地面状态
---@param isGrounded boolean 是否在地面
function SyncCharacterAnimator:SetGroundedState(isGrounded)
    self:SetAnimBool("grounded", isGrounded)
    
    if isGrounded then
        -- 落地时重置跳跃和下落动画
        self:SetAnimBool("freeFall", false)
        self:SetAnimBool("jumpStart", false)
        self:SetAnimBool("jump_start2", false)
    end
end

---根据消息类型设置动画状态（只处理走跑跳相关）
---@param msgType number 消息类型
function SyncCharacterAnimator:SetAnimationByMessageType(msgType)
    if msgType == ENUM.AVATAR_MSG_TYPE.MOVE then
        self:SetMoveState(true)
    elseif msgType == ENUM.AVATAR_MSG_TYPE.STOP then
        self:SetMoveState(false)
    end
end

---根据动作状态设置动画（只处理走跑跳相关）
---@param action table 动作数据
function SyncCharacterAnimator:SetAnimationByAction(action)
    if not action then
        return
    end
    
    -- 处理地面状态
    local isGrounded = action.g == 0
    self:SetGroundedState(isGrounded)
    
    -- 处理移动状态
    local isMoving = (action.s == 3) and action.t ~= ENUM.AVATAR_MSG_TYPE.STOP
    self:SetMoveState(isMoving)
    
    -- 处理跳跃状态
    local isJumping = action.s == 1 or action.s == 4
    local isSecondJump = action.s == 4
    self:SetJumpState(isJumping, isSecondJump)
    
    -- 处理下落状态
    local isFalling = action.s == 2
    self:SetFallState(isFalling)
end

---重置所有动画状态
function SyncCharacterAnimator:ResetAllAnimations()
    self:SetAnimBool("freeFall", false)
    self:SetAnimBool("jumpStart", false)
    self:SetAnimBool("jump_start2", false)
    self:SetAnimBool("grounded", false)
    self:SetAnimFloat("speed", 0)
    if self.animHashes.isWalking then
        self:SetAnimBool("isWalking", false)
    end
    
    -- 重置状态
    self.isMoving = false
    self.currentSpeed = 0
    self.lastSpeed = 0
end

---销毁时清理
function SyncCharacterAnimator:Destroy()
    self.targetAnimator = nil
    self.avatarCtrl = nil
    self.animHashes = nil
end

return SyncCharacterAnimator 