---@type function
local customAvatarCreator = nil


---@class PlanetAvatarCreator
local PlanetAvatarCreator = {
}


---@param callBack function
function PlanetAvatarCreator.SetAvatarCreator(callBack)
    customAvatarCreator = callBack
end

---@return boolean
function PlanetAvatarCreator.CheckIsInit()
    return customAvatarCreator ~= nil
end

---@param element WorldElement
---@return PlanetFsyncAvatar
--统一创建planet_avatar
function PlanetAvatarCreator.CreatePlanetAvatar(element)
    local avatar = nil
    if customAvatarCreator then
        avatar = customAvatarCreator(element)
    else
        g_LogError("customAvatarCreator is nil")
    end

    return avatar
end

return PlanetAvatarCreator
