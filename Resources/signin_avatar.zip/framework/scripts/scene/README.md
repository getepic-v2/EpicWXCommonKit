# 1. 场景管理
## 1.1 相关文档

传送门配置文件示例(spawn1 spawn2是标记传送位置的物体名)
[
  {
    "id": 1,
    "name": "door1",
    "describe": "出生地传送门",
    "sceneId": 100001,
    "to_sceneId": 100002,
    "spawn_name": "spawn1",
    "to_spawn_name": "spawn2"
  }
]

场景配置文件示例
[
  {
    "id": 100000,
    "scene_type": 1,
    "scene_name": "main_scene",
    "scene_describe": "启动基础场景（逻辑场景）",
    "scene_additive_list": "main_scene",
    "scene_model_prepath": "modules/dynasty/assets/scenes/"
  }
]

## 1.2 目录结构说明
```
script/scene/
├─ scene_manager  场景管理类
```

## 1.3 流程说明

1、scene_info.xlsx结构+资源可以放置各自的业务模块
```
     1、初始化各自业务的数据
     local SceneManager = require(MAIN_SCRIPTS_LOC.."scene/scene_manager")
     --初始化调用填充数据，方法中也会重置声音初始变量
     SceneManager:getInstance():FillData(sceneInfoData)
```

## 1.4 示例
``` 
    1.通用调用
    local SceneManager = require(MAIN_SCRIPTS_LOC.."scene/scene_manager")
     
    --TODO
    
 
    
```


