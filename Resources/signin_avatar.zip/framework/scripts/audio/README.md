# 1. 声音管理
## 1.1 声音相关文档
音效与技术资源文档【知音楼】：https://yach-doc-shimo.zhiyinlou.com/sheets/B1AwDxx1XXuywK3m/Tza80/ 「audio_info」
技术应用调研：https://yach-doc-shimo.zhiyinlou.com/docs/YYCCjHv9yjwKdxWT/  <X项目-Unity 相关技术应用>

## 1.2 目录结构说明
```
script/audio/
├─ audio_pool_manager  声音管理类
```

## 1.3 流程说明
全真春节课程说明：
1.音频资源统一放在 Components/Assets/modules/SpringFestival/assets/sounds
2.音频信息配置：Components/ConofigTable/table/audio_info.xlsx
  Tools/ExcelExportJson 操作导出audio_info.json 复制放到modules/SpringFestival/configs下
  音频区域控制表（暂时根据触发器划分区域）
3. 区域分组信息表，通过Mixer分组控制不同的区域的音量area_info.xlsx（具体声音分组可以查看Sound下MasterAudioMixer.mixer，并和audio_info.xlsx的audio_type对应）

声音管理器解藕处理
1.audio_pool_manager迁移到Main模块，各个室业务可共用，但是声音配置（可参考之前的audio_info.xlsx结构）+资源放置各自的业务模块
```
     1、初始化各自业务的数据
     local AudioPoolManager = require(MAIN_SCRIPTS_LOC.."audio/audio_pool_manager")
     --初始化调用填充数据，方法中也会重置声音初始变量
     AudioPoolManager:getInstance():FillAudioData(audioInfoData)
```

## 1.4 示例
``` 
    1.通用调用
    local AudioPoolManager = require(MAIN_SCRIPTS_LOC.."audio/audio_pool_manager")
     
     --声源：动态创建声音（当前物品的位置）【主要音效调用】
     --audio_id：音频id，唯一索引值, parent:当前物体的位置, loop:音频是否循环（其他的音频音量等参数，可以直接在audio_info配置表配置）
     if self.player ~= nil then
       AudioPoolManager:getInstance():StartPlayAudioClip(100070, self.player, function()
          print("----------100070----------")
       end, false)
     end
   
    
    ---停止单个声音，audio_id：音频id，唯一索引值（配合StartPlayAudioClip使用，如果loop为false，声音会自动处理暂停，不需要重复调用StopPlayAudioClip方法）
    if self.player ~= nil then
     AudioPoolManager:getInstance():StopPlayAudioClip(100070)
    end
    
    ---停止所有声音（可以在退出课程调用）
    AudioPoolManager:getInstance():StopAllSound()

   ---释放所有音频资源（可以在退出课程调用）
    AudioPoolManager:getInstance():ReleaseAudioAssets()
    
    全局声音控制：例如：moduleName:MasterVolume:全局/MusicVolume：背景/SFXVolume：特效, Volume：音频范围，-80，20
    AudioPoolManager:getInstance():ControlMixerVolume("MasterVolume",0)


    2.如果是角色相关的可以直接调用avatar.lua类，里面在audio_pool_manager基础上封装声音管理接口
    --音效调用(一次触发的音效可以挂在人身上，如果道具循环播放的，注意parent可以直接为当前道具对象)
    self.avatar.PlayAudioAction(self, true, 100069, self.gameObject, false, function()
        print("声音播放结束后回调")
       end)
    --音效暂停
    self.avatar.PlayAudioAction(self,false,100069)
    
```


