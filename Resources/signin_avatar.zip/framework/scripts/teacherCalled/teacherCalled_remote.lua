local class = require("middleclass")
---@type RemoteScript
local RemoteScript = require("mworld/remotescript")
---@class Remote: RemoteScript
local TeacherRemote = class("Remote", RemoteScript)
local json = require("nextjson")

function TeacherRemote:initialize(element, script)
    TeacherRemote.super.initialize(self,element,script)
    --todo:待放开
    local teacherService = App:GetService("TeacherService")
   teacherService:registerDropLine(self)
end

---@param action table
function TeacherRemote:OnClientCall(msg)
    self.Element:SetProperty("status",msg.status)
    --self.Element:SetProperty("transMsg",msg.transMsg)
end
function TeacherRemote:drop_down()
    debug_print('isOnline------召集跟随 dui---掉线回调---->')
    self.Element:SetProperty("status", json.encode({code = 100,status = "jiesan"}))--{status = json.encode({code = 100,status = "jiesan"})}
end
return TeacherRemote


