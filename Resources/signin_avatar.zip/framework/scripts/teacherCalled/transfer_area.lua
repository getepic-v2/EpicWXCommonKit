-- 使用方法
--  local transferArea = require("SpringFestival/scripts/transfer_area")
--  local transferAreaObj = transferArea:new(self.role)
local cs_coroutine = require("common/cs_coroutine")

local class = require("middleclass")
local TransferArea = class("TransferArea")
require("common/tableutil")
local util = require(MAIN_SCRIPTS_LOC.."common/util")
local tip = require(MAIN_SCRIPTS_LOC.."teacherCalled/tips_controller")
local json = require("nextjson")

function TransferArea:initialize(role)--body
    ---@type CS.UnityEngine.GameObject
    self.role = role
    self:_createTransferArea()
end

function TransferArea:_createTransferArea()
    --local that = self
    ResourceManager:LoadGameObjectWithExName(
        "modules/"..RESOURCE_LOC.."/assets/prefabs/transferArea/TransferArea.prefab",
        function(go)
            debug_print("liulin--load TransferArea !")
            self.TransferArea = GameObject.Instantiate(go)
            self.TransferArea.name = "TransferArea"
            self.TransferArea.transform:SetParent(self.role.transform, false)
            --meshRenderer = self.TransferArea:GetComponent(typeof(CS.UnityEngine.MeshRenderer))
            --meshRenderer.material.color = Color.cyan;
            --self:hideTransferArea()
            -- that:show()
            self:hide()
        end
    )
end

-- 获取20个站位的坐标和旋转
function TransferArea:getPlayersTransformParam()
    --ResourceManager:LoadGameObjectWithExName('modules/SpringFestival/assets/Prefabs/people/Boy.prefab', function(go)
    local playerTransformParam = {}
    local len = self.TransferArea.transform.childCount
    for i = 1, len do
        local point_area = self.TransferArea.transform:GetChild(i - 1).transform
        local npcPos = point_area.position
        local relativePos = self.role.transform.position - npcPos
        playerTransformParam[i] = {}
        playerTransformParam[i]["position"] = json.encode({x=npcPos.x,y=npcPos.y,z=npcPos.z})
        playerTransformParam[i]["rotation"] = json.encode({x=relativePos.x,y=0,z=relativePos.z})
        --json.encode(playerTransformParam[i])
    end
    return playerTransformParam
    --end)
end

-- 创建测试npc
--function TransferArea:createTestNpc(number)
--    self.npcs = {}
--    number = number or 1
--    ResourceManager:LoadGameObjectWithExName(
--        "modules/SpringFestival/assets/Prefabs/people/Boy.prefab",
--        function(go)
--            for i = 1, number do
--                npc = GameObject.Instantiate(go)
--                npc:GetComponent(typeof(NavMeshAgent)).enabled = false
--                npc.transform:SetParent(self.role.transform.parent, false)
--                npcPos = self.TransferArea.transform:GetChild(i - 1).transform.position
--                npc.transform.position = npcPos
--                --npc.transform.position.y = self.role.transform.position.y
--                --npc.transform.position = self.TransferArea.transform.position
--                relativePos = self.role.transform.position - npc.transform.position
--                npc.transform.rotation = Quaternion.LookRotation(relativePos, Vector3.up)
--                self.npcs[#self.npcs + 1] = npc
--            end
--        end
--    )
--end
---将自己传送到中央平台静态位置
function TransferArea:transToStatic()
    local static = GameObject.Find("StaticTransferArea")
    if static == nil then
        return
    end
    local trans = {}
    local len = static.transform.childCount
    for i = 1, len do
        local point_area = static.transform:GetChild(i - 1).transform
        local npcPos = point_area.position
        trans[i] = {}
        trans[i]["position"] = npcPos
    end
    local avatars = util:getInstance():getAllAvatar()
    local _ava = {}
    --只传送自己
    for k, v in pairs(avatars) do
        if (App.Uuid == v:GetProperty("uuid")) then
            table.insert(_ava, v)
        end
    end
    for i, v in pairs(_ava) do
        -- print("----------------")
        -- print(v.VisElement.gameObject.name) 
        local pos = trans[i]["position"]
        v.Local:SendTeleportPosition(pos)
        -- print("----------------")
    end
end
--召唤
function TransferArea:transLate()
    --local avatars = util:getInstance():getAllAvatar()
    local trans = self:getPlayersTransformParam()
    return trans
end
--[[function TransferArea:transLate()
    local avatars = util:getInstance():getAllAvatar()
    local trans = self:getPlayersTransformParam()
    local _ava = {}
    for k, v in pairs(avatars) do
        if (App.Uuid ~= v:GetProperty("uuid")) then
            -- local online = v:GetProperty('IsOnline')
            -- if online == "true" or online == nil then 
            --     table.insert(_ava, v)
            -- end
            table.insert(_ava, v)

        end
    end

    for i, v in pairs(_ava) do
        -- print("----------------")
        -- v.Local:SendMoveToTarget(self.role.transform.position)
        if trans[i]~=nil then
                --v:SetLockTransform(true)
                v.Local:SendTeleportPosition(trans[i]["position"])
                v.Local:SendRotation(trans[i]["rotation"])
        end
        -- print("----------------")
    end
end]]
---释放，自由活动
function TransferArea:release()
    local avatars = util:getInstance():getAllAvatar()
    -- local _ava = {}
    -- for k, v in pairs(avatars) do
    --     if (App.Uuid ~= v:GetProperty("uuid")) then
    --         table.insert(_ava, v)
    --     end
    -- end
    for i, v in pairs(avatars) do
        -- print("----------------")
        v:SetLockTransform(false)
        -- print("----------------")
    end
end
function TransferArea:getNpcs()
    return self.npcs
end

-- 显隐控制
function TransferArea:showHide()
    if self.TransferArea then
        -- print("self.TransferArea.gameObject.activeInHierarchy", self.TransferArea.gameObject.activeInHierarchy)
        if self.TransferArea.activeInHierarchy then
            self:hideTransferArea()
        else
            self:showTransferArea()
        end
    end
end

-- 显隐控制
function TransferArea:show()
    if self.TransferArea then
        self:showTransferArea()
    end
end

-- 显隐控制
function TransferArea:hide()
    if self.TransferArea then
        self:hideTransferArea()
    end
end

function TransferArea:showTransferArea()
    if self.TransferArea then
        self.TransferArea:SetActive(true)
    end
end

function TransferArea:hideTransferArea()
    if self.TransferArea then
        self.TransferArea:SetActive(false)
    end
end

return TransferArea
