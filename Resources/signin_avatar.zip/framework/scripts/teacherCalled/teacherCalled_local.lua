local class = require("middleclass")
---@type LocalScript
local LocalScript = require("mworld/localscript")
local teacherService = require(MAIN_SCRIPTS_LOC..'teacherCalled/teacherCalled_service')
---@class Local: LocalScript
local TeacherLocal = class("Local", LocalScript)
local EventSubscribe = require("event_subscribe")
local json = require("nextjson")
local cs_coroutine = require "common/cs_coroutine"

local ZHAOJIGENSUI = 100002
local RESUMESTATE = 333--状态恢复
local UPDATESTATE = 444--状态更新
function TeacherLocal:initialize(element, script)
    TeacherLocal.super.initialize(self, element, script)
    self.teacherService = App.Services["TeacherCalledService"] or App:RegisterService("TeacherCalledService",  teacherService:new())
    
    element.OnJoinedBlock:connect(function(block) 
        --学生以老师的来恢复
        if App.Info.role ~= 0 and block.Index ~= App.Info.selfBlockIndex then
            debug_print("liulin===1 判断恢复",element.Block.Index)
            self:resumeFollow()
        end

        --老师以自己的来恢复
        if App.Info.role == 0 and block.Index == App.Info.selfBlockIndex then
            debug_print("liulin===2 判断恢复",element.Block.Index)
            self:resumeFollow()
        end
    end)
end

function TeacherLocal:resumeFollow()

    if self.notFirst == true then
        return
    end
    
    self.notFirst = true
    
    --重进恢复
    local curStatusMsg = self.Element:GetProperty("status")--获取远端状态

    if curStatusMsg ~= nil and curStatusMsg ~= "" then
        self.curStatus = json.decode(curStatusMsg)
    end
    --self.curStatus =json.decode(self.Element:GetProperty("status"))--获取远端状态
    if App.Info.role == 0 then
        --老师恢复
        local type = 0
        if self.curStatus  and self.curStatus.status == "zhaoji" then
            type = 1
        end
        local statusService = App:GetService("StatusManagerService")
        if statusService then
            statusService:setStatus(ZHAOJIGENSUI,type)
        end
    else
        --学生恢复
        local message_ = {}
        if self.curStatus then
            message_ = {code = RESUMESTATE,status = self.curStatus.status,trans = self.curStatus.trans}
        else
            message_ = {code = RESUMESTATE,status = self.curStatus}
        end
        cs_coroutine.start(function()
            coroutine.yield(CS.UnityEngine.WaitForSeconds(3))
            print("liulin--发出恢复指令",table.dump(message_))
            self.teacherService:CurrentStatus(message_)--发出去
        end)
    end

    --状态更新
    self.Element.OnPropertyChanged:connect(function(k,v)
        if k == "status" then
            debug_print("liulinJson2--")
            local msg = json.decode(v)
            debug_print("liulinJson3--",table.dump(msg))
            --local msss = json.decode(msg.transMsg)
            --debug_print("liulinJson4--",table.dump(msss))
            --local msss1 = json.decode(msss[1].position)
            --debug_print("liulinJson5--",table.dump(msss1))
            local message_ = {code = UPDATESTATE,status = msg.status,trans = msg.transMsg}
            self.teacherService:CurrentStatus(message_)
        end
    end)
    ----接受发送
    self.teacherService.msg_send:connect(function(msg)
        self:send(msg)
    end)
end

function TeacherLocal:send(msg)
    self:SendToServer(msg)
end

-----@param action table
--function TeacherLocal:OnServerCall(action)
--    self.teacherService:recv(action)
--end

return TeacherLocal
