local class = require('middleclass')
local Service = require("app/service")
local EventSubscribe = require("event_subscribe")
local TeacherService = class("TeacherService", Service)
local Vector3      = CS.UnityEngine.Vector3
local json = require("nextjson")
local RESUMESTATE = 333--状态恢复
local UPDATESTATE = 444--状态更新
local conveneController = require(MAIN_SCRIPTS_LOC.."teacherCalled/conveneController")
local followController = require(MAIN_SCRIPTS_LOC.."follow/follow_controller")
local commonMenu = require(MAIN_SCRIPTS_LOC.."commonMenu_panel")
local explainSyncCamera = require(MAIN_SCRIPTS_LOC..'explainMode/explainSyncCamera')
local cs_coroutine = require("common/cs_coroutine")
local waitForEndOfFrame = CS.UnityEngine.WaitForEndOfFrame()

function TeacherService:initialize()
    self.msg_recv = EventSubscribe:new()
    self.msg_send = EventSubscribe:new()
    self.currentStatus = EventSubscribe:new()
    self.currentStatusTofollow = EventSubscribe:new()--跟随用
    self.teach_mode = EventSubscribe:new()--讲解模式回调
    --self.conveneController = conveneController:new(self)
    self.recordAudio = EventSubscribe:new()--录音事件
    self.curStatus = false --true:召集中，false，解散
end

--init
function TeacherService:initSetting()
    self.conveneController = conveneController:new(self)
    self.explainSyncCamera = explainSyncCamera:new(self)
end

function TeacherService:initFollowSetting()
    debug_print("follow---开始初始化")
    self:initCommonMenuPanel()
    self:initFollowController()
end

function TeacherService:initFollowController()
    if self.followController == nil then
        --传入出生地sceneId
        self.followController = followController:new(100001)

        --跟随停止 UI按钮状态恢复
        self.followController.followDidStop = function()
            self.commonMenu:switchFollowBtn(false)
        end

        --跟随被禁用 UI按钮置灰
        self.followController.DidInterrupt = function(isBreak,shouldResume)
            if self.commonMenu.followBtn then
                self.commonMenu.followBtn.interactable = (not isBreak)
                if shouldResume then
                    self.commonMenu:switchFollowBtn(true)
                end
            end
        end
        --禁言讲台  按钮禁用
        self.followController.joinLecture = function(isLecture)
            self.commonMenu.followBtn.interactable = (not isLecture)
        end
    end
end
-- 判断当前是跟随状态
function TeacherService:isFollowTeacher()
    if self.followController  then
        return self.followController.isFollowTeacher
    end
    return false  
end 
-- 场景切换时 取消跟随状态 
function TeacherService:needRelaseFollowStatus()
    if self:isFollowTeacher() then 
     self.commonMenu:updateFollowBtn(false)
    end 
end  

function TeacherService:initCommonMenuPanel()

    if App.Info.role == 0 then
        return
    end

    self.commonMenu = commonMenu:new(self)

    self.commonMenu.followSelected = function(isOn)
        debug_print('#####跟随')

        ---- 设置学生跟随音乐
        --self.avatar:setTeacherAudio()

        -- 处理跟随 还是取消跟随
        self.followController:followTeacherIfNeeded()
    end
end

function TeacherService:createTeacherElement()
    --local WorldService = App:GetService("WorldService")
    --local gate = WorldService.Gate
    --
    --local teacherCalled_lecture = import("teacherCalled_lecture")
    --gate:AddElementType("TeacherCalledElement", teacherCalled_lecture)
    --
    --if App.IsServer then
    --    local dict = CS.Tal.CourseEnv.MWorld.UProperty();
    --    dict:Add("type","TeacherCalledElement")
    --    self.teacherCalledElement = gate.State:CreateElementWithProperties(110011, dict, Vector3.zero, Vector3.one, Vector3.zero)
    --end
end
function TeacherService:CurrentStatus(msg)
    self.curStatus = msg.status == "zhaoji"
    if msg.code == RESUMESTATE then
        --self.currentStatus(true)
        if msg.status ~= ""then
            --self.currentStatus(curStatus)
            self.currentStatusTofollow(self.curStatus)
        end
    else
        self.currentStatus(self.curStatus)
        self.currentStatusTofollow(self.curStatus)
        debug_print("liulin--发出恢复指令0",self.curStatus)
    end
    debug_print("liulin--发出恢复指令1",table.dump(msg))

    self.msg_recv(msg)--展示UI
end
function TeacherService:send(msg)
    self.msg_send(msg)
end

function TeacherService:recv(msg)
    self.msg_recv(msg)
end

function TeacherService:TeachMode(msg)
    self.teach_mode(msg)
end

function TeacherService:Exit()
    if self.followController then
        self.followController:onExit()
    end

    if self.menuPanel then
        self.menuPanel:Hide()
        self.menuPanel = nil
    end
    if self.conveneController then
        self.conveneController:onExit()
    end
end

function TeacherService:changeSceneAndPosition()
    self.walkCoroutine = cs_coroutine.start(function()
        while true  do
            coroutine.yield(waitForEndOfFrame)
            if self.conveneController then
                self.conveneController:changeScenceAndPosition({status = ""})
                break
            end
        end
        cs_coroutine.stop(self.walkCoroutine)
        self.walkCoroutine = nil
    end)
end
--给业务用，取消主动跟随
function TeacherService:stopFollow()
    if self.followController and self.curStatus == false then
        self.followController:stop()
    end
end

return TeacherService


