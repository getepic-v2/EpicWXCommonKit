# 场景切换文档2.0

## 1. 配置文件

###场景配置文件示例
```
[
  {
    "id": 100001,
    "scene_type": 1,                        
    "scene_name": "birthplace",             
    "scene_describe": "集合地（默认场景）",
    "scene_name_cn": "集合地",               --场景中文名用于切场景toast提示
    "scene_additive_list": "birthplace",    --要加载的场景名,不加载此场景要设为-1或"",多个场景用"|"连接
    "use_mod_prepath": 0,                   --是否使用mod拼接路径(一般用不到)
    "scene_model_prepath": "modules/birthplace/assets/scenes/", --场景路径
    "scene_priority": 1,                    --场景优先级,越大代表优先级越高
    "skip_load": 1,                         --不加载场景(0:表示加载 1:表示不加载)
    "skybox_path": "modules/birthplace/assets/sky_box/sky.mat" --天空盒路径,用于动态切换天空盒
  }
]
```

###传送门配置文件示例
```
[
  {
    "id": 1,
    "name": "portal",        --传送门名称
    "describe": "集合地传送门",
    "sceneId": 100001,        --传送门所在的场景id
    "to_sceneId": 100002,     --传送门传送到的场景id
    "to_position": "0,0,0",   --传送门传送到的位置,用逗号分隔(与spawn_transform互斥)
    "spawn_transform": "1.40,1.51,-4.429|0,0,0|1,1,1",--传送门传送到的位置/角度/缩放
	"portal_transform": "-5.73,0.12,1.55|0,0,0|1,1,1"--传送门所在的位置/角度/缩放
  }
]
```

## 2. 各文件说明
```
scene_config:用于解析场景的配置文件
scene_controller:场景控制器,用于切换场景
scene_enum:场景相关的枚举
scene_explorer:切换场景,包括修改avatar的sceneId和position,切场景会调用scene_controller
scene_portal:传送门,会给avatar添加碰撞监听
scene_portal_config:传送门配置文件
scene_queue:场景队列
scene_service:切场景服务,通常情况下只需要关心这个类就可以了
skybox_manager:天空盒控制,可根据不同场景切换,以及环境光和雾
```

## 3. 使用示例

####切场景
```
--加载场景数据
local sceneService = App:GetService("SceneService")
local scenePath = "modules/dynasty/config/scene_info.json"
sceneService:FillData(avatar, scenePath)

--切场景回调通知,所有的切场景都会回调这个通知
sceneService.OnSwitchSceneComplete:connect(function(sceneId, resultState)
    debug_print("scene load result: ",sceneId, resultState)
end)

--启动加载场景(这个方法会先获取avatar的场景id, 100001表示默认场景, 不显示加载loading)
sceneService:LaunchLoadScene(100001, function(sceneId, resultState)
    if resultState == SCENE_ENUM.RESULT.SUCCEED then
        self:SwitchSceneComplete(sceneId)
    end
end)

--通用加载场景(会显示场景加载loading) position为空则不修改avatar位置
sceneService:SwitchScene(100002, position, function(sceneId, resultState)
    if resultState == SCENE_ENUM.RESULT.SUCCEED then
        self:SwitchSceneComplete(sceneId)
    else
        debug_print("scene load failed: ",sceneId, resultState)
    end
end)

--通用加载场景(不显示场景加载loading) position为空则不修改avatar位置
sceneService:SwitchSceneNoLoading(100002, position, function(sceneId, resultState)
    if resultState == SCENE_ENUM.RESULT.SUCCEED then
        self:SwitchSceneComplete(sceneId)
    else
        debug_print("scene load failed: ",sceneId, resultState)
    end
end)
```

####传送门

```
--加载传送门数据(function是碰撞切场景的回调)
local portalPath = "modules/dynasty/config/scene_portal.json"
sceneService:AddScenePortalByPath(portalPath, function(sceneId, resultState)
    --加载成功
    if resultState == SCENE_ENUM.RESULT.SUCCEED then
        self:SwitchSceneComplete(sceneId)
    end
end)


--隐藏指定场景的传送门
sceneService:UpdatePortalEnabled(100001, false)

```


