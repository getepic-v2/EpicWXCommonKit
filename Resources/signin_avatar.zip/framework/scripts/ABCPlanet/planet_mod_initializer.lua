---@class PlanetModInitializer
local PlanetModInitializer = {
    ---@type Vector3
    BirthPlacePosition = Vector3.zero
}

---@type function?(initFinishCallback: function)
local initializer = nil
---@type boolean
local _startFinish = false

---@param callback function
function PlanetModInitializer.Init(callback)
    initializer = callback
    if _startFinish then
        g_LogError("Init callback already called")
    end
end

---@return boolean
function PlanetModInitializer.CheckIsInit()
    return initializer ~= nil
end

---@param initFinishCallback function
function PlanetModInitializer.Start(initFinishCallback)
    _startFinish = true
    if initializer then
        initializer(initFinishCallback)
    else
        initFinishCallback()
    end
end

return PlanetModInitializer