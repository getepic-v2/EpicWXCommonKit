---
---  Author: 【荣雷】
---  AuthorID: 【189966】
---  CreateTime: 【2022-10-17 12:04:42】
--- 【FSync】
--- 【任务区集合v2.0】
---

local class = require("middleclass")
local cs_coroutine = require("common/cs_coroutine")

local TaskUILogic = class("TaskUILogic")

local TaskState = {
    Init = 0,     --未显示
    Doing = 1,    --进行中
    Success = 2   --成功
}

function TaskUILogic:initialize()
    --TaskUILogic.super.initialize(self, worldElement)

    self.haveInit = false
    self.haveInitFinish = false
    self.needRecover = false;
    self.needTriggerInterfaceID = {};
    self.uiObject = {}
    self.dataSource = {}
    self.subtaskState = {}
    self.currentGuideIndex = 0
    self.taskState = { isShow = 0 ,isExpand = 1,taskID = ""}

    self.normalColor = CS.UnityEngine.Color(1, 1, 1, 1)
    self.doingColor = CS.UnityEngine.Color(214/255, 250/255, 5/255, 1)
    self.failedColor = CS.UnityEngine.Color(162/255, 212/255, 248/255, 1)

    --self.subscribeKey = self.class.name.."_"..App.Uuid.."_task_area"
    --self:SubscribeMsgKey(self.subscribeKey)
    ----订阅key
    self.subscribeKey = self.class.name.."_"..App.Uuid.."_task_UILogic";
    App:GetService("DataCenterService"):AddKey(self.subscribeKey);
    App:GetService("DataCenterService"):Register(self.subscribeKey, function(key, json_data, isResume)
        -- g_LogColorMsg("TaskUILogic recive -- key: "..key .. " " .. table.dump(json_data));
        self:ReceiveMessage(key,json_data,isResume);
    end);

end
-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function TaskUILogic:ReceiveMessage(key, jsonValue, isResume)
    if not key == self.subscribeKey then
        return
    end

    if isResume == false then
        return;
    end
    --self:lazyInit()
    local taskState = jsonValue;
    print("TaskNode--ReceiveMessage Resume", table.dump(taskState))

    if(taskState.isShow ~= 1)then --不显示
        print("TaskNode-- 不是正在运行的任务，不进行恢复")
        return;
    end 
    
    --self.taskState = taskState
    --self.dataSource = taskState["subtask"]

    -- g_Log("TaskNode TaskUILogic sourceData 1 " .. table.dump(taskState));
    -- g_Log("TaskNode TaskUILogic sourceData 2 " .. table.dump(taskState["subtask"]));
    --return;
    
    if(self.haveInitFinish == false)then
        -- g_Log("TaskNode 收到恢复消息 但是UI还没有初始化");
        self.needRecover = true;
        local taskNode = App:GetService("BlueprintService"):GetNodeByID(taskState.taskID);
        if(taskNode ~= nil)then
            
            self:Init(taskNode.nodeData, function()

                -- g_Log("TaskNode TaskUILogic sourceData 3 " .. table.dump(taskState));
                -- g_Log("TaskNode TaskUILogic sourceData 4 " .. table.dump(taskState["subtask"]));
                self.taskState = taskState
                self.dataSource = taskState["subtask"]
                -- g_Log("TaskNode TaskUILogic Init cb1 " .. table.dump(self.taskState));
                -- g_Log("TaskNode TaskUILogic Init cb2 " .. table.dump(self.dataSource));
                self:Recover();
            end)
        end
    else
        self.taskState = taskState
        self.dataSource = taskState["subtask"]
        -- g_Log("TaskNode 收到恢复消息 UI进行恢复");
        self:Recover();
    end

    --local jsonValue = value[#value]
    --local taskState = CourseEnv.ServicesManager:GetJsonService():decode(jsonValue)
    --local taskState = jsonValue
    --print("TaskNode--ReceiveMessage No Resume", table.dump(taskState))
end

function TaskUILogic:Recover()
    if self.taskState.isShow == 1 then
        if self.taskState.isExpand == 1 then
            --    self.taskPanelGo:SetActive(true)
            --    self.taskButtonGo:SetActive(false)
            self.taskPanelGo:SetActive(true)
            self.taskButtonGo:SetActive(false)
        else
            self.taskPanelGo:SetActive(false)
            self.taskButtonGo:SetActive(true)
        end
    else
        self.taskPanelGo:SetActive(false)
        self.taskButtonGo:SetActive(false)
    end

    for i = 1, #self.dataSource do
        self:UpdateTask(i)
    end
end
function TaskUILogic:Init(taskData, cb)
    if not self.haveInit then
        --self.haveInit = true
        if(self.taskUI == nil)then
            local taskUIAssetPath = "modules/"..RESOURCE_LOC.."/assets/task_ui/Prefabs/TaskPanelv21.prefab";
            local that = self;
            --加载预制体
            self:LoadPrefabPath(taskUIAssetPath, function(gameObj)
                -- g_Log("TaskNode TaskUILogic LoadPrefabPath");
                local parent = GameObject.Find("Workspace");
                gameObj.transform:SetParent(parent.transform);
                that.taskUI = gameObj.transform;
                ----初始化
                that:prepareData(taskData)
                that:initializeUIObj();
                that:initializeUI()
                
                self.haveInit = true
                self.haveInitFinish = true
                if(self.needTriggerInterfaceID ~= nil)then
                    for id,v in pairs(self.needTriggerInterfaceID) do
                        self:OnReceiveTriggerEvent(v)
                    end
                    self.needTriggerInterfaceID = {};
                end
                -- g_Log("TaskNode TaskUILogic cb:" .. tostring(cb));
                if(cb~=nil)then
                    cb();
                end
            end)
        else
            self.haveInit = true
        end
    else
        -- g_Log("TaskNode Init 00");
        ----初始化
        self:prepareData(taskData)
        -- g_Log("TaskNode Init 11");
        self:initializeUI()
        self:resetAllTaskState();
        -- g_Log("TaskNode Init 22");
    end
end
----有数据需要进行恢复
--if(self.needRecover)then
--    g_Log("TaskNode UI加载完毕 进行恢复");
--    self:Recover();
--end
--解析数据
function TaskUILogic:prepareData(taskData)
    -- g_Log("TaskNode TaskUILogic --prepareData: -00")
    self.leftMargin = 88
    self.order = 100
    self.topMargin =  92
    self.title = taskData.taskName or "未配置"
    self.canClick = taskData.canTaskClick;
    self.stateDisplay = false;
    self.taskID = taskData.guid;
    self.dataSource = taskData.subTasks;
    self.taskState.taskID = taskData.guid;
    -- g_Log("TaskNode TaskUILogic --prepareData: -11")

    for i = 1, #self.dataSource do
        local data = self.dataSource[i]

        data.state = TaskState.Init
        data.originIndex = i
    end

    -- g_Log("TaskNode TaskUILogic --prepareData:",table.dump(self.dataSource))

    
end
function TaskUILogic:resetAllTaskState()
    if(self.needRecover == true)then
        --需要恢复，不能重置状态
        -- g_Log("TaskNode resetAllTaskState 需要恢复，不能重置状态");
        return;
    end
    for i = 1, #self.dataSource do
        local data = self.dataSource[i]

        if self.stateDisplay then
            data.state = TaskState.Doing
        else
            data.state = TaskState.Init
        end

        self:UpdateTask(i)
    end

    --self:SendCustomMessage(self.subscribeKey, self.taskState)
    App:GetService("DataCenterService"):SetData(self.subscribeKey, self.taskState);
end
function TaskUILogic:Exit()
    if(self.taskUI)then
        GameObject.Destroy(self.taskUI.gameObject)
    end
end
---加载预制体
---@param assetPath string 预制体路径
function TaskUILogic:LoadPrefabPath(assetPath,callback)
    ResourceManager:LoadGameObjectWithExName(assetPath, function(asset)
        ---@type GameObject
        local go = GameObject.Instantiate(asset)
        go.name = "TaskPanelv21"
        go.transform.localRotation = Quaternion.identity
        go.transform.localPosition = Vector3.zero
        go.transform.localScale = Vector3.one

        if callback then
            callback(go)
        end
    end)
end

function TaskUILogic:initializeUIObj()
    if(self.taskUI == nil)then
        local obj = GameObject.Find("Workspace/TaskPanelv21");
        self.taskUI = obj.transform;
    end
    self.panelTransform = self.taskUI;

    self.onelineTaskPrefab = self.panelTransform:Find("onelinetask").gameObject
    self.mutlineTaskPrefab = self.panelTransform:Find("mutlinetask").gameObject

    self.doingSprite = self.panelTransform:Find("doingimage").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.timingSprite = self.panelTransform:Find("timingimage").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.timeoutSprite = self.panelTransform:Find("timeoutimage").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.normalSprite = self.onelineTaskPrefab.transform:Find("image").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.successSprite = self.panelTransform:Find("successimage").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.failedSprite = self.panelTransform:Find("failedimage").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite

    self.lineTextGo = self.panelTransform:Find("text").gameObject

    self.taskButtonGo = self.panelTransform:Find("expand").gameObject

    self.taskPanelGo = self.panelTransform:Find("panel").gameObject

    self.compressButton = self.taskPanelGo.transform:Find("button").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))

    self.containerGo = self.taskPanelGo.transform:Find("container").gameObject
    self.taskTitleGo = self.taskPanelGo.transform:Find("title").gameObject
    self.taskTitleText = self.taskTitleGo:GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.taskFailedGo = self.taskPanelGo.transform:Find("falimage").gameObject
    self.taskSuccessGo = self.taskPanelGo.transform:Find("sucimage").gameObject

    self.viewportGo = self.containerGo.transform:Find("viewport").gameObject

    self.contentGo = self.containerGo.transform:Find("viewport/content").gameObject

    self.taskButton = self.taskButtonGo:GetComponent(typeof(CS.UnityEngine.UI.Button))
    App:GetService("CommonService"):AddEventListener(self.taskButton,"onClick",function()
        self.taskState.isExpand = 1
        self.taskPanelGo:SetActive(true)
        self.taskButtonGo:SetActive(false)
        --todo 数据恢复
        --self:SendCustomMessage(self.subscribeKey, self.taskState)
        App:GetService("DataCenterService"):SetData(self.subscribeKey, self.taskState);
    end)
end
function TaskUILogic:initializeUI()
    if(self.taskUI == nil)then
        local obj = GameObject.Find("Workspace/TaskPanelv21");
        self.taskUI = obj.transform;
    end
    self.panelTransform = self.taskUI;

    self.assetGo = self.taskUI.gameObject
    self.assetGo:GetComponent(typeof(CS.UnityEngine.Canvas)).sortingOrder = self.order;


    local transform = self.taskButtonGo.transform
    transform:SetInsetAndSizeFromParentEdge(CS.UnityEngine.RectTransform.Edge.Left, self.leftMargin, 72)
    transform:SetInsetAndSizeFromParentEdge(CS.UnityEngine.RectTransform.Edge.Top, self.topMargin+20, 60)

    
    transform = self.taskPanelGo.transform
    transform:SetInsetAndSizeFromParentEdge(CS.UnityEngine.RectTransform.Edge.Left, self.leftMargin, 464)
    transform:SetInsetAndSizeFromParentEdge(CS.UnityEngine.RectTransform.Edge.Top, self.topMargin, 242)


    App:GetService("CommonService"):AddEventListener(self.compressButton,"onClick",function()
        self.taskState.isExpand = 0
        self.taskPanelGo:SetActive(false)
        self.taskButtonGo:SetActive(true)
        --todo 数据恢复
        --self:SendCustomMessage(self.subscribeKey, self.taskState)
        App:GetService("DataCenterService"):SetData(self.subscribeKey, self.taskState);
    end)


    transform = self.viewportGo.transform
    transform:SetInsetAndSizeFromParentEdge(CS.UnityEngine.RectTransform.Edge.Left, 24, 392)
    transform:SetInsetAndSizeFromParentEdge(CS.UnityEngine.RectTransform.Edge.Top, 74, 168)


    local layoutGroup = self.contentGo:GetComponent(typeof(CS.UnityEngine.UI.LayoutGroup))
    layoutGroup.spacing = 22
    layoutGroup.padding.top = 20
    layoutGroup.padding.bottom = 20

    self.taskTitleText.text = self.title

    --销毁
    for i = 1, #self.uiObject do
        GameObject.Destroy(self.uiObject[i]);
    end
    self.uiObject = {};
    for i = 1, #self.dataSource do
        local data = self.dataSource[i]

        --local lineTextGo = GameObject.Instantiate(self.lineTextGo)
        --local lineText = lineTextGo:GetComponent(typeof(CS.UnityEngine.UI.Text))

        --lineText.text = data.name


        local taskGo = nil
        --local lineCount = lineText.cachedTextGenerator.lineCount
        --print("ronglei--",tostring(lineCount),lineText.text,data.name)
        if #data.name > 14 then
            taskGo = GameObject.Instantiate(self.mutlineTaskPrefab)
        else
            taskGo = GameObject.Instantiate(self.onelineTaskPrefab)
        end

        local taskText = taskGo.transform:Find("text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
        local taskImage = taskGo.transform:Find("image").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
        taskText.text = data.name

        if self.stateDisplay then
            taskText.color = self.doingColor
            taskImage.sprite = self.doingSprite
            data.state = TaskState.Doing
        else
            taskText.color = self.normalColor
            taskImage.sprite = self.normalSprite
            data.state = TaskState.Init
        end


        taskGo.transform:SetParent(self.contentGo.transform)
        taskGo.transform.localScale = Vector3.one
        taskGo.transform.localPosition = Vector3(0,0,0)

        if data.name == "" or data.name == nil then
            taskGo:SetActive(false)
        end

        if self.canClick then
            local button = taskGo:GetComponent(typeof(CS.UnityEngine.UI.Button))
            App:GetService("CommonService"):AddEventListener(button,"onClick",function()
                local data = self.dataSource[i]
                -- 成功的任务不可点击
                if data.state ~= TaskState.Success then
                    --todo 点击子任务
                    --self:Trigger("taskClick_"..i)
                    --g_Log("TaskArea2:", self.class.name)
                    --g_Log("TaskArea2--trigger:taskClick_"..i)
                end
            end)
        else
            taskGo.transform:Find("layout_r/icon").gameObject:SetActive(false)
        end
        taskGo.transform:Find("layout_r/icon").gameObject:SetActive(false)
        self.uiObject[i] = taskGo
        self.taskState["subtask"] = self.dataSource

        --cs_coroutine.start(function()
        --    coroutine.yield(CS.UnityEngine.WaitForEndOfFrame())
        --
        --    GameObject.Destroy(lineTextGo)
        --end)
    end

    self.taskPanelGo:SetActive(false)
    self.taskButtonGo:SetActive(false)
    g_Log("TaskUI init finish");
end


function TaskUILogic:refreshUIFromIndex(index)
    g_Log("TaskNode- refreshUIFromIndex: ".. tostring(index));
    for i = index, #self.dataSource do
        local data = self.dataSource[i]
        local object = self.uiObject[data.originIndex]
        object.transform:SetParent(nil)

        local title = ""
        local color = nil
        local sprite = nil

        if data.state == TaskState.Init then
            sprite = self.normalSprite
            color = self.normalColor
            title = data.name
        elseif data.state == TaskState.Doing then
            sprite = self.doingSprite
            color = self.doingColor
            title = data.name
        elseif data.state == TaskState.Success then
            sprite = self.successSprite
            color = self.normalColor
            title = data.name
        end

        if self.canClick then
            if data.state == TaskState.Success then
                object.transform:Find("layout_r/icon").gameObject:SetActive(false)
            end
        end
        object.transform:Find("layout_r/icon").gameObject:SetActive(false)
        object.transform:Find("text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text)).text = title
        object.transform:Find("text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text)).color = color
        object.transform:Find("image").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite = sprite
        object.transform:SetParent(self.contentGo.transform)
        object.transform.localScale = Vector3.one
        object.transform.localPosition = Vector3(0,0,0)
    end
end

--收到Trigger事件
function TaskUILogic:OnReceiveTriggerEvent(interfaceId)
    if(self.haveInitFinish == false)then
        table.insert(self.needTriggerInterfaceID, interfaceId);
        g_Log("TaskNode- 收到trigger:"..interfaceId.. ", 但是尚未初始化完毕");
        return;
    end
    --if(self.needTriggerInterfaceID~=nil and  (#self.needTriggerInterfaceID) > 0)then
    --    g_Log("TaskNode- 有前置的事件没有触发 需要排队:"..interfaceId);
    --    table.insert(self.needTriggerInterfaceID, interfaceId);
    --    return;
    --end
    g_Log("TaskNode--Start Trigger:", interfaceId)
    if interfaceId == "task_in" then
        self.taskState.isShow = 1
        self:resetAllTaskState(); --重置任务状态
        if self.taskState.isExpand == 1 then
            --g_Log("TaskNode-- "..tostring(self))
            --g_Log("TaskNode-- "..tostring(self.taskUI))
            if(self.taskPanelGo == nil)then
                self.taskPanelGo = self.taskUI:Find("panel").gameObject
            end
            self.taskPanelGo:SetActive(true)
            self.taskButtonGo:SetActive(false)
        else
            self.taskPanelGo:SetActive(false)
            self.taskButtonGo:SetActive(true)
        end
        App:GetService("DataCenterService"):SetData(self.subscribeKey, self.taskState);

        -- self:TriggerFirstUnfinishedTask()
    elseif interfaceId == "task_out" then
        self.taskState.isShow = 0

        self.taskPanelGo:SetActive(false)
        self.taskButtonGo:SetActive(false)
        
        App:GetService("DataCenterService"):SetData(self.subscribeKey, self.taskState);
    else

        for i = 1, #self.dataSource do
            local doingKey  = "subtask_start_"
            local finishKey = "subtask_end_"
            local name = self.dataSource[i].name
            --g_Log("TaskNode- " ..string.sub(interfaceId,1,string.len(doingKey)));
            if string.sub(interfaceId,1,string.len(doingKey)) == doingKey then
                -- 任务进行中
                local key = doingKey..tostring(i)
                if interfaceId == key then
                    --实时触发的trigger需要检测任务是否全部完成然后再去trigger出去

                    local data = self.dataSource[i]
                    if data.state == TaskState.Doing then
                        return
                    end

                    data.state = TaskState.Doing
                    self:UpdateTask(i)
                    --todo 不需要了
                    --self:Trigger("taskBegin_"..i)
                    --修改后进行存储
                    self.taskState["subtask"] = self.dataSource
                    -- g_Log("TaskNode save 01: " .. table.dump(self.taskState["subtask"]));
                    App:GetService("DataCenterService"):SetData(self.subscribeKey, self.taskState);


                    local value = {}
                    value["name"] = name
                    value["index"] = tostring(i)
                    NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("task_area","26758","任务完成","任务区","1",value)

                    break
                end
            elseif string.sub(interfaceId,1,string.len(finishKey)) == finishKey then
                -- 任务完成
                local key = finishKey..tostring(i)
                if interfaceId == key then
                    --实时触发的trigger需要检测任务是否全部完成然后再去trigger出去

                    local data = self.dataSource[i]
                    if data.state == TaskState.Success then
                        return
                    end

                    data.state = TaskState.Success
                    self:UpdateTask(i)
                    
                    --todo 不需要了
                    --self:Trigger("taskFinish_"..i)
                    --修改后进行存储
                    self.taskState["subtask"] = self.dataSource
                    -- g_Log("TaskNode save 02: " .. table.dump(self.taskState["subtask"]));
                    App:GetService("DataCenterService"):SetData(self.subscribeKey, self.taskState);
                    
                    local value = {}
                    value["name"] = name
                    value["index"] = tostring(i)
                    NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("task_area","26758","任务完成","任务区","2",value)

                    local allComplete = true
                    for j = 1, #self.dataSource do
                        local data = self.dataSource[j]
                        if data.state ~= TaskState.Success then
                            allComplete = false
                            break
                        end
                    end

                    if allComplete then
                        --不需要了
                        --self:Trigger("taskAllComplete")
                        -- g_Log("TaskNode2:", self.class.name)
                        -- g_Log("TaskNode2--trigger:taskAllComplete")
                        return
                    end
                    -- self:GuideNextTask()
                    break
                end
            end
            
        end
    end
end

function TaskUILogic:GuideNextTask()
    for i = 1, #self.dataSource do
        local data = self.dataSource[i]
        if data.state ~= TaskState.Success then
            -- 找到第一个状态是非成功的任务 改变成doing状态并且trigger taskGuide
            if data.state == TaskState.Init then
                data.state = TaskState.Doing
                self:UpdateTask(i)

                --todo 需要调试
                --self:Trigger("taskBegin_"..i)
                -- g_Log("TaskNode2:", self.class.name)
                -- g_Log("TaskNode2--trigger:taskBegin_"..i)

                local value = {}
                value["name"] = data.name or ""
                value["index"] = tostring(i)
                NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("task_area","28145","任务进行","任务区","1",value)
            end
            self.currentGuideIndex = i
            --todo 需要调试
            --self:Trigger("taskGuide_"..i)
            -- g_Log("TaskNode2:", self.class.name)
            -- g_Log("TaskNode2--trigger:taskGuide_"..i)

            break
        end
    end
end

function TaskUILogic:TriggerFirstUnfinishedTask()
    local guideIndex = 0
    for i = 1, #self.dataSource do

        local data = self.dataSource[i]
        if data.state ~= TaskState.Success then
            if guideIndex == 0 then
                guideIndex = i
            end
        end

        if guideIndex == i then
            -- 找到第一个状态是非成功的任务 改变成doing状态并且trigger taskGuide
            if data.state == TaskState.Init then
                data.state = TaskState.Doing
                self:UpdateTask(i)
            end
            self.currentGuideIndex = i
            --todo 需要调试
            --self:Trigger("taskBegin_"..i)
            --self:Trigger("taskGuide_"..i)

            -- g_Log("TaskNode2:", self.class.name)
            -- g_Log("TaskNode2--trigger:taskBegin_"..i)
            -- g_Log("TaskNode2--trigger:taskGuide_"..i)

            local value = {}
            value["name"] = data.name or ""
            value["index"] = tostring(i)
            NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("task_area","28145","任务进行","任务区","1",value)
        else
            if data.state == TaskState.Doing then
                --todo 需要调试
                --self:Trigger("taskBegin_"..i)

                -- g_Log("TaskNode2:", self.class.name)
                -- g_Log("TaskNode2--trigger:taskBegin_"..i)

                local value = {}
                value["name"] = data.name or ""
                value["index"] = tostring(i)
                NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam("task_area","28145","任务进行","任务区","1",value)
            end
        end
    end
end

function TaskUILogic:UpdateTask(index)
    g_Log("TaskNode- UpdateTask: ".. tostring(index));
    local data = self.dataSource[index]
    local taskGo = self.uiObject[index]

    local taskText = taskGo.transform:Find("text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
    local taskImage = taskGo.transform:Find("image").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))

    local title = ""
    local color = self.normalColor
    local sprite = self.normalSprite

    if data.state == TaskState.Init then
        title = data.name
        color = self.normalColor
        sprite = self.normalSprite
    elseif data.state == TaskState.Doing then
        title = data.name
        color = self.doingColor
        sprite = self.doingSprite
    elseif data.state == TaskState.Success then
        title = data.name
        color = self.normalColor
        sprite = self.successSprite
    end

    taskText.text = title
    taskText.color = color
    taskImage.sprite = sprite

    if self.canClick then
        local locationImage = taskGo.transform:Find("layout_r/icon").gameObject
        locationImage:SetActive(false)
        --if data.state == TaskState.Success then
        --    locationImage:SetActive(false)
        --else
        --    locationImage:SetActive(true)
        --end
    end

end

--收到GetData事件 
function TaskUILogic : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------
--
---- 发送KEY-VALUE 消息 
---- @param key自定义/协议key
---- @param body  table 消息体
--function TaskUILogic:SendCustomMessage(key, body)
--    self:SendMessage(key,body)
--end
--
---- 自己avatar对象创建完成
---- @param avatar对应自己的Fsync_avatar对象
--function TaskUILogic:SelfAvatarCreated(avatar)
--end
--
---- 自己avatar对象人物模型加载完成ba
---- @param avatar对应自己的Fsync_avatar对象
--function TaskUILogic:SelfAvatarPrefabLoaded(avatar)
--end
--
---- avatar对象创建完成，包含他人和自己
---- @param avatar对应自己的Fsync_avatar对象
--function TaskUILogic:AvatarCreated(avatar)
--end

------------------------蓝图组件相应方法---------------------------------------------
----是否是异步恢复如果是需要改成true
--function TaskUILogic:LogicMapIsAsyncRecorver()
--    return false
--end
----开始恢复方法（断线重连的时候用）
--function TaskUILogic:LogicMapStartRecover()
--    TaskUILogic.super:LogicMapStartRecover()
--    --TODO
--end
--
----结束恢复方法 (断线重连的时候用)
--function TaskUILogic:LogicMapEndRecover()
--    TaskUILogic.super:LogicMapEndRecover(self)
--    --TODO
--end
--
----所有的组件恢复完成
--function TaskUILogic:LogicMapAllComponentRecoverComplete()
--end
return TaskUILogic