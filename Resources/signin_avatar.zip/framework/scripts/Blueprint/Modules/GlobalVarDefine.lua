local GlobalVarDefine = {}

GlobalVarDefine.GlobalType = {
    Bool = 0,
    Number = 1
}

GlobalVarDefine.PurposeType = {
    Set = 0,
    Get = 1
}

GlobalVarDefine.SelectorOper = {
    jia = 0,
    jian = 1,
    cheng = 2,
    chu = 3,
    dengyu = 4,
    dayu = 5,
    xiaoyu = 6,
    dayudengyu = 7,
    xiaoyudengyu = 8
}

GlobalVarDefine.GetSelectorDesc = function(oper, isLeft)
    if (oper == GlobalVarDefine.SelectorOper.jia) then
        return "加"
    elseif (oper == GlobalVarDefine.SelectorOper.jian) then
        return "减"
    elseif (oper == GlobalVarDefine.SelectorOper.cheng) then
        return "乘"
    elseif (oper == GlobalVarDefine.SelectorOper.chu) then
        return "除"
    elseif (oper == GlobalVarDefine.SelectorOper.dengyu) then
        return "等于"
    elseif (oper == GlobalVarDefine.SelectorOper.xiaoyu) then
        return isLeft and "大于" or "小于"
    elseif (oper == GlobalVarDefine.SelectorOper.xiaoyudengyu) then
        return isLeft and "大于等于" or "小于等于"
    elseif (oper == GlobalVarDefine.SelectorOper.dayu) then
        return isLeft and "小于" or "大于"
    elseif (oper == GlobalVarDefine.SelectorOper.dayudengyu) then
        return isLeft and "小于等于" or "大于等于"
    end
end

return GlobalVarDefine
