
local class = require("middleclass")




local Avatar = require(MAIN_SCRIPTS_LOC.."avatar_ctrl")

local ENUM = require(MAIN_SCRIPTS_LOC.."avatar_control/avatar_consts")
local DiscussManager = require(MAIN_SCRIPTS_LOC.."avatar_control/avatar_discuss")
---@class NextAvatar : Avatar
local NextAvatar = class("NextAvatar ", Avatar)




---@param element  CS.Tal.CourseEnv.MWorld.MElement
function NextAvatar:initialize(element, callback, ctrlType, infoPath)
    NextAvatar.super.initialize(self,element,callback,ctrlType,infoPath)
end

function NextAvatar:CreateFirstPersonPart(name, posOffset,parent)
    ---@type CS.UnityEngine.GameObject
    local go = GameObject(name)
    go.transform:SetParent(parent)
    go.transform.localPosition = posOffset
    go.transform.localRotation = Quaternion.identity
    go.transform.localScale = Vector3.one
    return go
end


---加载avatar预制体
---@param assetPath string 预制体路径
---@param callback function 加载完成回调
function NextAvatar:LoadPrefabPath(assetPath, callback)
    ResourceManager:LoadGameObjectWithExName(assetPath, function(asset)
        local firstLoad = true

        if self.curAssetPath then
            --保存之前的动画数据
            self:SaveAnimationDataForKey(self.curAssetPath)
        end

        if self.character then
            firstLoad = false
            self.character:SetActive(false)
        end

        ---@type GameObject
        local go = self.characterTable[assetPath]
        if go == nil then
            go = GameObject.Instantiate(asset)
            go.name = "Character"
            go.transform:SetParent(self.Body.transform)
            go.transform.localRotation = Quaternion.identity
            go.transform.localPosition = Vector3.zero
            go.transform.localScale = Vector3.one
            self.characterTable[assetPath] = go
        else
            --删除之前的物体
            go:SetActive(true)
        end

        self.curAssetPath = assetPath

        ---@type CS.UnityEngine.GameObject
        self.character = go
        ---@type CS.UnityEngine.Animator
        self.Animator = go:GetComponent(typeof(CS.UnityEngine.Animator))

        --恢复之前的动画数据
        self:UpdateAnimationDataForKey(assetPath)

        if callback then
            callback(go)
        end
        --self:InitState()
        self:SetName(self:GetProperty("AvatarName"))

        if firstLoad then
            self.OnLoadAvatarComplete(self)
            self.FirstViewLookRotation = self:CreateFirstPersonPart("__FirstLookRotation",Vector3(0,2,1.4),self.character.transform)

            if self:GetProperty("uuid") == App.Uuid then
                local sceneAvatar = GameObject.Instantiate(asset)
                sceneAvatar.name = "sceneAvatar"
                sceneAvatar.transform.localScale = Vector3(0.001, 0.001, 0.001)
                if not App.IsServer then
                    self.DiscussManager = DiscussManager:new(self)
                end
            end
        end

        --资源加载通知(用于通知预制体换了)
        if self.OnReLoadAvatarComplete then
            self.OnReLoadAvatarComplete(firstLoad, go)
        end
    end)
end

function NextAvatar:Tick()
    ---@type CS.UnityEngine.CharacterController
    if App.IsServer then
        return
    end
    -----@type CS.UnityEngine.Animator
    local an = self.Animator
    local v = nil
    local speed = 0
    if self.ctrlType == ENUM.AVATAR_CTRL_TYPE.CHARACTER_CTRL_TYPE and self.characterCtrl then
        v = self.characterCtrl:GetVelocityV3()
        speed = 4
        self.characterCtrl:Tick()
    elseif self.ctrlType == ENUM.AVATAR_CTRL_TYPE.AGENT_CTRL_TYPE and self.agent then
        v = self.agent:GetVelocityV3()
        speed = v.sqrMagnitude
        self.agent:Tick()
    end
    if v and v.sqrMagnitude > 0 then
        if self.curCameraType == 3 then
            if self.bTeleport then
                self.bTeleport = false
            else
                local forward = Vector3(v.x, 0, v.z)
                self.Body.transform.rotation = Quaternion.LookRotation(forward.normalized)
            end
        end
        if an then
            an:SetFloat("speed", speed)
        end
    else
        if an then
            an:SetFloat("speed", 0)
        end
    end
end


return NextAvatar