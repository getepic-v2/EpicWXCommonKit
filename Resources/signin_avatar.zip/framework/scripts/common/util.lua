------------------------------------------------------------
--定时器
--
--例子，参数：间隔时间，次数，回调函数
--    timer:getInstance():AddTimer(1,1, function()
--        print("----------calllback ---------")
--    end)
------------------------------------------------------------
---@type CS.UnityEngine.Time
Time = CS.UnityEngine.Time
GameObject = CS.UnityEngine.GameObject
---@class Util
local Util = {}

function Util:getInstance()
    return Util
end

function Util:IsNil(obj)
    -- 快速判断基本类型nil
    if obj == nil then
        return true
    end
    
    -- 非userdata类型无需进一步判断Unity对象是否销毁
    local objType = type(obj)
    if objType ~= "userdata" then
        return false
    end
    
    -- 针对Unity对象的特殊判空（避免tostring产生的GC）
    -- 使用xlua提供的IsNull扩展（如果存在）
    if obj.IsNull then
        return obj:IsNull()
    else
        -- 兼容旧版本的备选方案（仍有少量GC但比原方法少）
        local str = tostring(obj)
        return str == "null" or str == "UnityEngine.Object"
    end
end

--检测是否存在某个C#类
function Util:IsExistCSharpClass(value)
    if type(typeof(value)) == 'userdata' then
        return true
    end
    return false
end

---@return Avatar
function Util:getSelfAvatar()
    --local world = App:GetService("WorldService")
    --local avatar = world:FindElementsByType("avatar")
    -----@type Avatar
    --local selfAvatar = nil
    --for k, v in pairs(avatar) do
    --    if (App.Uuid == v:GetProperty("uuid")) then
    --        selfAvatar = v
    --    end
    --end
    --return selfAvatar

    local avatars = App:GetService("Avatar"):GetAllAvatar()
    local selfAvatar = nil
    for k, v in pairs(avatars) do
        if (App.Uuid == v:GetProperty("uuid")) then
            selfAvatar = v
        end
    end
    return selfAvatar
end



---打印全部成员（为了查看这个类有哪些成员
function Util:printClassMember(cls)
    if (cls == nil) then
        print("argment is nil")
        return
    end
    for i, v in pairs(cls) do
        print(tostring(i) .. " : " .. tostring(v))
    end
end

function Util:handler(obj, method)
    return function(...)
        return method(obj, ...)
    end
end

function Util:RequestAsync(api, request, callBack)
    APIBridge.RequestAsync(
        api,
        request,
        function(res)
            if (callBack and type(callBack) == "function") then
                callBack()
            end
        end
    )
end

--世界坐标转换为2DUI坐标（优化版）
---@param w_position CS.UnityEngine.Vector3 3D世界坐标
---@param canvasRect CS.UnityEngine.RectTransform Canvas的RectTransform
---@return CS.UnityEngine.Vector2, boolean 返回UI坐标和是否成功转换
function Util:WorldPosToUIPos(w_position, canvasRect)
    -- 检查输入参数
    if not w_position or not canvasRect then
        return CS.UnityEngine.Vector2.zero, false
    end
    
    -- 优化：缓存相机引用，避免重复查找
    if not self._mainCamera then 
        self._mainCamera = CS.UnityEngine.Camera.main
    end
    
    if not self._mainCamera then
        return CS.UnityEngine.Vector2.zero, false
    end
    
    -- 第一步：3D世界坐标 → 屏幕坐标
    local screenPos = self._mainCamera:WorldToScreenPoint(w_position)
    
    -- 检查是否在相机前方
    if screenPos.z <= 0 then
        return CS.UnityEngine.Vector2.zero, false
    end
    
    if not self._cameraRTScale then
        self._cameraRTScale = App.CameraRTScale
    end
    
    -- 第二步：处理RenderTexture缩放
    local finalScreenX = screenPos.x
    local finalScreenY = screenPos.y
    
    -- 考虑App.CameraRTScale的影响
    if self._cameraRTScale then
        finalScreenX = screenPos.x * self._cameraRTScale
        finalScreenY = screenPos.y * self._cameraRTScale
    end
    
    -- 如果使用了RenderTexture，需要进行坐标映射
    if self._cameraRTScale and self._mainCamera.targetTexture then
        local renderTexture = self._mainCamera.targetTexture
        local rtWidth = renderTexture.width
        local rtHeight = renderTexture.height
        
        -- 将RenderTexture坐标映射到实际屏幕坐标
        finalScreenX = (screenPos.x / rtWidth) * Screen.width
        finalScreenY = (screenPos.y / rtHeight) * Screen.height
    end
    
    -- 优化：缓存Canvas组件，避免重复查找
    local canvas = self._canvasCache and self._canvasCache[canvasRect] or nil
    if not canvas then
        canvas = canvasRect:GetComponentInParent(typeof(CS.UnityEngine.Canvas))
        if not self._canvasCache then
            self._canvasCache = {}
        end
        -- 限制缓存大小，避免内存泄漏
        local cacheCount = 0
        for _ in pairs(self._canvasCache) do
            cacheCount = cacheCount + 1
        end
        if cacheCount < 50 then -- 最多缓存50个Canvas
            self._canvasCache[canvasRect] = canvas
        end
    end
    
    local canvasCamera = nil
    if canvas then
        if canvas.renderMode == CS.UnityEngine.RenderMode.ScreenSpaceOverlay then
            canvasCamera = nil  -- Overlay模式不需要相机
        elseif canvas.renderMode == CS.UnityEngine.RenderMode.ScreenSpaceCamera then
            canvasCamera = canvas.worldCamera or self._mainCamera
        else
            canvasCamera = self._mainCamera
        end
    end
    
    -- 优化：每次创建新的Vector2对象，避免坐标干扰
    local screenPoint = CS.UnityEngine.Vector2(finalScreenX, finalScreenY)
    
    -- 使用RectTransformUtility进行坐标转换
    local success, localPos = CS.UnityEngine.RectTransformUtility.ScreenPointToLocalPointInRectangle(
        canvasRect, 
        screenPoint, 
        canvasCamera
    )
    
    if not success then
        return CS.UnityEngine.Vector2.zero, false
    end
    
    return localPos, true
end

-- 清理WorldPosToUIPos的缓存，避免内存泄漏
function Util:ClearWorldPosToUIPosCache()
    self._mainCamera = nil
    self._cameraRTScale = nil
    self._canvasCache = nil
end


return Util

