local EventPool = require('common/eventpool')

-- 使用方法
--
-- 监听
-- eventCenter:getInstance():on("Cube", self.onEventCallBack)
-- 派发事件
-- eventCenter:getInstance():emit("Cube","param");
--

local class = require('middleclass')
---@class EventCenter @parent class
local EventCenter = class("EventCenter")

---@type EventCenter
local instance = nil

---@return EventCenter
function EventCenter:getInstance()
    if instance == nil then
        instance = EventCenter:new();
    end
    return instance
end

function EventCenter:initialize()
    --添加消息池
    self.pool = EventPool.NewPool("event_center_pool")
end

---监听事件
---@alias Handler fun(type: string, data: any):void
---@param eventName string | "'onEventXX'" | "'onData'"
---@param handler Handler | "function(type, data) print(data) end"
function EventCenter:on(eventName, handler)
    self.pool:ListenEvent(eventName, handler)
    self.pool:OnStart()
    print("注册事件：" .. eventName)
end

---分发事件
---@param eventName string | "'onEventXX'" | "'onData'"
---@param custom string | "'参数'"
function EventCenter:emit(eventName, custom)
    g_PushEvent(eventName, custom)
end

return EventCenter