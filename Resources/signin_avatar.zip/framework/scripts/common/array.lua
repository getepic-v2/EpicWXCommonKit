

local class = require("middleclass")
local Array = class("Array")

function Array:initialize()
    self.length = 0
    self.data = {}
end

--数组末尾增加元素
---@param element any
---@return nil
function Array:push(element)
    self.length = self.length + 1
    self.data[self.length] = element
end

--弹出末尾元素，如果数组为空返回nil
---@return any
function Array:pop()
    if(self.length == 0) then
        return nil
    end
    local element = self.data[self.length]
    table.remove(self.data, self.length)
    self.length = self.length - 1
    return element
end

--获取第index元素
---@param index number
---@return any
function Array:getIndex(index)
    return self.data[index];
end

--覆盖第index元素
---@param index number
---@param element any
---@return nil
function Array:setIndex(index, element)
    if(index < 1 or index > self.length + 1) then
        print("Array setIndex failed, index range 0 ~ length + 1")
        return
    end
    self.data[index] = element
end

--删除第index元素
---@param index number
---@return nil
function Array:remove(index)
    if(self.length == 0) then
        return
    end
    table.remove(self.data,index)
    self.length = self.length - 1
end

--删除元素
---@param element any
---@return nil
function Array:removeElement(element)
    if(self.length == 0) then
        return
    end
    local index = -1
    for i, v in ipairs(self.data) do
        if v == element then
            index = i
            break
        end
    end
    if index > -1 then
        table.remove(self.data,index)
        self.length = self.length - 1
    end
end

--遍历
--@param (i,v)={}
--@return nil
function Array:map(func)
    for i, v in ipairs(self.data) do
        func(i,v)
    end
end

--for test
function Array:print()
    for i, v in ipairs(self.data) do
        print("i = " .. tostring(i) .. " v = " .. tostring(v))
    end
end

--判断数组中是否包含某个元素
---@param element any
---@return boolean
function Array:contain(element)
    for _, v in ipairs(self.data) do
        if v == element then
            return true
        end
    end
    
    return false
end
    

return Array    
