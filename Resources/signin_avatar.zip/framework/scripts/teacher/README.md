# 1. 教师端IPC 
<教师端通讯模块>
- https://yach-doc-shimo.zhiyinlou.com/docs/erAdP0r1nOH5gvAG/  






