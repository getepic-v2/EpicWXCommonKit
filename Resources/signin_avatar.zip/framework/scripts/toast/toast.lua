---@author 钱成隆

local class = require("middleclass")
local Window = require("ui/window")
local DOTween = CS.DG.Tweening.DOTween
local Toast = class("Toast", Window)

---@param showWords 展示文字, 无配置会提示
---@param showTime 展示时间, 1至5s, 默认3s
function Toast:initialize()
    Toast.super.initialize(self, "Toast", RESOURCE_LOC.."/assets/prefabs/toast")
end

function Toast:OnCreate()
    self.root = self.UI:GetUIObject()

    self.toastGo =  self.root.transform:Find("toast").gameObject
    self.textGo = self.root.transform:Find("toast/Text").gameObject

    self.root:SetActive(false)
end

function Toast:Show(showWords, showTime)
    self.showWords = showWords or "无配置文字"
    self.showTime = tonumber(showTime) or 3
    
    self.showTime = math.floor(self.showTime)
    if self.showTime > 5 then
        self.showTime = 5
    elseif self.showTime < 1 then
        self.showTime = 1
    end

    self:Effects()
end

function Toast:Effects()
    g_LogColorMsg("------show toast------")
    self.textGo:GetComponent(typeof(CS.UnityEngine.UI.Text)).text = self.showWords
    local rect = self.toastGo.transform
    local text = self.textGo:GetComponent(typeof(CS.UnityEngine.UI.Text))
    rect.localScale = CS.UnityEngine.Vector3(1,0,1)

    text.color = CS.UnityEngine.Color(255,255,255,0)

    if self.seq then
        self.seq:Kill()
        self.seq = nil
    end

    self.seq = DOTween:Sequence()
    self.seq:Append(rect:DOScale(CS.UnityEngine.Vector3(1, 1, 1), 0.3):OnUpdate(function ()
        text.color = CS.UnityEngine.Color(255,255,255,rect.localScale.y)
    end))
    self.seq:AppendInterval(tonumber(self.showTime))
    self.seq:Append(rect:DOScale(CS.UnityEngine.Vector3(1, 0, 1), 0.3):OnUpdate(function ()
        text.color = CS.UnityEngine.Color(255,255,255,rect.localScale.y)
    end))
    self.seq:AppendCallback(function()
        self.root:SetActive(false)
        if self.seq then
            self.seq:Kill()
            self.seq = nil
        end
        g_LogColorMsg("------toast close------")
    end)
    
    self.textGo:SetActive(true)
    self.root:SetActive(true)

    self.seq:PlayForward()
end

return Toast
