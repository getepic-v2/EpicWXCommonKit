local class = require("middleclass")
local ConfigHandler = class("ConfigHandler")

function ConfigHandler:initialize(visElement)
    if not visElement then
        return
    end
    self.visElement = visElement;
end

function ConfigHandler:InitConfig(strJsonConfig)
    if self.json then
        --已经初始化过，不再初始化
        return
    end
    if not strJsonConfig then
        if not self.visElement then
            return
        end
        strJsonConfig = CourseEnv.ServicesManager:GetConfigService():GetConfigDataByScript(self.visElement)
        if not strJsonConfig then
            return
        end
    end
    local jsonConfig = strJsonConfig
    if type(strJsonConfig) == "string" then
        jsonConfig = CourseEnv.ServicesManager:GetConfigService():DecodeStringToTable(strJsonConfig)
    end
    self.json = jsonConfig
end
--- 获取配置的GameObject，包含节点、模型、特效、音频、视频、图片、文本
---@param strKey any
---@return CS.UnityEngine.GameObject
function ConfigHandler:GetGameObjectByConfigKey(strKey)
    local str = self:_getStringByConfigKey(strKey);
    if not str then
        return nil
    end
    if (not string.startswith(str,"{"))
     or (not string.endswith(str,"}")) then
        return nil
    end
    local jsonConfig = CourseEnv.ServicesManager:GetJsonService():decode(str)
    if not jsonConfig then
        return nil
    end
    if not self.visElement then
        return nil
    end
    local refGoInfo = jsonConfig["refGoInfo"]
    if refGoInfo then
        local gameObject = CourseEnv.ServicesManager:GetAssetService():GetConfigGameObjectWithRefInfo(self.visElement,refGoInfo);
        if gameObject then
            return gameObject
        end
    end
    local uAddress = jsonConfig["uAddress"]
    if uAddress then
        local gameObject = CourseEnv.ServicesManager:GetAssetService():GetConfigGameObjectWithUAddress(self.visElement,uAddress);
        if gameObject then
            return gameObject
        end
    end
    return nil
end
--- 获取key为strKey的Sprite资源
---@param strKey string
---@return CS.UnityEngine.Sprite
function ConfigHandler:GetSpriteByConfigKey(strKey)
    local gameObject = self:GetGameObjectByConfigKey(strKey)
    if not gameObject then
        return nil
    end
    return CourseEnv.ServicesManager:GetAssetService():GetSprite(gameObject);
end

--- 获取key为strKey的Texture资源
---@param strKey string 
---@return CS.UnityEngine.Texture2D
function ConfigHandler:GetTextureByConfigKey(strKey)
    local gameObject = self:GetGameObjectByConfigKey(strKey)
    if not gameObject then
        return nil
    end
    local assetType = gameObject:GetType()
    if assetType ~= typeof(CS.UnityEngine.Texture2D) then
        return nil
    end
    return gameObject
end

--- 获取key为strKey的AudioClip资源
---@param strKey string 
---@return CS.UnityEngine.AudioClip
function ConfigHandler:GetAudioByConfigKey(strKey)
    local gameObject = self:GetGameObjectByConfigKey(strKey)
    if not gameObject then
        return nil
    end
    local assetType = gameObject:GetType()
    if assetType ~= typeof(CS.UnityEngine.AudioClip) then
        return nil
    end
    return gameObject
end

--- 获取key为strKey的VideoClip资源
---@param strKey string
---@return CS.UnityEngine.VideoClip
function ConfigHandler:GetVideoByConfigKey(strKey)
    local gameObject = self:GetGameObjectByConfigKey(strKey)
    if not gameObject then
        return nil
    end
    local assetType = gameObject:GetType()
    if assetType ~= typeof(CS.UnityEngine.VideoClip) then
        return nil
    end
    return gameObject
end

--- 获取key为strKey的字符串
---@param strKey string 
function ConfigHandler:_getStringByConfigKey(strKey)
    self:InitConfig()
    if not self.json then
        return ""
    end
    local object = self.json[strKey]
    if not object then
        return ""
    end
    return object
end

--- 获取key为strKey的字符串,如果是文件则返回文件内容
---@param strKey string 
function ConfigHandler:GetStringByConfigKey(strKey)
    local str = self:_getStringByConfigKey(strKey)
    if not str then
        return ""
    end
    if (not string.startswith(str,"{"))
     or (not string.endswith(str,"}")) then
        return str
    end
    local gameObject = self:GetGameObjectByConfigKey(strKey)
    if not gameObject then
        return str
    end
    return tostring(gameObject)
end


--- 获取自增组件数据，返回ConfigHandler的数组 [ConfigHandler]
---@param strKey any
---@return table
function ConfigHandler:GetListSubConfigHandler(strKey)
    local list = {}
    local jsonConfig = self:_getStringByConfigKey(strKey)
    if not jsonConfig then
        return nil
    end

    local type = type(jsonConfig)
    if type == "string" then
        jsonConfig = CourseEnv.ServicesManager:GetJsonService():decode(jsonConfig);
    end
    if not jsonConfig then
        return list
    end
    for k, v in pairs(jsonConfig) do
        local configHandler = ConfigHandler:new(self.visElement)
        configHandler:InitConfig(v)
        table.insert(list, configHandler)
    end
    return list
end

return ConfigHandler


