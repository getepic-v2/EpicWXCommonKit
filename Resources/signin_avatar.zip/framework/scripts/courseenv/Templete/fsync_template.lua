---
---  DateTime: 【time】
--- 【type】
--- 【source】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class _ELEMENT_CLASS_FSYNC_ : WBElement
local FsyncElement = class("_ELEMENT__FSYNC_", WBElement)

local Fsync_Example_KEY = "ExampleKey"

function FsyncElement:initialize(worldElement)
    FsyncElement.super.initialize(self, worldElement)
    --订阅KEY消息
    self:SubscribeMsgKey(Fsync_Example_KEY)
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function FsyncElement:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function FsyncElement:SendCustomMessage(key, body)
    self:SendMessage(key,body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:AvatarCreated(avatar)

end

return FsyncElement