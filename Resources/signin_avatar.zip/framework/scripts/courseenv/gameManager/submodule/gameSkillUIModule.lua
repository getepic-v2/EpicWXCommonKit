---@type EventSubscribe
local EventSubscribe  = require("event_subscribe")

--- @class GameSkillUIModule
local gameSkillUIModule = {}

local ButtonManager = nil
---@private
---初始化游戏技能UI模块
function gameSkillUIModule:_Init()

    ButtonManager = require("gameplay/button")
    ButtonManager:Init()

    GameModuleManager:GetGameQuestionModule().energyChangeEvent:connect(function(energy)
        ButtonManager:OnEnergyChanged(energy)
    end)

    --隐藏麦克风
    local uiService = CourseEnv.ServicesManager:GetUIService()
    local voiceBtnHidenId = uiService:SetHidenVoiceBtnWithID()
end

--- 初始化技能UI
---@param configs table 技能配置表，结构如下：
---{
---    {
---        key = "子技能", -- 技能标识
---        hide = false, -- 是否隐藏
---        sprite = self.sprite, -- 技能图标
---        idx = 4, -- 技能盘位置，1-4分别代表左下到右上
---        cd = 5, -- 冷却时间
---        cost = 30, -- 消耗能量
---        autoExecute = true, -- 是否自动执行
---        execute = function(key) -- 执行函数
---            print("执行")
---        end,
---        willExecute = function(key) -- 执行前检查函数
---            print("执行前检查")
---            return true -- true执行，false不执行
---        end
---    }
---}
function gameSkillUIModule:InitSkillUI(configs)
    self:_Init()

    self.skillConfigs = configs
    self.skillKeyMap = {}
    self.buttonVisibility = {"0", "0", "0", "0"}  -- 初始化按钮可见性状态

    local data = {
        {key = "key1",hide = true},
        {key = "key2",hide = true},
        {key = "key3",hide = true},
        {key = "key4",hide = true},
    }

    ButtonManager:ShowSkillButtons(data, function()
         for _,v in pairs(self.skillConfigs) do
            ButtonManager:ChangeButton(v.idx,v)
            self.skillKeyMap[v.key] = v
            -- 初始化按钮显示状态
            if v.hide then
                self.buttonVisibility[v.idx] = "0"
            else
                self.buttonVisibility[v.idx] = "1"
            end
         end
         -- 应用初始显示状态
         ButtonManager:SwitchButtons(table.concat(self.buttonVisibility, ","))
    end)


    ButtonManager:OnEvent(function(key, data)
        if data.event == ButtonManager.ClickEvent.Execute then
            --执行
            local data = self.skillKeyMap[key]
            local execute = data.execute
            if execute then
                execute(key)
            end
            if data.cost then
                GameModuleManager:GetGameQuestionModule():AddEnergy(-data.cost)
            end

        elseif data.event == ButtonManager.ClickEvent.PreExecute then
            --执行前判定    
            local data = self.skillKeyMap[key]

            local willExecute = data.willExecute
            local ret = false
            if willExecute then
                ret = willExecute(key)
            end

            if ret then
                local _btn = ButtonManager:GetButton(data.idx)
                _btn.execute()
            end
        end
    end)

end

--- 增加能量值
---@param energy number 要增加的能量值
function gameSkillUIModule:AddEnergy(energy)
    GameModuleManager:GetGameQuestionModule():AddEnergy(energy)
end

--- 获取技能按钮
---@param key string 技能标识
---@return table|nil 返回对应技能的按钮，如果不存在则返回nil
function gameSkillUIModule:GetSkillButton(key)
    local data = self.skillKeyMap[key]
    if data then
        return ButtonManager:GetButton(data.idx)
    end
    return nil
end

--- 修改技能按钮配置
---@param key string 技能标识
---@param data table 新的技能按钮配置数据
function gameSkillUIModule:ChangeSkillButton(key,data)
    --TODO: 修改技能按钮
end

--- 隐藏指定技能
---@param key string 技能唯一标识
---@return boolean 是否成功隐藏
function gameSkillUIModule:HideSkill(key)
    local data = self.skillKeyMap[key]
    if data then
        local idx = data.idx
        self.buttonVisibility[idx] = "0"
        ButtonManager:SwitchButtons(table.concat(self.buttonVisibility, ","))
        return true
    end
    return false
end

--- 显示指定技能
---@param key string 技能唯一标识
---@return boolean 是否成功显示
function gameSkillUIModule:ShowSkill(key)
    local data = self.skillKeyMap[key]
    if data then
        local idx = data.idx
        self.buttonVisibility[idx] = "1"
        ButtonManager:SwitchButtons(table.concat(self.buttonVisibility, ","))
        return true
    end
    return false
end

--- 触发指定的技能
---@param key string 技能唯一标识
---@return boolean 是否成功触发
function gameSkillUIModule:TriggerSkill(key)
    local button = self:GetSkillButton(key)
    if button then
        button.execute()
        return true
    end
    return false
end

--- 设置技能冷却时间
---@param key string 技能唯一标识
---@param cdTime number 冷却时间(秒)
---@return boolean 是否设置成功
function gameSkillUIModule:SetSkillCD(key, cdTime)
    local data = self.skillKeyMap[key]
    if data then
        local idx = data.idx
        ButtonManager:CoolDown(idx, cdTime)
        return true
    end
    return false
end

--- 获取技能是否可用
---@param key string 技能唯一标识
---@return boolean 是否可用
function gameSkillUIModule:IsSkillReady(key)
    local button = self:GetSkillButton(key)
    if button then
        return not button.isCoolingDown
    end
    return false
end

return gameSkillUIModule
