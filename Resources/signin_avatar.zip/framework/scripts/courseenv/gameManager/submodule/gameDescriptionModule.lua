-- 游戏说明
-- toggle 是否显示玩法说明
-- text  玩法说明
-- audioClicp 首次打开时播放的音频
-- audioClicp 游戏说明语音
-- toggle 是否显示新UI

local gamePreview = require("rungamecommon/game_preview")

---@class GameDescriptionModule : GameModule
local GameDescription = {}

function GameDescription:Init(config)
    
    local url = "https://static0.xesimg.com/next-studio-pub/app/1743406746348/FRq74ICLEVxkUKQvPYKZ.mp3"

    local cfg = {
        isShowDesc = config.isShowDesc,
        description = config.description,
        isNewGuide = config.isNewGuide,
        firstAudioUrl = url,
        showAudioUrl = nil
    }

    CourseEnv.ServicesManager.Gate:AddElementType("gamePreview", gamePreview)
    local dict = CS.Tal.framesync.VisualProperty();
    dict:Add("type", "gamePreview")
    self.ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.one, Vector3.one,
        Vector3.one, "WorldElement")
    -- 注释三
    self.ret:setVisElement(self, self.VisElement, cfg)
end

function GameDescription:Show()
    self.ret:OnReceiveTriggerEvent("firstShowDialog")
end

function GameDescription:Hide()
    self.ret:OnReceiveTriggerEvent("closeDialog")
end

function GameDescription:GameStart()
    self.ret:OnReceiveTriggerEvent("gameStart")
end

return GameDescription