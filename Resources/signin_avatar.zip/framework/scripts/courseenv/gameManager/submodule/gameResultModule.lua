-- 游戏结算模块
local gameResult = require("rungamecommon/game_result")

---@class GameResultModule : GameModule
local GameResultModule = {}

---初始化游戏结算模块
---@return nil
function GameResultModule:Init()
    CourseEnv.ServicesManager.Gate:AddElementType("gameResult", gameResult)
    local dict = CS.Tal.framesync.VisualProperty();
    dict:Add("type", "gameResult")
    local ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.one, Vector3.one, Vector3.one,
        "WorldElement")
    ret:setVisElement(nil)

    self.ret = ret

    CourseEnv.ServicesManager:GetObserverService():Watch("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", function(key, args)
        local data = args and args[0]
        local op = data and data.op
        if op == "Stop" then -- 开始预播
            
            GameModuleManager:GetGameQuestionModule():HideQuestionPanel()

        end
    end)
end

---显示个人游戏结算界面（团队游戏结算走服务端）
---@param param table 结算参数
---@param param.rank number 排名
---@param param.award number 奖励
---@param param.score number 分数
---@param param.rankListType number 排行榜类型(可选，默认1)
---@param param.titleType number 标题类型(可选，默认1)   1.第几名 2.获胜 3.失败 4.已出局 5.平局 6.已完成 7.已淘汰 8.成功离开 9.尚未结束
---@param param.contentType number 内容类型(可选，默认1)   1.包含用时、芝士、经验 2.包含芝士、经验 3.包含经验 4.包含芝士 5.包含芝士、学识、经验
---@param param.closeBtnType number 关闭按钮类型(可选，默认2)   1. 3S后自动关闭不显示关闭按钮 2.显示关闭按钮 3.显示关闭和再来一局按钮
---@param param.clickCloseCallBack function 关闭按钮回调(可选，默认调用App:GameReturn())
---@return nil
function GameResultModule:ShowPersonalResult(param)

    -- 检查下param没有对应参数报错
    if param.rank == nil then
        error("param.rank is nil")
    end
    if param.award == nil then
        error("param.award is nil")
    end
    if param.score == nil then
        error("param.score is nil")
    end

    local gameResultData = {}
    gameResultData.rank = param.rank
    gameResultData.award = param.award
    gameResultData.score = param.score
    gameResultData.autoClose = true
    gameResultData.rankListType = param.rankListType or 1
    gameResultData.titleType = param.titleType or 1
    gameResultData.contentType = param.contentType or 1
    gameResultData.closeBtnType = param.closeBtnType or 2
    gameResultData.clickCloseCallBack = param.clickCloseCallBack or function()
        App:GameReturn()
    end
    CourseEnv.ServicesManager:GetObserverService():Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)

    g_Log("显示个人结算界面")
end

return GameResultModule
