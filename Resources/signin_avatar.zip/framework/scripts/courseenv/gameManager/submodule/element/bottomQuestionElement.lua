---
---  Author: 【王德】
---  AuthorID: 【102030】
---  CreateTime: 【2024-4-8 10:04:24】
--- 【FSync】
--- 【底部答题面板】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")


---@class fsync_ad69f622_6544_413d_9a7e_8fb0c38cdfbd : WorldBaseElement
local FsyncElement = class("fsync_ad69f622-6544-413d-9a7e-8fb0c38cdfbd", WBElement)
local TAG = "底部答题视频UI面板"

local uaddress = "989101743504153/assets/Prefabs/BottomQuestionPanel.prefab"

-- 文本最大宽度
local maxWidth = 580
-- 多行文本宽度
local multiLineWidth = 560

local styleIds = {
    sentence = 51,
    readBook = 52
}

-- 常量定义
local ASSESSMENT_CONSTANTS = {
    RESULT_DELAY = 2,
    READBOOK_RESULT_DELAY = 2.5,
    COUNTDOWN_TIME = 10,
    PET_EXP = 1
}

function FsyncElement:Print(...)
    g_Log(TAG, ...)
end

---@param worldElement CS.Tal.framesync.WorldElement
function FsyncElement:initialize(worldElement)
    FsyncElement.super.initialize(self, worldElement)
    -- 订阅KEY消息
    self.passScore = 60
    if not (App.IsStudioClient) then
        self.pluginJson = App.Info.plugins
        if self.pluginJson ~= nil and type(self.pluginJson) == "string" then
            self:InitPluginInfo()
        end
    end

    local appVersion = App.Info.appVersionNumber
    if App.IsStudioClient then
        appVersion = 10809
    end
    if appVersion then
        if tonumber(appVersion) < 10810 then
            self.lowAppVersion = true
        end
    end
    self.eventId = "BottomAnswerPanel"
    self.answerIndex = 0
    self.jewel = 0
    self.callFunSeqTb = {}
    self.callFunTb = {}

    -- 视频播放错误回调
    self.palyErrorCallFunTb = {}
    -- 视频播放完毕回调
    self.palyCompleteCallFunTb = {}

    self.initUI = false

    self:InitService()

    self:InitListener()
    -- 再来一局，学识改完0
    self.observerService:Watch("reStartGame", function()
        self.jewel = 0
        self.jewelCountTmp.text = tostring(self.jewel)
    end)

    self:LoadRemoteUaddress(uaddress, function(success, prefab)

        if success then
            local go = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform)
            go.name = "底部答题UI"
            go.gameObject:SetActive(false)

            self:InitView()
            self:InitConfig()
        end

        self.initUI = true
    end)
end

function FsyncElement:InitPluginInfo()
    local list = self.jsonService:decode(self.pluginJson)
    for _, v in pairs(list) do
        if v.pluginName == "ABC动态资源配置" then
            xpcall(function()
                if v.pluginVal.abc_evaluation_pass_score then
                    self.passScore = tonumber(v.pluginVal.abc_evaluation_pass_score)
                end
            end, function(err)

            end)
        end
    end
end

function FsyncElement:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.speechAssessmentBusiness = CourseEnv.BaseBusinessManager:GetSpeechAssessmentBusiness()
end

function FsyncElement:InitView()
    self.root = self.VisElement.gameObject
    self.rootTrans = self.root.transform
    self.panel = self.rootTrans:FindChildWithName("底部答题UI")

    self.sound = self.panel:FindChildWithName("Sound")
    self.resTmp = self.panel:FindChildWithName("tmp")

    -- 0317改动 去掉读句子领读特效，改为固定领读视频，去掉等待出题中特效
    self.waijiaozhuangzui = self.panel:FindChildWithName("waijiaozhuangzui")
    self.waijiaozhuangzuiAnim = self.waijiaozhuangzui:GetComponent(typeof(CS.UnityEngine.Animator))
    ---@type CS.UnityEngine.UI.Button
    self.soundBtn = self.sound:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.soundBtn.enabled = false

    self.contentEn = self.panel:FindChildWithName("Content_en")
    self.contentEnFit = self.contentEn.gameObject:GetComponent(typeof(CS.UnityEngine.UI.ContentSizeFitter))
    self.contentEnRect = self.contentEn:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.contentEnTmp = self.contentEn:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.preContent = self.contentEn:FindChildWithName("pre_content")
    self.preContentTmp = self.preContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.preContentTmp.isRightToLeftText = true
    self.preContentRect = self.preContent:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.lastContent = self.contentEn:FindChildWithName("last_content")
    self.lastContentTmp = self.lastContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.lastContentRect = self.lastContent:GetComponent(typeof(CS.UnityEngine.RectTransform))

    self.scrollViewCh = self.panel:FindChildWithName("ScrollView_ch")
    ---@type CS.UnityEngine.UI.ScrollRect
    self.scrollView = self.scrollViewCh:GetComponent(typeof(CS.UnityEngine.UI.ScrollRect))
    self.contentCh = self.panel:FindChildWithName("Content_ch")
    self.contentChTmp = self.contentCh:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    ---@type CS.UnityEngine.RectTransform
    self.contentChRect = self.contentCh:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.waitText = self.panel:FindChildWithName("Wait")
    self.waitTmp = self.waitText:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

    self.confirm = self.panel:FindChildWithName("Confirm")
    self.confirm.gameObject:SetActive(false)
    ---@type CS.UnityEngine.UI.Button
    self.confirmBtn = self.confirm:GetComponent(typeof(CS.UnityEngine.UI.Button))

    self.contentBg = self.panel:FindChildWithName("ContentBg")
    self.contentBgRect = self.contentBg:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.readBookBg = self.panel:FindChildWithName("ReadBookBg")
    self.readBookTextBg = self.contentBg:Find("ReadBookBg/TextBg")
    self.readBookOpenBg = self.contentBg:Find("ReadBookBg/OpenBg")

    self.zuanshi = self.readBookBg:FindChildWithName("zuanshi")
    self.zuanshiAnim = self.zuanshi:GetComponent(typeof(CS.UnityEngine.Animator))
    self.jewelCount = self.zuanshi:FindChildWithName("Text_1")
    self.jewelCountTmp = self.jewelCount:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.sentenceBg = self.panel:FindChildWithName("SentenceBg")
    self.sentenceBgTextBg = self.contentBg:Find("SentenceBg/TextBg")
    self.sentenceBgOpenBg = self.contentBg:Find("SentenceBg/OpenBg")
    self.aiTipsImage = self.contentBg:Find("SentenceBg/aiTip"):GetComponent(typeof(CS.UnityEngine.UI.Image))

    self.observerService:Fire("EVENT_ABCZONE_DEEPSEEK_TAG_SERVICE", {
        callBack = function(isShow, data)
            if not isShow then
                self.aiTipsImage.gameObject:SetActive(false)
            end

            if data.ds_chuti_img then
                self.httpService:LoadNetWorkTexture(data.ds_chuti_img, function(sprite)
                    if sprite then
                        self.aiTipsImage.sprite = sprite
                    end
                end)
            end

        end
    })

    self.effect = self.panel:FindChildWithName("Effect").gameObject

    -- 视频节点
    self.videoNode = self.panel:FindChildWithName("VideoNode")
    self.videoplayerNode = self.videoNode:FindChildWithName("Video Player")
    self.videoPlayer = self.videoplayerNode:GetComponent(typeof(CS.UnityEngine.Video.VideoPlayer))
    -- self.videoPlayer.audioOutputMode = CS.UnityEngine.Video.VideoAudioOutputMode.None
    self.videoPlayerAudio = self.videoplayerNode:GetComponent(typeof(CS.UnityEngine.AudioSource))
    if self.videoPlayerAudio then
        self.videoPlayerAudio.volume = 0
        g_Log(TAG, "设置视频音量为0")
    end

    -- 视频播放喇叭
    self.videoEff = self.videoNode:FindChildWithName("Qipao")
    -- 能量条
    self.sliderNode = self.panel:FindChildWithName("Slider")
    self.slider = self.sliderNode:GetComponent(typeof(CS.UnityEngine.UI.Slider))
    self.sliderPerText = self.sliderNode:FindChildWithName("perText"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.sliderNode.gameObject:SetActive(false)

    self.scoreRoot = self.panel:FindChildWithName("huodefenshu_xiao")
    ---@type CS.UnityEngine.RectTransform
    self.scoreRootRect = self.scoreRoot:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.scoreRoot.gameObject:SetActive(true)
    self.greatRoot = self.scoreRoot:Find("defen/Great")
    self.greatRootRect = self.greatRoot:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.greatLevel = self.greatRoot:Find("GREAT/GREAT")
    self.greatLevelImage = self.greatLevel:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.greatLevelRect = self.greatLevel:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.greatScoreHun = self.greatRoot:FindChildWithName("bai")
    self.greatScoreHunImage = self.greatScoreHun:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.greatScoreTen = self.greatRoot:FindChildWithName("shi")
    self.greatScoreTenImage = self.greatScoreTen:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.greatScoreOne = self.greatRoot:FindChildWithName("ge")
    self.greatScoreOneImage = self.greatScoreOne:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.awardBg = self.greatRoot:FindChildWithName("AwardBg")

    self.fightingRoot = self.scoreRoot:Find("defen/Fighting")
    self.fightingLevel = self.fightingRoot:Find("Fighting/Fighting")
    self.fightingLevelImage = self.fightingLevel:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.fightingScoreTen = self.fightingRoot:FindChildWithName("shi_2")
    self.fightingScoreTenImage = self.fightingScoreTen:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.fightingScoreOne = self.fightingRoot:FindChildWithName("ge_2")
    self.fightingScoreOneImage = self.fightingScoreOne:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.fightingContent = self.fightingRoot:FindChildWithName("fightingContent")
    self.fightingContentTmp = self.fightingContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.testPass = self.rootTrans:FindChildWithName("pass")
    self.testPassBtn = self.testPass:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.testNoPass = self.rootTrans:FindChildWithName("noPass")
    self.testNoPassBtn = self.testNoPass:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:StartCoroutine(function()
        self.commonService:Yield(self.commonService:WaitUntil(function()
            return self.recoverComplete
        end))
        self.observerService:Fire("Bottom_Answer_Panel_Size", {
            height = self.contentBgRect.sizeDelta.y + 40 + 12
        })
    end)

    -- 新增答题卡上方弹幕效果
    self.bulletCurtain = self.panel:FindChildWithName("BulletCurtain")
    self.bulletBg = self.panel:FindChildWithName("Bg")
    self.bulletEn = self.panel:FindChildWithName("EnTmp")
    self.bulletCh = self.panel:FindChildWithName("ChTmp")
    self.bulletEnTmp = self.bulletEn:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.bulletChTmp = self.bulletCh:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.bulletBgCanvasGroup = self.bulletBg:GetComponent(typeof(CS.UnityEngine.CanvasGroup))

    -- self.bulletEnRect = self.bulletEn:GetComponent(typeof(CS.UnityEngine.RectTransform))
    -- self.bulletChRect = self.bulletCh:GetComponent(typeof(CS.UnityEngine.RectTransform))

    -- -- 设置弹幕文本宽度为600
    -- self.bulletEnRect.sizeDelta = Vector2(700, self.bulletEnRect.sizeDelta.y)
    -- self.bulletChRect.sizeDelta = Vector2(700, self.bulletChRect.sizeDelta.y)

    self.bulletCurtain.gameObject:SetActive(false)
end

function FsyncElement:InitConfig()
    -- 新增弹幕开关
    -- self.curtainToggle = self.configService:GetConfigValueByConfigKey(self.VisElement, "curtainToggle")
    g_Log(TAG, "弹幕开关", self.curtainToggle)

    self.yellowNumImage = {}
    self.blueNumImage = {}

    self.resultImage = {}

    -- 获取audioSource的clip
    self.audioTip = self.resTmp:Find("audio/大声跟我读"):GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
    self.leadTip = self.resTmp:Find("audio/麦克风出现"):GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
    self.greatClip = self.resTmp:Find("audio/Great&Good job单声道"):GetComponent(typeof(CS.UnityEngine.AudioSource))
                         .clip
    self.niceTryClip = self.resTmp:Find("audio/Nice Try单声道"):GetComponent(typeof(CS.UnityEngine.AudioSource)).clip

    for i = 0, 9 do
        -- 从spriteRender获取
        ---@type CS.UnityEngine.Sprite
        self.yellowNumImage[i] = self.resTmp:Find("sprite/abc_color_num_y_" .. i):GetComponent(typeof(CS.UnityEngine
                                                                                                          .SpriteRenderer))
                                     .sprite
        ---@type CS.UnityEngine.Sprite
        self.blueNumImage[i] = self.resTmp:Find("sprite/abc_color_num_b_" .. i):GetComponent(typeof(CS.UnityEngine
                                                                                                        .SpriteRenderer))
                                   .sprite
    end

    local excellent = self.resTmp:Find("sprite/底部题版_excellent"):GetComponent(typeof(CS.UnityEngine
                                                                                                .SpriteRenderer)).sprite
    local great = self.resTmp:Find("sprite/底部题版_Great"):GetComponent(typeof(CS.UnityEngine.SpriteRenderer))
                      .sprite
    local perfect = self.resTmp:Find("sprite/底部题版_perfect"):GetComponent(typeof(CS.UnityEngine.SpriteRenderer))
                        .sprite

    self.resultImage[1] = perfect
    self.resultImage[2] = excellent
    self.resultImage[3] = great
end

function FsyncElement:untilExecute(func)

    self.commonService:StartCoroutine(function()
        self.commonService:Yield(self.commonService:WaitUntil(function()
            return self.initUI
        end))
        func()
    end)
end

function FsyncElement:InitListener()
    -- self.commonService:AddEventListener(self.soundBtn, "onClick", function()

    -- end)
    self:untilExecute(function()
        self.commonService:AddEventListener(self.confirmBtn, "onClick", function()
            self.confirm.gameObject:SetActive(false)
            self:UpdateAnswerBg(false)
            if App.IsStudioClient then
                self.testPass.gameObject:SetActive(false)
                self.testNoPass.gameObject:SetActive(false)
            end
            self:stopAnswer()
        end)

        if App.IsStudioClient then
            self.commonService:AddEventListener(self.testPassBtn, "onClick", function()
                self.observerService:Fire("speech_assessment_test", {
                    pass = true
                })
                self.testPass.gameObject:SetActive(false)
                self.testNoPass.gameObject:SetActive(false)
            end)
            self.commonService:AddEventListener(self.testNoPassBtn, "onClick", function()
                self.observerService:Fire("speech_assessment_test", {
                    pass = false
                })
                self.testPass.gameObject:SetActive(false)
                self.testNoPass.gameObject:SetActive(false)
            end)
        end
    end)

    -- 初始化能量条
    self.observerService:Watch("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_INIT_SLIDER", function(key, value)
        self:untilExecute(function()
            local data = value and value[0]
            local notShow = data.notShow
            local numerator = data.numerator
            local denominator = data.denominator
            self.sliderNode.gameObject:SetActive(not notShow)
            self.slider.value = numerator / denominator
            self.sliderNumerator = numerator
            self.sliderDenominator = denominator
            self.sliderPerText.text = "<color=#00A99B>" .. numerator .. "</color>" .. "<color=#000000>" .. "/" ..
                                          denominator .. "</color>"
        end)
    end)

    -- 设置能量值
    self.observerService:Watch("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_ADD_SLIDER_VALUE", function(key, value)
        self:untilExecute(function()
            local data = value and value[0]
            local addValue = data.addValue
            local numerator = math.max(math.min(self.sliderNumerator + addValue, self.sliderDenominator),0)
            self.sliderNumerator = self.sliderNumerator + addValue
            local denominator = self.sliderDenominator
            self.slider.value = numerator / denominator
            self.sliderPerText.text = "<color=#00A99B>" .. numerator .. "</color>" .. "<color=#000000>" .. "/" ..
                                          denominator .. "</color>"
        end)
    end)

    -- 设置能量条数值
    self.observerService:Watch("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_SET_SLIDER_VALUE", function(key, value)
        self:untilExecute(function()
            local data = value and value[0]
            local numerator = data.numerator
            local denominator = data.denominator
            self.sliderNode.gameObject:SetActive(true)
            self.slider.value = numerator / denominator
            self.sliderNumerator = numerator
            self.sliderDenominator = denominator
            self.sliderPerText.text = "<color=#00A99B>" .. numerator .. "</color>" .. "<color=#000000>" .. "/" ..
                                          denominator .. "</color>"
        end)
    end)

    -- 监听开始答题
    self.observerService:Watch("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", function(key, value)
        self:untilExecute(function()
            local data = value[0]
            local status = data.status
            if status == 1 then
                g_Log(TAG, "收到start Answer")
                APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
                    open = false,
                    isShow = false
                }, function()

                end)
                self.panel.gameObject:SetActive(true)
                self.scoreRoot.gameObject:SetActive(false)
                local callBack = data.callBack
                local showAwardType = data.showAwardType
                local awardCount = data.awardCount
                local reTryCount = data.reTryCount
                if not reTryCount then
                    reTryCount = 1
                end
                self.callBack = callBack

                -- 默认视频展示样式 4
                local videoViewType = 4
                -- 如果调用方传入了视频展示样式，则使用调用方传入的视频展示样式
                if data.videoViewType ~= nil then
                    videoViewType = data.videoViewType
                end

                local noLeadReading = false
                if data.noLeadReading ~= nil then
                    noLeadReading = data.noLeadReading
                end

                -- 默认全部打开视频领读能力
                self.evaInfo = {
                    showAwardType = showAwardType,
                    awardCount = awardCount,
                    reTryCount = reTryCount,
                    isShowVideo = true,
                    videoViewType = videoViewType,
                    noLeadReading = noLeadReading
                }

                self.cancel = false
                self.answerIndex = self.answerIndex + 1
                self:startAnswer(callBack, self.answerIndex)
            elseif status == 2 then
                g_Log(TAG, "收到stop Answer")
                if self.coroutine then
                    self.commonService:StopCoroutineSafely(self.coroutine)
                    self.coroutine = nil
                end
                self.panel.gameObject:SetActive(false)
                if self.leadAudio then
                    self.audioService:StopAudioSource(self.leadAudio)
                    self.leadAudio = nil
                end
                if self.audioSource then
                    self.audioService:StopAudioSource(self.audioSource)
                    self.audioSource = nil
                end
                self.cancel = true
                self:stopAnswer() ---有回调结果返回
                self.observerService:Fire("QUESTION_SOURCE_LEFT_SHOW", {
                    show = false
                })
            else
                g_Log(TAG, "收到cancel Answer")
                if self.coroutine then
                    self.commonService:StopCoroutineSafely(self.coroutine)
                    self.coroutine = nil
                end
                self.panel.gameObject:SetActive(false)
                if self.leadAudio then
                    self.audioService:StopAudioSource(self.leadAudio)
                    self.leadAudio = nil
                end
                if self.audioSource then
                    self.audioService:StopAudioSource(self.audioSource)
                    self.audioSource = nil
                end
                self.cancel = true
                self:cancelAnswer()
                ---取消时候保存最后一道题目
                if self.question and (not self.question.hasPass) then
                    self.lastQuestion = self.question
                end
            end

        end)
    end)
end

function FsyncElement:startAnswer(businessCallBack, answerIndex)
    g_Log(TAG, "开始答题")
    if self.answerIndex ~= answerIndex then
        return
    end
    if self.lastQuestion then
        self.question = self.lastQuestion
        self.lastQuestion = nil
        self:doAnswer(businessCallBack, answerIndex)
        return
    end
    self.observerService:Fire("EVENT_ABCZONE_QUESTION_MANATER", {
        params = {{
            qType = 51,
            qCount = 1
        }},
        callBack = function(question)
            -- local question = self.questionList[self.questionIndex]
            question = question["51"][1]
            self.question = question
            g_Log(TAG, table.dump(question))
            self.observerService:Fire("QUESTION_SOURCE_LEFT_UPDATA_QUESTION", {
                question = question
            })
            ---数据错误重新取题
            if not self.question.text_en or self.question.text_en == "" then
                self.answerIndex = self.answerIndex + 1
                self:startAnswer(businessCallBack, self.answerIndex)
                return
            end
            if App.IsStudioClient then
                local randomNum = math.random(0, 10)
                if randomNum % 2 == 0 then
                    self.question.style = styleIds.readBook
                    self.question.video =
                        "https://static0.xesimg.com/next-studio-pub/abc_zone/word/video/bella/can_you_ride_a_bike.mp4"
                    self.question.text_en =
                        "The Native Americans helped them and they had a good harvest the next year."
                end
            end
            self:UpdateAnswerBg(false)
            self:doAnswer(businessCallBack, answerIndex)
        end
    })
end

---根据题目设置Ui
function FsyncElement:SetQuestionView()
    g_Log(TAG, "设置题目")
    self.waitText.gameObject:SetActive(false)
    self.contentEn.gameObject:SetActive(true)
    self.contentCh.gameObject:SetActive(true)
    self.contentChTmp.text = self.question.text_cn
    self.contentEnFit.horizontalFit = CS.UnityEngine.UI.ContentSizeFitter.FitMode.PreferredSize
    self.contentEnTmp.fontSize = 40

    ---51 读句子 52 读课文
    if self.question.style == styleIds.readBook then
        self.readBookBg.gameObject:SetActive(true)
        self.sentenceBg.gameObject:SetActive(false)
        local text_en = ""
        local indexArray = self.question.indexArray
        if indexArray then
            if type(indexArray) == 'string' then
                indexArray = self.jsonService:decode(indexArray)
            end
            local froStr, endStr = self:GetKeyWordTextByIndex3(self.question.display, indexArray)
            if not froStr or not endStr then
                froStr, endStr = self:GetKeyWordText1(self.question.display, self.question.text_en)
            end
            self.preContent.gameObject:SetActive(true)
            self.lastContent.gameObject:SetActive(true)
            self.preContentTmp.text = froStr
            self.lastContentTmp.text = endStr
        end

        text_en = "<color=#FFE500>" .. self.question.text_en .. "</color>"
        self.contentEnTmp.text = text_en
        local width = self.contentEnTmp.preferredWidth

        if width > maxWidth then
            -- 文本超长换行
            self.contentEnTmp.fontSize = 26
            self.contentEnFit.horizontalFit = CS.UnityEngine.UI.ContentSizeFitter.FitMode.Unconstrained
            self.contentEnRect.sizeDelta = Vector2(multiLineWidth, self.contentEnRect.sizeDelta.y)
        end

        local enPreferredWidth = self.contentEnTmp.preferredWidth
        local contentPreORLastWidth = (maxWidth - enPreferredWidth) / 2
        self.preContentRect.sizeDelta = Vector2(contentPreORLastWidth, self.preContentRect.sizeDelta.y)
        self.lastContentRect.sizeDelta = Vector2(contentPreORLastWidth, self.lastContentRect.sizeDelta.y)
    else
        self.readBookBg.gameObject:SetActive(false)
        self.sentenceBg.gameObject:SetActive(true)
        self.contentEnTmp.color = CS.UnityEngine.Color(1, 1, 1, 1)
        local keyWord = self.question.word
        local indexArray = self.question.indexArray
        local text_en = ""
        if indexArray then
            if type(indexArray) == 'string' then
                indexArray = self.jsonService:decode(indexArray)
            end
            if indexArray and type(indexArray) == 'table' then
                text_en = self:GetKeyWordTextByIndex(self.question.text_en, indexArray)
            end
        end
        if (not text_en) or text_en == "" then
            -- g_Log(TAG, self.question.text_en, keyWord)
            text_en = self:GetKeyWordText(self.question.text_en, keyWord)
        end
        self.contentEnTmp.text = "<b>" .. text_en .. "</b>"
        self.preContent.gameObject:SetActive(false)
        self.lastContent.gameObject:SetActive(false)

        local width = self.contentEnTmp.preferredWidth
        if width > maxWidth then
            -- 文本超长换行
            self.contentEnTmp.fontSize = 26
            self.contentEnFit.horizontalFit = CS.UnityEngine.UI.ContentSizeFitter.FitMode.Unconstrained
            self.contentEnRect.sizeDelta = Vector2(multiLineWidth, self.contentEnRect.sizeDelta.y)
        end

        -- 上一题是视频领读
        if self.playVideoOpen then
            self.playVideoOpen = false
            self:StopVideoPlay()
        end
    end

    if self.scrollViewTimer then
        self.commonService:StopCoroutineSafely(self.scrollViewTimer)
        self.scrollViewTimer = nil
    end
    if self.contentChTmp.preferredWidth > 560 then
        self.contentChRect.pivot = Vector2(0, 0.5)
        self.scrollView.horizontalNormalizedPosition = 0
        local pos = -0.1
        ---使用ScrollView实现跑马灯
        self.scrollViewTimer = self.commonService:StartCoroutine(function()
            while true do
                self.scrollView.horizontalNormalizedPosition = pos
                self.commonService:YieldEndFrame()
                pos = pos + 0.015
                if pos > 1 then
                    self.commonService:YieldSeconds(0.8)
                    pos = -0.1
                end
            end
        end)
    else
        self.contentChRect.pivot = Vector2(0.5, 0.5)
    end

    -- self.sound.gameObject:SetActive(true)
end

---开始答题主流程
---@param businessCallBack function 业务回调函数
---@param answerIndex number 答题索引
function FsyncElement:doAnswer(businessCallBack, answerIndex)
    if not self:isValidAnswerIndex(answerIndex) then
        return
    end
    
    self:SetQuestionView()
    self:executeAnswerFlow(businessCallBack, answerIndex)
end

---检查答题索引是否有效
---@param answerIndex number 答题索引
---@return boolean 是否有效
function FsyncElement:isValidAnswerIndex(answerIndex)
    return self.answerIndex == answerIndex
end

---执行答题流程
---@param businessCallBack function 业务回调函数
---@param answerIndex number 答题索引
function FsyncElement:executeAnswerFlow(businessCallBack, answerIndex)
    -- 步骤1: 播放首次音频（引导音频）
    self:playFirstSound(function()
        if not self:isValidAnswerIndex(answerIndex) then
            g_Log(TAG, "index 错误 return")
            return
        end
        
        -- 步骤2: 播放引导提示音频
        self:playLeadTipAudio(function()
            if self:shouldCancelAnswer(answerIndex) then
                return
            end
            
            -- 步骤3: 设置答题UI和弹幕效果
            self:setupAnswerUI()
            
            -- 步骤4: 处理Studio客户端特殊逻辑
            self:handleStudioClientLogic()
            
            -- 步骤5: 开始语音评测
            self:startSpeechAssessment(businessCallBack)
        end)
    end)
end

---播放引导提示音频
---@param callback function 播放完成回调
function FsyncElement:playLeadTipAudio(callback)
    self.leadAudio = self.audioService:PlayClipOneShot(self.leadTip, callback)
end

---设置答题UI
function FsyncElement:setupAnswerUI()
    -- 设置弹幕效果
    self:setupBulletCurtain()
end

---开始语音评测
---@param businessCallBack function 业务回调函数
function FsyncElement:startSpeechAssessment(businessCallBack)
    local assessmentParams = self:buildAssessmentParams(businessCallBack)
    self.speechAssessmentBusiness:StartAssessment(assessmentParams, assessmentParams.callBack)
end

---检查是否应该取消答题
---@param answerIndex number 答题索引
---@return boolean 是否应该取消
function FsyncElement:shouldCancelAnswer(answerIndex)
    return self.cancel or not self:isValidAnswerIndex(answerIndex)
end

---设置弹幕效果
function FsyncElement:setupBulletCurtain()
    if self:isBulletCurtainEnabled() then
        self.bulletEnTmp.text = "<color=#FFE500>" .. self.question.text_en .. "</color>"
        self.bulletChTmp.text = self.question.text_cn
        self:ShowBulletCurtainWithAnimation()
    end
end

---检查弹幕是否启用
---@return boolean 弹幕是否启用
function FsyncElement:isBulletCurtainEnabled()
    return self.curtainToggle == "True"
end

---处理Studio客户端逻辑
function FsyncElement:handleStudioClientLogic()
    if not App.IsStudioClient then
        return
    end
    
    self.audioService:PlayClipOneShot(self.audioTip)
    self:UpdateAnswerBg(true)
    
    if self.lowAppVersion then
        self.confirm.gameObject:SetActive(true)
    end
    
    self.testPass.gameObject:SetActive(true)
    self.testNoPass.gameObject:SetActive(true)
end

---构建评测参数
---@param businessCallBack function 业务回调函数
---@return table 评测参数
function FsyncElement:buildAssessmentParams(businessCallBack)
    local showAwardType = self:determineShowAwardType()
    
    local params = {
        action = "start",
        serviceType = "evaAndRect",
        showMicView = false,
        preserveType = showAwardType,
        awardCount = self.evaInfo.awardCount,
        questionId = self.question.id,
        questionStyle = self.question.style,
        text_cn = self.question.text_cn,
        text_en = self.question.text_en,
        passBy = self.question.passBy,
        countdown = ASSESSMENT_CONSTANTS.COUNTDOWN_TIME,
        passScore = self.passScore,
        showResult = false,
        reTryCount = self.evaInfo.reTryCount,
        showAwardType = showAwardType,
        needInterception = true, -- 开启高分截停
        petExp = ASSESSMENT_CONSTANTS.PET_EXP,
        noChangeChat = true,
        callBack = function(score, isFinal, isNoSpeaking)
            self:handleAssessmentResult(score, isFinal, isNoSpeaking, businessCallBack)
        end,
        stepCallBack = function(step)
            self:handleAssessmentStep(step)
        end
    }
    
    -- 合并评估信息
    for k, v in pairs(self.evaInfo) do
        params[k] = v
    end
    
    return params
end

---确定奖励显示类型
---@return number 奖励显示类型
function FsyncElement:determineShowAwardType()
    local showAwardType = self.evaInfo.showAwardType
    
    if self:shouldUseDefaultAwardType(showAwardType) then
        if self:isReadBookQuestion() then
            return 14
        end
    end
    
    return showAwardType
end

---检查是否应该使用默认奖励类型
---@param showAwardType number 奖励显示类型
---@return boolean 是否使用默认类型
function FsyncElement:shouldUseDefaultAwardType(showAwardType)
    return (not showAwardType) or showAwardType == 2 or showAwardType == 11
end

---检查是否为读课文题目
---@return boolean 是否为读课文
function FsyncElement:isReadBookQuestion()
    return self.question.style == styleIds.readBook
end

---处理评测结果
---@param score number 评测分数
---@param isFinal boolean 是否为最终结果
---@param isNoSpeaking boolean 是否无语音
---@param businessCallBack function 业务回调函数
function FsyncElement:handleAssessmentResult(score, isFinal, isNoSpeaking, businessCallBack)
    g_Log(TAG, "score = " .. tostring(score) .. " isFinal = " .. tostring(isFinal))
    
    local isPass = score >= self.passScore
    self:markQuestionAsPassedIfNeeded(isPass)
    
    local isReadBook = self:isReadBookQuestion()
    self:executeBusinessCallback(businessCallBack, score, isFinal, isNoSpeaking, isPass, isReadBook)
    self:fireGameAnswerResultNotice(score, isFinal, isNoSpeaking, isPass, isReadBook)
    
    self:updateUIAfterAssessment()
    self:displayAssessmentResult(score, isPass)
    
    if isFinal then
        self:handleFinalResult(businessCallBack, isPass)
    end
end

---标记题目为通过状态（如果需要）
---@param isPass boolean 是否通过
function FsyncElement:markQuestionAsPassedIfNeeded(isPass)
    if isPass then
        self.question.hasPass = true
    end
end

---执行业务回调
---@param businessCallBack function 业务回调函数
---@param score number 分数
---@param isFinal boolean 是否为最终结果
---@param isNoSpeaking boolean 是否无语音
---@param isPass boolean 是否通过
---@param isReadBook boolean 是否为读课文
function FsyncElement:executeBusinessCallback(businessCallBack, score, isFinal, isNoSpeaking, isPass, isReadBook)
    if businessCallBack then
        businessCallBack(score, isFinal, isNoSpeaking, isPass, isReadBook)
    end
end

---触发游戏答题结果通知
---@param score number 分数
---@param isFinal boolean 是否为最终结果
---@param isNoSpeaking boolean 是否无语音
---@param isPass boolean 是否通过
---@param isReadBook boolean 是否为读课文
function FsyncElement:fireGameAnswerResultNotice(score, isFinal, isNoSpeaking, isPass, isReadBook)
    self.observerService:Fire("game_answer_result_notice", {
        score = score,
        isFinal = isFinal,
        isNoSpeaking = isNoSpeaking,
        isPass = isPass,
        isReadBook = isReadBook
    })
end

---更新评测后的UI
function FsyncElement:updateUIAfterAssessment()
    if self.lowAppVersion then
        self.confirm.gameObject:SetActive(false)
    end
    
    self:UpdateAnswerBg(false)
    self.contentCh.gameObject:SetActive(false)
    self.contentEn.gameObject:SetActive(false)
end

---显示评测结果
---@param score number 分数
---@param isPass boolean 是否通过
function FsyncElement:displayAssessmentResult(score, isPass)
    self:showResult(score, isPass)
    g_Log(TAG, "开始等待结果页显示")
end

---处理最终结果
---@param businessCallBack function 业务回调函数
---@param isPass boolean 是否通过
function FsyncElement:handleFinalResult(businessCallBack, isPass)
    local resultDelay = self:calculateResultDelay(isPass)
    
    if self:isBulletCurtainEnabled() then
        self.bulletCurtain.gameObject:SetActive(false)
    end
    
    self:startResultDelayCoroutine(resultDelay, businessCallBack)
end

---计算结果延迟时间
---@param isPass boolean 是否通过
---@return number 延迟时间
function FsyncElement:calculateResultDelay(isPass)
    if isPass and self:isReadBookQuestion() then
        return ASSESSMENT_CONSTANTS.READBOOK_RESULT_DELAY
    end
    return ASSESSMENT_CONSTANTS.RESULT_DELAY
end

---开始结果延迟协程
---@param resultDelay number 延迟时间
---@param businessCallBack function 业务回调函数
function FsyncElement:startResultDelayCoroutine(resultDelay, businessCallBack)
    self.coroutine = self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(resultDelay)
        g_Log(TAG, "开始等待结果页显示完成")
        self:handleResultDelayComplete(businessCallBack)
    end)
end

---处理结果延迟完成
---@param businessCallBack function 业务回调函数
function FsyncElement:handleResultDelayComplete(businessCallBack)
    self.scoreRoot.gameObject:SetActive(false)
    self:stopScrollViewTimer()
    
    g_Log(TAG, "评测结束,自动开始下一题")
    self.answerIndex = self.answerIndex + 1
    self:startAnswer(businessCallBack, self.answerIndex)
end

---停止滚动视图定时器
function FsyncElement:stopScrollViewTimer()
    if self.scrollViewTimer then
        self.commonService:StopCoroutineSafely(self.scrollViewTimer)
        self.scrollViewTimer = nil
    end
end

---处理评测步骤
---@param step number 步骤号
function FsyncElement:handleAssessmentStep(step)
    if step == 1 then
        self:handleStepOne()
    else
        self:handleOtherSteps()
    end
end

---处理步骤一
function FsyncElement:handleStepOne()
    self.contentCh.gameObject:SetActive(true)
    self.contentEn.gameObject:SetActive(true)
    
    self:setupVoiceAnimation()
    
    if self.lowAppVersion then
        self.confirm.gameObject:SetActive(true)
    end
    self:UpdateAnswerBg(true)
end

---设置语音动画
function FsyncElement:setupVoiceAnimation()
    self.commonService:RegisterIntervalSingleTimer(0, "_setVoiceAnim", function()
        CS.UnityEngine.AudioListener.volume = 1
    end, true)
    
    self.audioService:PlayClipOneShot(self.audioTip, function()
        CS.UnityEngine.AudioListener.volume = 0
        self.commonService:UnregisterIntervalSingleTimer(0, "_setVoiceAnim")
    end)
end

---处理其他步骤
function FsyncElement:handleOtherSteps()
    if self.lowAppVersion then
        self.confirm.gameObject:SetActive(false)
    end
    self:UpdateAnswerBg(false)
end

-- 检测视频领读是否可用
function FsyncElement:CanPlayVideoGuide()
    -- -- --是否开启外教领读
    -- local isShowVideo = self.evaInfo.isShowVideo
    -- local videoViewType = self.evaInfo.videoViewType or 1
    -- 播放引导视频是否可用
    local PlayVideo = false
    -- --播放视频功能是否可用 --版本、是否是测试环境
    -- local canUse = false
    -- self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
    --     op = "Available",
    --     callback = function(use)
    --         canUse = use
    --     end
    -- })
    local videoUrl = self.question.video
    if videoUrl and videoUrl ~= "" then
        PlayVideo = true
    end

    return PlayVideo
end

-- 播放视频
function FsyncElement:PlayVideoQuestion(question, PlayFinishCallBack)
    self:ClearCallBack()
    self:ClearCallBackSeq()
    -- 显示视频节点
    self.videoNode.gameObject:SetActive(true)

    -- 设置视频URl
    self.videoPlayer.url = question.video
    -- 添加准备完成回调
    local PrepareCall = function(source)
        self:Print("准备完成")
        -- 视频跳转到当前时间进度
        self.videoPlayer:Play()
        self.videoEff.gameObject:SetActive(true)

    end

    local playCompleteCallBack = function()
        self:Print("视频播放完毕->", os.clock())
        self.videoEff.gameObject:SetActive(false)
        if PlayFinishCallBack and type(PlayFinishCallBack) == "function" then
            PlayFinishCallBack()
        end
        self:ClearCallBackSeq()
    end

    local playErrorCallBack = function()
        self:Print("视频播放错误-走兜底逻辑>", os.clock())
        -- 获取视频时长 -length
        local videoLength = self.videoPlayer.length ~= 0 and self.videoPlayer.length or 2
        self:Print("视频时长->", videoLength)
        local seq = DOTween:Sequence()
        seq:AppendInterval(videoLength)
        seq:AppendCallback(function()
            self:Print("视频播放完毕-兜底>", os.clock())
            self.videoEff.gameObject:SetActive(false)
            if PlayFinishCallBack and type(PlayFinishCallBack) == "function" then
                PlayFinishCallBack()
            end
            self:ClearCallBackSeq()
        end)
        table.insert(self.callFunSeqTb, seq)
    end

    -- 视频播放完毕回调
    self.videoPlayer:loopPointReached('+', playCompleteCallBack)
    -- 视频播放错误回调
    self.videoPlayer:errorReceived('+', playErrorCallBack)
    -- 视频跳转准备工作
    self.videoPlayer:prepareCompleted('+', PrepareCall)

    self.videoPlayer:Prepare()
    table.insert(self.palyCompleteCallFunTb, playCompleteCallBack)
    table.insert(self.palyErrorCallFunTb, playErrorCallBack)
    table.insert(self.callFunTb, PrepareCall)
end

-- 更新答题背景
function FsyncElement:UpdateAnswerBg(answerState)
    self.effect:SetActive(answerState)
    local isReadBook = self.question.style == styleIds.readBook
    self.readBookTextBg.gameObject:SetActive(isReadBook and not answerState)
    self.readBookOpenBg.gameObject:SetActive(isReadBook and answerState)
    self.sentenceBgTextBg.gameObject:SetActive(not isReadBook and not answerState)
    self.sentenceBgOpenBg.gameObject:SetActive(not isReadBook and answerState)
end

function FsyncElement:StopVideoPlay()
    self.videoPlayer:Stop()
    self.videoNode.gameObject:SetActive(false)
end

function FsyncElement:ClearCallBack()
    for _, PrepareCall in pairs(self.callFunTb) do
        self.videoPlayer:prepareCompleted('-', PrepareCall)
    end
    self.callFunTb = {}

    for _, PrepareCall in pairs(self.palyCompleteCallFunTb) do
        self.videoPlayer:loopPointReached('-', PrepareCall)
    end
    self.palyCompleteCallFunTb = {}

    for _, PrepareCall in pairs(self.palyErrorCallFunTb) do
        self.videoPlayer:errorReceived('-', PrepareCall)
    end
    self.palyErrorCallFunTb = {}
end

function FsyncElement:ClearCallBackSeq()
    for _, seq in pairs(self.callFunSeqTb) do
        seq:Kill()
        seq = nil
    end
    self.callFunSeqTb = {}
end

function FsyncElement:playFirstSound(callBack)
    local noLeadReading = self.evaInfo.noLeadReading
    if noLeadReading then
        g_Log(TAG, "不播放引导音")
        callBack()
        return
    end
    local audio = self.question.audio
    local PlayVideo, videoViewType = self:CanPlayVideoGuide()
    g_Log(TAG, "PlayVideo", PlayVideo)

    if PlayVideo then
        -- self.isPlaying = true
        self.playVideoOpen = true

        -- self:UpdateAnswerBg(false)
        -- self.sound.gameObject:SetActive(false)
        self:PlayVideoQuestion(self.question, function()
            -- self.isPlaying = false
            -- self.sound.gameObject:SetActive(false)
            -- self:UpdateAnswerBg(true)
            -- if self.outTimeCoroutine then
            --     self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
            --     self.outTimeCoroutine = nil
            -- end
            -- callBack()
        end)
    end

    -- --超时兜底
    -- if self.outTimeCoroutine then
    --     self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
    --     self.outTimeCoroutine = nil
    -- end
    -- self.outTimeCoroutine = self.commonService:StartCoroutine(function()
    --     self.commonService:YieldSeconds(10)
    --     if self.isPlaying then
    --         self.isPlaying = false
    --         self:_reportData("播放音频超时", { url = audio, text_en = self.question.text_en, id = self.question.id }, "1")
    --         callBack()
    --     end
    -- end)

    self.isPlaying = true
    local audioClip = self.question.audioClip
    ---兜底
    if self.outTimeCoroutine then
        self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
        self.outTimeCoroutine = nil
    end
    self.outTimeCoroutine = self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(10)
        if self.isPlaying then
            self.isPlaying = false
            if self.audioSource then
                self.audioService:StopAudioSource(self.audioSource)
            end
            self.sound.gameObject:SetActive(false)
            -- 0317改动 去掉读句子领读特效，改为固定领读视频，去掉等待出题中特效
            self.waijiaozhuangzui.gameObject:SetActive(false)
            -- self.soundAnim:SetBool("play", false)
            self:_reportData("播放音频超时", {
                url = audio,
                text_en = self.question.text_en,
                id = self.question.id
            }, "1")
            if self.cancel then
                return
            end
            g_Log(TAG, "触发了播放兜底")
            callBack()
        end
    end)

    if audioClip then
        self:UpdateAnswerBg(false)
        -- self.soundAnim:SetBool("play", true)
        -- 0317改动 去掉读句子领读特效，改为固定领读视频，去掉等待出题中特效
        -- self.sound.gameObject:SetActive(not PlayVideo)
        self.waijiaozhuangzui.gameObject:SetActive(not PlayVideo)
        self.waijiaozhuangzuiAnim.enabled = not PlayVideo
        self.audioSource = self.audioService:PlayClipOneShot(audioClip, function()
            g_Log(TAG, "播放成功")
            if self.outTimeCoroutine then
                self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                self.outTimeCoroutine = nil
            end
            if not self.isPlaying then
                return
            end
            self.isPlaying = false
            self.sound.gameObject:SetActive(false)
            -- 0317改动 去掉读句子领读特效，改为固定领读视频，去掉等待出题中特效
            self.waijiaozhuangzuiAnim.enabled = false
            -- self.soundAnim:SetBool("play", false)
            if self.cancel then
                return
            end
            callBack()
        end)
    else
        self.audioService:GetMp3AudioFromGetUrl(audio, function()
            self.isPlaying = false
            if self.outTimeCoroutine then
                self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                self.outTimeCoroutine = nil
            end
            if self.cancel then
                return
            end
            self.sound.gameObject:SetActive(false)
            -- 0317改动 去掉读句子领读特效，改为固定领读视频，去掉等待出题中特效
            self.waijiaozhuangzui.gameObject:SetActive(false)
            g_Log(TAG, "下载失败，直接回调")
            callBack()
            self:_reportData("下载音频失败", {
                url = audio,
                text_en = self.question.text_en,
                id = self.question.id
            }, "0")
        end, function(clip)
            if self.outTimeCoroutine then
                self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
                self.outTimeCoroutine = nil
            end
            g_Log(TAG, "下载成功，准备播放")
            self.question.audioClip = clip
            self:playFirstSound(callBack)
        end)
    end

end

function FsyncElement:showResult(score, isPass)
    if isPass then
        self.greatRoot.gameObject:SetActive(true)
        self.fightingRoot.gameObject:SetActive(false)
        if score >= 100 then
            self.greatLevelImage.sprite = self.resultImage[1]
            self.greatLevelRect.sizeDelta = Vector2(164, 40) / 0.28
        elseif score >= 90 then
            self.greatLevelImage.sprite = self.resultImage[2]
            self.greatLevelRect.sizeDelta = Vector2(196, 40) / 0.28
        else
            self.greatLevelImage.sprite = self.resultImage[3]
            self.greatLevelRect.sizeDelta = Vector2(148, 40) / 0.28
        end
        if self.question.style == styleIds.sentence then
            self.awardBg.gameObject:SetActive(false)
        elseif self.question.style == styleIds.readBook then
            self.awardBg.gameObject:SetActive(true)
        end
        self.audioService:PlayClipOneShot(self.greatClip)

        if self.question.style == styleIds.readBook then
            self.jewel = self.jewel + 1
            self.commonService:StartCoroutine(function()
                self.commonService:YieldSeconds(1.5)
                self.zuanshiAnim:SetTrigger("Add")
                self.commonService:YieldSeconds(0.4)
                self.jewelCountTmp.text = tostring(self.jewel)
            end)
        end
    else
        self.fightingRoot.gameObject:SetActive(true)
        self.greatRoot.gameObject:SetActive(false)
        self.audioService:PlayClipOneShot(self.niceTryClip)
        if self.question.style == styleIds.readBook then
            self.fightingContentTmp.text = "未达标不能获得能量和学识哦～"
        else
            self.fightingContentTmp.text = "未达标不能获得能量哦～"
        end
    end
    self:setScore(score, isPass)
    self.scoreRoot.gameObject:SetActive(true)
end

function FsyncElement:setScore(score, isPass)
    local hun = 0
    local ten = 0
    local one = 0
    local hunShow = false
    local tenShow = true
    if score >= 100 then
        hun = 1
        ten = 0
        one = 0
        hunShow = true
    else
        hun = 0
        ten = math.floor(score / 10)
        one = score % 10
        if ten == 0 then
            tenShow = false
        end
    end
    if isPass then
        if hunShow then
            self.greatScoreHun.gameObject:SetActive(true)
            self.greatScoreTen.gameObject:SetActive(true)
            self.greatScoreOne.gameObject:SetActive(true)
            self.greatScoreHunImage.sprite = self.yellowNumImage[hun]
            self.greatScoreTenImage.sprite = self.yellowNumImage[ten]
            self.greatScoreOneImage.sprite = self.yellowNumImage[one]
            -- self.greatScoreHunImage:SetNativeSize()
            -- self.greatScoreTenImage:SetNativeSize()
            -- self.greatScoreOneImage:SetNativeSize()
        elseif tenShow then
            self.greatScoreHun.gameObject:SetActive(false)
            self.greatScoreTen.gameObject:SetActive(true)
            self.greatScoreOne.gameObject:SetActive(true)
            self.greatScoreTenImage.sprite = self.yellowNumImage[ten]
            self.greatScoreOneImage.sprite = self.yellowNumImage[one]
            -- self.greatScoreTenImage:SetNativeSize()
            -- self.greatScoreOneImage:SetNativeSize()
        else
            self.greatScoreHun.gameObject:SetActive(false)
            self.greatScoreTen.gameObject:SetActive(false)
            self.greatScoreOne.gameObject:SetActive(true)
            self.greatScoreOneImage.sprite = self.yellowNumImage[one]
            -- self.greatScoreOneImage:SetNativeSize()
        end
    else
        if tenShow then
            self.fightingScoreTen.gameObject:SetActive(true)
            self.fightingScoreOne.gameObject:SetActive(true)
            self.fightingScoreTenImage.sprite = self.blueNumImage[ten]
            self.fightingScoreOneImage.sprite = self.blueNumImage[one]
            -- self.fightingScoreTenImage:SetNativeSize()
            -- self.fightingScoreOneImage:SetNativeSize()
        else
            self.fightingScoreTen.gameObject:SetActive(false)
            self.fightingScoreOne.gameObject:SetActive(true)
            self.fightingScoreOneImage.sprite = self.blueNumImage[one]
            -- self.fightingScoreOneImage:SetNativeSize()
        end
    end
end

function FsyncElement:cancelAnswer()
    -- 取消视频领读UI
    if self.outTimeCoroutine then
        self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
        self.outTimeCoroutine = nil
    end
    self:StopVideoPlay()
    self.speechAssessmentBusiness:CancelAssessment()
end

function FsyncElement:stopAnswer()
    if self.outTimeCoroutine then
        self.commonService:StopCoroutineSafely(self.outTimeCoroutine)
        self.outTimeCoroutine = nil
    end
    self:StopVideoPlay()
    self.speechAssessmentBusiness:StopAssessment()
end

function FsyncElement:GetKeyWordTextByIndex(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return text
    end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                elseif lastIndex then
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#FFE500>" .. middleStr .. "</color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return text
end

function FsyncElement:GetKeyWordTextByIndex2(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return text
    end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                elseif lastIndex then
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            frontStr = "<color=#FFFFFF66>" .. frontStr .. "</color>"
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#FFE500><size=32>" .. middleStr .. "</size></color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                endStr = "<color=#FFFFFF66>" .. endStr .. "</color>"
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return text
end

function FsyncElement:GetKeyWordTextByIndex3(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return nil, nil
    end
    if not index[1] then
        return nil, nil
    end
    local index1 = index[1]

    local startIndex = index1[1]
    local endIndex = index1[2]
    local frontStr = ""

    if startIndex > 0 then
        frontStr = string.sub(text, 1, startIndex)
    end

    --- 对frontStr 反转
    local frontStrReverse = string.reverse(frontStr)
    local endStr = ""
    if endIndex + 2 <= #text then
        endStr = string.sub(text, endIndex + 2, #text)
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return frontStrReverse, endStr
end

-- 处理对应重点单词文字
function FsyncElement:GetKeyWordText(text, word)
    if not text and not word then
        return ""
    end
    if not word or word == "" then
        return text
    end
    if not text or text == "" then
        return ""
    end
    for keyWord in string.gmatch(word, "%w+") do
        local keyWordLower = keyWord:lower()
        local lowerText = text:lower()
        local startIndex, endIndex = string.find(lowerText, keyWordLower)
        if startIndex and endIndex then
            -- local key = string.sub(text, startIndex, endIndex)
            -- g_Log(TAG, "使用关键词高亮显示"..keyWord)
            text = text:gsub('(%f[%a]' .. keyWord .. '[%p]*%f[^%a])', "<color=#00DEA9>" .. keyWord .. "</color>")
        end
    end
    -- 替换所有出现的关键词
    return text
end

function FsyncElement:GetKeyWordText1(text, word)
    if not text and not word then
        return "", ""
    end
    if not word or word == "" then
        return "", ""
    end
    if not text or text == "" then
        return "", ""
    end
    local startIndex, endIndex = string.find(text, word)
    local frontStr = ""
    local endStr = ""
    if startIndex and startIndex > 1 then
        frontStr = string.sub(text, 1, startIndex - 1)
    end
    local frontStrReverse = string.reverse(frontStr)
    if endIndex and endIndex + 1 <= #text then
        endStr = string.sub(text, endIndex + 1, #text)
    end
    -- 替换所有出现的关键词
    return frontStrReverse, endStr
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function FsyncElement:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function FsyncElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function FsyncElement:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function FsyncElement:LogicMapStartRecover()
    FsyncElement.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function FsyncElement:LogicMapEndRecover()
    FsyncElement.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function FsyncElement:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

-- 收到Trigger事件
function FsyncElement:OnReceiveTriggerEvent(interfaceId)
end

-- 收到GetData事件
function FsyncElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

function FsyncElement:_reportData(label, value, action)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(self.eventId, "64007", "Special-Interaction",
            label, action, value)
    end
end

-- 脚本释放
function FsyncElement:Exit()
    self:ClearCallBack()
    self:ClearCallBackSeq()
    FsyncElement.super.Exit(self)
end

function FsyncElement:adjustBulletText()

end

function FsyncElement:ShowBulletCurtainWithAnimation()
    -- 先设置scale为0
    self.bulletCurtain.localScale = Vector3(0, 0, 0)
    self.bulletCurtain.gameObject:SetActive(true)
    -- 设置透明度为0
    self.bulletBgCanvasGroup.alpha = 0

    -- 强制刷新文本
    self.bulletEnTmp:SetAllDirty()
    self.bulletChTmp:SetAllDirty()

    -- 创建缩放动画
    local seq = DOTween:Sequence()
    seq:Append(self.bulletCurtain:DOScale(Vector3(1, 1, 1), 0.3))
    seq:Join(DOTween.To(function()
        return self.bulletBgCanvasGroup.alpha
    end, function(value)
        self.bulletBgCanvasGroup.alpha = value
    end, 1, 0.3))
    seq:SetEase(CS.DG.Tweening.Ease.OutBack)

    -- 下一帧再次强制刷新，确保文本适配正确
    self.commonService:DispatchNextFrame(function()
        if self.bulletEnTmp then
            self.bulletEnTmp:SetAllDirty()
        end
        if self.bulletChTmp then
            self.bulletChTmp:SetAllDirty()
        end
    end)
end

return FsyncElement
