-- 【开局分队组件】

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")
-- local cs_coroutine = require('common/cs_coroutine')

---@class fsync_23dc3145_da0e_43ac_8ee7_886b620796f2 : WorldBaseElement
local FsyncElement = class("fsync_23dc3145-da0e-43ac-8ee7-886b620796f2", WBElement)
local DOTween = CS.DG.Tweening.DOTween

local Fsync_openGame_KEY1 = "openGame_waitToLoad"
local Fsync_openGame_KEY2 = "openGame_redayStart"
local Fsync_openGame_KEY3 = "openGame_startGame"
local Fsync_openGame_KEY4 = "openGame_gameOver"

local countDownUaddress = "1001011746520209/assets/Prefabs/CountDown.prefab" -- 倒计时UI
local waitUaddress = "987061743387126_v1/assets/Prefabs/waitJoin.prefab" -- 等待UI

---@param worldElement CS.Tal.framesync.WorldElement
function FsyncElement:initialize(worldElement)
    FsyncElement.super.initialize(self, worldElement)
    -- 订阅KEY消息
    self:SubscribeMsgKey(Fsync_openGame_KEY1)
    self:SubscribeMsgKey(Fsync_openGame_KEY2)
    self:SubscribeMsgKey(Fsync_openGame_KEY3)
    self:SubscribeMsgKey(Fsync_openGame_KEY4)
    self:SubscribeMsgKey("resp_user_info")
    self:SubscribeMsgKey("activateRoom")
    self:SubscribeMsgKey("forceQuit")
    self:initService()

    -- 添加开始倒计时相关变量
    self.isRun = false -- 是否正在倒计时

    self.audioService:GetMp3AudioFromGetUrl(
        "https://static0.xesimg.com/next-studio-pub/app/1746520559327/MBNdTZP7MMnXp89UPQIt.mp3", function()

        end, function(audio)
            self.countDownAudio = audio
        end)

    self:LoadRemoteUaddress(waitUaddress, function(success, prefab)
        if success and prefab then
            -- 实例化预制体并挂载到当前节点
            local waitUI = self:Instantiate(prefab)
            waitUI.name = "等待UI" -- 命名为注释后的名字
            waitUI.transform:SetParent(self.VisElement.transform, false)

            g_Log("等待UI挂载成功")

            self:LoadRemoteUaddress(countDownUaddress, function(success, prefab)
                if success and prefab then
                    -- 实例化预制体并挂载到当前节点
                    local countDownUI = self:Instantiate(prefab)
                    countDownUI.name = "倒计时UI" -- 命名为注释后的名字
                    countDownUI.transform:SetParent(self.VisElement.transform, false)

                    self.loadedUI = true

                    g_Log("倒计时UI挂载成功")
                else
                    g_LogError("倒计时UI加载失败")
                end
            end, false)

        else
            g_LogError("等待UI加载失败")
        end
    end, false)

end

function FsyncElement:InitConfig(config)

    self.gameMode = 1

    self.isNeedKaiJuTip = config.isNeedKaiJuTip --是否显示开局提示
    self.gameMode = config.gameMode             -- 1单人一队 2双人一队 3四人一队
    self.kaijuImgUrl = config.kaijuImgUrl       -- 开局图片URL (占位，根据实际资源填写)

    
    self:WaitUntilExcute(function()
        return self.loadedUI == true
    end, function()
        self:initData()
    end)

end

function FsyncElement:initService()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.commonService = App:GetService("CommonService")
end

function FsyncElement:initData()

    self.inited = true

    self.num = 8
    -- 游戏模式 1:单人 2:双人 3:四人
    
    self.root = self.VisElement.transform
    self.kaijuditu = self.root:Find("倒计时UI/CountDownCanvas/startImage")
    self.kaijudituImage = self.kaijuditu:GetComponent(typeof(CS.UnityEngine.UI.Image))

    -- self.isNeedKaiJuTip = self.configService:GetConfigValueByConfigKey(self.VisElement, "isNeedKaiJuTip") == "True"
    -- self.gameMode = self.configService:GetConfigValueByConfigKey(self.VisElement, "isDoublePlayer") == "True" and 2 or 1
    -- self.gameMode = self.configService:GetConfigValueByConfigKey(self.VisElement, "isFourPlayer") == "True" and 3 or
    --                     self.gameMode
    g_Log("lshisneed", self.isNeedKaiJuTip, type(self.isNeedKaiJuTip))

    if self.kaijuImgUrl then
        self.httpService:LoadNetWorkTexture(self.kaijuImgUrl, function(texture)
            if texture and self.kaijudituImage then
                self.kaijudituImage.sprite = texture
            end
        end)
    end

    -- 等待界面新UI
    self.waitUI = self.root:Find("等待UI")
    self.singleWaitUI = self.waitUI:Find("Canvas/single")
    self.doubleWaitUI = self.waitUI:Find("Canvas/double")
    self.fourWaitUI = self.waitUI:Find("Canvas/four")
    self.singleWaitUI.gameObject:SetActive(false)
    self.doubleWaitUI.gameObject:SetActive(false)
    self.fourWaitUI.gameObject:SetActive(false)

    -- 初始化单人等待UI的子节点
    self.playerNum = self.singleWaitUI:Find("playerNum"):GetComponent(typeof(CS.UnityEngine.UI.Text))

    -- 初始化8个玩家槽位
    self.playerSlots = {}
    for i = 1, 8 do
        local playerSlot = {
            root = self.singleWaitUI:Find("players/player_" .. i),
            arrow = self.singleWaitUI:Find("players/player_" .. i .. "/arrow"),
            bg = {
                root = self.singleWaitUI:Find("players/player_" .. i .. "/BG"),
                image = self.singleWaitUI:Find("players/player_" .. i .. "/BG/Image"):GetComponent(typeof(CS.UnityEngine
                                                                                                              .UI.Image))
            }
        }
        -- 默认隐藏箭头和背景
        playerSlot.arrow.gameObject:SetActive(false)
        playerSlot.bg.image.gameObject:SetActive(false)

        self.playerSlots[i] = playerSlot
    end

    -- 初始化双人等待UI的子节点
    self.doublePlayerNum = self.doubleWaitUI:Find("playerNum"):GetComponent(typeof(CS.UnityEngine.UI.Text))

    -- 初始化4个队伍
    self.teamSlots = {}
    for i = 1, 4 do
        local teamSlot = {
            root = self.doubleWaitUI:Find("team_" .. i),
            teamNum = self.doubleWaitUI:Find("team_" .. i .. "/teamNum"):GetComponent(typeof(CS.UnityEngine.UI.Text)),
            players = {}
        }

        -- 初始化每个队伍的2个玩家槽位
        for j = 1, 2 do
            local playerSlot = {
                root = teamSlot.root:Find("player_" .. j),
                arrow = teamSlot.root:Find("player_" .. j .. "/arrow"),
                circle = teamSlot.root:Find("player_" .. j .. "/circle"),
                bg = {
                    root = teamSlot.root:Find("player_" .. j .. "/BG"),
                    image = teamSlot.root:Find("player_" .. j .. "/BG/Image"):GetComponent(typeof(CS.UnityEngine.UI
                                                                                                      .Image))
                }
            }
            -- 默认隐藏箭头、圆圈和背景
            playerSlot.arrow.gameObject:SetActive(false)
            playerSlot.bg.image.gameObject:SetActive(false)

            teamSlot.players[j] = playerSlot
        end

        self.teamSlots[i] = teamSlot
    end

    self.fourPlayerNum = self.fourWaitUI:Find("playerNum"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    -- 初始化2个队伍
    self.fourTeamSlots = {}
    for i = 1, 2 do
        local teamSlot = {
            root = self.fourWaitUI:Find("team_" .. i),
            teamNum = self.fourWaitUI:Find("team_" .. i .. "/teamNum"):GetComponent(typeof(CS.UnityEngine.UI.Text)),
            players = {}
        }

        -- 初始化每个队伍的4个玩家槽位
        for j = 1, 4 do
            local playerSlot = {
                root = teamSlot.root:Find("player_" .. j),
                arrow = teamSlot.root:Find("player_" .. j .. "/arrow"),
                circle = teamSlot.root:Find("player_" .. j .. "/circle"),
                bg = {
                    root = teamSlot.root:Find("player_" .. j .. "/BG"),
                    image = teamSlot.root:Find("player_" .. j .. "/BG/Image"):GetComponent(typeof(CS.UnityEngine.UI
                                                                                                      .Image))
                }
            }
            -- 默认隐藏箭头、圆圈和背景
            playerSlot.arrow.gameObject:SetActive(false)
            playerSlot.bg.image.gameObject:SetActive(false)

            teamSlot.players[j] = playerSlot
        end

        self.fourTeamSlots[i] = teamSlot
    end

    self.state = 0 -- 0: 未开局trigger 1: 开局trigger
end

-- 修改展示开局底图函数，添加回调参数
function FsyncElement:showKaijudituTip(onComplete)
    self.kaijuditu.gameObject:SetActive(true)
    local rect = self.kaijuditu.transform

    local showAction = DOTween:Sequence()
    showAction:Append(rect:DOScale(CS.UnityEngine.Vector3(1, 1, 1), 0.3))
    showAction:AppendInterval(1.5)
    showAction:Append(rect:DOScale(CS.UnityEngine.Vector3(1, 0, 1), 0.3))
    showAction:AppendCallback(function()
        g_Log("lsh开局底图隐藏")
        self.kaijuditu.gameObject:SetActive(false)
        self.singleWaitUI.gameObject:SetActive(false)
        self.doubleWaitUI.gameObject:SetActive(false)
        -- 底图动画完成后执行回调
        if onComplete then
            onComplete()
        end
    end)
end

-- 添加开始倒计时函数
function FsyncElement:StartCountStart()
    if self.isRun then
        return
    end
    self.isRun = true
    self:Trigger("startCountDown")
    -- 获取倒计时UI
    self.countDownCanvas = self.VisElement.gameObject.transform:Find("倒计时UI/CountDownCanvas")
    if not self.effect then
        self.effect = self.countDownCanvas:Find("countdown_321_go")
    end
    self.effect.gameObject:SetActive(true)

    -- 播放倒计时音效
    if self.countDownAudio then
        self.audioService:PlayClipOneShot(self.countDownAudio)
    else
        g_LogError("开始倒计时音频未配置")
    end

    -- 开始倒计时协程
    self.commonService:StartCoroutine(function()
        -- 等待动画播放完成
        self.commonService:YieldSeconds(4)

        -- 隐藏倒计时效果
        if self.effect then
            self.effect.gameObject:SetActive(false)
        end

        -- 执行开局逻辑
        self:StartGame()
    end)
end

-- 修改开局逻辑函数
function FsyncElement:StartGame()
    -- 触发游戏开始事件
    local msg = self.gameStartMsg
    if msg then
        local redayStartFrameIndex = msg.redayStartFrameIndex
        local onlineUser = msg.onlineUser
        self:Trigger("redayStart", {
            redayStartFrameIndex = redayStartFrameIndex
        })
        self.observerService:Fire("GameStart", {
            onlineUser = onlineUser
        })
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function FsyncElement:ReceiveMessage(key, value, isResume)


    local func = function(key,value,isResume)
        if key == "activateRoom" then
            self:HandleActivateRoom(value)
        elseif key == "resp_user_info" then
            self:HandleUserInfo(value)
        elseif key == "forceQuit" then
            -- 已注释，保留占位
        elseif key == Fsync_openGame_KEY1 and (isResume == false or App.IsStudioClient) then
            self:HandleWaitToLoad(value)
        elseif key == Fsync_openGame_KEY2 then
            self:HandleReadyStart(value, isResume)
        elseif key == Fsync_openGame_KEY4 then
            self:HandleGameOver(value)
        end
    end

    if self.inited then
        func(key, value, isResume)
        return
    end

    self:WaitUntilExcute(function()
        return self.inited == true
    end, function()
        func(key, value, isResume)
    end)

end

-- 处理房间激活消息
function FsyncElement:HandleActivateRoom(value)
    g_Log("lshactivateRoom")

    local msg = self.jsonService:decode(value[#value])
    if not msg then
        return
    end

    g_Log("lshacticate", table.dump(msg))

    -- 更新玩家数量
    if msg.num then
        self.num = msg.num
    end

    -- 记录最大玩家数量
    if msg.num_max then
        self.num_max = tonumber(msg.num_max)
        g_Log("lshmaxnum", self.num_max)
    end

    -- 根据game_type设置游戏模式
    if msg.game_type then
        -- game_type: 1=单人, 2=双人, 3=四人
        self.gameMode = tonumber(msg.game_type)
        g_Log("lshgametype", self.gameMode)
    end

    -- 处理队伍信息
    self:ProcessTeamInfo(msg)
    self:InitAvatar()
end

-- 处理队伍信息
function FsyncElement:ProcessTeamInfo(msg)
    self.teamUser = msg.wh_team_users
    if not msg.wh_team_users or #msg.wh_team_users == 0 then
        local team1 = self:ParseTeamData(msg.team1)
        local team2 = self:ParseTeamData(msg.team2)
        self.teamUser = {team1, team2}
    end

    if self.teamUser then
        -- 计算每队总人数
        self.teamSize = {}
        for i, team in ipairs(self.teamUser) do
            self.teamSize[i] = #team
        end
    end
end

-- 解析队伍数据
function FsyncElement:ParseTeamData(teamData)
    local result = {}
    if type(teamData) == "string" then
        -- 处理字符串格式，如："1090001943,1090000178"
        for userId in string.gmatch(teamData, "([^,]+)") do
            table.insert(result, userId)
        end
    elseif type(teamData) == "table" then
        -- 处理表格格式
        for _, v in pairs(teamData) do
            table.insert(result, v)
        end
    end
    return result
end

-- 处理用户信息
function FsyncElement:HandleUserInfo(value)
    local msg = self.jsonService:decode(value[#value])
    g_Log("lsh resp_user_info ", table.dump(msg, nil, 3))
    self.tableUserInfo = msg.tableUserInfo
    self:InitAvatar()
end

-- 合并头像加载逻辑
function FsyncElement:LoadUserAvatarByUserId(userId, imageComponent, callback)
    -- 获取用户信息中的头像URL
    local userInfo = self.tableUserInfo[userId]
    if userInfo and userInfo.avatar_url and userInfo.avatar_url ~= "" then
        g_Log("lsh 为用户" .. userId .. "加载头像: " .. userInfo.avatar_url)
        -- 加载头像
        self.httpService:LoadNetWorkTexture(userInfo.avatar_url, function(texture)
            if texture and imageComponent then
                imageComponent.sprite = texture

                -- 默认设置为半透明
                local color = imageComponent.color
                imageComponent.color = CS.UnityEngine.Color(color.r, color.g, color.b, 0.8)

                imageComponent.gameObject:SetActive(true)
                g_Log("lsh 成功加载头像")
                if callback then
                    callback()
                end
            else
                g_Log("lsh 加载头像失败")
            end
        end)
    else
        g_Log("lsh 用户" .. userId .. "没有头像URL")
    end
end

function FsyncElement:InitAvatar()
    -- 如果没有用户信息，或者没有分队信息，直接返回
    if not self.tableUserInfo or not self.teamUser then
        g_Log("lsh 用户信息或分队信息不完整，无法加载头像")
        return
    end

    if self.gameMode == 3 and self.fourTeamSlots then
        self:InitTeamAvatars(self.fourTeamSlots, 4)
    elseif self.gameMode == 2 and self.teamSlots then
        self:InitTeamAvatars(self.teamSlots, 2)
    elseif self.gameMode == 1 and self.playerSlots then
        self:InitSingleAvatars()
    end
end

-- 处理四人/双人模式头像加载
function FsyncElement:InitTeamAvatars(teamSlots, maxPlayersPerTeam)
    local gameModeStr = maxPlayersPerTeam == 4 and "四人" or "双人"
    g_Log("lsh 加载" .. gameModeStr .. "模式头像")

    -- 遍历所有队伍
    for teamIndex, team in ipairs(self.teamUser) do
        if teamIndex <= #teamSlots then
            local teamSlot = teamSlots[teamIndex]
            -- 遍历队伍中的每个玩家
            for playerIndex, userId in ipairs(team) do
                if playerIndex <= maxPlayersPerTeam and teamSlot.players[playerIndex] then
                    local playerSlot = teamSlot.players[playerIndex]
                    self:LoadUserAvatarByUserId(userId, playerSlot.bg.image)
                end
            end
        end
    end
end

-- 处理单人模式头像加载
function FsyncElement:InitSingleAvatars()
    g_Log("lsh 加载单人模式头像")

    -- 构建userId到索引的映射
    local userIdToIndex = {}
    local index = 1

    -- 将所有玩家ID扁平化到一个列表
    for _, team in ipairs(self.teamUser) do
        for _, userId in ipairs(team) do
            userIdToIndex[userId] = index
            index = index + 1
        end
    end

    -- 为每个玩家加载头像
    for userId, slotIndex in pairs(userIdToIndex) do
        if slotIndex <= #self.playerSlots then
            local slot = self.playerSlots[slotIndex]
            self:LoadUserAvatarByUserId(userId, slot.bg.image)
        end
    end
end

-- 处理等待加载阶段
function FsyncElement:HandleWaitToLoad(value)
    g_Log("lshFsync_openGame_KEY1")
    -- 等待加载阶段
    local msg = self.jsonService:decode(value[#value])
    local onlineUsers = msg.onlineUser

    if self.gameMode == 1 then
        self:HandleSingleMode(onlineUsers)
    elseif self.gameMode == 2 then
        self:HandleDoubleMode(onlineUsers)
    elseif self.gameMode == 3 then
        self:HandleFourMode(onlineUsers)
    end
end

-- 处理单人模式
function FsyncElement:HandleSingleMode(onlineUsers)
    -- 单人模式显示
    if not self.singleWaitUI.gameObject.activeSelf then
        self.singleWaitUI.gameObject:SetActive(true)
    end

    -- 获取在线玩家数量
    local totalNum = 0
    local onlineUserList = {}
    for uuid, userInfo in pairs(onlineUsers) do
        if userInfo then
            totalNum = totalNum + 1
            table.insert(onlineUserList, userInfo)
        end
    end

    -- 更新玩家数量显示
    local maxNum = self.num_max or self.num
    self.playerNum.text = string.format("等待加入 %d/%d", totalNum, maxNum)

    -- 构建UUID到在线状态的映射
    local uuidToOnline = {}
    for _, userInfo in ipairs(onlineUserList) do
        if userInfo and userInfo.uuid then
            uuidToOnline[userInfo.uuid] = true
        end
    end

    -- 更新玩家槽位显示
    for i = 1, 8 do
        local slot = self.playerSlots[i]
        if i <= totalNum then
            -- 显示已加入玩家
            local userInfo = onlineUserList[i]
            if userInfo then
                -- 显示自己的箭头指示器
                slot.arrow.gameObject:SetActive(userInfo.uuid == App.Uuid)

                -- 设置已加入玩家头像为完全不透明
                if slot.bg and slot.bg.image then
                    local color = slot.bg.image.color
                    slot.bg.image.color = CS.UnityEngine.Color(color.r, color.g, color.b, 1.0)
                end
            end
        else
            -- 隐藏未使用的槽位的箭头，但保留头像（透明度降低）
            slot.arrow.gameObject:SetActive(false)

            if slot.bg and slot.bg.image then
                local color = slot.bg.image.color
                slot.bg.image.color = CS.UnityEngine.Color(color.r, color.g, color.b, 0.8)
            end
        end
    end
end

-- 准备团队数据
function FsyncElement:PrepareTeamData(onlineUsers)
    local teamData = {}
    local totalJoined = 0
    for i, team in ipairs(self.teamUser) do
        teamData[i] = {
            teamSize = self.teamSize[i],
            teamJoinGamePlayer = {}
        }

        for _, userId in ipairs(team) do
            local uuid = nil
            for _, userInfo in pairs(onlineUsers) do
                if userInfo.userId == userId then
                    uuid = userInfo.uuid
                    break
                end
            end

            if uuid and onlineUsers[uuid] then
                table.insert(teamData[i].teamJoinGamePlayer, uuid)
                totalJoined = totalJoined + 1
            end
        end
    end

    return teamData, totalJoined
end

-- 处理双人模式
function FsyncElement:HandleDoubleMode(onlineUsers)
    -- 统计每队已加入人数
    g_Log("lshteamuser")
    -- 确保teamUser存在且有数据
    if not (self.teamUser and #self.teamUser > 0) then
        return
    end

    g_Log("lshteamuser2")
    if not self.doubleWaitUI.gameObject.activeSelf then
        self.doubleWaitUI.gameObject:SetActive(true)
    end

    local teamData, totalJoined = self:PrepareTeamData(onlineUsers)
    self:UpdateTeamSlots(teamData, {"红", "蓝", "绿", "黄"}, self.teamSlots, 2)
    self.doublePlayerNum.text = string.format("等待加入 %d/%d", totalJoined, self.num_max or self.num)
end

-- 处理四人模式
function FsyncElement:HandleFourMode(onlineUsers)
    g_Log("lsh gameMode = 3")
    -- 确保teamUser存在且有数据
    if not (self.teamUser and #self.teamUser > 0) then
        g_Log("lsh four waitui")
        return
    end

    g_Log("lsh teamuser 4")
    if not self.fourWaitUI.gameObject.activeSelf then
        self.fourWaitUI.gameObject:SetActive(true)
    end

    local teamData, totalJoined = self:PrepareTeamData(onlineUsers)
    g_Log("lshteamdata4", table.dump(teamData, nil, 3))
    self:UpdateTeamSlots(teamData, {"蓝", "红"}, self.fourTeamSlots, 4)
    self.fourPlayerNum.text = string.format("等待加入 %d/%d", totalJoined, self.num_max or self.num)
end

-- 更新团队槽位显示
function FsyncElement:UpdateTeamSlots(teamData, teamColors, teamSlots, playersPerTeam)
    for i = 1, #teamSlots do
        local teamSlot = teamSlots[i]
        if teamSlot then
            -- 初始化所有玩家槽位为半透明状态
            for j = 1, playersPerTeam do
                local playerSlot = teamSlot.players[j]
                if playerSlot then
                    -- 默认隐藏箭头
                    playerSlot.arrow.gameObject:SetActive(false)

                    -- 保留头像，但设置为半透明
                    if playerSlot.bg and playerSlot.bg.image then
                        local color = playerSlot.bg.image.color
                        playerSlot.bg.image.color = CS.UnityEngine.Color(color.r, color.g, color.b, 0.8)
                    end
                end
            end

            teamSlot.teamNum.text = string.format("%s队:0/%d", teamColors[i], playersPerTeam)

            if teamData[i] then
                local joinGamePlayerNum = 0
                for j, uuid in ipairs(teamData[i].teamJoinGamePlayer) do
                    local playerSlot = teamSlot.players[j]
                    if playerSlot then
                        joinGamePlayerNum = joinGamePlayerNum + 1

                        -- 显示当前玩家的箭头
                        playerSlot.arrow.gameObject:SetActive(uuid == App.Uuid)

                        -- 设置已加入玩家头像为完全不透明
                        if playerSlot.bg and playerSlot.bg.image then
                            local color = playerSlot.bg.image.color
                            playerSlot.bg.image.color = CS.UnityEngine.Color(color.r, color.g, color.b, 1.0)
                        end
                    end
                end

                teamSlot.teamNum.text = string.format("%s队:%d/%d", teamColors[i], joinGamePlayerNum,
                    teamData[i].teamSize)
            end
        end
    end
end

-- 处理准备开始
function FsyncElement:HandleReadyStart(value, isResume)
    g_Log("lshFsync_openGame_KEY2")
    -- 准备开始阶段，分队传送到指定位置
    self.singleWaitUI.gameObject:SetActive(false)
    self.doubleWaitUI.gameObject:SetActive(false)
    self.fourWaitUI.gameObject:SetActive(false)

    if isResume == false then
        self.state = 1
        self.gameStartMsg = self.jsonService:decode(value[#value])

        -- 先显示开局底图，完成后再开始倒计时
        self:Trigger("startShowTitle")
        self:Fire("pre_show_game_title")
        if self.isNeedKaiJuTip == true then
            self:showKaijudituTip(function()
                self:StartCountStart()
            end)
        else
            -- 执行开局逻辑
            self:StartGame()
        end
    else
        if self.state == 0 then
            g_Log("lsh断线开局，关闭其他开局UI")
            self.state = 1
            local msg = self.jsonService:decode(value[#value])
            local redayStartFrameIndex = msg.redayStartFrameIndex
            self:Trigger("redayStartIsResume", {
                redayStartFrameIndex = redayStartFrameIndex
            })
            self:Trigger("startShowTitle")

            if self.isNeedKaiJuTip == true then
                self:showKaijudituTip(function()
                    self:StartCountStart()
                end)
            else
                -- 执行开局逻辑
                self:StartGame()
            end
        end
    end
end

-- 处理游戏结束
function FsyncElement:HandleGameOver(value)
    CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
    local msg = CourseEnv.ServicesManager:GetJsonService():decode(value[#value])

    self.observerService:Fire("badGame")
    self:Trigger("badGame")

    -- 调用退出页面
    self.observerService:Fire("show_pop_ui", {
        seconds = 5,
        callback = function()
            App:GameReturn()
        end
    })
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function FsyncElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarPrefabLoaded(avatar)
    self.avatar = avatar
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:AvatarCreated(avatar)
end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function FsyncElement:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function FsyncElement:LogicMapStartRecover()
    FsyncElement.super:LogicMapStartRecover()
end
-- 结束恢复方法 (断线重连的时候用)
function FsyncElement:LogicMapEndRecover()
    FsyncElement.super:LogicMapEndRecover(self)
end
-- 所有的组件恢复完成
function FsyncElement:LogicMapAllComponentRecoverComplete()
    -- cs_coroutine.start(function()
    --     coroutine.yield(CS.UnityEngine.WaitForSeconds(2))

    -- end)

    -- if self.isNeedKaiJuTip then
    --     self.isNeedKaiJuTip = false
    --     self:showKaijudituTip()
    -- end
end

-- 收到Trigger事件
function FsyncElement:OnReceiveTriggerEvent(interfaceId)
end
-- 收到GetData事件
function FsyncElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end
------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function FsyncElement:Exit()
    FsyncElement.super.Exit(self)
end

return FsyncElement

