---
---  Author: 【李阳】
---  AuthorID: 【230054】
---  CreateTime: 【2024-12-19 15:41:46】
--- 【FSync】
--- 【头顶血条】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_489ca99e_e0fd_4a4d_bd2e_fdb4112254f7 : WorldBaseElement
local FsyncElement = class("fsync_489ca99e-e0fd-4a4d-bd2e-fdb4112254f7", WBElement)

local uaddress = "958181735551057_v1/assets/Prefabs/root.prefab"

local Color = CS.UnityEngine.Color
---@param worldElement CS.Tal.framesync.WorldElement
function FsyncElement:initialize(worldElement,hideNameCanvas)
    FsyncElement.super.initialize(self, worldElement)
    -- 订阅KEY消息

    -- 使用方式如下
    -- local testInfo = {{
    --     uuid = App.Uuid,  --需要设置血条的uuid
    --     health = 0.5,    --血条值 0-1
    --     color = Color.red --血条颜色
    -- }}
    -- self:Fire("SetHealthUI", testInfo)

    self.hideNameCanvas = hideNameCanvas

    self:InitEvent()

    self:LoadRemoteUaddress(uaddress, function(success, prefab)

        if success then
            local go = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform)
            go.name = "爪爪iconUI"

            self.healthUI = go
            self.healthUI.gameObject:SetActive(false)

        end

        self.initUI = true
    end)
end

function FsyncElement:InitEvent()

    self:Watch("SetHealthUI", function(key, value)

        self:WaitUntilExcute(function()
            return self.initUI
        end, function()
            local data = value[0]
            self:SetHealth({
                uuid = data.uuid,
                health = data.health,
                color = data.color,
                max = data.max
            })
        end)

    end)

end

function FsyncElement:SetHealth(data)
    local uuid = data.uuid
    local health = data.health
    local color = data.color
    local lineVisiable = data.lineVisiable
    local starVisiable = data.starVisiable
    local max = data.max

    if self.healthData == nil then
        self.healthData = {}
    end


    if uuid == nil then
        g_LogError("[Error][FsyncElement] SetHealth: uuid is nil.")
        return
    end

    g_Log("设置血量",table.dump(data))

    -- 更新缓存的数据
    if self.healthData[uuid] == nil then
        self.healthData[uuid] = {}
    end

    if health ~= nil then
        self.healthData[uuid].health = health
        self.healthData[uuid].color = color
    end
    if lineVisiable ~= nil then
        self.healthData[uuid].lineVisiable = lineVisiable
    end
    if starVisiable ~= nil then
        self.healthData[uuid].starVisiable = starVisiable
    end
    if max ~= nil then
        self.healthData[uuid].max = max
    end

    -- 重新赋值
    health = self.healthData[uuid].health
    color = self.healthData[uuid].color
    lineVisiable = self.healthData[uuid].lineVisiable
    starVisiable = self.healthData[uuid].starVisiable
    max = self.healthData[uuid].max

    local setHealth = function(go, health, color, lineVisiable, starVisiable, max)
        if go == nil or go:IsNull() then
            return
        end
        if max == nil then
            max = 100
        end

        go.gameObject:SetActive(true)
        if health ~= nil then
            go.transform:Find("progress/circle"):GetComponent(typeof(CS.UnityEngine.UI.Image)).color = color
            go.transform:Find("progress/circle"):GetComponent(typeof(CS.UnityEngine.RectTransform)).sizeDelta = Vector2(
                158.382 * health, 16)
        end
        if lineVisiable ~= nil then
            go.transform:Find("icon/1").gameObject:SetActive(lineVisiable)
        end
        if starVisiable ~= nil then
            go.transform:Find("icon/2").gameObject:SetActive(starVisiable)
        end

        local count = math.floor(max / 20)
        local content = go.transform:Find("progress/content")
        local tmp = content:GetChild(0)
        tmp.gameObject:SetActive(false)
        local childChout = content.childCount
        if childChout - 1 ~= count then
            local needRemove = {}

            for i = 1, childChout - 1, 1 do
                local child = content:GetChild(i)
                needRemove[i] = child
            end

            for k, v in pairs(needRemove) do
                GameObject.Destroy(v.gameObject)
            end
            for i = 1, count do
                local child = GameObject.Instantiate(tmp.gameObject)
                child.transform:SetParent(content)

                child.transform.localScale = Vector3(1, 1, 1)
                child.transform.localPosition = Vector3(0, 0, 0)
                child.transform.localRotation = Quaternion.Euler(0, 0, 0)
                child.gameObject:SetActive(true)
            end

            content:GetChild(content.childCount - 1):GetChild(0).gameObject:SetActive(false)
        end

    end
    self:AsyncGetAvatar(uuid, AvatarLoadType.AllLoaded, function()
        local avatar = self:GetAvatarByUUID(uuid)
        if avatar then
            if self.healthUIMap == nil then
                self.healthUIMap = {}
            end

            local go = self.healthUIMap[uuid]
            if go == nil or go:IsNull() then
                self:FindInAllUntil(avatar.BodyTrans, "RoleCanvas", function(go)

                    local healthGo = GameObject.Instantiate(self.healthUI.gameObject)
                    healthGo.transform:SetParent(go.transform)
                    healthGo.transform.localScale = Vector3(0.5, 0.5, 0.5)
                    healthGo.transform.localPosition = Vector3(0, 0, 0)
                    healthGo.transform.localRotation = Quaternion.Euler(0, 180, 0)
                    self.healthUIMap[uuid] = healthGo
                    healthGo.transform:Find("icon/1").gameObject:SetActive(false)
                    healthGo.transform:Find("icon/2").gameObject:SetActive(false)

                    setHealth(healthGo, health, color, lineVisiable, starVisiable, max)

                end)
            else
                setHealth(go, health, color, lineVisiable, starVisiable, max)
            end

        end
    end)

end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function FsyncElement:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function FsyncElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:AvatarCreated(avatar)
    if self.hideNameCanvas then
        avatar.OnReLoadAvatarComplete:connect(function(firstLoad, go)
            local roleCanvas = avatar.VisElement.transform:Find("__Body/Character/RoleCanvas")
            if roleCanvas then
                -- 查找roleCanvas所有子节点
                local childCount = roleCanvas.childCount
                for i = 0, childCount - 1 do
                    local child = roleCanvas:GetChild(i)
                    if child then
                        child.gameObject:SetActive(false)
                    end
                end

            end
        end)
    end
end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function FsyncElement:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function FsyncElement:LogicMapStartRecover()
    FsyncElement.super:LogicMapStartRecover()
    -- TODO
end
-- 结束恢复方法 (断线重连的时候用)
function FsyncElement:LogicMapEndRecover()
    FsyncElement.super:LogicMapEndRecover(self)
    -- TODO
end
-- 所有的组件恢复完成
function FsyncElement:LogicMapAllComponentRecoverComplete()
end

-- 收到Trigger事件
function FsyncElement:OnReceiveTriggerEvent(interfaceId)
end
-- 收到GetData事件
function FsyncElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function FsyncElement:Exit()
    FsyncElement.super.Exit(self)
end

return FsyncElement

