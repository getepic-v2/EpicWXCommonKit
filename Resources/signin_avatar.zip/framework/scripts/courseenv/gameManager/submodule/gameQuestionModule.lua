--- 游戏答题模块


local questionPanel = require("scripts/courseenv/gameManager/submodule/element/bottomQuestionElement")
---@type EventSubscribe
local EventSubscribe  = require("event_subscribe")

---@class GameQuestionModule 游戏答题模块
local GameQuestionModule = {}


--- 初始化游戏答题模块
function GameQuestionModule:Init()
    self.gameQuestionModule = nil
    self.questionManager = CourseEnv.BaseBusinessManager:GetQuestionManager()
    self.commonService = App:GetService("CommonService")
    self.observerService = CourseEnv.ServicesManager:GetObserverService()

    local questionTypeList = {
        {
            questionType = "51",
            questionCount = "50"
        }
    }

    self.questionManager:SetConfig(questionTypeList , 1)

end

--- 初始化问题面板
---@param config table 配置信息，结构如下：
---{
---    showEnergy = false,   -- 是否显示能量条
---    curEnergy = 30,    -- 能量初始值
---    maxEnergy = 100,   -- 能量上限
---    energyDecrease = 1, -- 衰减值 每秒掉多少能量
---    energyAdd = 20,      -- 答题后加多少能量
---    showBarrage = false, -- 是否显示弹幕
---}
function GameQuestionModule:InitQuestionPanel(config)
    CourseEnv.ServicesManager.Gate:AddElementType("gameQuestionPanel", questionPanel)
    local dict = CS.Tal.framesync.VisualProperty();
    dict:Add("type", "gameQuestionPanel")
    self.ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.one, Vector3.one,
        Vector3.one, "WorldElement")
    self.ret.curtainToggle = config.showBarrage and "True" or "False"

    self.questionConfig = config

    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_INIT_SLIDER", {
        notShow = not config.showEnergy, --是否显示能量条
        numerator = config.curEnergy,  --分子
        denominator = config.maxEnergy  --分母
    })

    self.maxEnergy = config.maxEnergy
    self.curEnergy = config.curEnergy

    self.energyChangeEvent = EventSubscribe:new()
    self.energyChangeEvent(self.curEnergy)
end

--- 获取当前能量值
---@return number 当前能量值
function GameQuestionModule:GetCurEnergy()
    return self.curEnergy
end

--- 设置当前能量值
---@param energy number 要设置的能量值（会自动限制在0到最大能量值之间）
function GameQuestionModule:SetCurEnergy(energy)

    if energy == self.curEnergy then
        return
    end

    energy = math.min(math.max(energy, 0), self.maxEnergy)

    self.curEnergy = energy
    self.energyChangeEvent(self.curEnergy)

    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_SET_SLIDER_VALUE", {
        numerator = self.curEnergy,
        denominator = self.maxEnergy
    })
end

--- 增加能量值
---@param energy number 要增加的能量值（可为负数，表示减少）
function GameQuestionModule:AddEnergy(energy)
    self:SetCurEnergy(self.curEnergy + energy)
end

--- 显示问题面板
--- 开始能量衰减计时，并监听答题结果
function GameQuestionModule:ShowQuestionPanel()

    if self.showQuestionPanel then
        return
    end

    self.showQuestionPanel = true

    self.cor = self.commonService:StartCoroutine(function()
        while self.showQuestionPanel do
            self.commonService:YieldSeconds(1)
            self:SetCurEnergy(math.max(self.curEnergy - self.questionConfig.energyDecrease, 0))
            if self.curEnergy >= 0 then
                -- self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_ADD_SLIDER_VALUE", {
                --     addValue = self.questionConfig.energyDecrease * -1
                -- })

                -- self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_SET_SLIDER_VALUE", {
                --     numerator = self.curEnergy,
                --     denominator = self.maxEnergy
                -- })
            end
        end
    end)

    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", {
        status = 1,
        awardCount = 1,
        showAwardType = 2,
        callBack = function(score, isFinal, isNoSpeaking, isPass)
            
            if isFinal then
                if isPass then
                    -- 答题通过
                    -- self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_ADD_SLIDER_VALUE", {
                    --     addValue = self.questionConfig.energyAdd
                    -- })
                    self:SetCurEnergy(math.min(self.curEnergy + self.questionConfig.energyAdd, self.maxEnergy))
                --     self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_SET_SLIDER_VALUE", {
                --     numerator = self.curEnergy,
                --     denominator = self.maxEnergy
                -- })
                end
            else
            end
        end
    })
end

--- 隐藏问题面板
--- 停止能量衰减计时
function GameQuestionModule:HideQuestionPanel()
    if not self.showQuestionPanel then
        return
    end

    if self.cor then
        self.commonService:StopCoroutineSafely(self.cor)
        self.cor = nil
    end

    self.showQuestionPanel = false

    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", {
        status = 2
    })
end

return GameQuestionModule