--游戏角色模块，负责管理游戏角色的血条

local avatarTopHealth = require("scripts/courseenv/gameManager/submodule/element/avatarTopHealth")

---@class GameAvatarModule : GameModule
local GameAvatarModule = {}

---初始化游戏角色血条
---@param hideNameCanvas boolean 是否隐藏名字
function GameAvatarModule:InitTopHealth(hideNameCanvas)
    CourseEnv.ServicesManager.Gate:AddElementType("avatarTopHealth", avatarTopHealth)

    local dict = CS.Tal.framesync.VisualProperty();
    dict:Add("type", "avatarTopHealth")
    self.avatarTopHealthEle = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.one, Vector3.one,
        Vector3.one, "WorldElement")
    self.avatarTopHealthEle.hideNameCanvas = hideNameCanvas
end

---设置头顶血条
---@param uuid string 角色ID
---@param health number 血量
---@param color CS.UnityEngine.Color 颜色
function GameAvatarModule:SetAvatarTopHealth(uuid, health, color)

    -- 加上检查
    if not uuid or not health or not color then
        g_LogError("设置头顶血条失败，参数错误")
        return
    end

    local testInfo = {
        uuid = uuid, -- 需要设置血条的uuid
        health = health, -- 血条值 0-1
        color = color -- 血条颜色
    }

    g_Log("设置血量",table.dump(testInfo))
    self.avatarTopHealthEle:Fire("SetHealthUI", testInfo)
end

return GameAvatarModule

