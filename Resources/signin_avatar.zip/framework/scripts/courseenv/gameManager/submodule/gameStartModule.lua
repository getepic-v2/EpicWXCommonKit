-- 游戏开局管理

local element =  require("scripts/courseenv/gameManager/submodule/element/gameStartElement")
---@type EventSubscribe
local EventSubscribe  = require("event_subscribe")

---@class GameStartModule 游戏开局模块
local GameStartModule = {}

---初始化游戏开局模块
---@param config table 配置参数
---   - isNeedKaiJuTip boolean 是否显示开局提示
---   - gameMode number 游戏模式，1=单人一队，2=双人一队，3=四人一队
function GameStartModule:InitConfig(config)
    self.config = config
    
    -- 创建事件订阅对象
    self.events = {}
    self.events.onStartCountDown = EventSubscribe:new()
    self.events.onStartShowTitle = EventSubscribe:new()
    self.events.onReadyStart = EventSubscribe:new()
    self.events.onReadyStartResume = EventSubscribe:new()
    self.events.onGameOver = EventSubscribe:new()
    
    CourseEnv.ServicesManager.Gate:AddElementType("GameStartModule", element)
    local dict = CS.Tal.framesync.VisualProperty();
    dict:Add("type", "GameStartModule")
    self.ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.one, Vector3.one,
        Vector3.one, "WorldElement")

    -- 初始化配置，config包含：
    -- isNeedKaiJuTip: 是否显示开局提示（boolean类型）
    -- gameMode: 游戏模式，1=单人一队，2=双人一队，3=四人一队（number类型）
    self.ret:InitConfig(config)

    -- 处理组件触发的事件
    self.ret.Trigger = function(receiver, interfaceId, args)
        -- interfaceId事件处理
        if interfaceId == "startCountDown" then
            -- 开始倒计时事件处理
            g_Log("开始倒计时")
            -- 通过EventSubscribe触发事件
            self.events.onStartCountDown()
            
        elseif interfaceId == "startShowTitle" then
            -- 显示开局标题事件处理
            g_Log("显示开局标题")
            -- 通过EventSubscribe触发事件
            self.events.onStartShowTitle()
            
        elseif interfaceId == "redayStart" then
            -- 准备开始游戏事件处理
            g_Log("准备开始游戏", args and args.redayStartFrameIndex or "")
            -- 通过EventSubscribe触发事件，传递参数
            self.events.onReadyStart(args)
            
        elseif interfaceId == "redayStartIsResume" then
            -- 恢复开始游戏事件处理（断线重连）
            g_Log("恢复开始游戏", args and args.redayStartFrameIndex or "")
            -- 通过EventSubscribe触发事件，传递参数
            self.events.onReadyStartResume(args)
            
        elseif interfaceId == "badGame" then
            -- 游戏结束事件处理
            g_Log("游戏结束")
            -- 通过EventSubscribe触发事件
            self.events.onGameOver()
            
        end
    end
end

---注册开始倒计时事件监听
---@param callback function 回调函数
---@return Subscribe 订阅对象，可用于取消订阅
function GameStartModule:OnStartCountDown(callback)
    return self.events.onStartCountDown:connect(callback)
end

---注册显示开局标题事件监听
---@param callback function 回调函数
---@return Subscribe 订阅对象，可用于取消订阅
function GameStartModule:OnStartShowTitle(callback)
    return self.events.onStartShowTitle:connect(callback)
end

---注册准备开始游戏事件监听
---@param callback function(args:table) 回调函数，args包含redayStartFrameIndex
---@return Subscribe 订阅对象，可用于取消订阅
function GameStartModule:OnReadyStart(callback)
    return self.events.onReadyStart:connect(callback)
end

---注册恢复游戏事件监听（断线重连）
---@param callback function(args:table) 回调函数，args包含redayStartFrameIndex
---@return Subscribe 订阅对象，可用于取消订阅
function GameStartModule:OnReadyStartResume(callback)
    return self.events.onReadyStartResume:connect(callback)
end

---注册游戏结束事件监听
---@param callback function 回调函数
---@return Subscribe 订阅对象，可用于取消订阅
function GameStartModule:OnGameOver(callback)
    return self.events.onGameOver:connect(callback)
end

return GameStartModule
