----
-- @file: game_manager.lua
-- @brief: 游戏管理器，负责初始化和管理各个游戏模块
-- @date: 2023-06-15
----

---@diagnostic disable: undefined-global

---@class GameModule


---@type GameDescriptionModule
local gameDescriptionModule = require("scripts/courseenv/gameManager/submodule/gameDescriptionModule")
---@type GameQuestionModule
local gameQuestionModule = require("scripts/courseenv/gameManager/submodule/gameQuestionModule")
---@type GameResultModule
local gameResultModule = require("scripts/courseenv/gameManager/submodule/gameResultModule")
---@type GameSkillUIModule
local gameSkillUIModule = require("scripts/courseenv/gameManager/submodule/gameSkillUIModule")
---@type GameStartModule
local gameStartModule = require("scripts/courseenv/gameManager/submodule/gameStartModule")
---@type GameAvatarModule
local gameAvatarModule = require("scripts/courseenv/gameManager/submodule/gameAvatarModule")

---@class GameModuleManager
---@field private gameModules table 游戏模块集合
---@field private ret any 模块创建返回值
GameModuleManager = {}

local self = GameModuleManager

---初始化游戏模块管理器
function GameModuleManager:Init()
    self.gameModules = {}

    -- 这些默认初始化
    gameQuestionModule:Init()
    gameResultModule:Init()

    self:InitModSubscripts()
end

---初始化MOD订阅脚本
---加载MOD目录下的所有自定义脚本并创建相应元素
function GameModuleManager:InitModSubscripts()
    local path = App:GetPackageCachePath(App.ModName) .. "/scripts/subScripts"
    local dir = CS.System.IO.Directory
    local pathService = CourseEnv.ServicesManager:GetPathService()

    if dir.Exists(path) then
        local files = dir.GetFiles(path)
        for i = 0, files.Length - 1 do
            local file = files[i]
            if string.find(file, ".lua") then
                file = pathService:GetFileNameWithoutExtension(files[i])

                local mFile = App.ModName.."/scripts/subScripts/"..file
                local element = require(mFile)
                CourseEnv.ServicesManager.Gate:AddElementType(file, element)
                local dict = CS.Tal.framesync.VisualProperty();
                dict:Add("type", file)
                self.ret = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.one, Vector3.one,
                    Vector3.one, "WorldElement")
            end
        end
    end
end

---初始化游戏描述模块
---@param config table 配置信息
---@return GameDescriptionModule  返回初始化后的游戏描述模块
function GameModuleManager:InitGameDescriptionModule(config)
    gameDescriptionModule:Init(config)
    return gameDescriptionModule
end

---获取游戏描述模块
---@return GameDescriptionModule 游戏描述模块实例
function GameModuleManager:GetGameDescriptionModule()
    return gameDescriptionModule
end

---获取游戏问题模块
---@return GameQuestionModule 游戏问题模块实例
function GameModuleManager:GetGameQuestionModule()
    return gameQuestionModule
end

---获取游戏技能UI模块
---@return GameSkillUIModule 游戏技能UI模块实例
function GameModuleManager:GetGameSkillUIModule()
    return gameSkillUIModule
end

---获取游戏结果模块
---@return GameResultModule 游戏结果模块实例
function GameModuleManager:GetGameResultModule()
    return gameResultModule
end

---获取游戏开始模块
---@return GameStartModule 游戏开始模块实例
function GameModuleManager:GetGameStartModule()
    return gameStartModule
end

---获取游戏角色模块
---@return GameAvatarModule 游戏角色模块实例
function GameModuleManager:GetGameAvatarModule()
    return gameAvatarModule
end

return GameModuleManager
