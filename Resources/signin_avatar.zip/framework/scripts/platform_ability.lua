---
--- Desc: 统计设备能力
--- Created: lifusong
--- DateTime: 2022-07-25 17:39
---

local class = require("middleclass")
---@type CS.UnityEngine.TextureFormat
local TextureFormat = CS.UnityEngine.TextureFormat
---@type CS.UnityEngine.SystemInfo
local SystemInfo = CS.UnityEngine.SystemInfo
local LogBridge = require(MAIN_SCRIPTS_LOC.."common/log_bridge")
local json = require("nextjson")

---@class PlatformAbility
local PlatformAbility = class("PlatformAbility")

function PlatformAbility:Start()
    local params = {}
    params.isSupportAstc = self:IsSupportASTC()
    LogBridge.SNoStatisticsWithParam("PlatformAbility", params)
end

function PlatformAbility:IsSupportASTC()
    local isSupport = false
    for i = TextureFormat.ASTC_RGB_4x4:GetHashCode(), TextureFormat.ASTC_RGBA_12x12:GetHashCode(), 1 do
        isSupport = SystemInfo.SupportsTextureFormat(i)
        if not isSupport then
            print("PlatformAbility not support " .. tostring(i))
            return isSupport
        end
    end
    return isSupport
end

return PlatformAbility
