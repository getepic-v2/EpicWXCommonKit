-- layer管理类
-- 目前player、teacherPlayer、NPC、互补碰撞
local LayerInfo = {
    [0]= "Default",
    [1]= "TransparentFX",
    [2]= "Ignore Raycast",
    [3]= "RayLayer",
    [4]="Water",
    [5]="UI",
    [6]="tian",
    [7]="Element",
    [8]="cow",
    [9]="target",
    [10]="wall",
    [11]="ground",
    [12]="foodArse",
    [13]="dinner",
    [14]="areaTrigger",
    [15]="Player",
    [16]="CoordinateAxis",
    [17]="GUIServices",
    [18]="PhotoLayer",
    [19]="TeacherPlayer", -- 和老师不碰撞
    [20]="NPC", -- NPC玩家 和老师、玩家都不碰撞 -- 所有CharacterController都是NPC
    [21]="UserLayer21",
    [22]="UserLayer22",
    [23]="UserLayer23",
    [24]="UserLayer24",
    [25]="UserLayer25",
    [26]="UserLayer26",
    [27]="UserLayer27",
    [28]="UserLayer28",
    [29]="UserLayer29",
    [30]="UserLayer30",
    [31]="UserLayer31"
}

LayerInfo.Apply = function()
    for i = 0, 31, 1 do
        if i == 14 or i == 25 then
            CS.UnityEngine.Physics.IgnoreLayerCollision(25,i,false)
        else
            CS.UnityEngine.Physics.IgnoreLayerCollision(25,i,true)
        end
        CS.UnityEngine.Physics.IgnoreLayerCollision(13,i,i ~= 13)
    end
    g_Log("LayerInfo.Apply")
end

--CS.UnityEngine.Physics.IgnoreLayerCollision(15,15,false)
--
return LayerInfo