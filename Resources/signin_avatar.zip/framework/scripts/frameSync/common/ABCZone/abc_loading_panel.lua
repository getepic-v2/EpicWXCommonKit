local window = require "ui/window"
local class = require('middleclass')
local loading_panel = class("loading_panel", window)

function loading_panel:initialize()
    loading_panel.super.initialize(self, "loading_panel",
        RESOURCE_LOC .. "/assets/prefabs/loadingPanel/loading_panel", WRenderType.Notify)
end

function loading_panel:OnCreate()

    self.root = self.UI:GetUIObject()
    
end


function loading_panel:OnBeforeShow()
    self.root.gameObject:SetActive(false)
end


function loading_panel:ShowLoading(show)
    if show then
        self.root.gameObject:SetActive(true)
    else
        self.root.gameObject:SetActive(false)
    end
end


return loading_panel