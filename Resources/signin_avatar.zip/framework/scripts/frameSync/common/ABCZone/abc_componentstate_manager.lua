local class = require('middleclass')
local manager = class("stateManager")

local TAG = "状态管理"

function manager:initialize()
    self.inited = false
    self.conflictMap = {}
    self.userStateMap = {}
end

function manager:RegisterConfig(config)
    for i, v in ipairs(config) do
        local name = "EVENT_BUSINESS_CONFLICT_" .. v.BusinessName
        local conflict = v.ConflictBusiness
        self.conflictMap[name] = conflict

        -- g_Log(TAG,"设置配置",name,table.dump(conflict))
    end
    self.inited = true
end

function manager:CanExcute(businessId, uid)
    if not string.startswith(businessId, "EVENT_BUSINESS_CONFLICT_") then
        businessId = "EVENT_BUSINESS_CONFLICT_" .. businessId
    end

    local userState = self.userStateMap[uid]
    if not userState then
        return true
    end

    local conflict = self.conflictMap[businessId]
    if not conflict then
        return true
    end

    -- g_Log(TAG,"冲突检测",businessId,uid,table.dump(userState),table.dump(conflict))
    for _, v in ipairs(conflict) do
        if not string.startswith(v, "EVENT_BUSINESS_CONFLICT_") then
            v = "EVENT_BUSINESS_CONFLICT_" .. v
        end

        if userState[v] == true then
            return false
        end
    end

    return true
end

function manager:StartBusiness(businessId, uid)
    if not string.startswith(businessId, "EVENT_BUSINESS_CONFLICT_") then
        businessId = "EVENT_BUSINESS_CONFLICT_" .. businessId
    end

    local can = self:CanExcute(businessId, uid)
    if not can then
        g_Log(TAG, "业务冲突", businessId, uid)
        return
    end

    local userState = self.userStateMap[uid]
    if not userState then
        userState = {}
        self.userStateMap[uid] = userState
    end

    userState[businessId] = true
    g_Log(TAG, "开始业务", businessId, uid, table.dump(userState))
end

function manager:StopBusiness(businessId, uid)
    if not string.startswith(businessId, "EVENT_BUSINESS_CONFLICT_") then
        businessId = "EVENT_BUSINESS_CONFLICT_" .. businessId
    end

    local userState = self.userStateMap[uid]
    if not userState then
        return
    end

    userState[businessId] = false

    g_Log(TAG, "结束业务", businessId, uid, table.dump(userState))
end

return manager
