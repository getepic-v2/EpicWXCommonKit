local window = require "ui/window"
local class = require('middleclass')
local download_panel = class("download_panel", window)
local EventSubscribe = require("event_subscribe")


function download_panel:initialize()
    download_panel.super.initialize(self, "download_panel",
        RESOURCE_LOC .. "/assets/prefabs/loadingPanel/download_panel", WRenderType.Notify)

    self.OnClosed = EventSubscribe:new()
    self.progress = 0
    self.size = 0
end

function download_panel:OnCreate()

    self.root = self.UI:GetUIObject()

    self.closeBtn = self.root.transform:Find("Image/closeBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))

    self.progressBg = self.root.transform:Find("Image/progressBg")
    self.progressView = self.root.transform:Find("Image/progressBg/progress")

    self.text = self.root.transform:Find("Image/Text"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

    self.bgRect = self.progressBg:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.progressRect = self.progressView:GetComponent(typeof(CS.UnityEngine.RectTransform))

    App:GetService("CommonService"):AddEventListener(self.closeBtn, "onClick", function()
        self:ShowLoading(false)
        self.OnClosed()
    end)
end


function download_panel:OnBeforeShow()
    self.root.gameObject:SetActive(false)
end


function download_panel:ShowLoading(show)
    if show then
        self.root.gameObject:SetActive(true)
        self.text.text = ""
        self.progressRect.sizeDelta = CS.UnityEngine.Vector2(self.bgRect.sizeDelta.x * 1, self.progressRect.sizeDelta.y)
    else
        self.root.gameObject:SetActive(false)
        self.progress = 0
        self.size = 0
        self.text.text = ""
    end
end

function download_panel:UpdateProgress(progress,size)
    if progress == self.progress then
        return
    end

    if progress < 0.1 then
        progress = 0.1
    end

    if progress >= 1 then
        progress = 0.99
    end

    self.progress = progress
    self.size = size

    local totalMb = size/1024/1024
    local progressStr = string.format("%.2f/%.2fM",progress*totalMb,totalMb)
    self.text.text = progressStr

    self.progressRect.sizeDelta = CS.UnityEngine.Vector2(self.bgRect.sizeDelta.x * progress, self.progressRect.sizeDelta.y)

end


return download_panel