local window = require "ui/window"
local class = require("middleclass")
local WRenderType = CS.Com.Tal.Unity.UI.WRenderType
local EventSubscribe = require("event_subscribe")
local Json = require("nextjson")
local IPC = require(MAIN_SCRIPTS_LOC.."ipc")
local cs_coroutine = require("common/cs_coroutine")
local explainSyncCamera = class('explain_sync_camera')
local ipcLog = require(MAIN_SCRIPTS_LOC.."IPC_log")
local focusAwatarCamera = require(MAIN_SCRIPTS_LOC.."frameSync/teacherCalled/fsync_focus_awatar_camera")

-- 方案： 老师获取摄像机参数 广播给学生用于同步
-- 学生创建摄像机 同步老师发来的相机参数
-- 老师发送相机参数
-- 学生接受参数 更新摄像机

-- 服务端召集模式状态码
local ZHAOJIGENSUI = 100002
-- 服务端讲解模式状态码
local JIANGJIEMOSHI = 100001
-- 同步讲解模式状态 给服务端 
local JIANGJIEMOSHISTATESERVER = 1000018
-- 同步讲解模式状态给 StatusManagerService服务
local JIANGJIEMOSHISTATE = 100001
-- 关闭讲解模式 给服务端
local JIANGJIEMOSHISTOP = 1000019
-- 讲解模式实例
function explainSyncCamera:initialize()
    -- self.playerService = App:GetService("PlayerService")
    self.teacherService = App:GetService("TeacherService")
    --self.teacherCalledService = TeacherService
    -- self.teacherCalledService = App:GetService("TeacherCalledService")
    -- self.teacherService:registerDropLine(self)

    self.teacherCameTransform = 0
    -- 当前是否为召集模式状态中
    self.isFocus = false
    -- 召集模式开关
    self.zhaojiswitch = false
    -- 如果为老师逻辑
    if App.Info.role == 0 then
        -- 同步当前状态 接受召集模式回调 广播摄像机参数

        --protalStatus 服务端存错的是否是讲解模式状态
         self.teacherService.msg_recv:connect(function(k,v)
            if k == tostring(JIANGJIEMOSHISTATESERVER) and self.teacherService.historyMsg == 'true' then
                if tonumber(v) == 1 then
                    self.isFocus = true
                    -- 如果是讲解模式 广播老师相机信息
                    self:updataCamera()
                    debug_print("讲解模式----接收到 召集模式回调--初始化----上次同步状态为1   开启同步视角-->")
                end
            end
        end)

        --local protalStatus = self.teacherService.element:GetProperty(tostring(JIANGJIEMOSHISTATESERVER))
        --print("liulin--protalStatus",protalStatus)
        --if tonumber(protalStatus) == 1 then
        --    self.isFocus = true
        --    -- 如果是讲解模式 广播老师相机信息
        --    self:updataCamera()
        --    debug_print("讲解模式----接收到 召集模式回调--初始化----上次同步状态为1   开启同步视角-->")
        --end
        ----教师同步状态给教师端用于展示ui开关 StatusManagerService
        --self.statusService = App:GetService("StatusManagerService")
        --self.statusService:setStatus(JIANGJIEMOSHISTATE, tonumber(protalStatus) or tonumber(0))
        -- fix：没有注释全
        --debug_print("讲解模式----接收到 召集模式回调--初始化----上次同步状态-->", tonumber(protalStatus) or tonumber(0))
        debug_print("讲解模式----接收到 召集模式回调--初始化----上次同步状态-->")
        --  接受召集模式回掉 广播参数
        self.teacherService.currentStatusTofollow:connect(function(curStatus)
            g_Log("讲解模式----接收到 召集模式回调- 跟随回调---开启状态---->", curStatus, self.isFocus)
            -- 教师点击之后触发 
            -- ture 开始同步信息
            if (curStatus and self.isFocus == true) then
                debug_print("讲解模式----接收到 召集模式回调--初始化----恢复了")
                -- 同步服务器老师状态
                self.teacherService:send({ code = tostring(JIANGJIEMOSHISTATESERVER), extra = tostring("1") })
                -- self.statusService:setStatus(JIANGJIEMOSHISTATE,tonumber(1))
                self:updataCamera()
            end
        end)

        -- 老师接受ipc消息
        IPC.OnIpcCallCompleted:connect(function(data)
            if not data or not data.activeid or not data.type then
                return
            end
            local activeid_ = tonumber(data.activeid)
            local type_ = tonumber(data.type)
            -- 如果是讲解模式 走触发逻辑
            if activeid_ == JIANGJIEMOSHI and (type_ == 0 or type_ == 1) then
                local msg_ = { code = activeid_, type = type_ }
                -- 同步相机控制器 参入开启关闭参数
                self:SyncCameracontroller(msg_)
            end
        end)
    else
        --上来就创建
        self:GetCameraController()
        -- 处理三分钟掉线 
        -- 如果是学生 监听召集模式回调 
        -- 如果是关闭操作 服务器同步关闭讲解模式 自身切换到main相机 如果不是讲解模式下收到召集回调 也充置服务器状态和相机状态也不影响
        self.teacherService.currentStatusTofollow:connect(function(curStatus)
            if (curStatus) then
                print("讲解模式----  学生--接收到 --召集模式回掉- true")
            else
                g_Log("讲解模式----  学生--接收到 --召集模式回掉- false", self.isFocus)
                self.teacherService:send({ code = tostring(JIANGJIEMOSHISTATESERVER), extra = tostring("0") })
                self:FocusCamera1to3()
            end

        end)

    end

    self:OnCreate()
    -- test
    -- explainSyncCamera.super.initialize(self, "teacherPanel", "dynasty/assets/prefabs/teacher_panel", WRenderType.Notify)
    -- test end

end
function explainSyncCamera:OnCreate()
    -- 本地测试触发按钮

    -- test
    -- if App.Info.role == 0 then

    --     self.focusBtn = self.UI:Find("Button", "focusBtn")
    --     self.focusBtn:AddClick(function()
    --         --广播给学生 同步视角
    --         debug_print("广播给学生 同步视角：")
    --         local msg_ = {code = JIANGJIEMOSHI,type = 1}
    --         self:SyncCameracontroller(msg_)
    --     end)
    --     self.setPosition = self.UI:Find("Button","setposition")
    --     self.setPosition:AddClick(function()
    --         local msg_ = {code = JIANGJIEMOSHI,type = 0}
    --         self:SyncCameracontroller(msg_)
    --     end)
    -- end

    -- test end

    -- 学生端监听服务端来的消息
    if App.Info.role ~= 0 then
        self.teacherService.msg_recv:connect(function(k, v)
            local type = tonumber(v)
            local activeid = tonumber(k)
            -- g_LogColorMsg("focus_camera-teacherCameTransform--activeid:"..activeid )
            if activeid == JIANGJIEMOSHI and self.teacherService.element:GetProperty(tostring(JIANGJIEMOSHISTATESERVER)) == "1" then
                debug_print("接收到教师摄像机参数：".."v-->"..v)
                ipcLog.baseIPCLog("001", "讲解模式", 1)
                self:initCamera()
                self:setCameraTransform(v)
                self.teacherService.teach_mode({ code = ZHAOJIGENSUI, tipStr = 1 })
            end

            if activeid == JIANGJIEMOSHISTOP then
                g_Log("讲解模式----接收到 --关闭了->")
                ipcLog.baseIPCLog("001", "讲解模式", 2)
                cs_coroutine.start(function()
                    --todo:延时原因：老师旋转视角后立马解散，旋转视角的消息可能后到，造成相机又变成讲解模式了
                    coroutine.yield(CS.UnityEngine.WaitForSeconds(2))
                    self.initCameraFlag = false
                end)
                self:showLongtermToastUI(false)
                self:FocusCamera1to3()

            end
        end)
    end

end
-- 讲解模式控制器 接受打开关闭参数
function explainSyncCamera:SyncCameracontroller(msg_)
    debug_print("讲解模式----接收到 explainSyncCamera---msg->", table.dump(msg_))
    if tonumber(msg_.type) == 1 then
        self.isFocus = true
    end
    if tonumber(msg_.type) == 0 then
        self.isFocus = false
    end

    if self.isFocus then
        self:start()
    else
        self:stop()
    end
end

-- 开启讲解模式 
function explainSyncCamera:start()
    if App.Info.role ~= 0 then
        --学生不触发
        return
    end
    -- 调用 跟随模式 启动 ->监听跟随模式的回调 =》currentStatusTofollow
    local msg_ = { code = ZHAOJIGENSUI, type = 1 }
    if (self.zhaojiswitch == false) then
        debug_print("讲解模式----发送 teacherCalledService:TeachMode ->", table.dump(msg_))
        self.teacherService.teach_mode(msg_)
        self.zhaojiswitch = true
    end
end
-- 更新相机参数
function explainSyncCamera:updataCamera()
    -- 启动协程向学生广播教师相机参数
    self.updateCoroutine = cs_coroutine.start(function()
        while self.isFocus do
            -- coroutine.yield(CS.UnityEngine.WaitForEndOfFrame())
            coroutine.yield(CS.UnityEngine.WaitForSeconds(0.4))
            self:toServerSend()
        end
    end)
end
-- 停止讲解模式 关闭协程
function explainSyncCamera:stop()
    if self.isFocus == true then
        return
    end
    -- 调用 跟随模式 关闭
    self.zhaojiswitch = false
    local msg_ = { code = ZHAOJIGENSUI, type = 0 }
    self.teacherService.teach_mode(msg_)
    -- 添加时间戳 强制数据更新
    local nowTime = os.time()
    -- 通知学生关闭跟随视角功能
    self.teacherService:send({ code = tostring(JIANGJIEMOSHISTOP), extra = tostring(nowTime) })
    -- 向服务器同步关闭状态
    self.teacherService:send({ code = tostring(JIANGJIEMOSHISTATESERVER), extra = tostring("0") })
    --  self.statusService:setStatus(JIANGJIEMOSHISTATE,tonumber(0))
    debug_print("讲解模式----广播消息---stop")
    -- self.playerService:FocusCamera1to3()
    -- 关闭协程
    if self.updateCoroutine then
        self.updateCoroutine:Stop()
        self.updateCoroutine = nil
    end
    -- if self.updateCoroutineTwo then
    --     self.updateCoroutineTwo:Stop()
    --     self.updateCoroutineTwo = nil
    -- end
end
-- 初始化相机 废弃 
function explainSyncCamera:sendSyncCamera()
    self:getCameraTransform()
    local data = {
        x = self.teacherCameTransform.x,
        y = self.teacherCameTransform.y,
        z = self.teacherCameTransform.z
    }
    self.teacherService:send({ code = tostring(JIANGJIEMOSHIINIT), extra = Json.encode(data) })
end

-- 如果是学生创建摄像机
function explainSyncCamera:initCamera()
    -- 创建同步视角
    if not self.initCameraFlag  then
        self.initCameraFlag = true
        --展示UI
        self:showLongtermToastUI(true)
        self:FocusCameraMirrorLens()
    end
end

function explainSyncCamera:showLongtermToastUI(shouldShow)
    local UIService = App:GetService("UIService")
    if shouldShow then
        UIService:showlongToast("老师已开启讲解模式")
    else
        UIService:hidenlongToast()
    end
end
-- 老师获取摄像机参数
function explainSyncCamera:getCameraTransform()

    -- local came = GameObject.Find("Main Camera")
    -- local came =  Camera.main.transform:Find("Main Camera").gameObject
    if App.Info.role == 0 then
        local came = GameObject.Find("Camera")
        if came == nil then
            came = GameObject.Find("Main Camera")
            if came ~= nil then
                self.teacherCameTransform = came.transform
            end
        else
            self.teacherCameTransform = came.transform
        end
    end
end
-- 广播摄像机参数
function explainSyncCamera:toServerSend()
    self:getCameraTransform()
    local nowTime = os.time()
    -- 获取相机参数 
    local data = {
        x = self.teacherCameTransform.position.x,
        y = self.teacherCameTransform.position.y,
        z = self.teacherCameTransform.position.z,
        rx = self.teacherCameTransform.localEulerAngles.x,
        ry = self.teacherCameTransform.localEulerAngles.y,
        rz = self.teacherCameTransform.localEulerAngles.z,
        st = nowTime

    }
    debug_print("广播给学生 同步视角数据：" .. Json.encode(data))

    self.teacherService:send({ code = tostring(JIANGJIEMOSHI), extra = Json.encode(data) })
end

-- 学生更新同步来的摄像机参数
function explainSyncCamera:setCameraTransform(num)

    self:MirrorLensSetPosition(num)
end
-- function explainSyncCamera:drop_down()
--     -- 掉线逻辑
--     print("讲解模式----接收到 --学生掉线了->")
-- end


function explainSyncCamera:GetCameraController()
    if self.awatar_focus_camera_controller then
        return self.awatar_focus_camera_controller
    end
    -- self.awatar_focus_camera_controller = import(MAIN_SCRIPTS_LOC.."player/focus_awatar_camera"):new()
    -- self.awatar_focus_camera_controller = import("focus_awatar_camera"):new()
    self.awatar_focus_camera_controller = focusAwatarCamera:new()

    return self.awatar_focus_camera_controller
end

--第一人称 to 第三人称
function explainSyncCamera:FocusCamera1to3()
    self:GetCameraController():FocusCamera1to3()
end

--第三人称 to 第一人称
function explainSyncCamera:FocusCamera3to1()
    self:GetCameraController():FocusCamera3to1()
end

-- 镜像老师 视角 用于老师操作 让学生同步老师画面
function explainSyncCamera:FocusCameraMirrorLens()
    self:GetCameraController():FocusCameraMirrorLens()
end
-- 镜像老师 视角 更新数据
function explainSyncCamera:MirrorLensSetPosition(num)
    self:GetCameraController():MirrorLensSetPosition(num)
end
function explainSyncCamera:OnExit()

end
return explainSyncCamera