local class = require('middleclass')
local ChatUIController = class("ChatUIController")
local Util = import("../../../common/util")

function ChatUIController:initialize(gate, oldState)
    self.alreadySendMsg = false
    self.commonPanelReady = false
    self.joystickReady = false
    self.oldState = oldState -- true normal false system

    self.uiServcie = App:GetService("UIService")
    self.joystickService = App:GetService("JoyStick")

    if self.uiServcie.commonMenu then
        self.uiServcie.commonMenu.OnCreateComplete:connect(function()
            self.commonPanelReady = true
            if self:CheckStart() then
                self:SetChatStatus("commonpenl create complete!", self.recordStatus, false)
            end
        end)
    end
    
    if self.joystickService.joyPanel then 
        self.joystickService.joyPanel.OnCreateComplete:connect(function()
            self.joystickReady = true
            if self:CheckStart() then
                self:SetChatStatus("joystick create complete!", self.recordStatus, false)
            end
        end)
    end

    -- 侦听老师端开启聊一聊功能消息
    self.teacherService = App:GetService("TeacherService")
    if self.teacherService then
        -- 
        if self.teacherService.changeChatType then
            self.teacherService.changeChatType:connect(function(type)
                --normal system
                print("fzg ----- receive teacherService msg: type = " .. type .. "  recordStatus is nil: " .. tostring(self.recordStatus == nil))
                if type == "system" and self:IsOpened() then
                    self:SetChatStatus("receive teacherService!", self.recordStatus, true)
                end
            end)
        end
    end

    gate.OnCreateElement:connect(function(element)
        if element:GetProperty('type') == "avatar" then
            if element:GetProperty('uuid') == App.Uuid then
                element.OnLoadAvatarComplete:connect(function(go)
                    self:_connectTeacherAvatar()
                end)
            end
        end
    end)

    -- 侦听老师端发送的开启关闭聊一聊消息
    APIBridge.CreateService("unity.buss.parentsMeeting.switch", {}, function(res)
        print("fzg ----- receive chat switch: " .. tostring(res.status))
        self.recordStatus = res.status
        if self:CheckStart() then
            self:SetChatStatus("receive chat switch!", res.status, false)
        end
    end)
end

-- 侦听老师禁言消息
function ChatUIController:_connectTeacherAvatar()
    local elements = App:GetService("Avatar"):GetAllAvatar()
    for i = 1, #elements do
        local avatar = elements[i]
        --监听老师是否禁言
        if avatar:isTeacher() then
            print("fzg ----- get teacher avatar property: " .. avatar:GetProperty("discuss_status") .. "  isopen: " .. tostring(self:IsOpened()))
            self:_setChatBtnEnable(avatar:GetProperty("discuss_status"))
            avatar.OnLocalPropertyChanged:connect(function(k, v)
                if k == "discuss_status" then
                    print("fzg ----- receive teacher avatar property change: " .. v .. "  isopen: " .. tostring(self:IsOpened()))
                    self:_setChatBtnEnable(v)
                end
            end)
        end
    end
end

function ChatUIController:_setChatBtnEnable(type)
    if not self:IsOpened() then
        return
    end

    if type == "1" then
        --老师开启禁言，学生收到消息，按钮置灰
        self.uiServcie:SetChatBtn(false)
    elseif type == "0" then
        self.uiServcie:SetChatBtn(true)
    end
end

function ChatUIController:CheckStart()
    print("fzg ----- CheckStart!  commonPanelReady: " .. tostring(self.commonPanelReady) .. "   joystickReady: " .. tostring(self.joystickReady) .. "  recordStatus is nil: " .. tostring(self.recordStatus == nil))
    return self.commonPanelReady and self.joystickReady and (self.recordStatus ~= nil)
end

--聊一聊功能是否开启
function ChatUIController:IsOpened()
    return self.recordStatus ~= nil and self.recordStatus
end

function ChatUIController:SetChatStatus(info, status, forceSend)
    print("fzg ----- SetChatStatus: " .. info .. "   status: " .. tostring(status) .. "   forceSend: " .. tostring(forceSend))
    if status then
        -- alreadySendMsg防止重复发送 forceSend 强制发送，忽略alreadySendMsg的作用
        if not self.alreadySendMsg or forceSend then
            self.alreadySendMsg = true
            self.uiServcie:showChatBtn(true)
            self.uiServcie:showVoiceBtn(false)
            self.uiServcie:SetFollowBtn(false)
            self:_setJoyStickEnable(false)
            
            APIBridge.RequestAsync("buss.menu.chatlist", { isShow = true, type = "normal" }, function(res)
                print("wwww 选择聊天区样式为 normal")
            end)
        end
    else
        self.alreadySendMsg = false
        self.uiServcie:showChatBtn(false)
        self.uiServcie:showVoiceBtn(true)
        self.uiServcie:SetFollowBtn(true)
        self:_setJoyStickEnable(true)

        local type = "system"
        if self.oldState then
            type = "normal"
        end
        APIBridge.RequestAsync("buss.menu.chatlist", { isShow = true, type = type }, function(res)
            print("wwww 选择聊天区样式为 system")
        end)
        APIBridge.RequestAsync("app.buss.menu.textchat", {
            active = false
        })
    end
end

function ChatUIController:_setJoyStickEnable(enabled)
    local joystickPanel = self.joystickService.joyPanel
    if joystickPanel then
        -- 解/锁镜头
        local touchPad = joystickPanel.UI:GetUIObject().transform:Find('TouchPadController'):GetComponent(typeof(CS.UnityEngine.UI.Image))
        if touchPad ~= nil and touchPad.gameObject ~= nil then
            touchPad.gameObject:SetActive(enabled)
            touchPad.color = CS.UnityEngine.Color(1,1,1,0)
        end
        
        -- 摇杆
        if joystickPanel.joystick then
            local joystick = joystickPanel.joystick.gameObject

            --遥感正在操作时 需要打断这次交互
            joystick:SetActive(false)
            joystick:SetActive(true)
    
            joystick:GetComponent(typeof(CS.ETCJoystick)).activated = enabled
            local canvasGroup = joystick:GetComponent(typeof(CS.UnityEngine.CanvasGroup))
            if Util:IsNil(canvasGroup) then
                canvasGroup = joystick:AddComponent(typeof(CS.UnityEngine.CanvasGroup))
            end
            canvasGroup.alpha = enabled and 1 or 0.4
    
            local jsArrow = joystick.transform:Find("JoyDir")
            if jsArrow and not enabled then
                jsArrow.gameObject:SetActive(enabled)
            end
        end

        -- 跳跃按钮
        if joystickPanel.jumpETCButton then
            local jump = joystickPanel.jumpETCButton.gameObject
            jump:GetComponent(typeof(CS.ETCButton)).activated = enabled
            local canvasGroup = jump:GetComponent(typeof(CS.UnityEngine.CanvasGroup))
            if Util:IsNil(canvasGroup) then
                canvasGroup = jump:AddComponent(typeof(CS.UnityEngine.CanvasGroup))
            end
            canvasGroup.alpha = enabled and 1 or 0.4
        end

        --游泳按钮
        if joystickPanel.swimUpBtn then
            local swimUpBtn = joystickPanel.swimUpBtn.gameObject
            swimUpBtn:GetComponent(typeof(CS.ETCButton)).activated = enabled
            local canvasGroup = swimUpBtn:GetComponent(typeof(CS.UnityEngine.CanvasGroup))
            if Util:IsNil(canvasGroup) then
                canvasGroup = swimUpBtn:AddComponent(typeof(CS.UnityEngine.CanvasGroup))
            end
            canvasGroup.alpha = enabled and 1 or 0.4
        end
        if joystickPanel.swimDownBtn then
            local swimDownBtn = joystickPanel.swimDownBtn.gameObject
            swimDownBtn:GetComponent(typeof(CS.ETCButton)).activated = enabled
            local canvasGroup = swimDownBtn:GetComponent(typeof(CS.UnityEngine.CanvasGroup))
            if Util:IsNil(canvasGroup) then
                canvasGroup = swimDownBtn:AddComponent(typeof(CS.UnityEngine.CanvasGroup))
            end
            canvasGroup.alpha = enabled and 1 or 0.4
        end
    end

    
end

return ChatUIController