require "hotfix/hotfix_manager"
require "hotfix/resource_manager"
require('common/define')
require("import")
require "app/application"
