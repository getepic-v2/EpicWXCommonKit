
--资源存储
RESOURCE_LOC = "Main"
--脚本存储根路径
--Main脚本位置
MAIN_SCRIPTS_LOC = "scripts/"

--courseenv存放脚本位置
COURSE_ENV_SCRIPTS_LOC = MAIN_SCRIPTS_LOC.."courseenv/"
--nextstudiobase存放脚本位置
NEXT_STUDIO_BASE_SCRIPTS_LOC = MAIN_SCRIPTS_LOC.."nextstudiobase/"

next_require = _G.require
_G.require = function(modname)  --Main/scripts/frameSync/entrance/baseModEntrance   Main/scripts/frameSync/entrance/baseModEntrance
    --兼容业务直接引用根路径的调用方式
    if string.find(modname,"Main/scripts/") ~= nil then
        modname = string.gsub(modname, "Main/scripts/", MAIN_SCRIPTS_LOC)
    elseif string.find(modname,"nextstudiobase/scripts/") ~= nil then
        modname = string.gsub(modname, "nextstudiobase/scripts/", NEXT_STUDIO_BASE_SCRIPTS_LOC)
    end
    return next_require(modname)
end

g_IsOSXEditor               = CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.OSXEditor
Debug = CS.UnityEngine.Debug
g_DisableEvents = {}

-- 调试模式控制，生产环境建议设为 false
g_DebugMode = true

next_print =_G.print
_G.print = function(...)
    if CS.UnityEngine.Application.isMobilePlatform == false then
        next_print(...)
    end
end


info_print = function(...)
    --默认关闭
    --print(...)
end

--取消消息监听、事件监听
g_DisableEvent = function(id)
    g_DisableEvents[id] = true
end

--错误处理函数
---@param msg string
g_LuaErrorFunc = function(msg)
    msg = tostring(msg)
    if g_DebugMode then
        Debug.LogError(msg.."\n"..debug.traceback())
    else
        Debug.LogError(msg)
    end
end

g_LogError = function(msg)
    msg = tostring(msg)
    if g_DebugMode then
        Debug.LogError("自定义error："..msg.."\n"..debug.traceback())
    else
        Debug.LogError("自定义error："..msg)
    end
end

g_Log = function(...)
    -- if App.GetCurrentRenderQualityLevel then
    --     local deviceLevel =  App:GetCurrentRenderQualityLevel()
    --     if deviceLevel and deviceLevel <= 1 then
    --         return
    --     end
    -- end

    -- msg = tostring(msg)
    --print(msg)

    if App.DisableDebugLogOnCurDevice then
        return
    end

    if App.isLowDevice then
        return
    end

    next_print(...)
end

g_ErrorPersonal = function(msg)
    msg = tostring(msg)
    --Debug.Log("@mwz  "..msg.."\n"..debug.traceback())
end

g_LogColorMsg = function(msg,color)

    if App.DisableDebugLogOnCurDevice then
        return
    end

    msg = tostring(msg)
    local colorCode
    if color == 'red' then
        colorCode = '#ff0000'
    else
        colorCode = '#7FFF00'
    end
    
    if g_DebugMode then
        Debug.Log("<color="..colorCode..">"..msg.."</color>"..'\n'..debug.traceback());
    else
        Debug.Log("<color="..colorCode..">"..msg.."</color>");
    end
end

--==========================================
---@class 计数table
g_CountTable = { _list = {},_count = 0 }

--创建
g_CountTable.new = function()
    local o = {}
    setmetatable(o,g_CountTable)
    g_CountTable.__index = g_CountTable
    o._list = {}
    o._count = 0
    return o
end

---@param id number
---@param value any
function g_CountTable:add(id,value)
    if self._list[id] == nil then
        self._count = self._count + 1
    end

    self._list[id] = value
end

--删除
---@param id number
function g_CountTable:del(id)
    if self._list[id] ~= nil then
        self._list[id] = nil
        self._count = self._count - 1
    end
end

--清理
function g_CountTable:clear()
    self._list = {}
    self._count = 0
end

--数量
function g_CountTable:count()
    return self._count
end

--是否存在
function g_CountTable:get(id)
    return self._list[id]
end

--遍历
function g_CountTable:foreach(func)
    table.foreach(self._list,func)
end

local l_v3 = {}
local l_v2 = {}
--保留n位小数的V3
function g_ConvertVector3Float(v3,n)
    n = n or 2
    l_v3 = {g_KeepDecimalTest(v3.x,n),g_KeepDecimalTest(v3.y,n),g_KeepDecimalTest(v3.z,n)}
    return l_v3
end

--保留n位小数的V2
function g_ConvertVector2Float(v2,n)
    n = n or 2
    -- fix：_v2应该是写错了，实际应该写成v2
    --l_v2 = Vector2(g_KeepDecimalTest(_v2.x,n),g_KeepDecimalTest(v2.y,n))
    l_v2 = Vector2(g_KeepDecimalTest(v2.x,n),g_KeepDecimalTest(v2.y,n))
    return l_v2
end

-- 保留n位小数
function g_KeepDecimalTest(num, n)
    if type(num) ~= "number" then
        return num
    end
    n = n or 2
    if num < 0 then
        return -(math.abs(num) - math.abs(num) % 0.1 ^ n)
    else
        return num - num % 0.1 ^ n
    end
end

--表结构打印
local key = ""
function PrintTable(table , level)
    level = level or 1
    local indent = ""
    for i = 1, level do
        indent = indent.."  "
    end

    if key ~= "" then
        print(indent..key.." ".."=".." ".."{")
    else
        print(indent .. "{")
    end

    key = ""
    for k,v in pairs(table) do
        if type(v) == "table" then
            key = k
            PrintTable(v, level + 1)
        elseif type(v) == "function" then

        else
            local content = string.format("%s%s = (%s)%s", indent .. "  ",tostring(k),type(v), tostring(v))
            print(content)
        end
    end
    print(indent .. "}")

end

function IsNull(gameObj) 
    return gameObj == nil
end
---@type CS.UnityEngine.WaitForEndOfFrame
local frame = CS.UnityEngine.WaitForEndOfFrame()
g_WaitForEndOfFrame = frame

---@param obj any
---@param cs_type string typeof所得类型
---@return boolean 是否一致
function cs_isTypeof(obj, cs_type)
    if obj == nil and cs_type == nil then
        return true
    end
    if obj == nil or cs_type == nil then
        return false
    end
    local split = string.split(tostring(cs_type), ':')
    local match_type = nil
    if #split > 1 then
        match_type = split[1]
    end
    if match_type == nil then
        return false
    end
    local obj_type = type(obj);
    if(obj_type == "table" or obj_type == "userdata") then
        local _meta = getmetatable(obj);
        if(_meta ~= nil and _meta.__name ~= nil) then
            return match_type == _meta.__name;
        end
    else
        return match_type == obj_type;
    end
end