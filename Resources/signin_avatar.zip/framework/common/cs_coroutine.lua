
---@alias MonoBehaviour CS.UnityEngine.MonoBehaviour


local util = require 'xlua.util'
local class = require "middleclass"



--local gameobject = CS.UnityEngine.GameObject('CoroutineRunner')
--CS.UnityEngine.Object.DontDestroyOnLoad(gameobject)

---@type MonoBehaviour
local cs_coroutine_runner = GateManager

---@class CoroutineRunner
local CoroutineRunner = class("CoroutineRunner")

function CoroutineRunner:initialize(runner,...)
	self.Runner = runner or cs_coroutine_runner
	self.cor = self.Runner:StartCoroutine(util.cs_generator(...))
end

function CoroutineRunner:Stop()
	if self.cor then
		self.Runner:StopCoroutine(self.cor)
		self.cor = nil
	end
end

function CoroutineRunner:StopAllCoroutines()
	self.Runner:StopAllCoroutines()
end


return  {
	--- start
    ---@return CoroutineRunner
    start = function(...)
		return CoroutineRunner:new(cs_coroutine_runner,...)
	end;

	--- stop
    ---@param coroutine CoroutineRunner
	stop = function(coroutine)
		coroutine:Stop()
	end;

	---@param runner MonoBehaviour
	---@return CoroutineRunner
	start_with = function(runner, ...)
		return CoroutineRunner:new(runner or cs_coroutine_runner,...)
	end;
}


