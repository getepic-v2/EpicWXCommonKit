--[[
-- string扩展工具类，对string不支持的功能执行扩展
--]]

function trim(s)
	return (s:gsub("^%s*(.-)%s*$", "%1"))
end
-- 字符串分割
---@param target_string string @被分割的字符串
---@param pattern string @分隔符
---@return table
--字符串拆分
function split(target_string, pattern)
	if target_string==nil or target_string=='' or pattern==nil then
		return nil
	end

    local result = {}
    for match in (target_string..pattern):gmatch("(.-)"..pattern) do
        table.insert(result, match)
    end
    return result
end

-- 是否包含
-- 注意：plain为true时，关闭模式匹配机制，此时函数仅做直接的 “查找子串”的操作
---@param target_string string
---@param pattern string
---@param plain boolean
---@return boolean
function contains(target_string, pattern, plain)
	if plain == nil then
		plain = false
	end
	local find_pos_begin, find_pos_end = string.find(target_string, pattern, 1, plain)
	return find_pos_begin ~= nil
end

-- 以某个字符串开始
-- 注意：plain为true时，关闭模式匹配机制，此时函数仅做直接的 “查找子串”的操作
---@param target_string string
---@param start_pattern string
---@param plain boolean
---@return boolean
function startswith(target_string, start_pattern, plain)
	if plain == nil then
		plain = false
	end
	local find_pos_begin, find_pos_end = string.find(target_string, start_pattern, 1, plain)
	return find_pos_begin == 1
end

-- 以某个字符串结尾
-- 注意：plain为true时，关闭模式匹配机制，此时函数仅做直接的 “查找子串”的操作
---@param target_string string
---@param start_pattern string
---@param plain boolean
---@return boolean
function endswith(target_string, start_pattern, plain)
	if plain == nil then
		plain = false
	end
	local find_pos_begin, find_pos_end = string.find(target_string, start_pattern, -#start_pattern, plain)
	return find_pos_end == #target_string
end

local function utf8offset(s, charNum)
    local index = 1

    for _ = 1, charNum - 1 do
        local c = string.byte(s, index)
        if not c then break end

        if c > 0 and c <= 127 then 
            index = index + 1 
        elseif c >= 194 and c <= 223 then 
            index = index + 2 
        elseif c >= 224 and c <= 239 then 
            index = index + 3 
        elseif c >= 240 and c <=244 then 
            index = index +4 
        else 
            error("Invalid UTF-8 character sequence") 
        end  
    end
    
    return index  
end

local function utf8sub(s, startChar, numChars)
    local startIndex = utf8offset(s, startChar)
    local endIndex = utf8offset(s, startChar + numChars) - 1

    return s:sub(startIndex, endIndex)
end

local function utf8len(s)
    local len = 0
    local i = 1
    while i <= #s do
        local c = string.byte(s, i)
        if c > 0 and c <= 127 then
            i = i + 1
        elseif c >= 194 and c <= 223 then
            i = i + 2
        elseif c >= 224 and c <= 239 then
            i = i + 3
        elseif c >= 240 and c <= 244 then
            i = i + 4
        else
            error("Invalid UTF-8 character sequence")
        end
        len = len + 1
    end
    return len
end

string.split = split
string.contains = contains
string.startswith = startswith
string.endswith = endswith
string.trim = trim
string.utf8len = utf8len
string.utf8sub = utf8sub
