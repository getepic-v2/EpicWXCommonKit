Next_LuaProfile = {
    profile = function(func)
        --统计耗时
        local startTime = os.clock() * 1000
        func()
        local endTime = os.clock() * 1000
        local costTime = endTime - startTime
        g_LogError(string.format("LuaProfile Function %s cost %f ms", func, costTime))
    end
}


return Next_LuaProfile