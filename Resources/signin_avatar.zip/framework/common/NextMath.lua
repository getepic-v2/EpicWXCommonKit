NextMath = {}

---@class Math_Vector3
local Math_Vector3 = { x = 0, y = 0, z = 0 }

---@class Math_Quaternion
local Math_Quaternion = { x = 0, y = 0, z = 0, w = 0 }

-- 创建Vector3
---@param x number
---@param y number
---@param z number
---@return Math_Vector3
function NextMath.Vector3(x, y, z)
    return { x = x or 0, y = y or 0, z = z or 0 }
end

-- 获取正前方
---@return Math_Vector3
function NextMath.Vector3Forward()
    return { x = 0, y = 0, z = 1 }
end

-- 获取正后方
---@return Math_Vector3
function NextMath.Vector3Back()
    return { x = 0, y = 0, z = -1 }
end

-- 获取正右方
---@return Math_Vector3
function NextMath.Vector3Right()
    return { x = 1, y = 0, z = 0 }
end

-- 获取正左方
---@return Math_Vector3
function NextMath.Vector3Left()
    return { x = -1, y = 0, z = 0 }
end

-- 获取正上方
---@return Math_Vector3
function NextMath.Vector3Up()
    return { x = 0, y = 1, z = 0 }
end

-- 获取正下方
---@return Math_Vector3
function NextMath.Vector3Down()
    return { x = 0, y = -1, z = 0 }
end

-- Vector3加法
---@param v1 Math_Vector3
---@param v2 Math_Vector3
---@return Math_Vector3
function NextMath.AddVector3(v1, v2)
    return {
        x = v1.x + v2.x,
        y = v1.y + v2.y,
        z = v1.z + v2.z
    }
end

-- Vector3减法
---@param v1 Math_Vector3
---@param v2 Math_Vector3
---@return Math_Vector3
function NextMath.SubtractVector3(v1, v2)
    return {
        x = v1.x - v2.x,
        y = v1.y - v2.y,
        z = v1.z - v2.z
    }
end

-- Vector3数乘
---@param v Math_Vector3
---@param scalar number
---@return Math_Vector3
function NextMath.MultiplyVector3(v, scalar)
    return {
        x = v.x * scalar,
        y = v.y * scalar,
        z = v.z * scalar
    }
end

-- Vector3点乘
---@param v1 Math_Vector3
---@param v2 Math_Vector3
---@return number
function NextMath.DotProduct(v1, v2)
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z
end

-- Vector3叉乘
---@param v1 Math_Vector3
---@param v2 Math_Vector3
---@return Math_Vector3
function NextMath.CrossProduct(v1, v2)
    return {
        x = v1.y * v2.z - v1.z * v2.y,
        y = v1.z * v2.x - v1.x * v2.z,
        z = v1.x * v2.y - v1.y * v2.x
    }
end

-- Vector3长度
---@param v Math_Vector3
---@return number
function NextMath.Magnitude(v)
    return math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
end

-- Vector3长度平方
---@param v Math_Vector3
---@return number
function NextMath.SqrMagnitude(v)
    return v.x * v.x + v.y * v.y + v.z * v.z
end

-- Vector3归一化
---@param v Math_Vector3
---@return Math_Vector3
function NextMath.Normalize(v)
    local mag = NextMath.Magnitude(v)
    if mag > 0 then
        return NextMath.MultiplyVector3(v, 1 / mag)
    end
    return { x = 0, y = 0, z = 0 }
end

-- Vector3距离
---@param v1 Math_Vector3
---@param v2 Math_Vector3
---@return number
function NextMath.Distance(v1, v2)
    return NextMath.Magnitude(NextMath.SubtractVector3(v1, v2))
end

-- Vector3距离平方
---@param v1 Math_Vector3
---@param v2 Math_Vector3
---@return number
function NextMath.DistanceSqrt(v1, v2)
    return (v1.x - v2.x) ^ 2 + (v1.y - v2.y) ^ 2 + (v1.z - v2.z) ^ 2
end

-- Vector3插值
---@param v1 Math_Vector3
---@param v2 Math_Vector3
---@param t number
---@return Math_Vector3
function NextMath.Lerp(v1, v2, t)
    t = math.max(0, math.min(1, t))
    return {
        x = v1.x + (v2.x - v1.x) * t,
        y = v1.y + (v2.y - v1.y) * t,
        z = v1.z + (v2.z - v1.z) * t
    }
end

-- Vector3投影
---@param v Math_Vector3
---@param onNormal Math_Vector3
---@return Math_Vector3
function NextMath.Project(v, onNormal)
    local normalized = NextMath.Normalize(onNormal)
    local dot = NextMath.DotProduct(v, normalized)
    return NextMath.MultiplyVector3(normalized, dot)
end

-- Vector3反射
---@param v Math_Vector3
---@param normal Math_Vector3
---@return Math_Vector3
function NextMath.Reflect(v, normal)
    local dot = NextMath.DotProduct(v, normal)
    return NextMath.SubtractVector3(v, NextMath.MultiplyVector3(normal, 2 * dot))
end

-- 定义一个四元数
---@param x number
---@param y number
---@param z number
---@param w number
---@return Math_Quaternion
function NextMath.Quaternion(x, y, z, w)
    return { x = x or 0, y = y or 0, z = z or 0, w = w or 0 }
end

--实现一个LookRotation
---@param forward Math_Vector3 要朝向的方向向量
---@param up Math_Vector3 可选的向上向量，默认值为 {x = 0, y = 1, z = 0}
---@return Math_Quaternion
function NextMath.LookRotation(forward, up)
    up = up or { x = 0, y = 1, z = 0 }

    -- 归一化前向向量
    local f = NextMath.Normalize(forward)

    -- 计算右向量
    local r = NextMath.Normalize(NextMath.CrossProduct(up, f))

    -- 重新计算上向量以确保正交
    local u = NextMath.CrossProduct(f, r)

    -- 计算四元数的分量
    local trace = r.x + u.y + f.z
    local q = { x = 0, y = 0, z = 0, w = 1 }

    if trace > 0 then
        local s = math.sqrt(trace + 1.0) * 2 -- S=4*qw
        q.w = 0.25 * s
        q.x = (u.z - f.y) / s
        q.y = (f.x - r.z) / s
        q.z = (r.y - u.x) / s
    elseif (r.x > u.y) and (r.x > f.z) then
        local s = math.sqrt(1.0 + r.x - u.y - f.z) * 2 -- S=4*qx
        q.w = (u.z - f.y) / s
        q.x = 0.25 * s
        q.y = (r.y + u.x) / s
        q.z = (r.z + f.x) / s
    elseif u.y > f.z then
        local s = math.sqrt(1.0 + u.y - r.x - f.z) * 2 -- S=4*qy
        q.w = (f.x - r.z) / s
        q.x = (r.y + u.x) / s
        q.y = 0.25 * s
        q.z = (u.z + f.y) / s
    else
        local s = math.sqrt(1.0 + f.z - r.x - u.y) * 2 -- S=4*qz
        q.w = (r.y - u.x) / s
        q.x = (r.z + f.x) / s
        q.y = (u.z + f.y) / s
        q.z = 0.25 * s
    end

    return q
end

-- 四元素lerp
---@param q1 Math_Quaternion
---@param q2 Math_Quaternion
---@param t number
---@return Math_Quaternionå
function NextMath.QuaternionLerp(q1, q2, t)
    -- 确保t在0到1之间
    t = math.max(0, math.min(1, t))

    -- 检查两个四元数之间的点积
    local dot = q1.x * q2.x + q1.y * q2.y + q1.z * q2.z + q1.w * q2.w

    -- 如果点积为负，则取q2的相反数
    if dot < 0.0 then
        q2.x = -q2.x
        q2.y = -q2.y
        q2.z = -q2.z
        q2.w = -q2.w
        dot = -dot -- 更新点积为正值，因为我们改变了q2的方向
    end

    -- 防止由于浮点精度问题导致dot > 1.0
    dot = math.min(1.0, dot)

    -- 线性插值四元数的每个分量
    local x = q1.x + (q2.x - q1.x) * t
    local y = q1.y + (q2.y - q1.y) * t
    local z = q1.z + (q2.z - q1.z) * t
    local w = q1.w + (q2.w - q1.w) * t

    -- 归一化结果四元数
    local mag = math.sqrt(x * x + y * y + z * z + w * w)

    if mag > 0 then
        return { x = x / mag, y = y / mag, z = z / mag, w = w / mag }
    else
        return { x = 0, y = 0, z = 0, w = 1 }
    end
end

return NextMath
