
local TouchDetector = { }
local PressFuncs = {}
local ReleaseFuncs = {}
local UpdateFuncs = {}


function TouchDetector:OnStart()
    TouchManager.Instance:PointersPressed('+',TouchDetector.OnPointerPressed)
    TouchManager.Instance:PointersReleased('+',TouchDetector.OnPointerReleased)
    TouchManager.Instance:PointersUpdated('+',TouchDetector.OnPointerUpdated)
end

function TouchDetector:OnDispose()
    TouchManager.Instance:PointersPressed('-',TouchDetector.OnPointerPressed)
    TouchManager.Instance:PointersReleased('-',TouchDetector.OnPointerReleased)
    TouchManager.Instance:PointersUpdated('-',TouchDetector.OnPointerUpdated)
    PressFuncs = {}
    ReleaseFuncs = {}
    UpdateFuncs = {}
end



-- 注册按下回调
-----@param func function<Pointer> @回调方法
function TouchDetector:RegisterPressedFunc(func)
    PressFuncs[#PressFuncs + 1] = func
end

-- 注册松开回调
-----@param func function<Pointer> @回调方法
function TouchDetector:RegisterReleasedFunc(func)
    ReleaseFuncs[#ReleaseFuncs + 1] = func
end

-- 注册帧逻辑回调
-----@param func function<Pointer> @回调方法
function TouchDetector:RegisterUpdateFunc(func)
    UpdateFuncs[#UpdateFuncs + 1] = func
end


--使用local变量承接，避免一直创建
local updatePointerCount = 0
local updatePoint = nil
local singlePointerId = -1

local releasePointerCount = 0
local releasePoint = nil

---@private
--只有在命中collider时才会调用func + 记录pointerId
function TouchDetector.OnPointerPressed(sender,e)
    local count = e.Pointers.Count
    if count > 0 then
        if singlePointerId ~= -1 then return end
        for i = 0,e.Pointers.Count - 1 do
            local point = e.Pointers[i]
            local data = point:GetOverData(true) -- 强制回收pointer，避免获取TargetBug

            if not data.Target then
                for k,func in pairs(PressFuncs) do
                    func(point)
                    singlePointerId = point.Id
                end
                break
            end
        end
    end
end

---@private
function TouchDetector.OnPointerUpdated(sender,e)
    updatePointerCount = e.Pointers.Count
    if updatePointerCount > 0 then
        -- match pointerId
        for i = 0,updatePointerCount - 1 do
            if e.Pointers[i].Id == singlePointerId then
                updatePoint = e.Pointers[i]
            end
        end
        if not updatePoint then
            return
        end
        for k,func in pairs(UpdateFuncs) do
            func(updatePoint)
        end

    end
end
---@private
function TouchDetector.OnPointerReleased(sender,e)
    releasePointerCount = e.Pointers.Count
    if releasePointerCount > 0 then
        -- match pointerId
        for i = 0,releasePointerCount - 1 do
            if e.Pointers[i].Id == singlePointerId then
                releasePoint = e.Pointers[i]
            end
        end
        if not releasePoint then
            return
        end
        singlePointerId = -1
        for k,func in pairs(ReleaseFuncs) do
            func(releasePoint)
        end
    end
end

return TouchDetector