
local class = require("middleclass")

---@class PoolInstance
local PoolInstance = class("PoolInstance")

local _event_pool_id = 0


---@type table<int,PoolInstance>
local _pools_ = {}

function PoolInstance:OnStart()
    _pools_[self.PoolId] = self
end

function PoolInstance:OnDispose()
    _pools_[self.PoolId] = nil
end

function PoolInstance:initialize(name)
    _event_pool_id = _event_pool_id +1
    self.PoolName = name
    self.PoolId = _event_pool_id
end


---@param id any @key
---@param listener_call fun(id:any, param:any)
function PoolInstance:ListenEvent(id,listener_call)
    self.Events = self.Events or {}
    local lis=
    {
        ["id"] = id,
        ["call"] = listener_call
    }
    table.insert(self.Events,lis)
end

function PoolInstance:FireEvent(id,param,...)
    if not self.Events then return end
    for _,v in pairs(self.Events) do
        if v.id == id and v.call then v.call(id,param,...) end
    end
end


---@class EventPool
EventPool = {}
--- 创建一个事件监听池
---@param name string 监听池的名字
EventPool.NewPool = function(name)
    return PoolInstance:new(name)
end



---@param id any
---@param param any
g_PushEvent = function(id,param,...)
    for k,v in pairs(_pools_) do
        v:FireEvent(id,param,...)
    end
end

return EventPool