
local standard = {}
for k in pairs(package.loaded) do
    standard[k] = true
end

function _R_()
    local loadThese = {}

    -- Unload all loaded packages...
    for k in pairs(package.loaded) do
        -- ... unless they're considered 'standard lib'
        if not standard[k] then
            -- Also save the old instance in order to replace global variable values
            loadThese[k] = package.loaded[k]
            package.loaded[k] = nil
        end
    end

    for lib, prevLoaded in pairs(loadThese) do
        -- Re-require the package
        local loaded = require(lib)

        -- Iterate all globals, if they match the old instance, replace the value
        for name, value in pairs(_G) do
            if value == prevLoaded then
                _G[name] = loaded
            end
        end
    end
end