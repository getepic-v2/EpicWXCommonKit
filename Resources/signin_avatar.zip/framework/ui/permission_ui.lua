---@author 

local class = require("middleclass")
local Window = require("ui/window")
local PermissionUI = class("PermissionUI", Window)
local cs_coroutine = require("common/cs_coroutine")

function PermissionUI:initialize()
    PermissionUI.super.initialize(self, "PermissionUI", RESOURCE_LOC.."/assets/prefabs/Permission")
end
function PermissionUI:OnCreate()
    self.backGround = self.UI:Find("Image", "BackGround").gameObject
    self.textContent = self.UI:Find("Text", "BackGround/Text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.textBtn = self.UI:Find("Text", "BackGround/Text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.backGround:SetActive(false)
end

function  PermissionUI:falseConnect(connectFalse,temploadcallBack,callbackJudgment)
    self.Coprogram = cs_coroutine.start(function()
        self.backGround:SetActive(true)
        self.textContent.text = connectFalse .. "无权限," .. "<color=" .. "#E1FC09" .. ">" .. "开启" ..
                " >" .. "</color>"
        self:initAdujustText(connectFalse)
        coroutine.yield(CS.UnityEngine.WaitForSeconds(2))
        App:GetService("CommonService"):AddEventListener(self.textBtn, "onClick", function()
            if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.Android then
                -- 安卓
                self.backGround:SetActive(false)
                index = 1
                isNext = true
                callbackJudgment()
            elseif CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.IPhonePlayer then
                self.backGround:SetActive(false)
                APIBridge.RequestAsync("app.api.auth.jumpSetting")
                end
        end)
        coroutine.yield(CS.UnityEngine.WaitForSeconds(5))
        if not isNext then
            temploadcallBack(false)
        end
        -- 协程关闭
        if self.Coprogram ~= nil then
            cs_coroutine.stop(self.Coprogram)
            self.Coprogram = nil
        end
        self.backGround:SetActive(false)
    end)
end


function PermissionUI:initAdujustText(connectFalse)
    local wordsCount = #connectFalse + 21
    local width = 72 + wordsCount * 9
    local pC = self.backGround.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
    pC.sizeDelta = CS.UnityEngine.Vector2(width, 60)
end

return PermissionUI