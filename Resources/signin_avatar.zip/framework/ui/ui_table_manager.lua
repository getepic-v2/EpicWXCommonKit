
---@alias LayoutGroup CS.UnityEngine.UI.LayoutGroup


local class = require("middleclass")

---@class UITableManager
---@field Items UITableItem[]
local UITableManager = class("UITableManager")

---@param grid LayoutGroup
---@param cls UITableItem @subclass of UITableItem
function UITableManager:initialize(grid,cls)
    ---@private
    ---@type CS.Com.Tal.Unity.UI.UITableManagerDefault
    self.Table = CS.Com.Tal.Unity.UI.UITableManagerDefault() 
 
    self.Table:Init(grid)
    ---@private
    self.model = cls
end

---@param count int @set table item count
---@return int
function UITableManager:SetCount(count)
    self.Table.Count = count
    local items = self.Table:GetItems() --list
    self.Items = {};
    for i = 1,items.Count  do
        self.Items[i] = self.model:new(items[i-1])
    end
    return count
end

return UITableManager