


local class = require("middleclass")

---@class UITableItem
---@field public _Item  CS.Com.Tal.Unity.UI.UITableItem
local UITableItem = class("UITableItem")


---@param item CS.Com.Tal.Unity.UI.UITableItem
---@return void
function UITableItem:initialize(item)
    self._Item = item
    self.OnCreate(self)   
end

---@return void
function UITableItem:OnCreate()
    
end

return UITableItem;