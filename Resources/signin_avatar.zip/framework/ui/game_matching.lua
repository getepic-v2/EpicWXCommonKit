local json = require("json")

local gameMatching = {
    prefab = nil,
    go = nil,
    data = nil
}
gameMatching.load = function(cb, againBtn, cancel)
    if gameMatching.go ~= nil then
        return
    end
    if gameMatching.prefab then
        local go = GameObject.Instantiate(gameMatching.prefab)
        gameMatching.init(go, againBtn, cancel)
        if cb then
            cb(go)
        end
        return
    end
    local assetPath = "modules/" .. RESOURCE_LOC ..
                          "/assets/prefabs/business/game_resultPanel/resultPanel/assets/Prefabs/queue.prefab"
    ResourceManager:LoadGameObjectWithExName(assetPath, function(asset)
        gameMatching.prefab = asset
        local go = GameObject.Instantiate(asset)
        gameMatching.init(go, againBtn, cancel)
        if cb then
            cb(go)
        end
    end)
end

gameMatching.init = function(go, againBtn, cancel)
    gameMatching.go = go
    -- 加一个延迟取消的标记变量，防止动画报错
    local canCancel = false
    App:GetService("CommonService"):StartCoroutine(function()
        App:GetService("CommonService"):YieldSeconds(1)
        canCancel = true
    end)

    local cancelfunc = function(cb)

        gameMatching.CancelCor()
        if gameMatching.go == nil then
            return
        end

        -- 取消匹配
        GameObject.Destroy(gameMatching.go)
        gameMatching.go = nil
        gameMatching.cancel = nil

        if againBtn then
            againBtn.gameObject:SetActive(true)
            againBtn.transform.localScale = Vector3.one
        end

        App:GetService("CommonService"):DispatchAfter(2, function()
            if againBtn then
                againBtn:GetComponentInChildren(typeof(CS.UnityEngine.UI.Button)).interactable = true
            end
        end)

        local url = "/v3/game/queue-cancel"
        local success = function(resp)
            if resp and resp ~= "" then
                local msg = nil
                if type(resp) == "string" then
                    msg = CourseEnv.ServicesManager:GetJsonService():decode(resp)
                end
                if msg and msg.code == 0 then
                    g_Log("已取消排队")
                    g_Log(resp)
                    gameMatching.data = nil
                    if cb then
                        cb(true)
                    end
                    return
                end
            end
            if cb then
                cb(false)
            end
        end
        local params = {
            game_id = tostring(gameMatching.game_id),
            room_id = App.Info.roomId,
            plan_id = tostring(gameMatching.plan_id),
            team_id = gameMatching.teamId and tonumber(gameMatching.teamId) or nil,
            user_id = tostring(App.Info.userId)
        }
        local data = gameMatching.data
        if data ~= nil then
            params.qid = data.qid
            params.grade = data.grade
            params.level = data.level
            params.queue_type = data.queue_type
        end

        -- if type(params.game_id) == "number" then
        --     if params.game_id == 1001 or params.game_id == 1003 or params.game_id == 1007 then
        --         params.game_id = params.game_id - 1000
        --     end
        -- elseif type(params.game_id) == "string" then
        --     local id = tonumber(params.game_id)
        --     if id == 1001 or id == 1003 or id == 1007 then
        --         id = id - 1000
        --         params.game_id = tostring(id)
        --     end
        -- else
        --     print("Value is of some other type")
        -- end

        if gameMatching.origin_game_id then
            params.game_id = gameMatching.origin_game_id
        end

        gameMatching.HttpRequest(url, params, success, function(res)
            g_LogError("取消排队失败")
            g_LogError(table.dump(res))

            if cb then
                cb(false)
            end
        end)

    end
    local btn = gameMatching.go.transform:Find("Button"):GetComponent(typeof(CS.UnityEngine.UI.Button))

    gameMatching.cancel = cancelfunc
    btn.interactable = true
    App:GetService("CommonService"):AddEventListener(btn, "onClick", function()

        if canCancel == false then
            return
        end
        btn.interactable = false
        if gameMatching.cancel then
            gameMatching.cancel()
        end
    end)

    ---开始排队
    local success = function(resp)

        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = CourseEnv.ServicesManager:GetJsonService():decode(resp)
            end

            g_Log("排队成功：")
            g_Log(resp)

            local data = {}
            if msg.data.qid then
                data.qid = tostring(msg.data.qid)
            end

            data.grade = tonumber(msg.data.grade)
            data.level = tonumber(msg.data.level)
            if msg.data.queue_type then
                data.queue_type = tonumber(msg.data.queue_type)
            end

            gameMatching.data = data
            g_Log(table.dump(gameMatching.data))

            local toastMsg = nil
            if msg and msg.code == 0 and msg.data then
                if msg.data ~= 1 and msg.data.msg and msg.data.msg ~= "" then
                    toastMsg = msg.data.msg
                else
                    return
                end
            end
        end
    end

    -- TODO 传入参数
    local params = {}
    params = {
        game_id = gameMatching.game_id,
        room_id = App.Info.roomId,
        plan_id = gameMatching.plan_id
    }

    -- if type(params.game_id) == "number" then
    --     if params.game_id == 1001 or params.game_id == 1003 or params.game_id == 1007 then
    --         params.game_id = params.game_id - 1000
    --     end
    -- elseif type(params.game_id) == "string" then
    --     local id = tonumber(params.game_id)
    --     if id == 1001 or id == 1003 or id == 1007 then
    --         id = id - 1000
    --         params.game_id = tostring(id)
    --     end
    -- else
    --     print("Value is of some other type")
    -- end

    if gameMatching.origin_game_id then
        params.game_id = gameMatching.origin_game_id
    end

    g_Log("点击再来一局")
    g_Log(table.dump(params))
    gameMatching.HttpRequest("/v3/game/queue-up", params, success, function(res)
        -- 展示排队UI
        g_LogError("排队失败：")
        if res.error and res.error ~= "" then
            local msg = string.gsub(resp.error, "%b()", "")
            g_LogError(msg)
        end
    end)

    gameMatching.SetText({"等待"})
    gameMatching.cor = App:GetService("CommonService"):StartCoroutine(function()
        App:GetService("CommonService"):YieldSeconds(12)
        -- 取消
        if gameMatching.cancel then
            gameMatching.cancel()
        end
    end)

end
function numberToStringArray(number)
    local str = tostring(number) -- 将数字转换为字符串
    local array = {}
    for i = 1, #str do
        local char = str:sub(i, i) -- 提取每一个字符
        table.insert(array, char) -- 将字符添加到数组中
    end
    return array
end
gameMatching.ReceiveMessage = function(key, value)
    if key == "activateRoom" then
        local lastMsg = value[#value]
        if lastMsg then
            local msg = CourseEnv.ServicesManager:GetJsonService():decode(lastMsg)
            if msg then
                gameMatching.game_id = msg.game_id
                gameMatching.set_id = msg.set_id
                gameMatching.plan_id = msg.plan_id
                gameMatching.origin_game_id = msg.origin_game_id
            end
        end
    end
end
gameMatching.CancelCor = function()
    if gameMatching.cor then
        App:GetService("CommonService"):StopCoroutineSafely(gameMatching.cor)
        gameMatching.cor = nil
    end
end
gameMatching.ReceivePeerMessage = function(key, value)
    if gameMatching.go == nil then
        return
    end

    local content = value
    local res = nil
    if content and type(content) == 'string' then
        res = CourseEnv.ServicesManager:GetJsonService():decode(content)
    end

    local data = gameMatching.data

    -- 数学不需要判断
    if App.modPlatformId ~= MOD_PLATFORM.Math then
        if data == nil then

        else
            if ((data.qid and res.qid == data.qid) or data.queue_type == 0) or data.qid == "" then
            else
                g_LogError("data排队消息不匹配:")
                g_LogError(table.dump(data))
                g_LogError(table.dump(res))
                return
            end
        end
    end

    if key == ("queue_up_num" .. App.Info.roomId) then
        gameMatching.CancelCor()
        if value and type(value) == 'string' then
            local data = CourseEnv.ServicesManager:GetJsonService():decode(value)
            local userId = tostring(data.user_id)
            if userId == tostring(App.Info.userId) then
                -- data.num, data.max_num
                local num = numberToStringArray(data.num)
                local max = numberToStringArray(data.max_num)
                local concat = {}
                for i = 1, #num do
                    table.insert(concat, num[i])
                end
                table.insert(concat, "/")
                for i = 1, #max do
                    table.insert(concat, max[i])
                end
                gameMatching.SetText(concat)
            end
        end

    elseif key == ("queue_up_succ" .. App.Info.roomId) then
        local data = CourseEnv.ServicesManager:GetJsonService():decode(value)
        local gameId = data.game_id
        local userId = tostring(data.user_id)
        local joinRoomScheme = CourseEnv.ServicesManager:GetJsonService():decode(data.join_room_scheme)
        if (userId == tostring(App.Info.userId)) and not gameMatching.hasJump then
            gameMatching.CancelCor()
            local params = {
                status = 5,
                data = {} -- TODO获取游戏信息self.gameConfig[gameId]
            }
            gameMatching.hasJump = true

            local request = {
                ["planId"] = data.plan_id,
                ["paramDic"] = {
                    roomId = joinRoomScheme.room_id,
                    byPass = CourseEnv.ServicesManager:GetJsonService():encode({
                        game_id = gameId
                    })
                },
                -- ["paramDic"] = { roomId = joinRoomScheme.room_id,byPass = self.jsonService:encode(byPass)},
                ["isGameScene"] = true
            }

            APIBridge.RequestAsync("app.api.jump.switch", request, function(res)
            end)
        end

    end

end

gameMatching.SetText = function(strs)
    local strsRoot = gameMatching.go.transform.transform:Find("str")
    local list = gameMatching.go.transform.transform:Find("list")
    for i = 0, strsRoot.childCount - 1, 1 do
        strsRoot:GetChild(i).gameObject:SetActive(false)
    end
    for i = 1, #strs, 1 do
        if list.childCount >= i then
            local img = list:GetChild(i - 1):GetComponent(typeof(CS.UnityEngine.UI.Image))
            img.gameObject:SetActive(true)
            local tr = strsRoot:Find(strs[i])
            if tr == nil then
                if strs[i] == "/" then
                    tr = strsRoot:GetChild(10)
                end
            end
            img.sprite = tr:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
            img:SetNativeSize()
        end
    end
end
gameMatching.HttpRequest = function(request, params, success, fail)
    local url = "https://app.chuangjing.com/abc-api" .. request
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041" .. request
        CourseEnv.ServicesManager:GetHttpService():PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end
return gameMatching
