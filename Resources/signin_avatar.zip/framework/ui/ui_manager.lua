---@alias WRenderType CS.Com.Tal.Unity.UI.WRenderType
---@alias Vector2 CS.UnityEngine.Vector2
if UIManager ~= nil then
    return UIManager
end

---@type WRenderType
WRenderType = CS.Com.Tal.Unity.UI.WRenderType

---@type CS.UnityEngine.Screen
Screen = CS.UnityEngine.Screen

---@class UIManager
UIManager = { }

UIManager.panelList = {}

local ui = CS.Com.Tal.Unity.UI.UIManager.S;

function UIManager:AdaptScreenRatio()
    if App.ScreenDefaultWidth * 1.0 / App.ScreenDefaultHeight == 16 * 1.0 / 9 then
        -- 16:9的屏幕改成宽度适配
        local notifyCanvas = ui.NotifyCanvas
        local baseCanvas = ui.BaseCanvas
        if notifyCanvas ~= nil and baseCanvas ~= nil then
            xpcall(function()
                local canvasScaler1 = notifyCanvas:GetComponent(typeof(CS.UnityEngine.UI.CanvasScaler))
                local canvasScaler2 = baseCanvas:GetComponent(typeof(CS.UnityEngine.UI.CanvasScaler))
                canvasScaler1.matchWidthOrHeight = 0
                canvasScaler2.matchWidthOrHeight = 0
            end, function(err)
                g_LogError('设置CanvasScaler出错')
            end)
        end
    end
end



function UIManager:OpenUI(state, window, callback, type)
    table.insert(UIManager.panelList, state)
    return ui:CreateScriptWindowAsync(state, window, callback, type or WRenderType.Base);
end

function UIManager:AdaptScreenRatio()
    local ratio = App.ScreenDefaultWidth * 1.0 / App.ScreenDefaultHeight
    if ratio == 16 * 1.0 / 9 or ratio == 667.0 / 375  then
        -- 16:9的屏幕改成宽度适配
        local notifyCanvas = ui.NotifyCanvas
        local baseCanvas = ui.BaseCanvas
        if notifyCanvas ~= nil and baseCanvas ~= nil then
            xpcall(function()
                local canvasScaler1 = notifyCanvas:GetComponent(typeof(CS.UnityEngine.UI.CanvasScaler))
                local canvasScaler2 = baseCanvas:GetComponent(typeof(CS.UnityEngine.UI.CanvasScaler))
                canvasScaler1.matchWidthOrHeight = 0
                canvasScaler2.matchWidthOrHeight = 0
            end, function(err)
                g_LogError('设置CanvasScaler出错')
            end)
        end
    end
end

function UIManager:StopLoad(coroutine)
    ui:StopCoroutine(coroutine)
end

function UIManager:AdaptScreen(width, height)
    self.realWidth = width
    self.realHeight = height
    ui:AdaptScreen(width, height)
end

--- get ui window 
---@param resName string
---@return ScriptWindow
function UIManager:GetScriptWindow(resName)
    return ui:GetScriptWindow(resName)
end
--- HideAll
function UIManager:HideAll()
    ui:HideAll()

    for i, state in ipairs(UIManager.panelList) do
        xpcall(function()
            if state.UI then
                state.UI.OnCreateHandle = nil
                state.UI.OnDestroyHandle = nil;
                state.UI.OnUpdateHandle = nil;
                state.UI.OnShowHandle = nil;
                state.UI.OnBeforeShowHandle = nil;
                state.UI.OnUpdateUIDataHandle = nil;
                state.UI.OnHideHandle = nil;
            end
            state:OnDestroy()
            
        end, function(err)
            g_LogError("HideAll Error:" .. tostring(err))
        end)
    end
    UIManager.panelList = {}
end

function UIManager:GetUICamera()
    return ui.BaseCanvas.worldCamera
end

function UIManager:GetRealScaleFactor(resolution, matchWidthOrHeight, kLogBase)
    kLogBase = kLogBase or 2
    return ui:GetRealScaleFactor(resolution, matchWidthOrHeight)
end

---@param pos Vector2
---@param matchWidthOrHeight float @根据CanvasScaler得到的真实位置坐标
function UIManager:GetAdaptableVector(pos, matchWidthOrHeight)
    self.matchWidthOrHeight = self.matchWidthOrHeight or 1
    self.realWidth = self.realWidth or Screen.width
    self.realHeight = self.realHeight or Screen.height

    local scaleFactor = UIManager:GetRealScaleFactor(Vector2(1624, 750), self.matchWidthOrHeight)
    local realX = ((Screen.width / scaleFactor) * pos.x) / 1624
    local realY = ((Screen.height / scaleFactor) * pos.y) / 750

    return Vector2(realX, realY)
end

function UIManager:GetCurrentWidth()
    return self.realWidth or Screen.width
end

function UIManager:GetCurrentHeight()
    return self.realHeight or Screen.height
end

function UIManager:GetUIManagerGameObject()
    return ui.gameObject
end

function UIManager:GetCurrentMatchWidthOrHeight()
    self.matchWidthOrHeight = self.matchWidthOrHeight or 1
    self.setted = self.setted or false
    if self.setted == false then
        local Base = GameObject.Find('Base')
        if Base and (not Base:IsNull()) then
            local canvasScaler = Base:GetComponent(typeof(CS.UnityEngine.UI.CanvasScaler))
            if canvasScaler and (not canvasScaler:IsNull()) then
                self.setted = true
                self.matchWidthOrHeight = canvasScaler.matchWidthOrHeight
            end
        end
    end
    return self.matchWidthOrHeight
end

---public 修改UIManager下所有CanvasScaler的Resolution
---@field width float 宽度
---@field height float 宽度
function UIManager:SetAllCanvasScalerResolution(width, height)
    local topCanvas = ui.top
    local notifyCanvas = ui.NotifyCanvas
    local baseCanvas = ui.BaseCanvas
    if topCanvas ~= nil and notifyCanvas ~= nil and baseCanvas ~= nil then
        xpcall(function()
            self:ChangeScalerResolution(topCanvas, width, height)
            self:ChangeScalerResolution(notifyCanvas, width, height)
            self:ChangeScalerResolution(baseCanvas, width, height)
        end, function(err)
            g_LogError('设置CanvasScaler出错')
        end)
    end
end

---public 根据Canvas物体对象修改ScaleResolution大小
function UIManager:ChangeScalerResolution(canvasGameObj, width, height)
    canvasGameObj:GetComponent(typeof(CS.UnityEngine.UI.CanvasScaler)).referenceResolution = Vector2(tonumber(width),
        tonumber(height))
end

return UIManager;
