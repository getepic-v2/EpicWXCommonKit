local class = require("middleclass")
local UIManager = require("ui/ui_manager")
local cs_coroutine = require("common/cs_coroutine")


---@class Window
local Window = class("Window")

---@param res string @resource name 
---@param key string
---@param type
---@return void
function Window:initialize(key,res,type)
    
    -- g_Log("Window:initialize",key,res,type,debug.traceback())
    
    type = type or WRenderType.Base
    local ui = CS.Com.Tal.Unity.UI.ScriptWindow(key, res)
    ui.state = self
    if (self.OnShow ~= nil) then
        ui.OnShowHandle = self.OnShow;
    end

    if (self.OnHide ~= nil) then
        ui.OnHideHandle = self.OnHide;
    end

    if (self.OnUpdateUIData ~= nil) then
        ui.OnUpdateUIDataHandle = self.OnUpdateUIData;
    end

    if (self.OnCreate ~= nil) then
        ui.OnCreateHandle = self.OnCreate
    end

    if (self.OnDestroy) then
        ui.OnDestroyHandle = self.OnDestroy
    end

    if(self.OnBeforeShow) then
        ui.OnBeforeShowHandle = self.OnBeforeShow
    end

    UIManager:OpenUI(self, ui, nil ,type)
    ---@type ScriptWindow
    self.UI = ui
    print("Loader")
    if self.UI then self.UI:ShowWindow() end 
end

---@public
---@return void
function Window:Hide()
    if self.UI then self.UI:HideWindow() end
end

---@public
---@return void
function Window:Show()
    if self.UI then self.UI:ShowWindow() end
end

function Window:OnCreate()

end

---@private
function Window:OnLoaded()
    --if self.UI then self.UI:ShowWindow() end
end

function Window:OnDestroy()
    self.UI = nil
end

function Window:OnBeforeShow()
    
end

---@protected
---@alias FindTypes string ｜ "'Scrollbar'" ｜ "'Component'"｜ "'RawImage'" ｜ "'Image'" ｜ "'Dropdown'" ｜ "'InputField'" ｜ "'Text'" ｜"'Button'"｜ "'ToggleGroup'" ｜ "'Toggle'" ｜ "'Slider'"  ｜"'LayoutGroup'" ｜"'GridLayoutGroup'"｜"'VerticalLayoutGroup'"
---@param type  FindTypes
---@param name string
---@return Component
function Window:FindChild(type, name)
    return self.UI:FindChild(type, name)
end

---@return MonoBehaviour
function Window:GetComponentAsync()
    return (self.UI 
            and self.UI:GetUIObject()
            and self.UI:GetUIObject():GetComponent(typeof(CS.Com.Tal.Unity.Core.ComponentAsync)))
end

---@return CoroutineRunner
function Window:StartCoroutine(coroutine)
      return cs_coroutine.start_with(self:GetComponentAsync(),coroutine)
end

---@param coroutine CoroutineRunner
function Window:StopCoroutine(coroutine)
    return cs_coroutine.stop(coroutine)
end

---@return void
function Window:StopAllCoroutine()
    self:GetComponentAsync():StopAllCoroutines()
end

return Window