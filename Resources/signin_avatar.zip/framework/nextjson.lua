local rapidjson = nil
local json = require("json")

xpcall(function()
    rapidjson = require("rapidjson")
end, function() end)

local nextjson = {}

--- 1.考虑 rapidjson 为 nil 的情况
--- 2.向前兼容，rapidjson encode 空 table 结果为"{}"
---   json encode 空 table 结果为"[]"
function nextjson.encode(val)
    if rapidjson and val and type(val) == "table" and _G.next(val) then
        return rapidjson.encode(val)
    else
        return json.encode(val)
    end
end

function nextjson.decode(str)

    if type(str) == "table" then
        return str
    end

    if rapidjson then
        return rapidjson.decode(str)
    else
        return json.decode(str)
    end
end

return nextjson
