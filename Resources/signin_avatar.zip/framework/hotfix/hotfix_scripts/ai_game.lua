local json = require("nextjson")
local class = require("middleclass")
local logic = class("CourseEntrance")
function endsWith(str, ending)
    return ending == "" or str:sub(-#ending) == ending
end
function logic:Setup(param)

    if (App:IsABCZoneApp() or App.IsStudioClient) and not App.IsABCZone then
        g_LogError("ai_game setup")

        -- 请求hook
        local map = {"v2/ai-game/reward"}

        local isValidUrl = function(url)
            for k, v in pairs(map) do
                if endsWith(url, v) then
                    return true
                end
            end

            return false
        end
        local ori = APIBridge.RequestAsync
        APIBridge.RequestAsync = function(api, request, callBack)
            if api == "api.httpclient.request" and isValidUrl(request.url) == true then

                if endsWith(request.url, "v2/ai-game/reward") then
                    local res = {
                        responseString = ""
                    }
                    local responseString = {
                        code = 0,
                        data = {
                            reward_amount = 0
                        }
                    }
                    res.responseString = json.encode(responseString)
                    callBack(res)
                else

                end

            else
                ori(api, request, callBack)
            end
        end

        -- trigger hook

        local bs = App:GetService("BlueprintService")

        local oriTrigger = bs.TriggerWithID

        bs.TriggerWithID = function(that, guid, interfaceID, args, info)

            if interfaceID == "finish_car_drive" then

                local script = self:GetElementByName("完课页_2_1")
                if script then
                    script:OnReceiveTriggerEvent("showDynamic")
                end

            elseif interfaceID == "start_trigger" and info and info.fromName == "延时组件_5" then
                local worldController = App:GetService("CommonService").gate.worldController
                local script = self:GetElementByName("AI转盘游戏")
                local tag =self:GetElementByName("播放音频大闹天宫") 
                if tag == nil and script then
                    script:Trigger("end")
                else
                    oriTrigger(that, guid, interfaceID, args, info)
                end
            elseif interfaceID == "start_trigger" and info and info.fromName == "延时组件_14" then
                local worldController = App:GetService("CommonService").gate.worldController
                local script = self:GetElementByName("AI转盘游戏")
                local tag =self:GetElementByName("播放音频大闹天宫") 
                if tag ~= nil and script then
                    script:Trigger("end")
                else
                    oriTrigger(that, guid, interfaceID, args, info)
                end
            elseif interfaceID == "pass_high_decibel_reward" then
                -- block

            else
                oriTrigger(that, guid, interfaceID, args, info)
            end
        end

        -- trigger model

        local modelNames = {"赛车3D排行榜模型", "女学生", "CheeseUIRoot"}
        for k, v in pairs(modelNames) do
            local go = CS.UnityEngine.GameObject.Find(v)
            if go then
                go:SetActive(false)
            end
        end

        local as = self:GetElementByNames({"诗词收集合成组件", "阅读收集合成组件"})
        if as then
            as.ShowAllVerseAndRecord = function()
                as.observerService:Fire("open_prop_detail_page", {
                    hideClose = true,
                    sprite = as:LoadImage(as.allVerseImage),
                    text = as.Poetrycontent,
                    tipAudio = as.narratorAudio,
                    ai_correct = true
                })
                -- 当前整首诗词纠音的序号
                as.curAllVerseCorrectIndex = 1
                -- 开始整首诗词纠音
                as:StartAiCorrectionAllVerse()
            end

        end

    end

end
function logic:GetElementByName(name)
    local worldController = App:GetService("CommonService").gate.worldController
    local script = nil;
    for k, v in pairs(worldController.allElements) do
        if v.VisElement.gameObject.name == name then
            script = v
            break
        end
    end

    return script

end
function logic:GetElementByNames(names)
    local worldController = App:GetService("CommonService").gate.worldController
    local script = nil;
    for k, v in pairs(worldController.allElements) do
        for _k, _v in pairs(names) do
            if v.VisElement.gameObject.name == _v then
                script = v
                break
            end
        end
    end

    return script

end
return logic
