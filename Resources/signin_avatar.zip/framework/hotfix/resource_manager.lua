---@alias GameObject CS.UnityEngine.GameObject
---@alias Sprite CS.UnityEngine.Sprite
---@alias Texture CS.UnityEngine.Texture
---@alias AudioClip CS.UnityEngine.AudioClip
---@alias TextAsset CS.UnityEngine.TextAsset
---@alias Material CS.UnityEngine.Material
---@alias Coroutine CS.UnityEngine.Coroutine
---@alias AssetCallBack fun(asset: GameObject):void
---@alias AssetSpriteCallBack fun(asset:Sprite):void
---@alias AssetTextureCallBack fun(asset:Texture):void
---@alias AssetAudioClipCallBack fun(asset:AudioClip):void
---@alias AssetTextAssetCallBack fun(asset:TextAsset):void
---@alias AssetMaterialCallBack fun(asset:Material):void
require("common/functionProxy")
local cs_coroutine = require("common/cs_coroutine")
---@class ResourceManager
ResourceManager = {}
ResourceManager._handles = {}
-- 是否加LodGroup，默认不加
isOpenLodGroup = false
---@type CS.Com.Tal.Unity.Asset.ResourcesManager
local mgr = CS.Com.Tal.Unity.Asset.ResourcesManager.S

local Util = require("scripts/common/util")

--- 判断文件是否存在
---@param path string
---@return boolean
function ResourceManager:IsPathExist(path)
    return mgr:IsPathExist(path)
end

-- 判断AB包是否完整存在
---@param pkgName string
---@return boolean
function ResourceManager:PackageExist(pkgName)
    local exist = false
    local LocalDir = App:GetPackageCachePath(pkgName)
    if CS.System.IO.Directory.Exists(LocalDir) then
        local pkgJson = LocalDir .. "/package.json"
        local assetCatalog = LocalDir .. "/assets/catalog.json"
        if ResourceManager:IsPathExist(pkgJson) and ResourceManager:IsPathExist(assetCatalog) then
            exist = true
        else
            g_Log("资源包不完整", pkgName, pkgJson, assetCatalog)

            -- TODO 删了
            xpcall(function()
                CS.System.IO.Directory.Delete(LocalDir, true)
            end, function(err)
                g_LogError(err)
            end)
        end
    end

    return exist
end

---load text from resources,需要加文件后缀名
---@param path string
---@return string
function ResourceManager:LoadText(path)
    return mgr:LoadText(path)
end

function ResourceManager:_getRidOfOutLine(go)
    if go == nil or go:Equals(nil) then
        return
    end
    -- 获取物体上的Renderer组件
    local rendererList = go:GetComponentsInChildren(typeof(CS.UnityEngine.Renderer))
    if rendererList == nil or rendererList:Equals(nil) then
        return
    end
    for i = 0, rendererList.Length - 1 do
        local renderer = rendererList[i]
        -- 获取所有的材质
        self:_getRidOfOutLineWithRenderer(renderer)
    end
end

function ResourceManager:_getRidOfOutLineWithRenderer(renderer)
    if renderer == nil or renderer:Equals(nil) then
        return
    end
    -- 获取所有的材质
    local materials = renderer.sharedMaterials
    if materials == nil or materials:Equals(nil) then
        return
    end
    -- 创建一个新的列表，排除不需要的材质
    local newMaterials = {}
    local needReplace = false
    for i = 0, materials.Length - 1 do
        local material = materials[i]
        if material ~= nil and not material:Equals(nil) then
            if string.find(material.name, "Outline") == nil then
                table.insert(newMaterials, material)
            else
                needReplace = true
            end

            if material:HasProperty("_OutlineArea") then
                material:SetFloat("_OutlineArea", 0)
            end
        end
    end

    -- 将新的材质列表赋值回给Renderer
    if needReplace then
        renderer.sharedMaterials = newMaterials
    end
end

ResourceManager.LoadIdx = 0
ResourceManager.LoadQueue = {}
function ResourceManager:EnqueueAction(path, callback, Immediate)
    if Immediate then
        self:_LoadGameobject(path, callback)
        return
    end

    local action = {
        ["path"] = path,
        ["callback"] = callback
    }
    table.insert(self.LoadQueue, action)
    if #self.LoadQueue == 1 then
        self:_Next()
    end
end

function ResourceManager:_Next()
    if #self.LoadQueue == 0 then
        return
    end
    local action = self.LoadQueue[1]
    self.LoadIdx = self.LoadIdx + 1

    if self.LoadIdx % 3 == 0 then
        App:GetService("CommonService"):StartCoroutine(function()
            App:GetService("CommonService"):YieldEndFrame()

            self:_LoadGameobject(action.path, function(asset)
                xpcall(function()
                    action.callback(asset)
                end, function(err)
                    g_LogError(err)
                end)
                table.remove(self.LoadQueue, 1)
                self:_Next()
            end)
        end)
    else
        self:_LoadGameobject(action.path, function(asset)
            xpcall(function()
                action.callback(asset)
            end, function(err)
                g_LogError(err)
            end)
        end)
        table.remove(self.LoadQueue, 1)
        self:_Next()
    end
end

function ResourceManager:_LoadGameobject(path, callback)
    local originCb = nil
    local noOutLine = true
    if noOutLine or App.isNoOutlineDevice or (App.IsUltraLowDevice and App.IsABCZone) then
        -- 极差机器 去掉描边
        originCb = function(asset)
            self:_getRidOfOutLine(asset)
            if callback then
                callback(asset)
            end
        end
    else
        originCb = callback
    end
    local cb = FunctionProxyManager:GetGameObjectAction(originCb, true)
    return mgr:LoadGameObjectWithExName(path, cb)
end

---load resource async
---@param path string
---@param callback AssetCallBack
---@return Coroutine
function ResourceManager:LoadGameObjectWithExName(path, callback, Immediate)
    if self.EnqueueAction then
        ResourceManager:EnqueueAction(path, callback, Immediate)
        return
    end

    local originCb = nil
    if App.isNoOutlineDevice or (App.IsUltraLowDevice and App.IsABCZone) then
        -- 极差机器 去掉描边
        originCb = function(asset)
            self:_getRidOfOutLine(asset)
            if callback then
                callback(asset)
            end
        end
    else
        originCb = callback
    end
    local cb = FunctionProxyManager:GetGameObjectAction(originCb, true)
    return mgr:LoadGameObjectWithExName(path, cb)
end

-- @public Addressables加载GameObject 可以拿到AsyncOperationHandle自己释放
-- @param path string
-- @param callback fun(asset:GameObject,handle:AsyncOperationHandle):void
function ResourceManager:LoadGameObjectAndHanlderWithPath(path, callback)
    cs_coroutine.start(function()
        path = CS.Com.Tal.Unity.Asset.ResourcesManager.GetPath(path)

        local Addressables = CS.UnityEngine.AddressableAssets.Addressables
        local LoadAssetAsyncMethod = xlua.get_generic_method(Addressables, "LoadAssetAsync", 1)
        -- 获取带泛型的LoadAssetAsync方法
        local LoadAssetAsyncGameObject = LoadAssetAsyncMethod(typeof(CS.UnityEngine.GameObject))

        -- 调用该方法
        local handle = LoadAssetAsyncGameObject(path)
        table.insert(ResourceManager._handles, handle)

        coroutine.yield(handle)

        callback(handle.Result, handle)
    end)
end

---load asset sync
---@param path string
---@return Object @Unity Object
function ResourceManager:LoadAssetWithExNameSync(path)
    return mgr:LoadPathSync(path)
end

---@param callback AssetSpriteCallBack
---@return Coroutine
function ResourceManager:LoadSpriteWithExName(path, callback)
    local cb = FunctionProxyManager:GetUnityObjectCallBack(typeof(CS.UnityEngine.Sprite), callback, true)
    return mgr:LoadSpriteWithExName(path, cb)
end

function ResourceManager:LoadRuntimeAnimatorControllerWithPath(path, callback)

    local cb = FunctionProxyManager:GetUnityObjectCallBack(typeof(CS.UnityEngine.RuntimeAnimatorController), callback,
        true)
    -- 获取泛型方法
    local class = CS.Com.Tal.Unity.Asset.ResourcesManager
    local funcMap = xlua.get_generic_method(class, "LoadResourcesWithExName")
    local realFunction = funcMap(typeof(CS.UnityEngine.RuntimeAnimatorController))

    return realFunction(mgr, path, cb)
end

---@param callback AssetTextureCallBack
---@return Coroutine
function ResourceManager:LoadTextureWithExName(path, callback)
    return mgr:LoadTextureWithExName(path, function(asset)
        callback(asset)
    end)
    -- local cb = FunctionProxyManager:GetUnityObjectCallBack(typeof(CS.UnityEngine.Texture),callback,true)
    -- return mgr:LoadTextureWithExName(path, cb)
end

---@param callback AssetAudioClipCallBack
---@return Coroutine
function ResourceManager:LoadAudioClipWithExName(path, callback)
    return mgr:LoadAudioClipWithExName(path, function(asset)
        callback(asset)
    end)

    -- local cb = FunctionProxyManager:GetUnityObjectCallBack(typeof(CS.UnityEngine.AudioClip),callback,true)
    -- mgr:LoadAudioClipWithExName(path, cb)
end

---@param callback AssetTextAssetCallBack
---@return Coroutine
function ResourceManager:LoadTextAssetWithExName(path, callback)
    return mgr:LoadTextAssetWithExName(path, function(asset)
        callback(asset)
    end)
    -- local cb = FunctionProxyManager:GetUnityObjectCallBack(typeof(CS.UnityEngine.TextAsset),callback,true)
    -- return mgr:LoadTextAssetWithExName(path, cb)
end

---@param callback AssetMaterialCallBack
---@return Coroutine
function ResourceManager:LoadMaterialWithExName(path, callback)
    return mgr:LoadMaterialWithExName(path, function(asset)
        callback(asset)
    end)
end

function ResourceManager:LoadAnimationClipWithExName(path, callback)
    return mgr:LoadAnimationClipWithExName(path, function(asset)
        callback(asset)
    end)
end

function ResourceManager:LoadPlayableAssetWithExName(path, callback)
    return mgr:LoadPlayableAssetWithExName(path, function(asset)
        callback(asset)
    end)
end

-- ---释放资源,Object类型的使用此
-- ---@param sp Object
-- ---@return void
-- function ResourceManager:ReleaseObject(sp)
--     return mgr:ReleaseObject(sp)
-- end

---销毁物体GameObject
---@param go GameObject
---@return void
function ResourceManager:ReleaseGameObject(go)
    return mgr:ReleaseGameObject(go)
end

---读取StreamingAssets下的Text文件
---@param filename string
---@return string
function ResourceManager:ReadStreamingFile(filename)
    return mgr:ReadStreamingFile(filename)
end

---读取StreamingAssets下的Text文件
---@param filename string
---@return Byte[] @bytes
function ResourceManager:ReadStreamingBytes(filename)
    return mgr:ReadStreamingFile(filename)
end

---读取本地文件string
---@param fullpath string 文件的绝对路径
---@return string 本地文件字符串
function ResourceManager:ReadLocalText(fullpath)
    return mgr:ReadLocalText(fullpath)
end

---读取本地文件Bytes
---@param fullpath string 文件的绝对路径
---@return Byte[] 本地文件字节
function ResourceManager:ReadLocalBytes(fullpath)
    return mgr:ReadLocalBytes(fullpath)
end

---@deprecated
---@param scenename string @根据Addressable的路径进行场景单独加载
---@return Coroutine @AsyncOperationHandle<SceneInstance>
function ResourceManager:LoadSceneAysncSingle(scenename)
    return self:LoadSceneAsyncSingle(scenename)
end

function ResourceManager:LoadSceneAsyncSingle(scenename)
    if string.find(scenename, ".unity") == nil then
        scenename = scenename .. ".unity"
    end
    return mgr:LoadSceneAsync(scenename)
end

---@deprecated
---@param scenename string @根据Addressable的路径进行场景增量加载
---@return Coroutine @AsyncOperationHandle<SceneInstance>
function ResourceManager:LoadSceneAysncAdditive(scenename)
    return self:LoadSceneAsyncAdditive(scenename)
end

---@param scenename string @根据Addressable的路径进行场景增量加载
---@return Coroutine @AsyncOperationHandle<SceneInstance>
function ResourceManager:LoadSceneAsyncAdditive(scenename)
    if string.find(scenename, ".unity") == nil then
        scenename = scenename .. ".unity"
    end
    return mgr:LoadSceneAsyncAdditive(scenename)
end

---@param scenename string 卸载场景
---@return Coroutine @AsyncOperationHandle<SceneInstance>
function ResourceManager:UnLoadSceneAsync(sceneInstance)
    mgr:UnLoadSceneAsync(sceneInstance)
end

function ResourceManager:LoadPlayableAsset(path, callback)
    return mgr:LoadPlayableAsset(path, callback)
end

---@param path string
---@param callback fun(asset:Object):void
function ResourceManager:LoadAssetWithExName(path, callback)
    return mgr:LoadAssetWithExName(path, function(asset)
        callback(asset)
    end)
end

function ResourceManager:LoadGraphNodeAssetWithExName(path, callback)
    return mgr:LoadGraphNodeAssetWithExName(path, function(asset)
        callback(asset)
    end)
end

---@param path string
---@param callback fun(clip:AudioClip):void
function ResourceManager:LoadLocalAudioClip(path, callback)
    mgr:LoadLocalAudioClip(path, function(asset)
        callback(asset)
    end)
end

function ResourceManager:UnloadUnUsedAssets()
    mgr:UnloadUnusedAsset()
end

---此方法不可以在interaction中调用,只能在环节结束的gate中使用
function ResourceManager:ForceReleaseAllAssetBundles()
    mgr:ForceReleaseAllAssetBundles()
end

---@public 释放异步加载的资源
---@param handle AsyncOperationHandle
function ResourceManager:ReleaseAsyncOperation(handle)
    mgr:ReleaseAsyncOperation(handle)
end

---@public 释放异步加载的资源
---@param object Object
function ResourceManager:ReleaseObject(object)
    -- xpcall(function()
    mgr:ReleaseObject(object)
    -- end,function(err) g_LogError(err) end)
end

function ResourceManager:tryToRelease()
    mgr:TryToRelease()

    if ResourceManager._handles then
        for i, v in ipairs(ResourceManager._handles) do
            ResourceManager:ReleaseAsyncOperation(v)
        end
        ResourceManager._handles = {}
    end

    g_Log("frame -- ResourceManager:tryToRelease")
    if not App.EnableForceRelease then
        return
    end

    g_Log("frame -- 检测未释放资源 开启强制释放")
    -- 处理下release后如果存在未释放的资源 释放一下
    local loadedAssets = CS.UnityEngine.AssetBundle.GetAllLoadedAssetBundles()
    for i = 0, loadedAssets.Length - 1 do
        xpcall(function()
            local ab = loadedAssets[i]
            local assetNames = ab:GetAllAssetNames()
            local isMain = false
            for i = 0, assetNames.Length - 1 do
                local name = assetNames[i]
                if string.startswith(name, "Assets/modules/ABC_Main") then
                    isMain = true
                else
                    isMain = false
                    break
                end
                g_Log("未释放掉的资源名字", name)
            end
            if isMain then
                ab:Unload(true)
            end
        end, function(err)
            g_LogError(err)
        end)
    end
end

--- 清除内存，执行GC，可能会造成1s的卡顿
--- 建议在场景切换的时候执行
function ResourceManager:CleanMemoryAndUnUsedAsset()
    -- 低版本的壳工程不支持
    xpcall(function()
        mgr:GCCleanUpMemory()
    end, function(err)
        g_LogError(err)
    end)
    mgr:UnloadUnusedAsset();
end

-- 加Lod Group
---@param gameObject GameObject 加 lod 的物体
---@param screenRelativeTransitionHeight number 物体相对屏幕大小比例（范围0～1）
---@param type number 物体类型 1：avatar 2：宠物 3：道具
function ResourceManager:AddLodGroup(gameObject, type)
    if not App:IsLowDevice() then
        -- 非低端机不加lod
        return
    end
    -- if isOpenLodGroup == false then
    --     -- 由组件去控制开关
    --     return
    -- end

    if App.IsUltraLowDevice then
        -- 极差设备已经视距25 不用开LOD了
        return
    end

    -- 暂时只给abc主场景开启
    if not App:IsAbcZoneMain() and not App:IsMathMain() and not App:IsCNMain() then
        return
    end

    -- {"isOpen":"1","avatarScreenRelativeTransitionHeight":"0.048","petScreenRelativeTransitionHeight":"0.04","propScreenRelativeTransitionHeight":"0.072"}
    if App.LodConfiguration and App.LodConfiguration.isOpen then
        if tonumber(App.LodConfiguration.isOpen) == 0 then
            return
        end
    end
    ---@type number
    local screenRelativeTransitionHeight = 0.012
    if type == 1 then
        if self.canSend then
            -- 自己不加lod
            return
        end
        if App.LodConfiguration and App.LodConfiguration.avatarScreenRelativeTransitionHeight then
            screenRelativeTransitionHeight = tonumber(App.LodConfiguration.avatarScreenRelativeTransitionHeight)
        else
            screenRelativeTransitionHeight = 0.048
        end
    end
    if type == 2 then
        if App.LodConfiguration and App.LodConfiguration.petScreenRelativeTransitionHeight then
            screenRelativeTransitionHeight = tonumber(App.LodConfiguration.petScreenRelativeTransitionHeight)
        else
            screenRelativeTransitionHeight = 0.04
        end
    end

    if type == 3 then
        if App.LodConfiguration and App.LodConfiguration.propScreenRelativeTransitionHeight then
            screenRelativeTransitionHeight = tonumber(App.LodConfiguration.propScreenRelativeTransitionHeight)
        else
            screenRelativeTransitionHeight = 0.072
        end
    end

    self:AddLodGroupByHeight(gameObject, screenRelativeTransitionHeight)
end

-- 加Lod Group
---@param gameObject GameObject 加 lod 的物体
---@param height number 物体相对屏幕大小比例（范围0～1）
function ResourceManager:AddLodGroupByHeight(gameObject, height)
    -- 鸿蒙关闭lod
    if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.OpenHarmony then
        return
    end

    if not App:IsLowDevice() then
        -- 非低端机不加lod
        return
    end

    if App.IsUltraLowDevice then
        -- 极差设备已经视距25 不用开LOD了
        return
    end

    if App.LodConfiguration and App.LodConfiguration.isOpen then
        if tonumber(App.LodConfiguration.isOpen) == 0 then
            return
        end
    end

    local lodGroup = gameObject:GetComponent(typeof(CS.UnityEngine.LODGroup))
    if lodGroup == nil then
        lodGroup = gameObject:AddComponent(typeof(CS.UnityEngine.LODGroup))
    end
    lodGroup.fadeMode = CS.UnityEngine.LODFadeMode.CrossFade

    local renderers = gameObject:GetComponentsInChildren(typeof(CS.UnityEngine.Renderer))
    local curRenderersTable = {}
    for i = 0, renderers.Length - 1 do
        table.insert(curRenderersTable, renderers[i])
    end
    local lods = {}
    local lod = CS.UnityEngine.LOD(height, curRenderersTable)
    table.insert(lods, lod)

    lodGroup:SetLODs(lods)

    lodGroup:RecalculateBounds()
end

function ResourceManager:AddAnimatorLod(animator)

    -- if App:IsLowDevice() and not App.IsStudioClient then
    --     return
    -- end
    if not App:IsLowDevice() then
        return
    end

    if Util:IsNil(Camera.main) then
        return
    end

    --这里需要加个类型检查 是Animator类型才可以
    if not cs_isTypeof(animator, typeof(CS.UnityEngine.Animator)) then
        return
    end

    if Util:IsNil(animator) then
        return
    end

    if not self.animatorLodMap then
        self.animLodNear = 20 * 20
        self.animLodMiddle = 30 * 30
        self.animLodFar = 40 * 40
        self.lodnum = 0
        self.animatorLodMap = {}
        self.cameraPos = NextMath.Vector3(Camera.main.transform.position.x, Camera.main.transform.position.y,
            Camera.main.transform.position.z)
        -- 新增：记录上一帧相机位置（微移动检测），相机/角色运动都很小则跳过距离重算，减少CPU
        self.lastCameraPos = NextMath.Vector3(self.cameraPos.x, self.cameraPos.y, self.cameraPos.z)
        -- 新增：缓存相机Transform，减少每次 Camera.main.transform 的跨语言访问
        self.camTrans = Camera.main and Camera.main.transform or nil
        -- 新增：LOD滞回带宽（10%），进入与退出阈值不同，避免在边界来回抖动频繁enable/disable Animator
        self.lodHysteresisMargin = self.lodHysteresisMargin or 0.1
        -- 新增：大规模对象分批扫描配置，每次只处理固定配额，避免0.1s时钟点全量抖动
        self.lodBatchSize = self.lodBatchSize or 100
        self._keysCache = nil
        self._keysDirty = true
        self._scanCursor = 1
        -- 新增：逻辑时钟用于累积各对象未处理期间的时间，保证time-slicing下动画推进一致性
        self._time = self._time or 0
        -- 新增：单次Animator.Update步进上限（秒），避免累计时间过大导致一次性卡顿
        self.maxAnimatorUpdateStep = self.maxAnimatorUpdateStep or 0.2
        -- 新增：相机/角色微移动阈值（平方距离），小于阈值时认为未显著移动
        self.camMoveEps2 = self.camMoveEps2 or (0.05 * 0.05)
        self.roleMoveEps2 = self.roleMoveEps2 or (0.05 * 0.05)
        self.deltaTime = 0.1
        self.tickId = App:GetService("CommonService"):RegisterGlobalTimer(self.deltaTime, function()
            self:Update()

        end, false)
    end

    local instanceId = animator:GetInstanceID()
    if not self.animatorLodMap[instanceId] then
        self.animatorLodMap[instanceId] = {
            animator = animator,
            lodLevel = -1,
            lodTimer = 0,
            rolePos = NextMath.Vector3(animator.transform.position.x, animator.transform.position.y,
                animator.transform.position.z),
            animLodInterval = self.deltaTime * 3,
            -- 新增：记录上次被处理的逻辑时间，time-slicing 时用于计算准确dt
            lastProcessedTime = self._time or 0
        }
        self.lodnum = self.lodnum + 1
        -- 新增：标记key缓存已脏，下一轮重建keys列表（供时间片扫描使用）
        self._keysDirty = true
    end

end

function ResourceManager:Update()
    if self.lodnum <= 0 then
        return
    end

    -- 累积逻辑时间：用于time-slicing下为每个对象提供准确的dt
    self._time = (self._time or 0) + self.deltaTime

    -- 使用缓存的相机Transform，减少跨语言调用；若失效则重新获取
    local camT = self.camTrans
    if Util:IsNil(camT) then
        local cam = Camera.main
        if Util:IsNil(cam) then return end
        self.camTrans = cam.transform
        camT = self.camTrans
    end
    local p = camT.position

    -- 计算相机微移动（平方距离），小于阈值认为不需要重算LOD
    local lcp = self.lastCameraPos or self.cameraPos
    local cdx = p.x - lcp.x
    local cdy = p.y - lcp.y
    local cdz = p.z - lcp.z
    local camMoved2 = cdx * cdx + cdy * cdy + cdz * cdz

    -- 更新相机位置缓存
    self.cameraPos.x = p.x
    self.cameraPos.y = p.y
    self.cameraPos.z = p.z
    if self.lastCameraPos then
        self.lastCameraPos.x = p.x
        self.lastCameraPos.y = p.y
        self.lastCameraPos.z = p.z
    end

    -- 重建keys缓存（当新增/移除对象后）
    if self._keysDirty or (not self._keysCache) then
        self._keysCache = {}
        for k, _ in pairs(self.animatorLodMap) do
            table.insert(self._keysCache, k)
        end
        self._keysDirty = false
        if self._scanCursor > #self._keysCache then
            self._scanCursor = 1
        end
    end

    -- 常量本地化，减少查表/桥接
    local near = self.animLodNear
    local middle = self.animLodMiddle
    local far = self.animLodFar
    local margin = self.lodHysteresisMargin or 0
    local camEps2 = self.camMoveEps2 or 0
    local roleEps2 = self.roleMoveEps2 or 0
    local stepMax = self.maxAnimatorUpdateStep or 0.2
    local batch = self.lodBatchSize or 100
    local total = #self._keysCache
    if total == 0 then
        return
    end

    local startIdx = self._scanCursor
    local cnt = math.min(batch, total)
    local deadKeys = {}

    -- 带滞回的LOD计算，使用进入/退出不同阈值减少抖动
    local function computeLodWithHysteresis(dist, prev)
        if prev == nil then prev = -1 end
        local nIn, nOut = near * (1 - margin), near * (1 + margin)
        local mIn, mOut = middle * (1 - margin), middle * (1 + margin)
        local fIn, fOut = far * (1 - margin), far * (1 + margin)

        if prev == -1 then
            if dist < near then return 0 elseif dist < middle then return 1 elseif dist < far then return 2 else return 3 end
        elseif prev == 0 then
            if dist > nOut then
                if dist > mOut then
                    if dist > fOut then return 3 else return 2 end
                else return 1 end
            else return 0 end
        elseif prev == 1 then
            if dist < nIn then return 0
            elseif dist > mOut then
                if dist > fOut then return 3 else return 2 end
            else return 1 end
        elseif prev == 2 then
            if dist < mIn then
                if dist < nIn then return 0 else return 1 end
            elseif dist > fOut then
                return 3
            else return 2 end
        elseif prev == 3 then
            if dist < fIn then
                if dist < mIn then
                    if dist < nIn then return 0 else return 1 end
                else return 2 end
            else return 3 end
        end
        return prev
    end

    -- 扫描本批次对象，分摊大规模遍历成本
    local idx = startIdx
    for i = 1, cnt do
        if idx > total then idx = 1 end
        local k = self._keysCache[idx]
        idx = idx + 1
        local v = self.animatorLodMap[k]
        if v ~= nil then
            local animator = v.animator

            if Util:IsNil(animator) then
                table.insert(deadKeys, k)
            else
                -- 使用累计逻辑时间计算本批次的dt，确保降频仍能正确推进动画
                local dt = self._time - (v.lastProcessedTime or self._time)
                v.lastProcessedTime = self._time

                -- 角色微移动检测，微动时无需重算LOD
                local rolePos = v.rolePos
                local t = animator.transform
                local pos = t.position
                local rdx = pos.x - rolePos.x
                local rdy = pos.y - rolePos.y
                local rdz = pos.z - rolePos.z
                local roleMoved2 = rdx * rdx + rdy * rdy + rdz * rdz

                -- 更新缓存位置（后续可能用于距离计算）
                rolePos.x = pos.x
                rolePos.y = pos.y
                rolePos.z = pos.z

                local needReLod = camMoved2 >= camEps2 or roleMoved2 >= roleEps2 or v.lodLevel == -1
                if needReLod then
                    local dist = NextMath.DistanceSqrt(self.cameraPos, rolePos)
                    local lod = computeLodWithHysteresis(dist, v.lodLevel)
                    if lod ~= v.lodLevel then
                        -- 仅在等级变化时落地设置，避免重复调用，且设置不同的限频间隔
                        if lod == 0 then
                            animator.enabled = true
                            v.animLodInterval = self.deltaTime * 1
                        elseif lod == 1 then
                            animator.enabled = false
                            v.animLodInterval = self.deltaTime * 2
                        elseif lod == 2 then
                            animator.enabled = false
                            v.animLodInterval = self.deltaTime * 4
                        elseif lod == 3 then
                            animator.enabled = false
                        end
                        v.lodLevel = lod
                        v.lodTimer = 0
                    end
                end

                -- 根据LOD等级推进动画：近(0)无需我们手动Update；中远(1/2)按间隔补偿；最远(3)不评估
                if v.lodLevel == 1 or v.lodLevel == 2 then
                    v.lodTimer = v.lodTimer + dt
                    if v.lodTimer >= (v.animLodInterval or self.deltaTime) then
                        -- 单次步进上限，避免一次性 Update(大dt) 卡顿，将累计时间分片推进
                        local remaining = v.lodTimer
                        while remaining > 0 do
                            local step = remaining > stepMax and stepMax or remaining
                            animator:Update(step)
                            remaining = remaining - step
                        end
                        v.lodTimer = 0
                    end
                end
            end
        end
    end

    -- 更新扫描游标，下一次从上次结束位置继续
    self._scanCursor = idx

    -- 集中清理无效项，避免在pairs中改表结构导致的抖动
    if #deadKeys > 0 then
        for _, key in ipairs(deadKeys) do
            if self.animatorLodMap[key] ~= nil then
                self.animatorLodMap[key] = nil
                self.lodnum = self.lodnum - 1
            end
        end
        self._keysDirty = true
    end
end

return ResourceManager
