

if(HotfixManager ~=nil) then return HotfixManager end

---@class HotfixManager
HotfixManager = {}

---@type CS.Com.Tal.Unity.Runtime.Hotfix.HotfixManager
local manager = CS.Com.Tal.Unity.Runtime.Hotfix.HotfixManager.S
local resourceManager = require("hotfix/resource_manager")
---@param catalog string
---@return Coroutine
function HotfixManager:LoadCatalog(catalog) 
   return  manager:BeginLoadCatalog(catalog)
end


function HotfixManager:AfterSceneLoadedImmediately(scene)
    -- 判断是否需要去描边
    if true then
      local rendererList = scene:FindObjectsOfType(typeof(CS.UnityEngine.Renderer),true)
      for i =0 ,rendererList.Length - 1 do
         local sRenderer = rendererList[i]
         resourceManager:_getRidOfOutLineWithRenderer(sRenderer)
      end
    end
end

function HotfixManager:SetupFixScripts(param)
   local files = {"ai_game"}
   for k, v in pairs(files) do
       xpcall(function()
           local s = require("hotfix/hotfix_scripts/" .. v)
           if s and s.Setup then
              s:Setup()
           end
       end, function(err)
           print("error", err)
       end)
   end
end


return HotfixManager