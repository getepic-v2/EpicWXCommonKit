
local class = require(" middleclass")
---@class Asset @Asset:new(address,fun(self, asset) end)
local Asset = class("Asset")

function Asset:initialize(address,loaded)
    ---@private
    self.Asset = address
    self.Loaded = loaded
end

function Asset:Destroy()
    
end