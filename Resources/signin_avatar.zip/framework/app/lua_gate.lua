
local class = require("middleclass")

---@class LuaGate
local LuaGate = class("LuaGate")

--- enter gate
---@return void
function LuaGate:Enter()
    
end

--- exit gate
---@return void
function LuaGate:Exit()
    
end

---@return boolean @true is means finished
function LuaGate:Tick()
    return false
end

function LuaGate:SetQuality()
    g_Log("lua_gate ---SetQuality: IsStudioClient = " .. tostring(App.IsStudioClient) .. "  IsStudioClass = " .. tostring(App.IsStudioClass))
    -- pc端画质分级走的是studio设置，不响应此接口。
    if App.IsStudioClient then
        return
    end

    local targetLevel = 0
    local scale = '1/1'
    -- perfQuality 1 低端机  2 中端机  3 高端机  6 vr
    if App.Info and App.Info.perfQuality then
        g_Log("lua_gate ScreenResolution ---perfQuality: ", App.Info.perfQuality)
        if App.IsStudioClass then
            if App.Info.perfQuality >= 3 then
                targetLevel = 2
            elseif App.Info.perfQuality == 2 then
                targetLevel = 1
                -- 这行代码设置了Unity引擎中的LOD偏差值为1
                -- LOD (Level of Detail) 是一种优化技术，用于根据物体与相机的距离来调整模型的细节程度
                -- lodBias值为1表示使用标准LOD级别，值越小模型细节越低（性能更好），值越大模型细节越高（性能要求更高）
                -- 这里为中端机设置了标准LOD级别，以平衡性能和视觉质量
                CS.UnityEngine.QualitySettings.lodBias = 1  
            else 
                targetLevel = 0
            end
        else
            targetLevel = 0
        end
    else
        targetLevel = 0
    end

    if App.Info and type(App.Info.screenScale) == 'string' then
        scale = App.Info.screenScale
    elseif targetLevel == 0 then
        scale = '2/3'
    end
    g_Log("ScreenResolution level:" .. tostring(targetLevel) .. "  scale:" .. tostring(scale))
    App:SetQuality(targetLevel, scale)
end

return LuaGate