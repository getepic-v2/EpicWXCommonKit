---@type EventSubscribe
local EventSubscribe = require("event_subscribe")

-- 引用数据埋点API
require(NEXT_STUDIO_BASE_SCRIPTS_LOC .. "nextstudio_component_api")

if (App ~= nil) then
    return App
end

---@class PlayerType
local PlayerType = {
    Student = 'student',
    Teacher = 'teacher',
    GameServer = 'server',
    UserId = ''
}

NEXT_ENUM_LIVETYPE = {
    RECORD_LOCAL = 1, -- 录播单机
    RECORD_ONLINE = 2, -- 录播联机
    RECORD_LIVE_LOCAL = 3, -- 录直播单机
    RECORD_LIVE_ONLINE = 4 -- 录直播或者直播联机
}

TRIGGER_LEVEL = {
    TRIGGER_LEVEL_FIRST = 1, -- 第一个调用
    TRIGGER_LEVEL_NORMAL = 50, -- 正常调用
    TRIGGER_LEVEL_LAST = 100 -- 最后一个调用
}

MOD_PLATFORM = {
    Default     = 1, -- 默认 少年创境
    ABCZone     = 2, -- ABC英语角（英语天天练）
    Math        = 3, -- 数学天天练
    Preview     = 4, -- 学而思天天练
    Chinese     = 4, -- 语文(后改名天天学)
    ABCPlanet   = 5, -- ABC星球
    Science     = 6, -- 科学天天练
    RealChinese = 7,-- 新的语文天天练
}

---@class App @Application
---@field OnServiceStarted EventSubscribe @<Service,string>
---@field OnServiceStop   EventSubscribe @<Service,string>
---@field Uuid string
---@field Properties.AvatarName  string
---@field Properties.AvatarType string@teacher,student
---@field Properties.Gender string @male,female
---@field Properties.UserId string @用户id
---@field Properties.UnionId string @账号互通后的unionId
---@field Properties.SkinName string @皮肤名称
---@field Properties.SkinIosUrl string @皮肤对应ios的地址
---@field Properties.SkinAndroidUrl string @皮肤对应Android的地址
---@field Properties.FaceInfo table @脸部信息
---@field Properties.Platform MOD_PLATFORM @平台
---@field Properties.ImgUrl string @头像地址
---@field ScreenDefaultWidth number 屏幕原始宽度（按横屏，宽度比高度大处理）
---@field ScreenDefaultHeight number 屏幕原始高度
---@field curFrameIndex number @当前远端帧号
---@field modPlatform MOD_PLATFORM @平台
---@field IsServer boolean @是否是服务器
---@field IsStudioClient boolean @是否是StudioClient
---@field IsStudioClass boolean @是否是StudioClass
---@field IsUltraLowDevice boolean @是否是极差机型
---@field isLowDevice boolean @是否是低端机
---@field isMiddleDevice boolean @是否是中端机
---@field isHighDevice boolean @是否是高端机
---@field courseType NEXT_ENUM_LIVETYPE @课程类型
---@field IsLocalModel boolean @是否是本地模式
---@field IsPlayBack boolean @是否是回放
---@field IsABCZoneApp boolean @是否是ABC英语角
---@field IsDebugAppBundle boolean @是否是DebugAppBundle
---@field IsXpad boolean @是否是Xpad
---@field IsDebug boolean @是否是Debug
---@field Info.sessionId string @SessionId
---@field Info.localSessionId string @本地SessionId
---@field Info.liveId string @直播id
---@field Info.userId string @用户id
---@field Info.configMap table @配置信息
---@field Info.netEnvType number @网络环境类型
---@field Info.pattern number @模式
---@field Info.roomId string @房间id
---@field hookEnable boolean @是否开启lua的hook
---@field CameraRTScaleHigh number @高端机分辨率缩放值
---@field CameraRTScaleMedium number @中端机分辨率缩放值
---@field CameraRTScaleLow number @低端机分辨率缩放值
---@field CameraRTScaleUltraLow number @极差机分辨率缩放值
App = {
    OnServiceStarted = EventSubscribe:new(),
    OnServiceStop = EventSubscribe:new(),
    OnSceneDidLoaded = EventSubscribe:new(),
    Uuid = '', -- Irc的NickName 注意：不是用户id
    Properties = {
        AvatarName = 'Default', -- 昵称
        AvatarType = 'student', -- 类型 老师or学生
        Gender = 'male', -- 性别
        UserId = '', -- userId
        SkinName = nil, -- 皮肤名称
        SkinIosUrl = nil, -- 皮肤对应ios的地址
        SkinAndroidUrl = nil, -- 皮肤对应Android的地址
        FaceInfo = {}, -- 脸部信息
        Platform = MOD_PLATFORM.Default, -- 平台
        ImgUrl = '', -- 头像地址
        UnionId = '' -- 账号互通后的unionId
    },
    ScreenDefaultWidth = math.max(CS.UnityEngine.Screen.width, CS.UnityEngine.Screen.height),
    ScreenDefaultHeight = math.min(CS.UnityEngine.Screen.width, CS.UnityEngine.Screen.height),
    curFrameIndex = 0, -- 当前远端帧号

    modPlatform = MOD_PLATFORM.Default, -- 默认 少年创境

    hookEnable = false, -- 是否开启lua的hook
    targetFrameRate = 30, -- 目标帧率
    isLowDevice = false, -- 是否是低端机
    isMiddleDevice = false, -- 是否是中端机
    isHighDevice = false, -- 是否是高端机
    CameraRTScaleHigh = 100, -- 高端机分辨率缩放值
    CameraRTScaleMedium = 100, -- 中端机分辨率缩放值
    CameraRTScaleLow = 50, -- 低端机分辨率缩放值
    CameraRTScaleUltraLow = 40, -- 极差机分辨率缩放值
    CameraRTScale = 1 -- 分辨率缩放值
}

-- 默认开启LuaVector3
App.UseLuaVector3 = true

App.OnServiceStop:connect(function(service, name)
    info_print("Stop service " .. name)
end)

App.OnServiceStarted:connect(function(service, name)
    info_print("Start service" .. name)
end)

---@type boolean
App.IsServer = GateManager.IsServer

---@type boolean
App.IsStudioClient = GateManager.IsStudioClient

---@type boolean
App.IsStudioClass = GateManager.IsStudioClass

g_LogColorMsg("App Run Type Is Server :" .. tostring(App.IsServer) .. tostring(App.IsStudioClient) ..
                  tostring(App.IsStudioClass))

---load null
function App:LoadNull()
    GateManager:LoadNull()
end

function App:GetVersion()
    return GateManager.AppVersion
end

---@return string @ PlayerType
function App:AppPlatform()
    for k, v in pairs(PlayerType) do
        if App.Properties.AvatarType == v then
            return k
        end
    end
end

---@public
---@param gate LuaGate
function App:StartGate(gate)
    return GateManager:StartInvoke(gate, gate.Enter, gate.Exit, gate.Tick)
end

---@public
---@param level
---@param scale string 分数，如 1/2, 1/3
function App:SetQuality(level, scale)
    -- 由 c# 实现
    -- App:SetResolution(scale)
    App:SetRenderQualityLevel(level)
end

---@public
---@param frame
function App:SetFrameRate(frame)
    print("Current FrameRate is:" .. tostring(frame))
    GateManager:SetFrameRate(frame)
end

function App:SetLandscape()
    GateManager:SetLandscape()
end

function App:SetPortrait()
    GateManager:SetPortrait()
end

function App:SetPostProcessing(bActive)
    GateManager:SetCameraPostProcessing(bActive)
end

function App:SetCameraRenderer(index)
    --    GateManager:SetCameraRenderer(index)
end

function App:TryToRelease()
    GateManager:TryToRelease()
end

---@param cb fun(ver:string) :void
---@param err fun(err:string) :void
function App:ImportAsync(cb, err, ...)
    GateManager:ImportAsync(cb, err, ...)
end

function App:GetPackageCachePath(packageName)
    if not packageName then
        return GateManager.PackageCachePath
    end
    return GateManager:GetPackageCachePath(packageName)
end

---@param name string
---@return Service
function App:GetService(name)
    local s = self.Services and self.Services[name]
    if not s then
        -- g_LogError("not found service of "..name..debug.traceback())
        return nil
    else
        return s;
    end
end

---@param service Service
---@param name string
---@return Service
function App:RegisterService(name, service)
    self.Services = self.Services or {}
    self.Services[name] = service
    service.ServiceName = name
    service:Start()
    self.OnServiceStarted(service, name)
    return service
end

---public
---只注册服务，不开启服务
---@param service Service
---@param name string
---@return Service
function App:RegisterServiceOnly(name, service)
    self.Services = self.Services or {}
    self.Services[name] = service
    service.ServiceName = name
    return service
end

---public
---开启服务
---@field service Service
function App:CallServiceStart(service)
    service:Start()
    self.OnServiceStarted(service, service.ServiceName)
end

---@param name string
function App:UnRegisterService(name)
    local s = self.Services and self.Services[name] ---@type Service
    if s then
        self.OnServiceStop(s, name)
        s:Exit()
        self.Services[name] = nil
    end
end

function App:IsLowDevice()
    if App.IsUltraLowDevice or App.isLowDevice then
        return true
    end
    local deviceLevel = App:GetCurrentRenderQualityLevel()
    if deviceLevel and deviceLevel == 1 then
        App.isLowDevice = true
        return true
    end

    return false;
end

function App:IsMiddleDevice()
    if App.isMiddleDevice then
        return true
    end
    local deviceLevel = App:GetCurrentRenderQualityLevel()
    if deviceLevel and deviceLevel == 2 then
        App.isMiddleDevice = true
        return true
    end

    return false;
end

function App:IsHighDevice()
    if App.isHighDevice then
        return true
    end
    local deviceLevel = App:GetCurrentRenderQualityLevel()
    if deviceLevel and deviceLevel == 3 then
        App.isHighDevice = true
        return true
    end
    return false;
end



---画质1，2，3.低，中，高
function App:GetCurrentRenderQualityLevel()
    local level = 999
    if App.Info and App.Info.perfQuality then
        level = App.Info.perfQuality
    end
    return level
end

---画质0，1，2.低，中，高
function App:SetRenderQualityLevel(level)
    xpcall(function()
        local QualitySettings = CS.UnityEngine.QualitySettings
        QualitySettings.SetQualityLevel(level)
    end, function()
        g_LogError("壳工程版本不对，无法修改")
    end)
end

--- 低端机降低分辨率
---@param scale string 分数，如 1/2, 1/3
function App:SetResolution(scale)
    xpcall(function()
        if scale ~= nil and type(scale) == 'string' and #scale > 0 then
            local result = string.split(scale, '/')
            -- 分子 分母
            local numerator = tonumber(result[1])
            local denominator = tonumber(result[2])
            local s = 1
            if numerator ~= 0 and denominator ~= 0 then
                s = numerator / denominator
            end
            local width = App.ScreenDefaultWidth
            local height = App.ScreenDefaultHeight
            if width > 0 and height > 0 then
                CS.UnityEngine.Screen.SetResolution(math.floor(width * s), math.floor(height * s), true)
                g_Log("ScreenResolution 设为原 " .. scale)
            end
        else
            g_Log("ScreenResolution 未更改 " .. tostring(scale))
        end
    end, function()
        g_LogError("ScreenResolution 设置失败" .. tostring(scale))
    end)
end

--- 获取真正的物理像素，如果 Unity 修改了屏幕缩放，获取的尺寸是缩放后的
--- @param size number 需要转换的尺寸
function App:GetRealPixel(size)
    if App.ScreenDefaultWidth == 0 then
        return size
    end

    --- 计算屏幕当前缩放值
    local scale = math.max(CS.UnityEngine.Screen.width, CS.UnityEngine.Screen.height) / App.ScreenDefaultWidth
    if scale == 0 then
        return size
    end
    return size / scale
end

function App:ConvertRecordLiveTimestamp(Timestamp)
    g_Log("ConvertRecordLiveTimestamp 方法已经弃用请老师使用：WorldController中 GetTimeFromFirstFrame()")
    local timestamp = Timestamp
    local isLive = self:IsLive()
    if isLive then
        return timestamp
    end

    local playTime = App.Info.recordPlayTime

    local planTime = self.Info.configMap.businessField.recordPlanStartTime
    local videoStartTime = self.Info.configMap.businessField.recordVideoStartTime
    planTime = tonumber(planTime)
    videoStartTime = tonumber(videoStartTime)

    if playTime and playTime > 0.1 and planTime ~= nil and videoStartTime ~= nil then
        local sendTime = App.Info.recordSendTime
        local updateTime = App.Info.recordUpdateTime
        local Millisecond_Timestamp = 1577850781000 -- 2020年的毫秒级时间戳
        if timestamp ~= nil then
            local isString = false
            if type(timestamp) == "string" then
                timestamp = tonumber(timestamp)
            end

            local sendDuration = 300 -- 毫秒级时间
            if timestamp < Millisecond_Timestamp then -- 证明是秒级时间戳
                planTime = planTime / 1000
                playTime = playTime / 1000
                sendTime = sendTime / 1000
                videoStartTime = videoStartTime / 1000

                if updateTime ~= nil then
                    updateTime = updateTime / 1000
                else
                    updateTime = 0
                end
                sendDuration = 0.3
                isString = true
            end

            if sendTime and sendTime > 0.1 then
                g_Log("ConvertRecordLiveTimestemp" .. "|value" .. tostring(timestamp) .. "|planeTime" ..
                          tostring(planTime) .. "|playTime" .. tostring(playTime) .. "|sendTime" .. tostring(sendTime))

                timestamp = timestamp + planTime + playTime - sendTime

                g_Log("ConvertRecordLiveTimestemp" .. "|value" .. tostring(timestamp) .. "|planeTime" ..
                          tostring(planTime) .. "|playTime" .. tostring(playTime) .. "|sendTime" .. tostring(sendTime))
            else
                -- 处理topic的情况topic返回updatetime和playTime 在playtime基础上减300毫秒作为sendTime发送时间
                timestamp = timestamp + planTime + playTime - updateTime - sendDuration
                g_Log("ConvertRecordLiveTimestemp " .. "|value" .. tostring(timestamp) .. "|planeTime" ..
                          tostring(planTime) .. "|playTime" .. tostring(playTime))
            end

            if timestamp < 0 then
                timestamp = 0
            end

            if isString then
                timestamp = tostring(timestamp)
            end
        else
            g_Log("ConvertRecordLiveTimestemp:badkeyEmptyvalue")
            return timestamp
        end
    end

    return timestamp
end

function App:IsLive()
    local isLive = true
    if self.Info.configMap ~= nil then
        local configMap = App.Info.configMap

        if configMap.businessField ~= nil and type(configMap.businessField) == "table" then
            local businessField = configMap.businessField

            if businessField.planType ~= nil then
                local planType = businessField.planType

                if planType == 3 or planType == "3" then
                    isLive = false
                end
            end
        end
    end
    return isLive
end

function App:IsPlayBack()
    if self.Info.configMap ~= nil then
        local configMap = App.Info.configMap

        if configMap.businessField ~= nil and type(configMap.businessField) == "table" then
            local businessField = configMap.businessField

            if businessField.isPlayback ~= nil then
                return businessField.isPlayback
            end
        end
    end
    return false
end

function App:IsABCZoneApp()
    local identifier = CS.UnityEngine.Application.identifier
    local sub_str = "abczone"
    local ret = App:stringJudge(identifier, sub_str)
    return ret
end

function App:IsDebugAppBundle()
    local identifier = CS.UnityEngine.Application.identifier
    if identifier == "com.xueersi.next.debug" or identifier == "com.enterprise.next" then
        return true
    end
    if identifier == "com.xueersi.abczone.debug" or identifier == "com.enterprise.abczone" then
        return true
    end
    return false
end

function App:stringJudge(str, sub_str)
    local lowerStr = string.lower(str)
    -- g_Log("lshlowerStr",lowerStr)
    if string.find(lowerStr, sub_str) then
        return true
    else
        return false
    end
end

function App:IsXpad()
    local identifier = CS.UnityEngine.Application.identifier
    if identifier == "com.xueersi.abczone.xpad" or identifier == "com.xueersi.abczone.xpad.debug" then
        return true
    end

    return false
end

function App:IsDebug()
    local identifier = CS.UnityEngine.Application.identifier
    if identifier == "com.xueersi.next.debug" or identifier == "com.enterprise.next" then
        return true
    elseif self.Info.netEnvType == 9003 then
        return true
    elseif CS.UnityEngine.Application.isMobilePlatform == false then
        return true
    end
    return false
end

-- 每次App切后台生成新的SessionId
function App:_RefreshLocalSessionId(num)
    if self.Info.sessionId == nil then
        self:_CreateSessionId()
    end
    self.Info.localSessionId = self.Info.sessionId .. "-" .. tostring(num)
end

-- 生成新的SessionId
function App:_CreateSessionId()
    local liveId = self.Info.liveId or "notSet"
    local nickname = self.Info.userId or "notSet"
    local deviceLevel = self:GetCurrentRenderQualityLevel()
    self.Info.sessionId =
        nickname .. "-" .. tostring(os.time()) .. "-" .. liveId .. "-" .. tostring(math.random(10000)) .. "-" ..
            tostring(deviceLevel)
end

function App:IsLocalModel()
    local pattern = "1"
    if self.Info.pattern ~= nil and tostring(self.Info.pattern) then
        pattern = tostring(self.Info.pattern)
    end
    local isLocalMode = (string.find(self.Info.roomId, "#nextLocalTest") ~= nil) or pattern == "2"

    return isLocalMode
end

function App:_RefreshCourseType()
    xpcall(function()
        local planType = self.Info.configMap.businessField.planType
        self.courseType = NEXT_ENUM_LIVETYPE.RECORD_LIVE_ONLINE
        if planType == "1" or planType == "3" or planType == "4" then
            if self:IsLocalModel() then
                self.courseType = NEXT_ENUM_LIVETYPE.RECORD_LIVE_LOCAL
            else
                self.courseType = NEXT_ENUM_LIVETYPE.RECORD_LIVE_ONLINE
            end
        elseif planType == "2" or planType == "5" then
            if self:IsLocalModel() then
                self.courseType = NEXT_ENUM_LIVETYPE.RECORD_LOCAL
            else
                self.courseType = NEXT_ENUM_LIVETYPE.RECORD_ONLINE
            end
        end

        if self:IsPlayBack() then
            self.courseType = NEXT_ENUM_LIVETYPE.RECORD_LIVE_LOCAL
        end

        if GateManager.courseType ~= nil then
            GateManager.courseType = self.courseType
        end
    end, function()
        g_LogError("_RefreshCourseType Error")
    end)
end

function App:GetRankImage()
    if self.Info.configMap ~= nil then
        local configMap = App.Info.configMap
        if configMap.rank ~= nil and type(configMap.rank) == "table" then
            local rank = configMap.rank
            if rank.rankBelongSmallImage ~= nil and rank.rankBelongSmallImage ~= "" then
                return rank.rankBelongSmallImage
            end
        end
    end
    return nil
end

function App:GameReturn()
    local byPassData = {
        source = "game"
    }
    local request = {
        ["planId"] = "",
        ["paramDic"] = {
            byPass = CourseEnv.ServicesManager:GetJsonService():encode(byPassData)
        }
    }
    g_Log("GameReturn 调用 ", table.dump(request))
    APIBridge.RequestAsync("app.api.jump.switch", request, function(res)
    end)
end

function App:IsRealChineseApp()
    local identifier = CS.UnityEngine.Application.identifier
    if identifier == "com.enterprise.yuwen" or identifier == "com.next.yuwen" then
        return true
    end
    if identifier == "com.next.yuwen.debug" or identifier == "com.next.yuwen " then
        return true
    end
    return false
end

function App:IsChinese() --这个改名成天天学了
    local identifier = CS.UnityEngine.Application.identifier
    if identifier == "com.next.yuwenexercise.debug" or identifier == "com.next.yuwenexercise" then
        return true
    end
    if identifier == "com.next.yuwenexercise" or identifier == "com.enterprise.yuwenexercise" then
        return true
    end
    return false
end

function App:JumpToAppStore(platform)
    local url = ""
    local packageName = ""
    if platform == MOD_PLATFORM.ABCZone then
        url = "https://apps.apple.com/cn/app/id6451403869"
        packageName = "com.xueersi.abczone"
    elseif platform == MOD_PLATFORM.Math then
        url = "https://apps.apple.com/cn/app/id6450438253"
        packageName = "com.xueersi.aitutor"
    end

    if packageName == "" then
        return
    end

    if url == "" then
        return
    end

    -- 区分下 安卓还是iOS
    if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.Android then
        -- 英语是 com.xueersi.abczone
        -- 数学是 com.xueersi.aitutor
        APIBridge.RequestAsync("app.api.jump.openShop", {
            packageName = packageName
        })
    elseif CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.IPhonePlayer then
        APIBridge.RequestAsync("app.api.jump.openURL", {
            url = url
        })
    end
end

function App:JumpToMathStore(channelId)

    if channelId == nil or channelId == "" then
        return
    end
    local baseUrl = "https://app-test.chuangjing.com/client/abc/math/install"
    if App.Info.configMap.env == "online" then
        baseUrl = "https://app.chuangjing.com/client/abc/math/install"
    end

    local url = baseUrl .. "?channelCode=" .. channelId

    local normalizedPosition = {0, 0, 1, 1}
    local param = {
        url = url,
        normalizedPosition = normalizedPosition,
        show_close_btn = false,
        clear_cache = false
    }

    local openH5Ids = CourseEnv.ServicesManager:GetH5Service():OpenH5OnRoom(param, function(res)

    end)

    App:GetService("CommonService"):DispatchAfter(2, function()
        CourseEnv.ServicesManager:GetH5Service():CloseH5OnRoom(openH5Ids)
    end)
end

function App:IsAbcZoneMain()
    return App.ModName and (App.ModName == "uB0J1kQjAkGzBTwDcQtSOA" or App.ModName == "7kioVOWRqk6Lpol2xwA1cA")
end

function App:IsMathMain()
    return App.ModName and App.ModName == "vKEF0QFDekCpcZs2aBITIA"
end

function App:IsHome()
    return App.ModName and App.ModName == "CQkV8RVnWEu2X58gOO39OQ"
end

-- 语文主场景
function App:IsCNMain()
    return App.ModName and App.ModName == "fGS00BKmUihRJbwCd0cA"
end

-- 农场
function App:IsCNFarm()
    return App.ModName and App.ModName == "g1VY7cssUa2gT8XdWThHw"
end

return App
