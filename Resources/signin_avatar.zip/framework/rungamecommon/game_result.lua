---
---  Author: 【彩滨滨】
---  AuthorID: 【246276】
---  CreateTime: 【2023-6-20 15:30:46】
--- 【FSync】
--- 【游戏结果页逻辑代码】
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")
local GameMatching = require("ui/game_matching")

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local GameResult = class("game_result_comlogic", WBElement)
local log = function(...)
    g_Log("zcl 【ABCZone结算面板】1.0】", ...)
end
local fsync_activateRoom = "activateRoom"
local process_game_result = "process_game_result"
local game_remote_params = "game_remote_params"
---@param worldElement CS.Tal.framesync.WorldElement
function GameResult:initialize(worldElement)
    GameResult.super.initialize(self, worldElement)

    -- 订阅KEY消息
    self:SubscribeMsgKey(fsync_activateRoom)
    self:SubscribeMsgKey(process_game_result)
    self:SubscribeMsgKey(game_remote_params)
    -- 排队按钮注册
    self:SubscribePeerMsgKey("queue_up_num" .. App.Info.roomId)
    self:SubscribePeerMsgKey("queue_up_succ" .. App.Info.roomId)

    --- 打开和关闭面板的标记,FIX重复打开和关闭导致的遥杆消失问题 
    self.SHOW_MAIN_PANEL = false
    self.hasRequest = false
    self.isReportStart = false
    self.isReportEnd = false
    self.needShowMatching = false

    self.pauseFunction = function(pause)
        self.hasPause = pause
        if self.hasPause and self.hasPause ~= nil then
            if self.isMatching == true then
                if GameMatching.cancel then
                    GameMatching.cancel()
                end
            end
        end
    end

    self.commonService:DispatchAfter(1, function()
        if self.gate.worldController.World.OnApplicationPauseAction == nil then
            self.gate.worldController.World.OnApplicationPauseAction = self.pauseFunction
        else
            self.gate.worldController.World.OnApplicationPauseAction =
                self.gate.worldController.World.OnApplicationPauseAction + self.pauseFunction
        end
    end)
end

function GameResult:setVisElement(VisElement)
    if VisElement ~= nil then
        self.VisElement = VisElement
    end
    self:InitService()
    self:InitConfig()
    -- self:InitView()
    -- self:InitEventListener()
    if App.IsStudioClient then
        self:GameMatchingReq()
    end

    if VisElement then
        -- 查找测试按钮
        self.gBtn = self.VisElement.transform:Find("屏幕画布/测试按钮").gameObject:GetComponent(typeof(
            CS.UnityEngine.UI.Button))
        App:GetService("CommonService"):AddEventListener(self.gBtn, "onClick", function()
            g_LogColorMsg("点击了测试按钮")
            self.BusEventService:Fire("SHOW_MINI_GAME_RESULT_PANEL_NEW", {
                titleType = 4, -- 1.第几名 2.获胜 3.失败 4.已出局 5.平局 6.已完成 7.已淘汰 8.成功离开 9.尚未结束 10.吃鸡胜利 11.吃鸡失败
                contentType = 4, -- 内容类别：1.包含用时、芝士、经验 2.包含芝士、经验 3.包含经验 4.包含芝士 5.包含芝士、学识、经验
                closeBtnType = 3, -- 1. 3S后自动关闭不显示关闭按钮 2.显示关闭按钮 3.显示关闭和再来一局按钮

                rank = 7,
                rankList = { -- rankListType = 2时需要传递此参数
                {
                    user_id = App.Info.userId,
                    avatarName = "avatarName",
                    score = 99
                }, {
                    user_id = App.Info.userId,
                    avatarName = "avatarName",
                    score = 100
                }, {
                    user_id = App.Info.userId,
                    avatarName = "avatarName",
                    score = 101
                }, {
                    user_id = App.Info.userId,
                    avatarName = "avatarName",
                    score = 102
                }},

                useTime = 68, -- 用时
                isFinish = false, -- 是否完成
                award = 10, -- 芝士
                xueshi = 10, -- 学识
                petExp = 10, -- 宠物经验

                is_school_settle = true, -- 该游戏是否参与校园经验加成
                join_school_flag = true, -- 是否加入学校
                add_value = 6, -- 增加的学校经验值
                is_double_game = true, -- 是否双倍加分
                school_extra_score = 1, -- 学校额外增加的经验值
                has_upgrade = true, -- 学校是否升级
                after_level = 3, -- 学校升级后等级

                autoCloseCallBack = function()
                    g_LogColorMsg("自动关闭回调")
                end,
                clickCloseCallBack = function()
                    g_LogColorMsg("点击关闭回调")
                end,
                clickAgainCallBack = function()
                    g_LogColorMsg("点击再来一局回调")
                end,
                -- 重来一局额外参数
                game_id = 1,
                opt_source = 1
            })
        end)
        self.VisElement.transform:Find("屏幕画布/测试按钮").gameObject:SetActive(false)
    end
end

function GameResult:InitEventListener()
    -- 接收学识和宠物经验
    self.BusEventService:Watch("add_pet_exp_from_read", function(key, args)
        local value = args[0]
        if value.petExp then
            self.petExpFromAnswer = self.petExpFromAnswer + value.petExp
        end
    end)

    self.BusEventService:Watch("add_diamond_from_read", function(key, args)
        local value = args[0]
        if value.addDiamond then
            self.xueshiFromAnswer = self.xueshiFromAnswer + value.addDiamond
        end
    end)

    -- 新增单独展示校园升级
    -- self.BusEventService:Watch("SHOW_SCHOOL_UPGRADE_PANEL", function(key, args)
    --     g_LogError("单独展示校园升级" .. table.dump(args[0]))
    --     self.canvasRect:Find("jieguoye/biaoti").gameObject:SetActive(false)
    --     self.canvasRect:Find("jieguoye/Mask group").gameObject:SetActive(false)
    --     self.canvasRect:Find("jieguoye/xiaoyuan").gameObject:SetActive(false)
    --     self.canvasRect:Find("jieguoye/anjian_1").gameObject:SetActive(false)
    --     local Animator = self.canvasRect:Find("jieguoye").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
    --     local afterShi = math.floor(args[0].after_level / 10)
    --     local afterGe = args[0].after_level % 10
    --     local before = args[0].before_level
    --     if before < 0 then
    --         before = 0
    --     end
    --     local beforeShi = math.floor(before / 10)
    --     local beforeGe = before % 10
    --     self.schoolBeforeShi.sprite = self.noImageBlackList[beforeShi]
    --     self.schoolBeforeGe.sprite = self.noImageBlackList[beforeGe]
    --     self.schoolAfterShi.sprite = self.noImageBlackList[afterShi]
    --     self.schoolAfterGe.sprite = self.noImageBlackList[afterGe]
    --     self.rootUI:SetActive(true)
    --     Animator:Play("xiaoyuanshengji", 0, 0)
    --     -- 延迟4秒执行
    --     self.commonService:DispatchAfter(4, function()
    --         self.rootUI:SetActive(false)
    --     end)
    -- end)

    -- 监听游戏结果页显示消息
    self.BusEventService:Watch("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", function(key, args)
        log("展示结果页", table.dump(args[0]))
        local data = args[0]
        if self.hasRequest then
            data.has_upgrade = self.has_upgrade
            data.after_level = self.after_level
            data.add_value = self.add_value
            data.join_school_flag = self.join_school_flag
            data.is_school_settle = self.is_school_settle
            data.is_double_game = self.is_double_game
            data.jiziNum = self.jiziNum
            self.BusEventService:Fire("SHOW_MINI_GAME_RESULT_PANEL_NEW", data)
        else
            self.hasRequest = true
            self:reportPoint(args[0], function()
                data.has_upgrade = self.has_upgrade
                data.after_level = self.after_level
                data.add_value = self.add_value
                data.join_school_flag = self.join_school_flag
                data.is_school_settle = self.is_school_settle
                data.is_double_game = self.is_double_game
                data.jiziNum = self.jiziNum
                self.BusEventService:Fire("SHOW_MINI_GAME_RESULT_PANEL_NEW", data)
            end)
        end
    end)
    -- 监听游戏段位页显示消息
    self.BusEventService:Watch("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST", function(key, args)
        log("展示段位页", table.dump(args[0]))
        if self.hasRequest then
            self.BusEventService:Fire("SHOW_GAME_RANK_RESULT_PANEL", {
                change_score = self.change_score,
                is_protect = self.is_protect,
                protect_score = self.protect_score,
                ranking_before = self.ranking_before,
                ranking_after = self.ranking_after,
                rank = self.finalRankNum,
                type = args[0].type,
                isFailed = args[0].isFailed,
                isTeamWin = args[0].isTeamWin,
                btnCallBack = function(returnBtn, againBtn)
                    self:GameMatchingLogic(returnBtn, againBtn)

                end
            })
        else
            self.hasRequest = true
            self:reportPoint(args[0], function()
                self.BusEventService:Fire("SHOW_GAME_RANK_RESULT_PANEL", {
                    change_score = self.change_score,
                    is_protect = self.is_protect,
                    protect_score = self.protect_score,
                    ranking_before = self.ranking_before,
                    ranking_after = self.ranking_after,
                    rank = self.finalRankNum,
                    type = args[0].type,
                    isFailed = args[0].isFailed,
                    isTeamWin = args[0].isTeamWin,
                    btnCallBack = function(returnBtn, againBtn)
                        self:GameMatchingLogic(returnBtn, againBtn)
                    end
                })
            end)
        end
    end)

    self.commonService:AddEventListener(self.closebtn, "onClick", function()

        if self.needShowMatching == true then
            self.rootUI.gameObject:SetActive(false)
            log("点击按钮回调")
            App:GameReturn()
            self.clickCloseCallBack()
            return
        end
        if self.clickCloseCallBack then
            self.rootUI.gameObject:SetActive(false)
            log("点击按钮回调")
            App:GameReturn()
            self.clickCloseCallBack()
        end
    end)

    self.BusEventService:Watch("SHOW_TEAM_MINI_GAME_RESULT_PANEL_NEW", function(key, args)
        if self.teamReslutData then
            log("客户端展示队伍结果页", table.dump(self.teamReslutData))
            self.BusEventService:Fire("SHOW_MINI_GAME_RESULT_PANEL_NEW", self.teamReslutData)
        end
    end)

    self.BusEventService:Watch("SHOW_MINI_GAME_RESULT_PANEL_NEW", function(key, args)
        -- 结果页显示时禁用断线提示
        CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
        -- 停止题目预播
        self.BusEventService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", {
            op = "Stop"
        }) -- 在游戏结算的时候调用
        local service = App:GetService("MonitorService")
        if self.isReportStart == false then
            self:reportLog("gameResultView")
            self.isReportStart = true
        end

        self:reportData("resule_school_exp", "【曝光】获得校园经验", {
            param_one = args[0].add_value,
            param_two = self.game_id
        })

        log("SHOW_MINI_GAME_RESULT_PANEL_NEW", table.dump(args[0]))
        self.opt_source = args[0].opt_source
        -- 处理学识数据
        local xueshiNum = 0
        if args[0].xueshi then
            xueshiNum = args[0].xueshi
        else
            xueshiNum = self.xueshiFromAnswer
        end
        -- 处理宠物经验数据
        local petExpNum = 0
        if args[0].petExp then
            petExpNum = args[0].petExp
        else
            petExpNum = self.petExpFromAnswer
        end
        -- 1.排名列表
        if args[0].rankList ~= nil then
            self.ranks.gameObject:SetActive(true)
            for i = 1, 4 do
                local rankView = self.rankViews[i]
                local rank = args[0].rankList[i]
                if rank then
                    if tostring(rank.user_id) == tostring(App.Info.userId) then
                        rank.avatarName = "<color=#FFE81F>" .. rank.avatarName .. "</color>"
                    end
                    rankView.rank.gameObject:SetActive(true)
                    rankView.name.text = rank.avatarName
                    rankView.score.text = rank.score
                else
                    rankView.rank.gameObject:SetActive(false)
                end
            end
        end

        -- 2.自己排名
        self.rank = args[0].rank
        self.titleType = args[0].titleType

        if self.titleType == nil then
            g_LogError("结果页没有区分标题类别")
            return
        end

        if self.titleType == 1 then
            if self.rank ~= nil then
                if self.rank > 9 then
                    local shi = math.floor(self.rank / 10)
                    local ge = self.rank % 10
                    self.sortNumImgShi.sprite = self.noWhiteImageList[shi]
                    self.sortNumImgGe.sprite = self.noWhiteImageList[ge]
                    self.mingci1:SetActive(false)
                    self.mingci2:SetActive(true)
                elseif self.rank > 0 then
                    self.sortNumImg.sprite = self.noWhiteImageList[self.rank]
                    self.mingci1:SetActive(true)
                    self.mingci2:SetActive(false)
                elseif self.rank == -1 then
                    self.weiwancheng.gameObject:SetActive(true)
                    self.mingci_01.gameObject:SetActive(false)
                end

                self.huosheng:SetActive(false)
                self.shibai:SetActive(false)
                self.yichuju:SetActive(false)
                self.pingju:SetActive(false)
                self.shangweijiesu:SetActive(false)
            end
        elseif self.titleType == 2 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(true)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(false)
        elseif self.titleType == 3 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(false)
            self.shibai:SetActive(true)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(false)
        elseif self.titleType == 4 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(false)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(true)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(false)
        elseif self.titleType == 5 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(false)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(true)
            self.shangweijiesu:SetActive(false)
        elseif self.titleType == 6 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(true)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(false)
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite =
                self.yiwancheng
            -- 更改大小
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
                .sizeDelta = CS.UnityEngine.Vector2(306, 132)
        elseif self.titleType == 7 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(true)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(false)
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite =
                self.yitaotai
            -- 更改大小
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
                .sizeDelta = CS.UnityEngine.Vector2(306, 132)
        elseif self.titleType == 8 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(true)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(false)
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite =
                self.chenggonglikai
            -- 更改大小
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
                .sizeDelta = CS.UnityEngine.Vector2(402, 132)
        elseif self.titleType == 9 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(false)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(true)
        elseif self.titleType == 10 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(true)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(false)
            --关闭校园分
            self.schoolScoreRoot.gameObject:SetActive(false)
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite =
                self.chijishengli
            -- 更改大小
            self.huoshengRect.anchoredPosition = CS.UnityEngine.Vector2(0,-100)
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
                .sizeDelta = CS.UnityEngine.Vector2(1048, 200)
        elseif self.titleType == 11 then
            self.mingci1:SetActive(false)
            self.mingci2:SetActive(false)
            self.huosheng:SetActive(true)
            self.shibai:SetActive(false)
            self.yichuju:SetActive(false)
            self.pingju:SetActive(false)
            self.shangweijiesu:SetActive(false)
            --关闭校园分
            self.schoolScoreRoot.gameObject:SetActive(false)
            -- 修改结算ui坐标
            self.huoshengRect.anchoredPosition = CS.UnityEngine.Vector2(0,-100)
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite =
                self.chijishibai
            -- 更改大小
            self.huosheng.transform:Find("huosheng").gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
                .sizeDelta = CS.UnityEngine.Vector2(1048, 200)
        end

        --- 3.自己的用时 + 自己宠物的经验 + 自己获得的芝士
        local contentType = args[0].contentType
        -- 从开局消息监听是否为读课文模式
        if self.activeQuestionType ~= nil and self.activeQuestionType == 1 then
            contentType = 5
        end

        if contentType == nil then
            g_LogError("结果页没有区分内容类别")
            return
        end

        if not args[0].award then
            args[0].award = self.add_cheese_val or 0
        end

        if contentType == 1 then
            self.useTimeV = args[0].useTime
            self.isFinish = args[0].isFinish

            self.petExpV = petExpNum
            self.award = args[0].award

            if self.useTimeV == nil or self.petExpV == nil or self.award == nil then
                g_LogError("结果页时间芝士经验传值有误")
                return
            end
            self.neirong1.gameObject:SetActive(true)
            -- 时间
            local min, miao = self:FormatTime(self.useTimeV)

            if self.isFinish then
                self.useTimeText.text = min .. "分" .. miao .. "秒"
            else
                self.useTimeText.text = "未完成"
            end

            ---@type CS.UnityEngine.RectTransform
            self.getCheeseText = self.neirong1:Find("huodezhishi/shuliang").gameObject:GetComponent(typeof(
                CS.UnityEngine.UI.Text))
            ---@type CS.UnityEngine.RectTransform
            self.petExpText = self.neirong1:Find("chongwujingyan/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                            .UI.Text))

            if self.award > 0 then
                self.getCheeseText.text = self.award
            else
                self.getCheeseText.text = "0"
            end

            -- 经验
            if self.petExpV > 0 then
                self.petExpText.text = self.petExpV
            else
                self.petExpText.text = "0"
            end
        elseif contentType == 2 then
            self.petExpV = petExpNum
            self.award = args[0].award

            if self.petExpV == nil or self.award == nil then
                g_LogError("结果页芝士经验传值有误")
                return
            end

            self.neirong2.gameObject:SetActive(true)

            ---@type CS.UnityEngine.RectTransform
            self.getCheeseText = self.neirong2:Find("huodezhishi/shuliang").gameObject:GetComponent(typeof(
                CS.UnityEngine.UI.Text))
            ---@type CS.UnityEngine.RectTransform
            self.petExpText = self.neirong2:Find("chongwujingyan/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                            .UI.Text))

            if self.award > 0 then
                self.getCheeseText.text = self.award
            else
                self.getCheeseText.text = "0"
            end

            -- 经验
            if self.petExpV > 0 then
                self.petExpText.text = self.petExpV
            else
                self.petExpText.text = "0"
            end
        elseif contentType == 3 then
            self.petExpV = petExpNum

            if self.petExpV == nil then
                g_LogError("结果页经验传值有误")
                return
            end
            self.neirong3.gameObject:SetActive(true)

            ---@type CS.UnityEngine.RectTransform
            self.petExpText = self.neirong3:Find("chongwujingyan/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                            .UI.Text))

            -- 经验
            if self.petExpV > 0 then
                self.petExpText.text = self.petExpV
            else
                self.petExpText.text = "0"
            end
        elseif contentType == 4 then
            self.award = args[0].award
            if self.award == nil then
                g_LogError("结果页芝士传值有误")
                return
            end
            self.neirong4.gameObject:SetActive(true)

            ---@type CS.UnityEngine.RectTransform
            self.getCheeseText = self.neirong4:Find("huodezhishi/shuliang").gameObject:GetComponent(typeof(
                CS.UnityEngine.UI.Text))

            if self.award > 0 then
                self.getCheeseText.text = self.award
            else
                self.getCheeseText.text = "0"
            end
        elseif contentType == 5 then
            self.xueshi = xueshiNum
            self.petExpV = petExpNum
            self.award = args[0].award
            self.neirong5.gameObject:SetActive(true)

            --- 芝士
            self.getCheeseText = self.neirong5:Find("huodezhishi/shuliang").gameObject:GetComponent(typeof(
                CS.UnityEngine.UI.Text))
            --- 学识
            self.xueshiText = self.neirong5:Find("xueshi/shuliang").gameObject:GetComponent(typeof(CS.UnityEngine.UI
                                                                                                       .Text))
            --- 宠物经验
            self.petExpText = self.neirong5:Find("chongwujingyan/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                            .UI.Text))

            if self.award > 0 then
                self.getCheeseText.text = self.award
            else
                self.getCheeseText.text = "0"
            end
            -- 学识
            if self.xueshi > 0 then
                self.xueshiText.text = self.xueshi
            else
                self.xueshiText.text = "0"
            end
            -- 经验
            if self.petExpV > 0 then
                self.petExpText.text = self.petExpV
            else
                self.petExpText.text = "0"
            end
        end

        -- 4.校园升级相关
        if self.season_id then
            self.session.sprite = self.sessionImageList[self.season_id]
        end
        if args[0].is_school_settle == nil or args[0].is_school_settle == false then
            g_LogError("结果页没有获取到校园相关信息")
            self.noSchool.gameObject:SetActive(false)
            self.hasSchool.gameObject:SetActive(false)
            self.hasSchoolExtra.gameObject:SetActive(false)
            self.hasSchoolDouble.gameObject:SetActive(false)
            self.hasSchoolDoubleExtra.gameObject:SetActive(false)
            -- self.schoolUpgrade.gameObject:SetActive(false)
        else
            if args[0].join_school_flag == nil and args[0].add_value == nil and args[0].has_upgrade == nil and
                args[0].after_level == nil then
                g_LogError("结果页没有获取到校园相关信息")
                return
            end
            -- 加入学校
            if args[0].join_school_flag == true then
                -- 处理校园成长之路
                -- 任务系统去掉成长之路相关UI显示逻辑
                -- if self.grow_route_info then
                --     g_Log("校园成长之路", table.dump(self.grow_route_info))
                --     self.levelUpEffect.gameObject:SetActive(true)
                --     -- 开始展示成长之路升级特效
                --     self:showLevelUpEffect(self.grow_route_info)
                -- end

                self.noSchool.gameObject:SetActive(false)
                if args[0].is_double_game then
                    -- 双倍校园加分
                    if args[0].school_extra_score == nil or args[0].school_extra_score == 0 then
                        self.hasSchool.gameObject:SetActive(false)
                        self.hasSchoolExtra.gameObject:SetActive(false)
                        self.hasSchoolDouble.gameObject:SetActive(true)
                        self.hasSchoolDoubleExtra.gameObject:SetActive(false)
                        self.hasSchoolExtraTip.gameObject:SetActive(false)
                        local after_value = args[0].add_value
                        local before_value = math.floor(args[0].add_value / 2)

                        if before_value <= 0 then
                            g_LogError("结果页校园额外加分有误" .. before_value .. "-" .. after_value)
                            -- return
                        end

                        if before_value > 99 then
                            local bai = math.floor(before_value / 100)
                            local shi = math.floor((before_value - bai * 100) / 10)
                            local ge = before_value % 10
                            self.hasSchoolDoubleBeforeBai.sprite = self.rNumList[bai]
                            self.hasSchoolDoubleBeforeShi.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleBeforeGe.sprite = self.rNumList[ge]
                            self.hasSchoolDoubleBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleBeforeShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleBeforeGe.gameObject:SetActive(true)

                            self.hasSchoolDoubleTip1.gameObject:SetActive(false)
                            self.hasSchoolDoubleTip2.gameObject:SetActive(false)
                            self.hasSchoolDoubleTip3.gameObject:SetActive(true)
                        elseif before_value > 9 then
                            local shi = math.floor(before_value / 10)
                            local ge = before_value % 10
                            self.hasSchoolDoubleBeforeBai.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleBeforeShi.sprite = self.rNumList[ge]
                            self.hasSchoolDoubleBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleBeforeShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleBeforeGe.gameObject:SetActive(false)

                            self.hasSchoolDoubleTip1.gameObject:SetActive(false)
                            self.hasSchoolDoubleTip2.gameObject:SetActive(true)
                            self.hasSchoolDoubleTip3.gameObject:SetActive(false)
                        else
                            self.hasSchoolDoubleBeforeBai.sprite = self.rNumList[before_value]
                            self.hasSchoolDoubleBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleBeforeShi.gameObject:SetActive(false)
                            self.hasSchoolDoubleBeforeGe.gameObject:SetActive(false)
                            self.hasSchoolDoubleTip1.gameObject:SetActive(true)
                            self.hasSchoolDoubleTip2.gameObject:SetActive(false)
                            self.hasSchoolDoubleTip3.gameObject:SetActive(false)
                        end
                        if after_value > 99 then
                            local bai = math.floor(after_value / 100)
                            local shi = math.floor((after_value - bai * 100) / 10)
                            local ge = after_value % 10
                            self.hasSchoolDoubleAfterBai.sprite = self.rNumList[bai]
                            self.hasSchoolDoubleAfterShi.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleAfterGe.sprite = self.rNumList[ge]
                            self.hasSchoolDoubleAfterBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleAfterShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleAfterGe.gameObject:SetActive(true)
                        elseif after_value > 9 then
                            local shi = math.floor(after_value / 10)
                            local ge = after_value % 10
                            self.hasSchoolDoubleAfterBai.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleAfterShi.sprite = self.rNumList[ge]

                            self.hasSchoolDoubleAfterBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleAfterShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleAfterGe.gameObject:SetActive(false)
                        else
                            self.hasSchoolDoubleAfterBai.sprite = self.rNumList[after_value]
                            self.hasSchoolDoubleAfterBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleAfterShi.gameObject:SetActive(false)
                            self.hasSchoolDoubleAfterGe.gameObject:SetActive(false)
                        end
                    else -- 双倍有额外加分
                        self.hasSchool.gameObject:SetActive(false)
                        self.hasSchoolExtra.gameObject:SetActive(false)
                        self.hasSchoolDouble.gameObject:SetActive(false)
                        self.hasSchoolDoubleExtra.gameObject:SetActive(true)
                        self.hasSchoolExtraTip.gameObject:SetActive(true)

                        local afterValue = args[0].add_value
                        local midValue = math.floor(args[0].add_value / 2)
                        local beforeValue = midValue - args[0].school_extra_score

                        if midValue <= 0 then
                            g_LogError("结果页校园额外加分有误" .. beforeValue .. "-" .. midValue .. "-" ..
                                           afterValue)
                            return
                        end

                        if beforeValue > 99 then
                            local bai = math.floor(beforeValue / 100)
                            local shi = math.floor((beforeValue - bai * 100) / 10)
                            local ge = beforeValue % 10
                            self.hasSchoolDoubleExtraBeforeBai.sprite = self.rNumList[bai]
                            self.hasSchoolDoubleExtraBeforeShi.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleExtraBeforeGe.sprite = self.rNumList[ge]

                            self.hasSchoolDoubleExtraBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraBeforeShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraBeforeGe.gameObject:SetActive(true)
                        elseif beforeValue > 9 then
                            local shi = math.floor(beforeValue / 10)
                            local ge = beforeValue % 10
                            self.hasSchoolDoubleExtraBeforeBai.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleExtraBeforeShi.sprite = self.rNumList[ge]

                            self.hasSchoolDoubleExtraBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraBeforeShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraBeforeGe.gameObject:SetActive(false)
                        else
                            self.hasSchoolDoubleExtraBeforeBai.sprite = self.rNumList[beforeValue]
                            self.hasSchoolDoubleExtraBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraBeforeShi.gameObject:SetActive(false)
                            self.hasSchoolDoubleExtraBeforeGe.gameObject:SetActive(false)
                        end

                        if midValue > 99 then
                            local bai = math.floor(midValue / 100)
                            local shi = math.floor((midValue - bai * 100) / 10)
                            local ge = midValue % 10
                            self.hasSchoolDoubleExtraMidBai.sprite = self.rNumList[bai]
                            self.hasSchoolDoubleExtraMidShi.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleExtraMidGe.sprite = self.rNumList[ge]

                            self.hasSchoolDoubleExtraMidBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraMidShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraMidGe.gameObject:SetActive(true)

                            self.hasSchoolDoubleExtraTip1.gameObject:SetActive(false)
                            self.hasSchoolDoubleExtraTip2.gameObject:SetActive(false)
                            self.hasSchoolDoubleExtraTip3.gameObject:SetActive(true)
                        elseif midValue > 9 then
                            local shi = math.floor(midValue / 10)
                            local ge = midValue % 10
                            self.hasSchoolDoubleExtraMidBai.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleExtraMidShi.sprite = self.rNumList[ge]

                            self.hasSchoolDoubleExtraMidBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraMidShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraMidGe.gameObject:SetActive(false)

                            self.hasSchoolDoubleExtraTip1.gameObject:SetActive(false)
                            self.hasSchoolDoubleExtraTip2.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraTip3.gameObject:SetActive(false)
                        else
                            self.hasSchoolDoubleExtraMidBai.sprite = self.rNumList[midValue]
                            self.hasSchoolDoubleExtraMidBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraMidShi.gameObject:SetActive(false)
                            self.hasSchoolDoubleExtraMidGe.gameObject:SetActive(false)
                            self.hasSchoolDoubleExtraTip1.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraTip2.gameObject:SetActive(false)
                            self.hasSchoolDoubleExtraTip3.gameObject:SetActive(false)
                        end
                        if afterValue > 99 then
                            local bai = math.floor(afterValue / 100)
                            local shi = math.floor((afterValue - bai * 100) / 10)
                            local ge = afterValue % 10
                            self.hasSchoolDoubleExtraAfterBai.sprite = self.rNumList[bai]
                            self.hasSchoolDoubleExtraAfterShi.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleExtraAfterGe.sprite = self.rNumList[ge]

                            self.hasSchoolDoubleExtraAfterBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraAfterShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraAfterGe.gameObject:SetActive(true)
                        elseif afterValue > 9 then
                            local shi = math.floor(afterValue / 10)
                            local ge = afterValue % 10
                            self.hasSchoolDoubleExtraAfterBai.sprite = self.rNumList[shi]
                            self.hasSchoolDoubleExtraAfterShi.sprite = self.rNumList[ge]

                            self.hasSchoolDoubleExtraAfterBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraAfterShi.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraAfterGe.gameObject:SetActive(false)
                        else
                            self.hasSchoolDoubleExtraAfterBai.sprite = self.rNumList[afterValue]
                            self.hasSchoolDoubleExtraAfterBai.gameObject:SetActive(true)
                            self.hasSchoolDoubleExtraAfterShi.gameObject:SetActive(false)
                            self.hasSchoolDoubleExtraAfterGe.gameObject:SetActive(false)
                        end
                    end
                else
                    -- 单倍校园加分
                    if args[0].school_extra_score == nil or args[0].school_extra_score == 0 then
                        self.hasSchool.gameObject:SetActive(true)
                        self.hasSchoolExtra.gameObject:SetActive(false)
                        self.hasSchoolDouble.gameObject:SetActive(false)
                        self.hasSchoolDoubleExtra.gameObject:SetActive(false)
                        self.hasSchoolExtraTip.gameObject:SetActive(false)
                        local add_value = args[0].add_value
                        if add_value > 99 then
                            local bai = math.floor(add_value / 100)
                            local shi = math.floor((add_value - bai * 100) / 10)
                            local ge = add_value % 10
                            self.schoolScoreImageBai.sprite = self.rNumList[bai]
                            self.schoolScoreImageShi.sprite = self.rNumList[shi]
                            self.schoolScoreImageGe.sprite = self.rNumList[ge]
                            self.schoolScoreImageBai.gameObject:SetActive(true)
                            self.schoolScoreImageShi.gameObject:SetActive(true)
                            self.schoolScoreImageGe.gameObject:SetActive(true)
                        elseif add_value > 9 then
                            local shi = math.floor(add_value / 10)
                            local ge = add_value % 10
                            self.schoolScoreImageBai.sprite = self.rNumList[shi]
                            self.schoolScoreImageShi.sprite = self.rNumList[ge]
                            self.schoolScoreImageBai.gameObject:SetActive(true)
                            self.schoolScoreImageShi.gameObject:SetActive(true)
                            self.schoolScoreImageGe.gameObject:SetActive(false)
                        else
                            self.schoolScoreImageBai.sprite = self.rNumList[add_value]
                            self.schoolScoreImageBai.gameObject:SetActive(true)
                            self.schoolScoreImageShi.gameObject:SetActive(false)
                            self.schoolScoreImageGe.gameObject:SetActive(false)
                        end
                    else -- 单倍有额外加分
                        self.hasSchool.gameObject:SetActive(false)
                        self.hasSchoolExtra.gameObject:SetActive(true)
                        self.hasSchoolDouble.gameObject:SetActive(false)
                        self.hasSchoolDoubleExtra.gameObject:SetActive(false)
                        self.hasSchoolExtraTip.gameObject:SetActive(true)

                        if args[0].add_value < args[0].school_extra_score then
                            g_LogError("结果页校园额外加分有误")
                            return
                        end

                        local beforeValue = args[0].add_value - args[0].school_extra_score
                        if beforeValue > 99 then
                            local bai = math.floor(beforeValue / 100)
                            local shi = math.floor((beforeValue - bai * 100) / 10)
                            local ge = beforeValue % 10
                            self.hasSchoolExtraBeforeBai.sprite = self.rNumList[bai]
                            self.hasSchoolExtraBeforeShi.sprite = self.rNumList[shi]
                            self.hasSchoolExtraBeforeGe.sprite = self.rNumList[ge]

                            self.hasSchoolExtraBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolExtraBeforeShi.gameObject:SetActive(true)
                            self.hasSchoolExtraBeforeGe.gameObject:SetActive(true)
                        elseif beforeValue > 9 then
                            local shi = math.floor(beforeValue / 10)
                            local ge = beforeValue % 10
                            self.hasSchoolExtraBeforeBai.sprite = self.rNumList[shi]
                            self.hasSchoolExtraBeforeShi.sprite = self.rNumList[ge]

                            self.hasSchoolExtraBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolExtraBeforeShi.gameObject:SetActive(true)
                            self.hasSchoolExtraBeforeGe.gameObject:SetActive(false)
                        else
                            self.hasSchoolExtraBeforeBai.sprite = self.rNumList[beforeValue]
                            self.hasSchoolExtraBeforeBai.gameObject:SetActive(true)
                            self.hasSchoolExtraBeforeShi.gameObject:SetActive(false)
                            self.hasSchoolExtraBeforeGe.gameObject:SetActive(false)
                        end
                        local afterValue = args[0].add_value
                        if afterValue > 99 then
                            local bai = math.floor(afterValue / 100)
                            local shi = math.floor((afterValue - bai * 100) / 10)
                            local ge = afterValue % 10
                            self.hasSchoolExtraAfterBai.sprite = self.rNumList[bai]
                            self.hasSchoolExtraAfterShi.sprite = self.rNumList[shi]
                            self.hasSchoolExtraAfterGe.sprite = self.rNumList[ge]

                            self.hasSchoolExtraAfterBai.gameObject:SetActive(true)
                            self.hasSchoolExtraAfterShi.gameObject:SetActive(true)
                            self.hasSchoolExtraAfterGe.gameObject:SetActive(true)
                        elseif afterValue > 9 then
                            local shi = math.floor(afterValue / 10)
                            local ge = afterValue % 10
                            self.hasSchoolExtraAfterBai.sprite = self.rNumList[shi]
                            self.hasSchoolExtraAfterShi.sprite = self.rNumList[ge]

                            self.hasSchoolExtraAfterBai.gameObject:SetActive(true)
                            self.hasSchoolExtraAfterShi.gameObject:SetActive(true)
                            self.hasSchoolExtraAfterGe.gameObject:SetActive(false)
                        else
                            self.hasSchoolExtraAfterBai.sprite = self.rNumList[afterValue]
                            self.hasSchoolExtraAfterBai.gameObject:SetActive(true)
                            self.hasSchoolExtraAfterShi.gameObject:SetActive(false)
                            self.hasSchoolExtraAfterGe.gameObject:SetActive(false)
                        end
                    end
                end
            else -- 未加入学校
                self.noSchool.gameObject:SetActive(true)
                self.hasSchool.gameObject:SetActive(false)
                self.hasSchoolExtra.gameObject:SetActive(false)
                self.hasSchoolDouble.gameObject:SetActive(false)
                self.hasSchoolDoubleExtra.gameObject:SetActive(false)
                -- self.schoolUpgrade.gameObject:SetActive(false)
                -- 任务系统去掉成长之路相关UI显示逻辑
                -- 处理校园成长之路
                -- self.enterSchoolReward.gameObject:SetActive(true)
                -- if self.grow_route_info and self.grow_route_info.big_award_img then
                --     g_Log("lsh加载校园奖励图片" .. self.grow_route_info.big_award_img)
                --     self.httpService:LoadNetWorkTexture(self.grow_route_info.big_award_img, function(texture)
                --         g_Log("lsh加载校园奖励图片")
                --         self.enterSchoolRewardImage.sprite = texture
                --     end)
                -- end
            end
            -- self.schoolUpgrade.gameObject:SetActive(false)
            -- if args[0].has_upgrade == true then
            --     local afterShi = math.floor(args[0].after_level / 10)
            --     local afterGe = args[0].after_level % 10
            --     local before = args[0].after_level - 1
            --     if before < 0 then
            --         before = 0
            --     end
            --     local beforeShi = math.floor(before / 10)
            --     local beforeGe = before % 10
            --     self.schoolBeforeShi.sprite = self.noImageBlackList[beforeShi]
            --     self.schoolBeforeGe.sprite = self.noImageBlackList[beforeGe]
            --     self.schoolAfterShi.sprite = self.noImageBlackList[afterShi]
            --     self.schoolAfterGe.sprite = self.noImageBlackList[afterGe]
            -- else
            --     self.schoolUpgrade.gameObject:SetActive(false)
            -- end
        end

        -- 奖励稍后发放特殊处理
        if self.titleType == 9 then
            self.shouhoufafang.gameObject:SetActive(true)
            self.noSchool.gameObject:SetActive(false)
            self.hasSchool.gameObject:SetActive(false)
            self.hasSchoolExtra.gameObject:SetActive(false)
            self.hasSchoolDouble.gameObject:SetActive(false)
            self.hasSchoolDoubleExtra.gameObject:SetActive(false)

            self.chengzhangzhilu.gameObject:SetActive(false)
        else
            self.shouhoufafang.gameObject:SetActive(false)
            self.chengzhangzhilu.gameObject:SetActive(true)
        end
        -- 5.退出相关逻辑
        if args[0].closeBtnType == nil then
            g_LogError("结果页没有区分按钮类别")
            return
        end

        if self.needShowMatching == true and args[0].closeBtnType ~= 3 and self.gameMode ~= 2 and self.gameMode ~= 1 then
            self:checkEnergy()
            -- 休闲
            if self.needShowMatching then
                -- 非排位游戏，仅在排队按钮需要时处理按钮显示
                self:GameMatchingLogic(self.closebtn2, self.zailaiyiju)
            end
        elseif args[0].closeBtnType == 1 then
            local time = 3
            if args[0].has_upgrade then
                time = 6
            end
            self.commonService:DispatchAfter(time, function()
                self.rootUI:SetActive(false)
                self:ShowMainPanel(false)
                if args[0].autoCloseCallBack then
                    args[0].autoCloseCallBack()
                end
            end)

            self:ShowMainPanel(true)
            self.rootUI:SetActive(true)
        elseif args[0].closeBtnType == 2 then
            self.closebtn.gameObject:SetActive(true)
            if args[0].clickCloseCallBack then
                self.clickCloseCallBack = args[0].clickCloseCallBack
            end
            self:ShowMainPanel(true)
            self.rootUI:SetActive(true)
        elseif args[0].closeBtnType == 3 then
            if args[0].clickCloseCallBack then
                self.clickCloseCallBack = args[0].clickCloseCallBack
            end
            if args[0].clickAgainCallBack then
                self.clickAgainCallBack = args[0].clickAgainCallBack
            end

            self.zailaiyiju["onClick"]:RemoveAllListeners()
            -- 再来一局
            self.commonService:AddEventListener(self.zailaiyiju, "onClick", function()
                self:againGame()
                self.hasRequest = false

                -- 清空接口请求获取数据
                self.change_score = nil
                self.ranking_before = nil
                self.ranking_after = nil
                self.is_protect = nil
                self.protect_score = nil
                self.is_school_settle = nil
                self.join_school_flag = nil
                self.add_value = nil
                self.has_upgrade = nil
                self.after_level = nil
                self.is_double_game = nil
                self.add_cheese_val = nil
                self.grow_route_info = nil
                self.season_id = nil
                -- 是否获得集字
                self.jiziNum = nil

                -- 清空统计开口相关数据
                self.petExpFromAnswer = 0
                self.xueshiFromAnswer = 0
            end)
            self.closebtn2["onClick"]:RemoveAllListeners()
            self.commonService:AddEventListener(self.closebtn2, "onClick", function()
                log("点击按钮回调")
                if self.clickCloseCallBack then
                    self.clickCloseCallBack()
                end
                App:GameReturn()
            end)

            self:checkEnergy()
        end

        -- 6 显示集字活动UI
        -- 添加集字埋点
        self:reportLog("tiedup_game_result", args[0].jiziNum)
        if args[0].jiziNum and args[0].jiziNum > 0 and self.jiziNumImageList[args[0].jiziNum] then
            if self.jiziroot and self.jiziNumImage then
                self.jiziNumImage.sprite = self.jiziNumImageList[args[0].jiziNum]
                self.jiziroot.gameObject:SetActive(true)
            end
        end

        if self.isReportEnd == false then
            self:reportLog("gameResultView")
            self.isReportEnd = true
        end

    end)

    -- 新增隐藏界面
    self.BusEventService:Watch("HIDE_MINI_GAME_RESULT_PANEL", function(key, args)
        self.rootUI.gameObject:SetActive(false)
    end)
end

-- 展示成长之路升级特效
function GameResult:showLevelUpEffect(growRouteInfo)
    -- 判断是否升阶段
    if not self.levelUpEffect then
        return
    end

    if growRouteInfo.is_full == true then
        self.levelUpEffect.gameObject:SetActive(false)
        return
    end

    if growRouteInfo.before_stage == growRouteInfo.after_stage and growRouteInfo.before_step == growRouteInfo.after_step then
        -- 设置左右字体
        local beforeStr = string.format("成长第%s阶·%d", self:num2Chinese(growRouteInfo.before_stage),
            growRouteInfo.before_step)
        self.levelUpZuoText.text = beforeStr
        local afterStr = string.format("%d/需%d贡献分", growRouteInfo.cur_emp_val, growRouteInfo.cost_emp_val)
        self.levelUpYouText.text = afterStr
        -- 设置解锁图片
        if growRouteInfo.award_num and growRouteInfo.award_num > 1 then
            self.levelUpLockNum.text = "x" .. growRouteInfo.award_num
        else
            self.levelUpLockNum.text = ""
        end
        self.httpService:LoadNetWorkTexture(growRouteInfo.locking_award_img, function(texture)
            self.levelUpLockImage.sprite = texture
        end)
        -- 暂停获取奖励动画
        self.levelUpEffectAni.enabled = false
        -- 播放一秒进度条变化动画
        if self.seqEnergy then
            self.seqEnergy:Kill()
            self.seqEnergy = nil
        end

        local beforeX = (growRouteInfo.before_emp_val / growRouteInfo.cost_emp_val - 1) * 952
        local afterX = (growRouteInfo.cur_emp_val / growRouteInfo.cost_emp_val - 1) * 952
        self.levelUpEffectJindu.transform.localPosition = Vector3(beforeX,
            self.levelUpEffectJindu.transform.localPosition.y, self.levelUpEffectJindu.transform.localPosition.z)
        self.seqEnergy = CS.DG.Tweening.DOTween:Sequence()
        self.seqEnergy:Append(self.levelUpEffectJindu:DOLocalMoveX(afterX, 0.63))
    else
        self.commonService:StartCoroutine(function()
            -- 设置最初状态
            -- 左边字体
            -- 设置左右字体
            local beforeStr = string.format("成长第%s阶·%d", self:num2Chinese(growRouteInfo.before_stage),
                growRouteInfo.before_step)
            self.levelUpZuoText.text = beforeStr
            -- 初始进度条
            local beforeX = (growRouteInfo.before_emp_val / growRouteInfo.cost_emp_val - 1) * 952
            self.levelUpEffectJindu.transform.localPosition =
                Vector3(beforeX, self.levelUpEffectJindu.transform.localPosition.y,
                    self.levelUpEffectJindu.transform.localPosition.z)
            -- 延迟0.5S显示动效
            self.commonService:YieldSeconds(0.5)
            local lastState = nil
            local lastStep = nil
            for k, v in ipairs(growRouteInfo.can_own_list) do
                -- 左边字体
                if lastState and lastStep then
                    local beforeStr = string.format("成长第%s阶·%d", self:num2Chinese(lastState), lastStep)
                    self.levelUpZuoText.text = beforeStr
                    self.levelUpEffectJindu.transform.localPosition =
                        Vector3(-952, self.levelUpEffectJindu.transform.localPosition.y,
                            self.levelUpEffectJindu.transform.localPosition.z)
                end
                lastState = v.stage
                lastStep = v.step
                -- 右边字体
                local afterStr = string.format("%d/需%d贡献分", v.cost_emp_val, v.cost_emp_val)
                self.levelUpYouText.text = afterStr
                -- 图片
                -- 设置解锁图片
                if v.award_num and v.award_num > 1 then
                    self.levelUpLockNum.text = "x" .. v.award_num
                else
                    self.levelUpLockNum.text = ""
                end
                self.httpService:LoadNetWorkTexture(v.award_img, function(texture)
                    self.levelUpLockImage.sprite = texture
                end)
                -- 播放进度条
                if self.seqEnergy then
                    self.seqEnergy:Kill()
                    self.seqEnergy = nil
                end
                self.seqEnergy = CS.DG.Tweening.DOTween:Sequence()
                self.seqEnergy:Append(self.levelUpEffectJindu:DOLocalMoveX(0, 0.63))
                -- 播放动画
                self.levelUpEffectAni.enabled = true
                self.levelUpEffectAni:Play("dangqianzhuangbei", 0, 0)
                self.commonService:YieldSeconds(0.63)
            end

            -- 设置最终状态
            -- 关闭奖励动画
            self.levelUpEffectAni.enabled = false
            -- 左边字体
            local beforeStr = string.format("成长第%s阶·%d", self:num2Chinese(lastState), lastStep)
            self.levelUpZuoText.text = beforeStr
            -- 右边字体
            local afterStr = string.format("%d/需%d贡献分", growRouteInfo.cur_emp_val, growRouteInfo.cost_emp_val)
            self.levelUpYouText.text = afterStr
            -- 设置解锁图片
            if growRouteInfo.award_num and growRouteInfo.award_num > 1 then
                self.levelUpLockNum.text = "x" .. growRouteInfo.award_num
            else
                self.levelUpLockNum.text = ""
            end
            self.httpService:LoadNetWorkTexture(growRouteInfo.locking_award_img, function(texture)
                self.levelUpLockImage.sprite = texture
            end)
            -- 播放一秒进度条变化动画
            if self.seqEnergy then
                self.seqEnergy:Kill()
                self.seqEnergy = nil
            end

            local afterX = (growRouteInfo.cur_emp_val / growRouteInfo.cost_emp_val - 1) * 952
            self.levelUpEffectJindu.transform.localPosition =
                Vector3(-952, self.levelUpEffectJindu.transform.localPosition.y,
                    self.levelUpEffectJindu.transform.localPosition.z)
            self.seqEnergy = CS.DG.Tweening.DOTween:Sequence()
            self.seqEnergy:Append(self.levelUpEffectJindu:DOLocalMoveX(afterX, 0.63))
        end)
    end
end

function GameResult:checkEnergy()
    if App.IsStudioClient then
        -- 直接当成成功
        self.closebtn.gameObject:SetActive(false)
        self.closebtn2.gameObject:SetActive(true)
        self.zailaiyiju.gameObject:SetActive(true)

        self:ShowMainPanel(true)
        self.rootUI:SetActive(true)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = "https://app.chuangjing.com/next-api/v3/user/power/is-enough",
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = {
                game_id = 86
            }
        }, function(res)
            local resp = res.responseString
            local data = self.jsonService:decode(res.responseString)
            if data.data then
                g_Log("lsh消耗体力是否足够" .. tostring(data.data.is_enough))
                self.powerEnough = data.data.is_enough
                if self.powerEnough == true then
                    g_Log("结果页：体力够用")
                    self.closebtn.gameObject:SetActive(false)
                    self.closebtn2.gameObject:SetActive(true)
                    self.zailaiyiju.gameObject:SetActive(true)
                else
                    g_Log("结果页：体力不足")
                    self.closebtn.gameObject:SetActive(true)
                    self.closebtn2.gameObject:SetActive(false)
                    self.zailaiyiju.gameObject:SetActive(false)
                end
            else
                g_Log("结果页：体力请求出错")
                self.closebtn.gameObject:SetActive(true)
                self.closebtn2.gameObject:SetActive(false)
                self.zailaiyiju.gameObject:SetActive(false)
            end

            self:ShowMainPanel(true)
            self.rootUI:SetActive(true)
        end)
    end
end
function GameResult:AsyncHasPower(cb)
    if App.IsStudioClient then
        cb(true)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = "https://app.chuangjing.com/next-api/v3/user/power/is-enough",
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = {
                game_id = 86
            }
        }, function(res)
            local resp = res.responseString
            local data = self.jsonService:decode(res.responseString)
            if data.data then
                g_Log("lsh消耗体力是否足够" .. tostring(data.data.is_enough))
                self.powerEnough = data.data.is_enough
                if self.powerEnough == true then
                    g_Log("结果页：体力够用")
                else
                    g_Log("结果页：体力不足")
                end
            else
                g_Log("结果页：体力请求出错")
            end

            cb(self.powerEnough)

        end)
    end
end

function GameResult:againGame()

    if App.IsStudioClient then
        if self.clickAgainCallBack then
            -- self.rootUI.gameObject:SetActive(false)
            log("点击再来一局回调")
            self:ShowMainPanel(false)
            self.clickAgainCallBack()
        end
    else
        if self.clickAgainCallBack then
            if self.needShowMatching ~= true then
                self.rootUI.gameObject:SetActive(false)
            end
            log("点击再来一局回调")
            self:ShowMainPanel(false)
            self.clickAgainCallBack()
        end

        -- APIBridge.RequestAsync('api.httpclient.request', {
        --     ["url"] = "https://app.chuangjing.com/next-api/v3/user/power/cost",
        --     ["headers"] = {
        --         ["Content-Type"] = "application/json"
        --     },
        --     ["data"] = {
        --         game_id = 86,
        --         opt_source = self.opt_source
        --     }
        -- }, function(res)
        --     g_Log("lsh消耗一个体力" .. tostring(86))
        --     local data = self.jsonService:decode(res.responseString)
        --     g_Log("lsh消耗体力是否成功" .. tostring(data.data.is_success))
        --     if data.data then
        --         self.costIsSuccess = data.data.is_success
        --         if self.costIsSuccess then
        --             if self.clickAgainCallBack then
        --                 if self.needShowMatching ~= true then
        --                     self.rootUI.gameObject:SetActive(false)
        --                 end
        --                 log("点击再来一局回调")
        --                 self:ShowMainPanel(false)
        --                 self.clickAgainCallBack()
        --             end
        --         else
        --             g_LogError("结果页：消耗体力失败")
        --         end
        --     else
        --         g_LogError("结果页：消耗体力解析失败")
        --     end
        -- end)
    end
end

-- 上报自己积分
function GameResult:reportPoint(data, callback)
    local totalUrl = self.totalUrl
    local game_id = tonumber(self.game_id)
    local set_id = tonumber(self.set_id)
    local plan_id = tonumber(self.plan_id)
    if data.game_id then
        self.game_id = game_id
        game_id = tonumber(data.game_id)
    end
    if data.set_id then
        set_id = tonumber(data.set_id)
    end
    if data.plan_id then
        plan_id = tonumber(data.plan_id)
    end
    local param = {
        game_id = game_id,
        set_id = set_id,
        plan_id = plan_id,
        rank = data.rank,
        score = data.score,
        award = data.award,
        team = data.team,
        is_run = data.is_run,
        is_captor = data.is_captor
    }

    if self.finalRankNum == nil then
        self.finalRankNum = param.rank
    end

    g_Log("上报自己积分入参" .. table.dump(param))
    if App.IsStudioClient then
        totalUrl = "https://yapi.xesv5.com/mock/2041/v3/game/person-settle"
        self.httpService:PostForm(totalUrl, param, {}, function(res)
            local msg
            if type(res) == "string" then
                msg = self.jsonService:decode(res)
            end
            g_Log("上报自己积分成功成功" .. table.dump(msg))
            if msg and msg.msg == "success" then
                if msg.code == 0 then
                    local data = msg.data
                    if data then
                        -- 返回值
                        -- "change_score":3,
                        -- "ranking_before":{"level":"1","level_name":"磐石","level_score":0},
                        -- "ranking_after":{"level":"1","level_name":"磐石","level_score":3}
                        g_Log("上报自己积分成功成功")
                        if self.change_score == nil then
                            self.change_score = data.change_score
                        end
                        if self.ranking_before == nil then
                            self.ranking_before = data.ranking_before
                        end
                        if self.ranking_after == nil then
                            self.ranking_after = data.ranking_after
                        end
                        if self.is_protect == nil then
                            self.is_protect = data.is_protect
                        end
                        if self.protect_score == nil then
                            self.protect_score = data.protect_score
                        end

                        if self.is_school_settle == nil then
                            self.is_school_settle = data.is_school_settle
                        end

                        if self.join_school_flag == nil then
                            self.join_school_flag = data.join_school_flag
                        end

                        if self.add_value == nil then
                            self.add_value = data.add_value
                        end

                        if self.has_upgrade == nil then
                            self.has_upgrade = data.has_upgrade
                        end

                        if self.after_level == nil then
                            self.after_level = data.after_level
                        end

                        if self.is_double_game == nil then
                            self.is_double_game = data.is_double_game
                        end

                        if self.add_cheese_val == nil then
                            self.add_cheese_val = data.add_cheese_val
                        end

                        if self.grow_route_info == nil then
                            self.grow_route_info = data.grow_route_info
                        end

                        if self.season_id == nil then
                            self.season_id = data.season_id
                        end

                        if self.jiziNum == nil then
                            self.jiziNum = data.word_num
                        end
                    end
                end
                if callback then
                    callback()
                end
            else
                g_Log("上报自己积分成功失败-")
                if callback then
                    callback()
                end
            end
        end, nil)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = totalUrl,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = param
        }, function(res)
            if type(res) == "string" then
                res = self.jsonService:decode(res)
            end
            g_Log("上报结果初始返回值" .. table.dump(res))
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                local msg = nil
                if type(resp) == "string" then
                    msg = self.jsonService:decode(resp)
                end
                g_Log("上报自己积分结果" .. table.dump(msg))
                if msg and msg.msg == "success" then
                    if msg.code == 0 then
                        local data = msg.data
                        if data then
                            -- 返回值
                            -- "change_score":3,
                            -- "ranking_before":{"level":"1","level_name":"磐石","level_score":0},
                            -- "ranking_after":{"level":"1","level_name":"磐石","level_score":3}
                            g_Log("上报自己积分成功成功")
                            if self.change_score == nil then
                                self.change_score = data.change_score
                            end
                            if self.ranking_before == nil then
                                self.ranking_before = data.ranking_before
                            end
                            if self.ranking_after == nil then
                                self.ranking_after = data.ranking_after
                            end
                            if self.is_protect == nil then
                                self.is_protect = data.is_protect
                            end
                            if self.protect_score == nil then
                                self.protect_score = data.protect_score
                            end

                            if self.is_school_settle == nil then
                                self.is_school_settle = data.is_school_settle
                            end

                            if self.join_school_flag == nil then
                                self.join_school_flag = data.join_school_flag
                            end

                            if self.add_value == nil then
                                self.add_value = data.add_value
                            end

                            if self.has_upgrade == nil then
                                self.has_upgrade = data.has_upgrade
                            end

                            if self.after_level == nil then
                                self.after_level = data.after_level
                            end

                            if self.is_double_game == nil then
                                self.is_double_game = data.is_double_game
                            end

                            if self.add_cheese_val == nil then
                                self.add_cheese_val = data.add_cheese_val
                            end

                            if self.grow_route_info == nil then
                                self.grow_route_info = data.grow_route_info
                            end

                            if self.season_id == nil then
                                self.season_id = data.season_id
                            end

                            if self.jiziNum == nil then
                                self.jiziNum = data.word_num
                            end
                        end
                    end
                    if callback then
                        callback()
                    end
                else
                    g_Log("上报自己积分成功失败-")
                    if callback then
                        callback()
                    end
                end
            else
                g_Log("上报自己积分成功失败")
                if callback then
                    callback()
                end
            end
        end)
    end
end

function GameResult:FormatTime(seconds)
    if seconds == nil or seconds < 0 then
        return "0'00''"
    end
    local minutes = math.floor(seconds / 60)
    local remainingSeconds = seconds % 60
    -- -- 格式化分钟和秒钟
    -- local formattedTime = string.format("%d'%02d''", minutes, remainingSeconds)
    -- return formattedTime

    return minutes, remainingSeconds
end

function GameResult:InitView()

    ---@type CS.UnityEngine.RectTransform
    self.canvasRect = self.rootUI.transform:Find("Canvas")
    ---@type CS.UnityEngine.Canvas
    self.canvas = self.canvasRect.gameObject:GetComponent(typeof(CS.UnityEngine.Canvas))
    self.canvas.sortingOrder = 1200

    if App.IsStudioClient then
        self.canvas.sortingOrder = 100
    end

    -- 1.标题
    ---@type CS.UnityEngine.UI.Image
    -- self.sortNumImg = self.canvasRect:Find("jieguoye/mingci_1/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.mingci1 = self.canvasRect:Find("jieguoye/biaoti/mingci_01/mingci_1").gameObject
    self.sortNumImg = self.canvasRect:Find("jieguoye/biaoti/mingci_01/mingci_1/shuzi").gameObject:GetComponent(typeof(
        CS.UnityEngine.UI.Image))
    self.mingci2 = self.canvasRect:Find("jieguoye/biaoti/mingci_01/mingci_2").gameObject
    self.sortNumImgShi = self.canvasRect:Find("jieguoye/biaoti/mingci_01/mingci_2/shuzi _shi").gameObject:GetComponent(
        typeof(CS.UnityEngine.UI.Image))
    self.sortNumImgGe = self.canvasRect:Find("jieguoye/biaoti/mingci_01/mingci_2/shuzi _ge").gameObject:GetComponent(
        typeof(CS.UnityEngine.UI.Image))
    self.huosheng = self.canvasRect:Find("jieguoye/biaoti/huosheng").gameObject
    self.huoshengRect = self.huosheng.transform:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.pingju = self.canvasRect:Find("jieguoye/biaoti/pingju").gameObject
    self.shibai = self.canvasRect:Find("jieguoye/biaoti/shibai").gameObject
    self.yichuju = self.canvasRect:Find("jieguoye/biaoti/yichuju").gameObject
    self.shangweijiesu = self.canvasRect:Find("jieguoye/biaoti/shangweijiesu").gameObject
    self.weiwancheng = self.canvasRect:Find("jieguoye/biaoti/weiwancheng").gameObject
    self.weiwancheng.gameObject:SetActive(false)
    self.mingci_01 = self.canvasRect:Find("jieguoye/biaoti/mingci_01").gameObject

    -- 2.用时等内容
    self.canvasRect:Find("jieguoye/Mask group/huoqufenshu_2").gameObject:SetActive(false)
    self.neirong1 =
        self.canvasRect:Find("jieguoye/Mask group/huoqufenshu/yongshi_zhishi_jingyan/yongshi_zhishi_jingyan")
    self.neirong2 = self.canvasRect:Find("jieguoye/Mask group/huoqufenshu/zhishi_jingyan")
    self.neirong3 = self.canvasRect:Find("jieguoye/Mask group/huoqufenshu/jingyan")
    self.neirong4 = self.canvasRect:Find("jieguoye/Mask group/huoqufenshu/zhishi")
    self.neirong5 = self.canvasRect:Find("jieguoye/Mask group/huoqufenshu/zhishi_xueshi_jingyan/zhishi_xueshi_jingyan")

    self.neirong1.gameObject:SetActive(false)
    self.neirong2.gameObject:SetActive(false)
    self.neirong3.gameObject:SetActive(false)
    self.neirong4.gameObject:SetActive(false)
    self.neirong5.gameObject:SetActive(false)

    ---@type CS.UnityEngine.RectTransform
    self.useTime = self.neirong1:Find("chuangguanyongshi/shijian")
    self.useTimeText = self.useTime.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
    -- 3.校园升级相关内容
    -- 未加入校园
    self.schoolScoreRoot = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao")
    self.noSchool = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao/weijiaruxiaoyuan")
    -- 额外加分
    self.hasSchoolExtraTip = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao/1")
    self.hasSchoolExtraTip.gameObject:SetActive(false)
    -- 获得集字
    self.jiziroot = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao/2")
    if self.jiziroot then
        self.jiziroot.gameObject:SetActive(false)
        self.jiziNumImage = self.jiziroot:Find("huodezipai/zipai/numImage").gameObject:GetComponent(typeof(
            CS.UnityEngine.UI.Image))
    end
    -- MVP界面
    self.mvp = self.canvasRect:Find("jieguoye/MVP-erwaijiangli")
    self.mvpGongxianfen = self.mvp:Find("gongxianfen/Text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.mvpGongxianfen.text = "+0"
    self.mvpHuodezhishi = self.mvp:Find("huodezhishi/Text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.mvpHuodezhishi.text = "x0"
    self.mvp.gameObject:SetActive(false)
    -- 普通校园加分
    self.hasSchool = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao/xiaoyuanjingyan")
    self.schoolScoreImageBai = self.hasSchool:Find("shuzi_1").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.schoolScoreImageShi = self.hasSchool:Find("shuzi_2").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.schoolScoreImageGe = self.hasSchool:Find("shuzi_3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.schoolScoreImageBai.gameObject:SetActive(true)
    self.schoolScoreImageShi.gameObject:SetActive(true)
    self.schoolScoreImageGe.gameObject:SetActive(true)
    -- 校园加分加额外加分
    self.hasSchoolExtra = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao/jiafen_duijue")
    self.hasSchoolExtraBeforeBai =
        self.hasSchoolExtra:Find("xiaoyuanjingyan/Mask/fenhsu/shuzi_1").gameObject:GetComponent(typeof(CS.UnityEngine.UI
                                                                                                           .Image))
    self.hasSchoolExtraBeforeShi =
        self.hasSchoolExtra:Find("xiaoyuanjingyan/Mask/fenhsu/shuzi_2").gameObject:GetComponent(typeof(CS.UnityEngine.UI
                                                                                                           .Image))
    self.hasSchoolExtraBeforeGe =
        self.hasSchoolExtra:Find("xiaoyuanjingyan/Mask/fenhsu/shuzi_3").gameObject:GetComponent(typeof(CS.UnityEngine.UI
                                                                                                           .Image))

    self.hasSchoolExtraAfterBai =
        self.hasSchoolExtra:Find("xiaoyuanjingyan/Mask/fenhsu2/shuzi_1").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                            .UI.Image))
    self.hasSchoolExtraAfterShi =
        self.hasSchoolExtra:Find("xiaoyuanjingyan/Mask/fenhsu2/shuzi_2").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                            .UI.Image))
    self.hasSchoolExtraAfterGe =
        self.hasSchoolExtra:Find("xiaoyuanjingyan/Mask/fenhsu2/shuzi_3").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                            .UI.Image))

    self.hasSchoolExtraBeforeBai.gameObject:SetActive(true)
    self.hasSchoolExtraBeforeShi.gameObject:SetActive(true)
    self.hasSchoolExtraBeforeGe.gameObject:SetActive(true)
    self.hasSchoolExtraAfterBai.gameObject:SetActive(true)
    self.hasSchoolExtraAfterShi.gameObject:SetActive(true)
    self.hasSchoolExtraAfterGe.gameObject:SetActive(true)

    -- 双倍校园加分
    self.hasSchoolDouble = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao/jiafen_shuangbei")
    self.hasSchoolDoubleBeforeBai =
        self.hasSchoolDouble:Find("gongxianfen/Mask/fenhsu/shuzi_1").gameObject:GetComponent(typeof(CS.UnityEngine.UI
                                                                                                        .Image))
    self.hasSchoolDoubleBeforeShi =
        self.hasSchoolDouble:Find("gongxianfen/Mask/fenhsu/shuzi_2").gameObject:GetComponent(typeof(CS.UnityEngine.UI
                                                                                                        .Image))
    self.hasSchoolDoubleBeforeGe = self.hasSchoolDouble:Find("gongxianfen/Mask/fenhsu/shuzi_3").gameObject:GetComponent(
        typeof(CS.UnityEngine.UI.Image))
    self.hasSchoolDoubleAfterBai =
        self.hasSchoolDouble:Find("gongxianfen/Mask/fenhsu2/shuzi_1").gameObject:GetComponent(typeof(CS.UnityEngine.UI
                                                                                                         .Image))
    self.hasSchoolDoubleAfterShi =
        self.hasSchoolDouble:Find("gongxianfen/Mask/fenhsu2/shuzi_2").gameObject:GetComponent(typeof(CS.UnityEngine.UI
                                                                                                         .Image))
    self.hasSchoolDoubleAfterGe = self.hasSchoolDouble:Find("gongxianfen/Mask/fenhsu2/shuzi_3").gameObject:GetComponent(
        typeof(CS.UnityEngine.UI.Image))
    self.hasSchoolDoubleTip1 = self.hasSchoolDouble:Find("gongxianfen/shuangbei_1")
    self.hasSchoolDoubleTip2 = self.hasSchoolDouble:Find("gongxianfen/shuangbei_2")
    self.hasSchoolDoubleTip3 = self.hasSchoolDouble:Find("gongxianfen/shuangbei_3")
    self.hasSchoolDoubleTip1.gameObject:SetActive(false)
    self.hasSchoolDoubleTip2.gameObject:SetActive(false)
    self.hasSchoolDoubleTip3.gameObject:SetActive(false)
    self.hasSchoolDoubleBeforeBai.gameObject:SetActive(true)
    self.hasSchoolDoubleBeforeShi.gameObject:SetActive(true)
    self.hasSchoolDoubleBeforeGe.gameObject:SetActive(true)
    self.hasSchoolDoubleAfterBai.gameObject:SetActive(true)
    self.hasSchoolDoubleAfterShi.gameObject:SetActive(true)
    self.hasSchoolDoubleAfterGe.gameObject:SetActive(true)
    -- 双倍校园额外加分
    self.hasSchoolDoubleExtra = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao/jiafen_shuangbei_duijue")
    self.hasSchoolDoubleExtraBeforeBai =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu/shuzi_1").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                             .UI.Image))
    self.hasSchoolDoubleExtraBeforeShi =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu/shuzi_2").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                             .UI.Image))
    self.hasSchoolDoubleExtraBeforeGe =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu/shuzi_3").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                             .UI.Image))
    self.hasSchoolDoubleExtraMidBai =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu2/shuzi_1").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                              .UI.Image))
    self.hasSchoolDoubleExtraMidShi =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu2/shuzi_2").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                              .UI.Image))
    self.hasSchoolDoubleExtraMidGe =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu2/shuzi_3").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                              .UI.Image))
    self.hasSchoolDoubleExtraAfterBai =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu3/shuzi_1").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                              .UI.Image))
    self.hasSchoolDoubleExtraAfterShi =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu3/shuzi_2").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                              .UI.Image))
    self.hasSchoolDoubleExtraAfterGe =
        self.hasSchoolDoubleExtra:Find("gongxianfen/Mask/fenhsu3/shuzi_3").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                              .UI.Image))
    self.hasSchoolDoubleExtraTip1 = self.hasSchoolDoubleExtra:Find("gongxianfen/shuangbei_1")
    self.hasSchoolDoubleExtraTip2 = self.hasSchoolDoubleExtra:Find("gongxianfen/shuangbei_2")
    self.hasSchoolDoubleExtraTip3 = self.hasSchoolDoubleExtra:Find("gongxianfen/shuangbei_3")
    self.hasSchoolDoubleExtraTip1.gameObject:SetActive(false)
    self.hasSchoolDoubleExtraTip2.gameObject:SetActive(false)
    self.hasSchoolDoubleExtraTip3.gameObject:SetActive(false)
    self.hasSchoolDoubleExtraBeforeBai.gameObject:SetActive(true)
    self.hasSchoolDoubleExtraBeforeShi.gameObject:SetActive(true)
    self.hasSchoolDoubleExtraBeforeGe.gameObject:SetActive(true)
    self.hasSchoolDoubleExtraMidBai.gameObject:SetActive(true)
    self.hasSchoolDoubleExtraMidShi.gameObject:SetActive(true)
    self.hasSchoolDoubleExtraMidGe.gameObject:SetActive(true)
    self.hasSchoolDoubleExtraAfterBai.gameObject:SetActive(true)
    self.hasSchoolDoubleExtraAfterShi.gameObject:SetActive(true)
    self.hasSchoolDoubleExtraAfterGe.gameObject:SetActive(true)
    -- 稍后发放
    self.shouhoufafang = self.canvasRect:Find("jieguoye/Mask group/xiaotibiao/shaohoufafang")
    self.shouhoufafang.gameObject:SetActive(false)
    -- 成长之路相关UI
    self.chengzhangzhilu = self.canvasRect:Find("jieguoye/chengzhangzhilu")
    -- 学期
    self.session = self.canvasRect:Find("jieguoye/chengzhangzhilu/diyiqi").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                              .UI.Image))
    --  加入校园后礼包
    self.enterSchoolReward = self.canvasRect:Find("jieguoye/chengzhanglibao")
    self.enterSchoolReward.gameObject:SetActive(false)
    self.enterSchoolRewardImage = self.enterSchoolReward:Find("libao/daoju").gameObject:GetComponent(typeof(
        CS.UnityEngine.UI.Image))
    -- 成长之路等级升级特效
    self.levelUpEffect = self.canvasRect:Find("jieguoye/jindutiao")
    self.levelUpEffect.gameObject:SetActive(false)
    self.levelUpEffectJindu = self.levelUpEffect:Find("jindutiao/Rectangle_1/Rectangle_2/jindu")
    self.levelUpEffectAni = self.levelUpEffect:Find("dangqianzhaungbei").gameObject:GetComponent(typeof(CS.UnityEngine
                                                                                                            .Animator))
    self.levelUpZuoText = self.levelUpEffect:Find("Text-zuo").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.levelUpYouText = self.levelUpEffect:Find("Text-you").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.levelUpLockImage =
        self.levelUpEffect:Find("dangqianzhaungbei/dangqian/zhuangbei_bg/zhaungbei").gameObject:GetComponent(typeof(
            CS.UnityEngine.UI.Image))
    self.levelUpLockNum =
        self.levelUpEffect:Find("dangqianzhaungbei/dangqian/zhuangbei_bg/zhaungbei/Num").gameObject:GetComponent(typeof(
            CS.TMPro.TextMeshProUGUI))
    self.levelUpLockNum.text = ""
    -- 校园升级
    -- self.schoolUpgrade = self.canvasRect:Find("jieguoye/xiaoyuanshengji")
    -- self.schoolMask = self.schoolUpgrade:Find("xiaoyuanshengji_1/xiaohui/02/xiaohui/xiaohui-2/xiaohui_mask")
    -- self.schoolBeforeShi = self.schoolMask:Find("shuzi_1/shiwei").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    -- self.schoolBeforeGe = self.schoolMask:Find("shuzi_1/gewei").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    -- self.schoolAfterShi = self.schoolMask:Find("shuzi_2/shiwei").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    -- self.schoolAfterGe = self.schoolMask:Find("shuzi_2/gewei").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
    -- 4.退出按钮
    ---@type CS.UnityEngine.UI.Button
    self.closebtn = self.canvasRect:Find("jieguoye/anjian/anjian_1/tuichu").gameObject:GetComponent(typeof(
        CS.UnityEngine.UI.Button))
    self.closebtn.gameObject:SetActive(false)
    self.closebtn2 = self.canvasRect:Find("jieguoye/anjian/anjian_2/tuichu").gameObject:GetComponent(typeof(
        CS.UnityEngine.UI.Button))
    self.closebtn2.gameObject:SetActive(false)
    self.zailaiyiju = self.canvasRect:Find("jieguoye/anjian/anjian_2/zailaiyiju").gameObject:GetComponent(typeof(
        CS.UnityEngine.UI.Button))
    self.zailaiyiju.gameObject:SetActive(false)
    -- 排名列表
    self.ranks = self.canvasRect:Find("jieguoye/paiming/ranks")
    self.ranks.gameObject:SetActive(false)
    self.rankViews = {}
    for i = 1, 4 do
        local rank = self.ranks:FindChildWithName(i .. "bg")
        local name = rank:FindChildWithName("name")
        local nameTmp = name:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        local score = rank:FindChildWithName("score")
        local scoreTmp = score:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        local rankView = {
            rank = rank,
            name = nameTmp,
            score = scoreTmp
        }
        self.rankViews[i] = rankView
    end

end

function GameResult:InitConfig()

    self.root = self.VisElement.gameObject
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/game_resultPanel/"
    local micPrefabPath = ResourcePathRoot .. "resultPanel/assets/Prefabs/jieguoye.prefab"
    local picturePathRoot = ResourcePathRoot .. "testures/"
    ResourceManager:LoadGameObjectWithExName(micPrefabPath, function(go)
        self.rootUI = GameObject.Instantiate(go)
        self.rootUI.transform:SetParent(self.root.transform)
        self.rootUI.transform.localPosition = Vector3.zero
        self.rootUI.transform.localScale = Vector3.one
        self.rootUI.transform.localRotation = Quaternion.identity
        self.rootUI:SetActive(false)

        self:InitView()
        self:InitEventListener()
    end)

    -- self.noImageBlackList = {}
    self.noWhiteImageList = {}
    self.rNumList = {}
    self.sessionImageList = {}
    self.jiziNumImageList = {}
    for i = 0, 9 do
        -- ResourceManager:LoadSpriteWithExName(picturePathRoot .. "blackNum_" .. i .. ".png", function(sprite)
        --     self.noImageBlackList[i] = sprite
        -- end)
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "whiteNum_" .. i .. ".png", function(sprite)
            self.noWhiteImageList[i] = sprite
        end)
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "redNum_" .. i .. ".png", function(sprite)
            self.rNumList[i] = sprite
        end)
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "zipai_" .. i .. ".png", function(sprite)
            self.jiziNumImageList[i] = sprite
        end)
    end

    for i = 1, 20 do
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "session" .. i .. ".png", function(sprite)
            self.sessionImageList[i] = sprite
        end)
    end

    ResourceManager:LoadSpriteWithExName(picturePathRoot .. "yiwancheng.png", function(sprite)
        self.yiwancheng = sprite
    end)
    ResourceManager:LoadSpriteWithExName(picturePathRoot .. "chenggonglikai.png", function(sprite)
        self.chenggonglikai = sprite
    end)
    ResourceManager:LoadSpriteWithExName(picturePathRoot .. "yitaotai.png", function(sprite)
        self.yitaotai = sprite
    end)
    self.httpService:LoadNetWorkTexture("https://static0.xesimg.com/next-studio-pub/app/1753258986069/Gm4yflFUSA6Dj4TYbPax.png", function(sprite)
        self.chijishibai = sprite
    end)
    self.httpService:LoadNetWorkTexture("https://static0.xesimg.com/next-studio-pub/app/1753258986066/UX2891Sb9dPWzCKisPML.png", function(sprite)
        self.chijishengli = sprite
    end)

    self.petExpFromAnswer = 0
    self.xueshiFromAnswer = 0

    -- 上报结果接口
    self.totalUrl = "https://app.chuangjing.com/next-api/v3/game/person-settle"
    -- 游戏模式
    self.gameMode = 3
end

function GameResult:InitService()
    ---@type Gate
    self.gate = CourseEnv.ServicesManager.Gate
    ---@type ObserverService
    self.BusEventService = CourseEnv.ServicesManager:GetObserverService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type UIService
    self.UIService = App:GetService("UIService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DecorateService
    self.decorateService = CourseEnv.ServicesManager:GetDecorateService()
    ---@type LightService
    self.lightService = CourseEnv.ServicesManager:GetLightService()
end

function GameResult:ShowMainPanel(isShow)
    if self.SHOW_MAIN_PANEL == isShow then
        return
    end

    if isShow then
        self.joyId = self.joystickService:setHidenJoyWithID()
        self.jumpId = self.joystickService:setHidenJumpWithID()
        self.voiceId = self.UIService:SetHidenVoiceBtnWithID()
        -- self.followId = self.UIService:SetHidenFollowBtnWithID()
        --- 左上角退出按钮隐藏
        -- APIBridge.RequestAsync('app.business.view.backroom', { show = 0 })
        self.SHOW_MAIN_PANEL = true
    else
        self.joystickService:setVisibleJoyWithID(self.joyId)
        self.joystickService:setVisibleJumpWithID(self.jumpId)
        self.UIService:SetVisibleHidenVoiceBtnWithID(self.voiceId)
        -- self.UIService:SetVisibleHidenFollowBtnWithID(self.followId)
        --- 左上角退出按钮显示 
        -- APIBridge.RequestAsync('app.business.view.backroom', { show = 1 })
        self.SHOW_MAIN_PANEL = false

        self.petExpFromAnswer = 0
        self.xueshiFromAnswer = 0
    end
end

-- 截取指定长度
function GameResult:GetMaxLenString(s, maxLen)
    local len = self:GetUTFLen(s)

    local dstString = s
    -- 超长，裁剪，加...
    if len > maxLen then
        dstString = string.sub(s, 1, self:GetUTFLenWithCount(s, maxLen))
        dstString = dstString
    end

    return dstString
end

function GameResult:StringToTable(s)
    local tb = {}
    for utfChar in string.gmatch(s, "[%z\1-\127\194-\244][\128-\191]*") do
        table.insert(tb, utfChar)
    end
    return tb
end

function GameResult:GetUTFLenWithCount(s, count)
    local sTable = self:StringToTable(s)

    local len = 0
    local charLen = 0
    local isLimited = (count >= 0)

    for i = 1, #sTable do
        local utfCharLen = string.len(sTable[i])
        if utfCharLen > 1 then -- 长度大于1的就认为是中文
            charLen = 2
        else
            charLen = 1
        end
        len = len + utfCharLen
        if isLimited then
            count = count - charLen
            if count <= 0 then
                break
            end
        end
    end
    return len
end

function GameResult:GetUTFLen(s)
    local sTable = self:StringToTable(s)

    local len = 0
    local charLen = 0

    for i = 1, #sTable do
        local utfCharLen = string.len(sTable[i])
        if utfCharLen > 1 then -- 长度大于1的就认为是中文
            charLen = 2
        else
            charLen = 1
        end
        len = len + charLen
    end
    return len
end

function GameResult:buildResultData(data, comm_game_settle_param, school_pk_settle_param, schoolData, rankInfo,
    add_word_list)
    log("开始构建结果数据")
    local result = {}
    result["contentType"] = 2
    if data ~= nil then
        for i, group in ipairs(data) do
            for i, v in ipairs(group) do
                if tostring(v.user_id) == tostring(App.Info.userId) then
                    result["rankList"] = group
                    local score = v.point
                    local isWin = false
                    if v.team == 1 then
                        isWin = true
                        result["titleType"] = 2
                    elseif v.team == 2 then
                        isWin = false
                        result["titleType"] = 3
                    elseif v.team == 3 then
                        isWin = true
                        result["titleType"] = 5
                    else
                        result["titleType"] = 1
                    end
                    result["rank"] = i
                    result["award"] = score
                    if self.gameMode == 2 then
                        result["closeBtnType"] = 1
                        result["autoCloseCallBack"] = function()
                            log("显示排位信息")
                            self:showRankInfo(i, isWin)
                        end
                    else
                        result["closeBtnType"] = 2
                        result["clickCloseCallBack"] = function()
                            App:GameReturn()
                        end
                    end
                    break
                end
            end
        end
    elseif comm_game_settle_param ~= nil then
        for i, v in ipairs(comm_game_settle_param) do
            if tostring(v.user_id) == tostring(App.Info.userId) then
                local score = v.point
                local isWin = false
                if v.team == 1 then
                    isWin = true
                    result["titleType"] = 2
                elseif v.team == 2 then
                    isWin = false
                    result["titleType"] = 3
                elseif v.team == 3 then
                    isWin = true
                    result["titleType"] = 5
                else
                    result["titleType"] = 1
                end
                result["rank"] = v.rank
                result["award"] = score
                if self.gameMode == 2 then
                    result["closeBtnType"] = 1
                    result["autoCloseCallBack"] = function()
                        log("显示排位信息")
                        self:showRankInfo(v.rank, isWin)
                    end
                else
                    result["closeBtnType"] = 2
                    result["clickCloseCallBack"] = function()
                        App:GameReturn()
                    end
                end
                break
            end
        end
    elseif school_pk_settle_param ~= nil then
        local selfTeamScore = 0
        local otherTeamScore = 0
        for _, v in ipairs(school_pk_settle_param) do
            if v.user_list then
                local isSelfIn = false
                for _, userid in ipairs(v.user_list) do
                    if tostring(userid) == tostring(App.Info.userId) then
                        isSelfIn = true
                    end
                end
                if isSelfIn then
                    selfTeamScore = v.score
                else
                    otherTeamScore = v.score
                end
            end
        end

        if selfTeamScore > otherTeamScore then
            result["titleType"] = 2
        elseif selfTeamScore < otherTeamScore then
            result["titleType"] = 3
        elseif selfTeamScore == otherTeamScore then
            result["titleType"] = 5
        else
            result["titleType"] = 1
        end
        result["award"] = selfTeamScore
        if self.gameMode == 2 then
        else
            result["closeBtnType"] = 2
            result["clickCloseCallBack"] = function()
                App:GameReturn()
            end
        end
    else
        g_LogError("团队结果页透传数据为空")
    end

    -- 解析校园数据
    if schoolData then
        result["is_school_settle"] = schoolData.is_school_settle
        if schoolData.list and type(schoolData.list) == "table" then
            log("学校数据1" .. table.dump(schoolData.list))
        elseif schoolData.list and type(schoolData.list) == "string" then
            schoolData.list = self.jsonService:decode(schoolData.list)
        else
            schoolData.list = {}
        end
        for i, v in ipairs(schoolData.list) do
            if tostring(v.user_id) == tostring(App.Info.userId) then
                result["join_school_flag"] = v.join_flag
                result["add_value"] = v.add_value
                result["has_upgrade"] = v.has_upgrade
                result["after_level"] = v.after_level
                self.grow_route_info = v.grow_route_info
                self.season_id = schoolData.season_id
                break
            end
        end
        if schoolData.is_battle_time and result["titleType"] == 2 then
            result["school_extra_score"] = 1
        end

        result["is_double_game"] = schoolData.is_double_game
        log("学校数据2" .. table.dump(schoolData.list))
    end
    log("构建结果数据" .. table.dump(result))
    -- 解析段位数据
    if self.gameMode == 2 then
        for i, v in ipairs(rankInfo) do
            if tostring(v.user_id) == tostring(App.Info.userId) then
                self.myLevelInfo = v
                break
            end
        end
    end

    -- 解析集字数据
    if add_word_list then
        for i, v in ipairs(add_word_list) do
            if tostring(v.user_id) == tostring(App.Info.userId) then
                result["jiziNum"] = v.word_num
                break
            end
        end
    end

    return result
end

function GameResult:showRankInfo(rank, isWin)
    log("显示排位" .. table.dump(self.myLevelInfo))

    self.BusEventService:Fire("SHOW_GAME_RANK_RESULT_PANEL", {
        type = 2,
        rank = rank,
        isTeamWin = isWin,
        change_score = self.myLevelInfo.change_score,
        ranking_before = self.myLevelInfo.ranking_before,
        ranking_after = self.myLevelInfo.ranking_after,
        is_protect = self.myLevelInfo.is_protect,
        protect_score = self.myLevelInfo.protect_score,
        btnCallBack = function(returnBtn, againBtn)
            self:GameMatchingLogic(returnBtn, againBtn)

        end
    })
end
function GameResult:ReceivePeerMessage(key, value, isResume)
    GameMatching.ReceivePeerMessage(key, value, isResume)
end
-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function GameResult:ReceiveMessage(key, value, isResume)
    GameMatching.ReceiveMessage(key, value, isResume)
    if key == fsync_activateRoom then
        local lastMsg = value[#value]
        if lastMsg and not self.activeQuestionType then
            log("activateRoom " .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if msg.question_type then
                    self.activeQuestionType = tonumber(msg.question_type)
                else
                    self.activeQuestionType = 0
                end

                if msg.game_type then
                    self.gameMode = tonumber(msg.game_type)
                    log("游戏模式" .. self.gameMode)
                end

                self.game_id = msg.game_id
                self.set_id = msg.set_id
                self.plan_id = msg.plan_id
                self:GameMatchingReq()
            end
        end
    elseif key == process_game_result then
        local lastMsg = value[#value]
        if lastMsg then
            log("团队游戏，展示结果页消息" .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if self.teamResultsHasShow == true then
                else
                    self.teamResultsHasShow = true
                    if msg.isSuccessed then
                        -- 解析团队游戏结果并进行展示
                        local result = self:buildResultData(msg.groupResult, msg.comm_game_settle_param,
                            msg.school_pk_settle_param, msg.schoolInfo, msg.rankInfo, msg.add_word_list)
                        if msg.contentType then
                            result["contentType"] = msg.contentType
                        end
                        -- 延迟两秒显示结果页
                        if msg.delay then
                            if msg.delay >= 0 then
                                self.commonService:DispatchAfter(msg.delay, function()
                                    log("团队游戏，展示结果页消息成功")
                                    self.BusEventService:Fire("SHOW_MINI_GAME_RESULT_PANEL_NEW", result)
                                end)
                            else
                                self.teamReslutData = result
                            end
                        else
                            log("团队游戏，展示结果页消息成功")
                            self.BusEventService:Fire("SHOW_MINI_GAME_RESULT_PANEL_NEW", result)
                        end
                    else
                        log("团队游戏，展示结果页消息失败")
                    end
                end
            end
        end
    elseif key == game_remote_params then
        local lastMsg = value[#value]
        if lastMsg then
            log("game_remote_params " .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if msg.game_id then
                    self.game_id = msg.game_id
                end
                if msg.set_id then
                    self.set_id = msg.set_id
                end
                if msg.plan_id then
                    self.plan_id = msg.plan_id
                end
            end
        end
    end
end

function GameResult:reportData(eventId, label, value, action)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(eventId, "67881", "Special-Interaction", label,
            action, value)
    else
        g_Log("埋点数据", eventId, label)
    end
end

-- 数字转汉字
function GameResult:num2Chinese(num)
    local rankStr = ""
    if num then
        if num == 1 then
            rankStr = "一"
        elseif num == 2 then
            rankStr = "二"
        elseif num == 3 then
            rankStr = "三"
        elseif num == 4 then
            rankStr = "四"
        elseif num == 5 then
            rankStr = "五"
        elseif num == 6 then
            rankStr = "六"
        elseif num == 7 then
            rankStr = "七"
        elseif num == 8 then
            rankStr = "八"
        elseif num == 9 then
            rankStr = "九"
        elseif num == 10 then
            rankStr = "十"
        end

    end
    return rankStr
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function GameResult:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function GameResult:SelfAvatarCreated(avatar)
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function GameResult:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function GameResult:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function GameResult:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function GameResult:LogicMapStartRecover()
    GameResult.super:LogicMapStartRecover()
    -- TODO
end
-- 结束恢复方法 (断线重连的时候用)
function GameResult:LogicMapEndRecover()
    GameResult.super:LogicMapEndRecover(self)
end
-- 所有的组件恢复完成
function GameResult:LogicMapAllComponentRecoverComplete()

end

-- 收到Trigger事件
function GameResult:OnReceiveTriggerEvent(interfaceId)
end
-- 收到GetData事件
function GameResult:OnReceiveGetDataEvent(interfaceId)
    return nil
end
-- 请求判断是否需要显示再来一局
function GameResult:GameMatchingReq()
    if App.IsStudioClient then
        self.needShowMatching = true
        -- self.gameMode = 2
    end
    -- if self.game_id == "66" then
    --     self.needShowMatching = true
    -- end

    -- TODO 请求判断是否需要通用再来一局的排队
    local url = "/v3/game/get-game-by-id"

    local params = {
        game_id = tonumber(self.game_id)
    }
    local success = function(resp)
        if resp and resp ~= "" then

            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
                -- once_again
                if msg.data.once_again == 1 then
                    -- 这里同时要判断防沉迷

                    self.needShowMatching = true
                    CourseEnv.ServicesManager:GetObserverService():Fire("EVENT_GET_ANTI_ADDICTION_CONTINUOUS_STATE", {
                        callBack = function(isLimit)
                            if isLimit then
                                g_LogError("防沉迷限制再来一局")
                                self.needShowMatching = false
                            end
                        end
                    })
                    local appVersion = App.Info.appVersionNumber
                    if appVersion then
                        if tonumber(appVersion) < 10800 then
                            self.needShowMatching = false
                        end
                    end
                end
            end
            if msg and msg.code == 0 then
                return
            end
        end
    end

    self:HttpRequest(url, params, success, function(res)
        -- fail
        g_LogError("get-game_by_id fail")
        g_LogError(table.dump(res))
    end)
end

function GameResult:GameMatchingLogic(backBtn, againBtn)

    if self.isShowingMatching then
        g_LogError("已经结算，不再显示再来一局")
        return
    end
    self.isShowingMatching = true

    backBtn.gameObject:SetActive(true)
    if self.needShowMatching then
        againBtn.gameObject:SetActive(true)
    else
        againBtn.gameObject:SetActive(false)
    end

    -- 通用逻辑
    -- 退出按钮（90s）倒计时

    local tuichu_text = backBtn.gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
    tuichu_text.text = "退出"
    tuichu_text.fontStyle = CS.UnityEngine.FontStyle.Bold;
    self:AsyncHasPower(function(hasPower)
        if hasPower == false then
            againBtn.gameObject:SetActive(false)
        else
        end
    end)

    local returnCallback = function()
        if App.IsStudioClient then
            self.rootUI.gameObject:SetActive(false)
        end

        if self.needShowMatching == true then
            if GameMatching.cancel then
                GameMatching.cancel(function()
                    log("点击按钮回调")
                    if self.clickCloseCallBack then
                        self.clickCloseCallBack()
                    end
                    App:GameReturn()

                end)
            else
                App:GameReturn()
            end

        else
            App:GameReturn()
        end
    end

    -- 重来退出按钮
    self.commonService:AddEventListener(backBtn.gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Button)),
        "onClick", function()

            returnCallback()

        end)

    if self.needShowMatching ~= true then
        return
    end
    if self.countdownCor then
        self.commonService:StopCoroutineSafely(self.countdownCor)
    end
    self.countdownCor = self.commonService:StartCoroutine(function()
        local countDown = 30
        while countDown > 0 do
            -- TODO 改文本 （退出（90s））
            tuichu_text.text = "退出(" .. countDown .. "s)"
            self.commonService:YieldSeconds(1)
            countDown = countDown - 1

            if self.powerEnough == false then
                tuichu_text.text = "退出"
                return
            end
        end
        -- TODO执行退出返回主场景
        returnCallback()
    end)

    -- 再来一局
    -- againBtn.gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Button))["onClick"]:RemoveAllListeners()

    self.commonService:AddEventListener(againBtn.gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Button)),
        "onClick", function()
            self.againButton = againBtn.gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Button))
            self.againButton.interactable = false
            self:againGame()
            self.hasRequest = false

            -- 清空接口请求获取数据
            self.change_score = nil
            self.ranking_before = nil
            self.ranking_after = nil
            self.is_protect = nil
            self.protect_score = nil
            self.is_school_settle = nil
            self.join_school_flag = nil
            self.add_value = nil
            self.has_upgrade = nil
            self.after_level = nil
            self.is_double_game = nil
            self.add_cheese_val = nil
            self.grow_route_info = nil
            self.season_id = nil
            -- 是否获得集字
            self.jiziNum = nil
            -- 清空统计开口相关数据
            self.petExpFromAnswer = 0
            self.xueshiFromAnswer = 0
        end)

    self.clickAgainCallBack = function()
        self:GameMatchingLoad(againBtn)

    end
end
function GameResult:GameMatchingLoad(againBtn)
    self._againBtn = againBtn
    self:reportData("resule_play_again", "再来一次", {
        param_one = self.game_id
    })
    GameMatching.load(function(go)
        -- play anim
        self.isMatching = true
        go.transform:SetParent(againBtn.transform.parent)
        go.transform.localPosition = againBtn.transform.localPosition
        go.gameObject:SetActive(false)
        go.transform.localScale = Vector3(0.5, 0.5)
        local cg = go:GetComponent(typeof(CS.UnityEngine.CanvasGroup))
        cg.alpha = 0
        local seq = DOTween.Sequence()
        -- seq:Append(self.zailaiyiju.transform:DOScale(0.5, 1))
        -- seq:Join(self.zailaiyiju:DORotate(Vector3(0, 0, 720), distance / 10, CS.DG.Tweening.RotateMode.FastBeyond360))
        seq:AppendCallback(function()
            againBtn.gameObject:SetActive(false)
            go.gameObject:SetActive(true)
        end)
        seq:Append(go.transform:DOScale(1, 0.3))
        seq:Join(DOTween.To(function()
            return cg.alpha
        end, function(x)
            cg.alpha = x
        end, 1, 0.3))

    end, againBtn, function()
        self.isMatching = false
    end)
end

-- 添加埋点
function GameResult:reportLog(eventId, action)
    local param = {}
    param["modName"] = App.modName
    param["liveId"] = App.Info.liveId
    param["userId"] = App.Info.userId
    param["eventId"] = eventId
    param["eventtype"] = eventId
    param["action"] = action
    if self.game_id then
        param["param_one"] = self.game_id
    end
    if self.set_id then
        param["param_two"] = self.set_id
    end
    if self.plan_id then
        param["param_three"] = self.plan_id
    end
    APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function GameResult:Exit()
    GameResult.super.Exit(self)
end
-- http请求地址封装
function GameResult:HttpRequest(request, params, success, fail)
    local url = "https://app.chuangjing.com/abc-api" .. request
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041" .. request
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

return GameResult

