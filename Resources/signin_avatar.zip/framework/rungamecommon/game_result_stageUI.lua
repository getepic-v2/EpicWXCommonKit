---  Author: 【孙鹏飞】
---  AuthorID: 【V0047328】
---  CreateTime: 【2025-8-14 14:31:39】
--- 【FSync】
--- 【MVP展示UI】
---
---@diagnostic disable: undefined-global
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class GameResultStage : WorldBaseElement
local GameResultStageUI = class("game_result_stage_ui_comlogic", WBElement)

local uAddress = "1081881761187354/assets/Prefabs/MVPCanvas.prefab" --MVP展示UI地址
local SHOW_MVP_STAGE_UI = "SHOW_MVP_STAGE_UI" --展示mvp舞台UI事件
local HIDE_MVP_STAGE_UI = "HIDE_MVP_STAGE_UI" --隐藏mvp舞台UI事件
local SHOW_RESULT_COMMON_UI = "SHOW_RESULT_COMMON_UI" --展示结算UI事件
local COUNTDOWN_TIME = 5 --下一步按钮倒计时时间
local ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK = "ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK"   --再来一局按钮点击事件

---@param worldElement CS.Tal.framesync.WorldElement
function GameResultStageUI:initialize(worldElement)
    GameResultStageUI.super.initialize(self, worldElement)
    self:RegisterDownloadUaddress(uAddress)
end

function GameResultStageUI:setVisElement(VisElement)
    if VisElement ~= nil then
        self.VisElement = VisElement
    end
    self:InitVariable()
    self:InitService()
    self:InitConfig()
    self:InitListener()
    self:InitView()
end

--初始化变量
function GameResultStageUI:InitVariable()
    self:resetVariable()
end

-- 重置变量 再来一局时使用
function GameResultStageUI:resetVariable()
    -- 清空接口请求获取数据
    self.change_score = nil
    self.ranking_before = nil
    self.ranking_after = nil
    self.is_protect = nil
    self.protect_score = nil
    self.is_school_settle = nil
    self.join_school_flag = nil
    self.add_value = nil
    self.has_upgrade = nil
    self.after_level = nil
    self.is_double_game = nil
    self.add_cheese_val = nil
    self.grow_route_info = nil
    self.season_id = nil
    self.jiziNum = nil
end

function GameResultStageUI:InitService()
    self.gate = CourseEnv.ServicesManager.Gate
    self.BusEventService = CourseEnv.ServicesManager:GetObserverService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.commonService = App:GetService("CommonService")
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    self.UIService = App:GetService("UIService")
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.decorateService = CourseEnv.ServicesManager:GetDecorateService()
    self.lightService = CourseEnv.ServicesManager:GetLightService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.permissionService = CourseEnv.ServicesManager:GetPermissionService()
end

function GameResultStageUI:InitConfig()

end

function GameResultStageUI:InitListener()
    --展示mvpUI
    self.observerService:Watch(SHOW_MVP_STAGE_UI, function(key, args)
        local data = args[0] -- 获取事件参数
        if data == nil then
            self:Print("展示mvp舞台失败 data为nil")
            return
        end
        self.data = data
        self.isShowMVPStage = data.isShowMVPStage --是否展示mvp舞台 默认展示（如游戏中途展示的时候没有MVP) 同时ui不展示MVP
        self.gameType = data.gameType --游戏类型 GAME_RESULT_GAME_TYPE
        self.titleData = data.titleData --标题数据
        self.awardData = data.awardData --奖励数据
        self.matchData = data.matchData --匹配数据
        self.gameData = data.gameData --游戏自定义数据
        self.autoCloseCallBack = data.autoCloseCallBack --自动关闭回调函数
        self.clickCloseCallBack = data.clickCloseCallBack --点击关闭回调函数
        self.clickAgainCallBack = data.clickAgainCallBack --点击再来一局回调函数
        self.playerStats = data.playerStats --所有玩家统计数据
        self.mvpPlayerUuid = data.mvpPlayerUuid --MVP玩家UUID
        self.mvpPlayerScoreStats = data.mvpPlayerScoreStats --MVP玩家评分数据
        -- SVP数据 
        self.svpPlayerUuid = data.svpPlayerUuid --SVP玩家UUID

        --请求数据
        self.change_score = data.change_score
        self.ranking_before = data.ranking_before
        self.ranking_after = data.ranking_after
        self.is_protect = data.is_protect
        self.protect_score = data.protect_score
        self.is_school_settle = data.is_school_settle
        self.join_school_flag = data.join_school_flag
        self.add_value = data.add_value
        self.has_upgrade = data.has_upgrade
        self.after_level = data.after_level
        self.is_double_game = data.is_double_game
        self.add_cheese_val = data.add_cheese_val
        self.grow_route_info = data.grow_route_info
        self.season_id = data.season_id
        self.jiziNum = data.jiziNum

        self.playerAvatarSprites = data.playerAvatarSprites --玩家头像
        self:ShowMvpStageUI(data.callBack)
    end)
    --隐藏结算
    self.BusEventService:Watch("HIDE_MINI_GAME_RESULT_PANEL", function(key, args)
        self:HideMvpStageUI()
    end)
    --再来一局按钮点击
    self.observerService:Watch(ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK, function(key, args)
        self:resetVariable()
    end)
end

function GameResultStageUI:InitView()
    --debug
    -- self.debugService:AddDebugActionWithTitleAndCategory("展示mvp舞台UI", "test"):connect(function()
    --     self:ShowMvpStageUI(nil,App.Uuid,{"100","3","100"})
    -- end)
end


--region mvp舞台UI初始化-----------------------------------------------------------------------------------------------------------------------------

---展示mvp舞台UI
---@param callBack function 回调函数
function GameResultStageUI:ShowMvpStageUI(callBack)
    self:Print("展示mvp舞台UI",self.gameType,table.dump(self.gameData),table.dump(self.mvpPlayerScoreStats),self.mvpPlayerUuid)
    self:LoadStage(function()
        if callBack and type(callBack) == "function" then
            callBack()
        end
    end)
end

---隐藏mvp舞台
function GameResultStageUI:HideMvpStageUI()
    self.stageUI.gameObject:SetActive(false)
end

---加载mvp舞台UI
function GameResultStageUI:LoadStage(callBack)
    if self.stageUI then
        self:ShowStageUI()
        if callBack and type(callBack) == "function" then
            callBack()
        end
        return
    end
    self:LoadRemoteUaddress(uAddress, function(success, prefab)
        if success and prefab then
            if self.prefab then
                ResourceManager:ReleaseObject(self.prefab)
                self.prefab = nil
            end
            self.prefab = prefab
            self.stageUI = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
            self:InitStageUI()
            self:ShowStageUI()
            if callBack and type(callBack) == "function" then
                callBack()
            end
        end
    end)
end

---初始化舞台UI
function GameResultStageUI:InitStageUI()
    self.stageUI.gameObject:SetActive(false)
    -- 设置canvas的sortingOrder 挡住玩家头顶UI
    self.stageUI.transform:GetComponent(typeof(CS.UnityEngine.Canvas)).sortingOrder = 2201 --(App.IsStudioClient or App:IsDebug())  and 201 or 2201
    self.schoolTxt = self.stageUI:Find("left/schoolTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.schoolbg = self.stageUI:Find("left/schoolbg")
    self.nameTxt = self.stageUI:Find("left/nameTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.Scores = self.stageUI:Find("left/bgdown/Scores")
    self.ScoresItem = self.stageUI:Find("left/bgdown/ScoresItem")
   --评分数据
    self.CountList = {}
    self.mvpKeyData = self:createScoreItem()
    self.currentScoresData = GAME_RESULT_STAGE_DATA_CONFIG[App.modPlatform]
    for index, key in ipairs(self.currentScoresData) do
        self.CountList[key] = self:createScoreItem()
        self.CountList[key].TitleTxt.text = GAME_RESULT_DATA_DISPLAY[key].display
        self.CountList[key].UnitTxt.text = GAME_RESULT_DATA_DISPLAY[key].unit
    end
    --下一步按钮
    self.nextTxt = self.stageUI:Find("right/nextTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.nextTxt.text = "下一步  (" .. COUNTDOWN_TIME .. "s)"
    self.nextBtn = self.stageUI:Find("right/nextBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.nextBtn, "onClick", function()
        self:OnNextBtnClick()
    end)
    --音效
    -- self.jiesuanbgm = self.stageUI:Find("Config/jiesuanbgm").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
end

function GameResultStageUI:createScoreItem()
    local item = CS.UnityEngine.GameObject.Instantiate(self.ScoresItem, self.Scores)
    item.transform:SetParent(self.Scores.transform)
    item.transform.localScale = CS.UnityEngine.Vector3.one
    item.transform.localPosition = CS.UnityEngine.Vector3.zero
    local TitleTxt = item.transform:Find("Title"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    local CountTxt = item.transform:Find("Count"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    local UnitTxt = item.transform:Find("Unit"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    local bg = item.transform:Find("bg")
    bg.gameObject:SetActive(false)
 
    CountTxt.resizeTextForBestFit = true --开启最佳适应 防止超框
    TitleTxt.text = "" 
    UnitTxt.text = ""
    CountTxt.text = ""
    item.gameObject:SetActive(true)
    return {
        item = item,
        TitleTxt = TitleTxt, --文字内容
        CountTxt = CountTxt, --分数
        UnitTxt = UnitTxt, --单位
        bg = bg --背景
    }
end

--endregion

--region 下一步按钮-----------------------------------------------------------------------------------------------------------------------------

---下一步按钮点击
function GameResultStageUI:OnNextBtnClick()
    self:StopCountDownTime()
    self:HideMvpStageUI()
    self:Fire(HIDE_MVP_STAGE_UI)
    self:Fire(SHOW_RESULT_COMMON_UI,{
        callBack = function()
       
        end,
        isShowMVPStage = self.isShowMVPStage, --是否展示mvp舞台 默认展示（如游戏中途展示的时候没有MVP) 同时ui不展示MVP
        gameType = self.gameType,--游戏类型 GAME_RESULT_GAME_TYPE
        titleData = self.titleData, --标题数据
        awardData = self.awardData, --奖励数据
        matchData = self.matchData, --匹配数据
        gameData = self.gameData, --游戏自定义数据
        autoCloseCallBack = self.autoCloseCallBack, --自动关闭回调函数
        clickCloseCallBack = self.clickCloseCallBack, --点击关闭回调函数
        clickAgainCallBack = self.clickAgainCallBack, --点击再来一局回调函数
        playerStats = self.playerStats, --所有玩家统计数据
        mvpPlayerUuid = self.mvpPlayerUuid, --MVP玩家UUID
        mvpPlayerScoreStats = self.mvpPlayerScoreStats, --MVP玩家评分数据
        svpPlayerUuid = self.svpPlayerUuid, --SVP玩家UUID
        --请求数据
        change_score = self.change_score,
        ranking_before = self.ranking_before,
        ranking_after = self.ranking_after,
        is_protect = self.is_protect,
        protect_score = self.protect_score,
        is_school_settle = self.is_school_settle,
        join_school_flag = self.join_school_flag,
        add_value = self.add_value,
        has_upgrade = self.has_upgrade,
        after_level = self.after_level,
        is_double_game = self.is_double_game,
        add_cheese_val = self.add_cheese_val,
        grow_route_info = self.grow_route_info,
        season_id = self.season_id,
        jiziNum = self.jiziNum,
        playerAvatarSprites = self.playerAvatarSprites, --玩家头像
    })
end

---展示舞台UI
function GameResultStageUI:ShowStageUI()
    self:StartCountDownTime()
    self:SetMVPInfo()
    self.stageUI.gameObject:SetActive(true)
end

---开始倒计时
function GameResultStageUI:StartCountDownTime()
    self.countDownTime = COUNTDOWN_TIME
    self.countDownCoroutine = self.commonService:StartCoroutine(function()
        while self.countDownTime > 0 do
            self.commonService:YieldSeconds(1)
            self.countDownTime = self.countDownTime - 1
            if self.nextTxt then
                self.nextTxt.text = "下一步  (" .. self.countDownTime .. "s)"
            end
        end
        -- 倒计时结束，自动执行下一步
        if self.countDownTime <= 0 then
            self:Print("倒计时结束，自动执行下一步")
            self:OnNextBtnClick()
        end
    end)
end

---停止倒计时
function GameResultStageUI:StopCountDownTime()
    if self.countDownCoroutine then
        self:StopCoroutineSafely(self.countDownCoroutine)
        self.countDownCoroutine = nil
    end
end

--endregion


--region MVP信息展示-----------------------------------------------------------------------------------------------------------------------------

---根据UUID获取玩家信息并设置显示
function GameResultStageUI:SetMVPInfo()
    --玩家数据
    local avatar = self.avatarService:GetAvatarByUUID(self.mvpPlayerUuid)
    if not avatar  then
        self:Print("获取玩家信息失败 App.Uuid= ", self.mvpPlayerUuid)
        return 
    end
    local userName = avatar:GetProperty("AvatarName") or avatar.nickName 
    local schoolName = self.playerStats[self.mvpPlayerUuid][GAME_RESULT_DATA_KEYS.SCHOOL] or ""
    --如果没有学校名称，则获取玩家学校名称 不显示学校名称
    if schoolName == nil or schoolName == "" then
        self.schoolTxt.gameObject:SetActive(false)
        self.schoolbg.gameObject:SetActive(false)
    else
        self.schoolTxt.gameObject:SetActive(true)
        self.schoolbg.gameObject:SetActive(true)
        self:RefreshLimitText(self.schoolTxt, schoolName, 300)
    end
    self.nameTxt.text = userName
    --评分数据
    for index, key in ipairs(self.currentScoresData) do
        local value = self.mvpPlayerScoreStats[key]
        if not value then
            self:Print("评分数据不存在 key= ", key)
            value = GAME_RESULT_DATA_DISPLAY[key].default  -- 给一个默认值
        end
        self.CountList[key].CountTxt.text = GAME_RESULT_DATA_DISPLAY[key].displayformat and GAME_RESULT_DATA_DISPLAY[key].displayformat(value) or tostring(value)
    end
     --MVP关键项目数据
    local mvpKeyData = self:GetGameMVPKeyData()
    self:SetScoreItemDisplay(mvpKeyData,self.mvpKeyData.CountTxt,self.mvpKeyData.TitleTxt,self.mvpKeyData.UnitTxt,self.mvpKeyData.bg,true)
end

---获取游戏关键项目数据
---@return table 游戏关键项目数据
function GameResultStageUI:GetGameMVPKeyData()
    local config = GAME_RESULT_DATA_CONFIG[self.gameType]
    if not config then
        self:Print("获取游戏关键项目数据失败 gameType= ", self.gameType)
        return {}
    end

    local gameKey = nil

    local game_mvp_and_svp_rule = config.game_mvp_and_svp_rule
    if not game_mvp_and_svp_rule then
        self:Print("获取游戏关键项目数据失败 gameMVPAndSVPRule= 请配置GAME_RESULT_DATA_CONFIG ", game_mvp_and_svp_rule)
        return {}
    end

    local get_type = game_mvp_and_svp_rule.get_type
    --根据get_type 获取游戏关键项目数据
    if get_type == 1 then
        gameKey = game_mvp_and_svp_rule.mvpKey
    elseif get_type == 2 then
        local gameKeys = game_mvp_and_svp_rule.mvpKey
        if not gameKeys then
            self:Print("获取游戏关键项目数据失败 gameKeys= 请配置GAME_RESULT_DATA_CONFIG ", gameKeys)
            return {}
        end
        local teamTypeKey = config.teamTypeKey
        if not teamTypeKey then
            self:Print("获取游戏关键项目数据失败 teamTypeKey= 请配置GAME_RESULT_DATA_CONFIG ", teamTypeKey)
            return {}
        end
        --根据teamTypeKey 获取不同类型队伍的MVP数据
        local teamType = self.playerStats[self.mvpPlayerUuid][teamTypeKey]
        if not teamType then
            self:Print("获取游戏关键项目数据失败 teamType= 请配置GAME_RESULT_DATA_CONFIG ", teamType)
            return {}
        end
        gameKey = gameKeys[teamType]
    else
        self:Print("获取游戏关键项目数据失败 get_type= 请配置GAME_RESULT_DATA_CONFIG ", get_type)
        return {}
    end

    if not gameKey then
        self:Print("获取游戏关键项目数据失败 gameKey= 请配置GAME_RESULT_DATA_CONFIG ", gameKey)
        return {}
    end

    local MVPKeyData = {
        gameKeyData = nil,
        gameKey = nil,
        gameKeyDisplay = nil,
        gameKeyUnit = nil,
        gameKeyDisplayFormat = nil,
    }
    MVPKeyData.gameKey = gameKey
    self:Print("获取游戏关键项目数据 gameKey= ", gameKey)
 
    --根据gameKey 获得游戏关键项目数据
    local gameKeyData = self.playerStats[self.mvpPlayerUuid][gameKey]
    if not gameKeyData then     
        self:Print("获取游戏关键项目数据失败 gameKeyData= 请配置GAME_RESULT_DATA_DISPLAY ", gameKeyData)
        gameKeyData = GAME_RESULT_DATA_DISPLAY[gameKey].default  -- 给一个默认值
        if not gameKeyData then
            self:Print("获取游戏关键项目数据失败 gameKeyData= 请配置GAME_RESULT_DATA_DISPLAY 默认值为0 ", gameKeyData)
            gameKeyData = 0
        end
    end
    MVPKeyData.gameKeyData = gameKeyData

    local gameKeyDisplay = GAME_RESULT_DATA_DISPLAY[gameKey].display
    if not gameKeyDisplay then
        self:Print("获取游戏关键项目数据失败 gameKeyDisplay= 请配置GAME_RESULT_DATA_DISPLAY ", gameKeyDisplay)
    end
    MVPKeyData.gameKeyDisplay = gameKeyDisplay

    local gameKeyUnit = GAME_RESULT_DATA_DISPLAY[gameKey].unit
    if not gameKeyUnit then
        self:Print("获取游戏关键项目数据失败 gameKeyUnit= 请配置GAME_RESULT_DATA_DISPLAY ", gameKeyUnit)
    end

    MVPKeyData.gameKeyUnit = gameKeyUnit
    
    
    MVPKeyData.gameKeyDisplayFormat = GAME_RESULT_DATA_DISPLAY[gameKey].displayformat

    self:Print("获取游戏关键项目数据 MVPKeyData= ", table.dump(MVPKeyData))
    return  MVPKeyData
end


---设置评分数据
---@param mvpKeyData table 评分数据
---@param CountTxt CS.UnityEngine.UI.Text 分数文本
---@param TitleTxt CS.UnityEngine.UI.Text 标题文本
---@param UnitTxt CS.UnityEngine.UI.Text 单位文本
---@param bg CS.UnityEngine.GameObject 背景
---@param isShowBg boolean 是否显示背景
function GameResultStageUI:SetScoreItemDisplay(mvpKeyData,CountTxt,TitleTxt,UnitTxt,bg,isShowBg)
    --显示单位
    if  mvpKeyData.gameKeyUnit == nil  then
        UnitTxt.gameObject:SetActive(false)
        self:SetNoUnitLayout(CountTxt,TitleTxt)
    --特殊处理这个单位时间格式
    elseif mvpKeyData.gameKeyUnit == "" then
        UnitTxt.gameObject:SetActive(false)
    else
        UnitTxt.gameObject:SetActive(true)
 
        UnitTxt.text = mvpKeyData.gameKeyUnit
    end

    --显示分数
    CountTxt.text = mvpKeyData.gameKeyDisplayFormat and mvpKeyData.gameKeyDisplayFormat(mvpKeyData.gameKeyData) or tostring(mvpKeyData.gameKeyData)
    
    ---显示标题
    TitleTxt.text = mvpKeyData.gameKeyDisplay

    ---显示背景
    bg.gameObject:SetActive(isShowBg)
end

---设置没有单位的布局方式
---@param CountTxt CS.UnityEngine.UI.Text 分数文本
---@param TitleTxt CS.UnityEngine.UI.Text 标题文本
function GameResultStageUI:SetNoUnitLayout(CountTxt,TitleTxt)
    if not CountTxt or not TitleTxt then
        self:Print("设置没有单位的布局方式失败 CountTxt或TitleTxt为空")
        return
    end

    TitleTxt.rectTransform.anchorMin = Vector2(0.5,0.5)
    TitleTxt.rectTransform.anchorMax = Vector2(0.5,0.5)
    TitleTxt.rectTransform.anchoredPosition = Vector2(-100.4296,-0.3473892)
    TitleTxt.rectTransform.sizeDelta = Vector2(146.9448,81.3061)

    CountTxt.rectTransform.anchoredPosition = Vector2(69.427,-1.3973)
    CountTxt.rectTransform.sizeDelta = Vector2(192.77,78.795)

    -- TitleTxt.rectTransform.anchorMin = CS.UnityEngine.Vector2.zero
    -- TitleTxt.rectTransform.anchorMax = CS.UnityEngine.Vector2.zero
    -- TitleTxt.rectTransform.pivot = CS.UnityEngine.Vector2.zero
    -- TitleTxt.rectTransform.anchoredPosition = CS.UnityEngine.Vector2.zero
    -- TitleTxt.rectTransform.anchorMin = CS.UnityEngine.Vector2.zero
    -- TitleTxt.rectTransform.anchorMax = CS.UnityEngine.Vector2.zero
end

---文本显示优化 超过限制之后显示省略号
---@param textComponent CS.UnityEngine.UI.Text 文本组件
---@param str string 文本
---@param maxWidth number 最大宽度
function GameResultStageUI:RefreshLimitText(textComponent, str, maxWidth)
    if not textComponent or not str  or not maxWidth then
        self:Print("文本组件或文本为空")
        return
    end
    textComponent.text = str
    local preferredWidth = textComponent.preferredWidth
    if preferredWidth > maxWidth then
        local finalStr = str
        local count = utf8.len(str)
        for i = 2, count, 1 do
            -- 使用 utf8.offset 获取正确的字节位置
            local endPos = utf8.offset(str, i)
            local testStr = str:sub(1, endPos - 1) .. "..."
            textComponent.text = testStr
            if textComponent.preferredWidth > maxWidth then
                -- 同样使用 utf8.offset 获取正确的字节位置
                local prevPos = utf8.offset(str, i - 1)
                finalStr = str:sub(1, prevPos - 1) .. "..."
                break
            end
        end
        textComponent.text = finalStr
    end
end

--endregion

---打印日志
function GameResultStageUI:Print(...)
    g_Log("【MVP展示UI】", ...)
end

return GameResultStageUI
