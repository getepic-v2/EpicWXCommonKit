---  Author: 【孙鹏飞】
---  AuthorID: 【V0047328】
---  CreateTime: 【2025-8-14 14:31:39】
--- 【FSync】
--- 【结算新版】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class GameResultNew : WorldBaseElement
local GameResultNew = class("game_result_new_comlogic", WBElement)

local GAME_RESULT_SET_MAIN_PANEL = "GAME_RESULT_SET_MAIN_PANEL" --游戏结算设置主面板显示/隐藏事件
local GET_SCHOOL_NAME_BY_USER_IDS = "GET_SCHOOL_NAME_BY_USER_IDS" --获取玩家学校名称事件

---@param worldElement CS.Tal.framesync.WorldElement
function GameResultNew:initialize(worldElement)
    GameResultNew.super.initialize(self, worldElement)
end

function GameResultNew:setVisElement(VisElement)
    if VisElement ~= nil then
        self.VisElement = VisElement
    end
    self:InitService()
    self:InitConfig()
    self:InitListener()
    self:InitView()
end

function GameResultNew:InitService()
    self.gate = CourseEnv.ServicesManager.Gate
    self.BusEventService = CourseEnv.ServicesManager:GetObserverService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.commonService = App:GetService("CommonService")
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    self.UIService = App:GetService("UIService")
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.decorateService = CourseEnv.ServicesManager:GetDecorateService()
    self.lightService = CourseEnv.ServicesManager:GetLightService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.permissionService = CourseEnv.ServicesManager:GetPermissionService()
end

function GameResultNew:InitConfig()
   
end

function GameResultNew:InitListener()
    -- 监听获取玩家学校名称
    self.observerService:Watch(GET_SCHOOL_NAME_BY_USER_IDS, function(key, args)
        local data = args[0] -- 获取事件参数
        local UnionIds = data.UnionIds
        local callback = data.callback

        if App.IsStudioClient then
            UnionIds = {1090052439}
        end
        if callback then
            self:TryGetSchoolNameByUserIds(UnionIds,callback)
        end
    end)

    -- 监听游戏结算设置主面板显示/隐藏事件
    self.observerService:Watch(GAME_RESULT_SET_MAIN_PANEL, function(key, args)
        local data = args[0]
        if data and data.isShow ~= nil then
            self:SetMainPanel(data.isShow)
            self:Print("设置主面板显示状态:", data.isShow)
        else
            self:Print("GAME_RESULT_SET_MAIN_PANEL事件参数错误")
        end
    end)

    --隐藏结算
    self.BusEventService:Watch("HIDE_MINI_GAME_RESULT_PANEL", function(key, args)
        self:SetMainPanel(false)
    end)
end

function GameResultNew:InitView()
    -- --debug
    -- self.debugService:AddDebugActionWithTitleAndCategory("克隆其他玩家", "test"):connect(function()
    --     self:ShowMvpStage()
    -- end)
end

---主控界面控制  
---@param isShow boolean 是否显示 打开和关闭面板的标记,FIX重复打开和关闭导致的遥杆消失问题 
function GameResultNew:SetMainPanel(isShow)
    if isShow then
        self.joystickService:setVisibleJoyWithID(self.joyId)
        self.joystickService:setVisibleJumpWithID(self.jumpId)
        self.UIService:SetVisibleHidenVoiceBtnWithID(self.voiceId)
        -- self.UIService:SetVisibleHidenFollowBtnWithID(self.followId)
        --- 左上角退出按钮显示 
        -- APIBridge.RequestAsync('app.business.view.backroom', { show = 1 })
    else
 self.joyId = self.joystickService:setHidenJoyWithID()
        self.jumpId = self.joystickService:setHidenJumpWithID()
        self.voiceId = self.UIService:SetHidenVoiceBtnWithID()
        -- self.followId = self.UIService:SetHidenFollowBtnWithID()
        --- 左上角退出按钮隐藏
        -- APIBridge.RequestAsync('app.business.view.backroom', { show = 0 })
        self:forbidLostLoading()
        self.audioService:StopAllSound() --停止所有音效 值播结果页的
        self.audioService:StopBgm()
        --【数学】关闭答题
        self.BusEventService:Fire("MATH_ANSWER_CLOSE")
    end
end

function GameResultNew:forbidLostLoading()
    -- 结果页显示时禁用断线提示
    CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
    -- 停止题目预播
    self.BusEventService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", {
        op = "Stop"
    })
end

-- -- http请求地址封装
-- ---@param request string 请求地址 /v3/brain-pk/count
-- ---@param params table 请求参数
-- ---@param success function 成功回调
-- ---@param fail function 失败回调
-- function GameResultNew:HttpRequest(request, params, success, fail)
--     local url = "https://app.chuangjing.com/abc-api" .. request
--     if App.IsStudioClient then
--         url = "https://yapi.xesv5.com/mock/2041" .. request
--         self.httpService:PostForm(url, params, {}, success, fail)
--     else
--         APIBridge.RequestAsync('api.httpclient.request', {
--             ["url"] = url,
--             ["headers"] = {
--                 ["Content-Type"] = "application/json"
--             },
--             ["data"] = params
--         }, function(res)
--             if res ~= nil and res.responseString ~= nil and res.isSuccessed then
--                 local resp = res.responseString
--                 success(resp)
--             else
--                 fail(res)
--             end
--         end)
--     end
-- end

---打印日志
function GameResultNew:Print(...)
    g_Log("【结算新版】", ...)
end

return GameResultNew
