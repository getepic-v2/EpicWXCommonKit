local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local ExitGame = class("exitGame", WBElement)

---@param worldElement CS.Tal.framesync.WorldElement
function ExitGame:initialize(worldElement)
    ExitGame.super.initialize(self, worldElement)
end

function ExitGame:setVisElement(parent, VisElement)
    self.VisElement = VisElement
    self.parent = parent
    self:initData()
end

function ExitGame:initData()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.text1 = self.configService:GetConfigValueByConfigKey(self.VisElement, "text1")
    self.text2 = self.configService:GetConfigValueByConfigKey(self.VisElement, "text2")
    self.text3 = self.configService:GetConfigValueByConfigKey(self.VisElement, "text3")
    self.text4 = self.configService:GetConfigValueByConfigKey(self.VisElement, "text4")
    self.gameMode = self.configService:GetConfigValueByConfigKey(self.VisElement, "gameMode")
    g_Log("lsh游戏模式", self.gameMode, type(self.gameMode))
    self.root = self.VisElement.gameObject

    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/exitGame/"
    local micPrefabPath = ResourcePathRoot .. "assets/Prefabs/exitGame.prefab"
    local picturePathRoot = ResourcePathRoot .. "testures/"

    ResourceManager:LoadGameObjectWithExName(micPrefabPath, function(go)
        self.rootUI = GameObject.Instantiate(go)
        self.rootUI.transform:SetParent(self.root.transform)
        self.rootUI.transform.localPosition = Vector3.zero
        self.rootUI.transform.localScale = Vector3.one
        self.rootUI.transform.localRotation = Quaternion.identity
        self.rootUI.transform.name = "exitGame"
        self.exitGame = self.root.transform:Find("exitGame")
        self.exitGame.gameObject:SetActive(true)
        self.exitImage = self.exitGame:Find("Canvas/Image")

        local exitGameRenderer = self.exitGame:Find("Canvas"):GetComponent(typeof(CS.UnityEngine.Canvas))
        exitGameRenderer.sortingOrder = 1102
        self:textInit()
        self:btnAddOnclick(self.gameMode)
        self.isWatchBattle = false
        self.observerService:Watch("isWatchBattle", function(key, args)
            self.isWatchBattle = args[0].isWatchBattle
        end)

        self.callback = nil
        self.content = nil
    end)
end

-- 文案初始化
function ExitGame:textInit()
    local bg = self.exitGame:Find("Canvas/Image/bg")
    self.firstTitle = bg:Find("firstTitle")
    self.firstTitleText = self.firstTitle:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.firstTitleText.text = self.text1
    self.firstTitleText.text = "练习中"
    self.secondTitle = bg:Find("secondTitle")
    self.secondTitleText = self.secondTitle:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.secondTitleText.text = self.text2
    if self.gameMode == "0" then
        self.secondTitleText.text = "练习尚未结束，退出会失去所有奖励，并会降低学位分。"
    elseif self.gameMode == "1" then
        self.secondTitleText.text = "中途退出将无法获得奖励，是否退出？"
    end

    self.cancelText = bg:Find("cancel/cancelText")
    self.cancelTextText = self.cancelText:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.cancelTextText.text = self.text3
    self.verifyText = bg:Find("verify/verifyText")
    self.verifyTextText = self.verifyText:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.verifyTextText.text = self.text4
end

-- 取消确认按钮
function ExitGame:btnAddOnclick(gameMode)
    self.back = self.exitGame:Find("Canvas/back")
    self.backBtn = self.back:GetComponent(typeof(CS.UnityEngine.UI.Button))
    App:GetService("CommonService"):AddEventListener(self.backBtn, "onClick", function()
        if self.content ~= nil then
            local secondTitle = self.exitGame:Find("Canvas/Image/bg/secondTitle")
            local secondTitleText = secondTitle:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
            secondTitleText.text = self.content
            self.exitImage.gameObject:SetActive(true)
            return
        else
            self.exitImage.gameObject:SetActive(true)
        end
        if self.isWatchBattle then
            -- 已观战模式,文案修改
            local secondTitle = self.exitGame:Find("Canvas/Image/bg/secondTitle")
            local secondTitleText = secondTitle:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
            secondTitleText.text = "退出不会影响结算，是否退出观战？"
            self.exitImage.gameObject:SetActive(true)
        end

        --视频预读暂停
        self:PauseOrResumeVideo(true)
    end)

    self.cancelBtn = self.exitGame.transform:Find("Canvas/Image/bg/cancel"):GetComponent(typeof(CS.UnityEngine.UI
        .Button))
    App:GetService("CommonService"):AddEventListener(self.cancelBtn, "onClick", function()
        self.exitImage.gameObject:SetActive(false)
        --视频领读or预读恢复
        self:PauseOrResumeVideo(false)
    end)

    self.verifyBtn = self.exitGame.transform:Find("Canvas/Image/bg/verify"):GetComponent(typeof(CS.UnityEngine.UI
        .Button))
    App:GetService("CommonService"):AddEventListener(self.verifyBtn, "onClick", function()
        if self.callback ~= nil then
            self.callback()
            self.exitImage.gameObject:SetActive(false)
            return
        end
        self.observerService:Fire("quitVerify", {})
        if gameMode == "0" then
            -- 排位模式
            self.observerService:Fire("startSettle", { true })
            self.exitImage.gameObject:SetActive(false)
        elseif gameMode == "1" then
            -- 休闲模式
            g_Log("lsh退出游戏，退回ABCZone主场景")
            App:GameReturn()
            self.exitImage.gameObject:SetActive(false)
        elseif gameMode == "2" then
            -- 中途退出模式
            g_Log("lsh中途退出游戏")
            self.exitImage.gameObject:SetActive(false)
            self.observerService:Fire("quitMidway")
        end
        --视频领读or预读恢复
        self:PauseOrResumeVideo(false)
    end)
end

--暂停or恢复视频领读和预读相关
function ExitGame:PauseOrResumeVideo(pause)
    if pause then
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", { op = "PauseOrHide" })
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", { op = "Pause" })
    else
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", { op = "ResumeOrShow" })
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", { op = "Resume" })
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function ExitGame:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function ExitGame:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function ExitGame:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function ExitGame:SelfAvatarPrefabLoaded(avatar)
    self.parent:Trigger("trigger", self)
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function ExitGame:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function ExitGame:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function ExitGame:LogicMapStartRecover()
    ExitGame.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function ExitGame:LogicMapEndRecover()
    ExitGame.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function ExitGame:LogicMapAllComponentRecoverComplete()

end

-- 收到Trigger事件
function ExitGame:OnReceiveTriggerEvent(interfaceId)
end

-- 收到GetData事件
function ExitGame:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function ExitGame:Exit()
    ExitGame.super.Exit(self)
end

return ExitGame
