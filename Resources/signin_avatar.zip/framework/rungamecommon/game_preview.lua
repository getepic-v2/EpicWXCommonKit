---
---  Author: 【王德】
---  AuthorID: 【102030】
---  CreateTime: 【2023-10-31 10:32:01】
--- 【FSync】
--- 【游戏说明】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_607b0d3d_9766_4f3b_a8d7_d3de61816b87 : WorldBaseElement
local GamePreview = class("GamePreview", WBElement)
local prefsKey = "Game_Description_First_Show_Dialog"
local TAG = "玩法说明"
local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/smallGameTip/"
local prefabPath = ResourcePathRoot .. "assets/Prefabs/smallGameTip.prefab"

---@param worldElement CS.Tal.framesync.WorldElement
function GamePreview:initialize(worldElement)
    GamePreview.super.initialize(self, worldElement)
    self.lastRewardCount = 1
    self.observerService:Watch("on_change_last_reward_count", function(key, params)
        local data = params[0]
        if data then
            self.lastRewardCount = data.count or -1
        end
        if self.readBookLabel then
            self.readBookLabel.gameObject:SetActive(self.lastRewardCount > 0)
        end
    end)
    -- 订阅KEY消息
end

function GamePreview:setVisElement(parent, VisElement, config)
    self.parent = parent

    if VisElement then
        self.VisElement = VisElement
    end

    self.config = config
    self.first = true
    prefsKey = prefsKey .. tostring(App.ModName)
    self.tabIndex = 1
    self.gapWidth = 82.5
    self.questionIndex = 1
    self.questionList = {}
    self.hasChange = false
    self.viewPanelShow = false
    -- 外教视频播放是否初始化
    self.videoLeadReadingInit = false
    self:InitService()
    self:InitConfig()
    self:InitView()

    self.debugService:AddDebugActionWithTitleAndCategory("游戏说明清除第一次记录", "test"):connect(function()
        CS.UnityEngine.PlayerPrefs.SetString(prefsKey, "")
        CS.UnityEngine.PlayerPrefs.Save()
    end)
end

function GamePreview:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type ColliderService
    self.colliderService = CourseEnv.ServicesManager:GetColliderService()
end

function GamePreview:InitConfig()
    if self.config then
        self.isShowDesc = self.config.isShowDesc
        self.description = self.config.description
        self.isNewGuide = self.config.isNewGuide
        self.firstAudioUrl = self.config.firstAudioUrl
        self.showAudioUrl = self.config.showAudioUrl
    else
        self.isShowDesc = self.configService:GetConfigValueByConfigKey(self.VisElement, "isShow") == "True"
        self.description = self.configService:GetConfigValueByConfigKey(self.VisElement, "description")
        self.firstAudio = self.configService:GetAssetByConfigKey(self.VisElement, "firstAudio")
        self.showAudio = self.configService:GetAssetByConfigKey(self.VisElement, "showAudio")
        self.isNewGuide = self.configService:GetConfigValueByConfigKey(self.VisElement, "isNewGuide") == "True"
    end
end

function GamePreview:InitView()
    
    self.rootTrans = self.VisElement.transform
    ResourceManager:LoadGameObjectWithExName(prefabPath, function(go)
        self.rootView = GameObject.Instantiate(go).transform
        -- 设置canvas sortinggroup为499
        local canvas = self.rootView:GetComponentInChildren(typeof(CS.UnityEngine.Canvas))
        if canvas then
            canvas.sortingOrder = 499
        end

        -- 如果有SortingGroup组件，也设置为499
        local sortingGroup = self.rootView:GetComponent(typeof(CS.UnityEngine.Rendering.SortingGroup))
        if sortingGroup then
            sortingGroup.sortingOrder = 499
        end

        self.rootView:SetParent(self.rootTrans)
        self.rootView.localPosition = Vector3.zero
        self.rootView.localScale = Vector3.one
        self.rootView.localRotation = Quaternion.identity

        self.tipView = self.rootTrans:FindChildWithName("IconBtn")
        self.transBg = self.rootTrans:FindChildWithName("videoBg")
        self.transBg.gameObject:SetActive(false)
        ---@type CS.UnityEngine.UI.Button
        self.tipBtn = self.tipView:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.tipBtn, "onClick", function()
            self.dialogRoot.gameObject:SetActive(true)
            self.viewPanelShow = true
            if self.tabIndex == 1 then
                self:playQuestionByIndex(self.questionIndex)
            end
        end)
        self.tipView.gameObject:SetActive(false)

        -- 事件触发逻辑
        self.observerService:Watch("UI_SHOW_INSTRUCTION", function(key, args)
            local data = args and args[0]
            local show = data.show
            if show then
                self:OnReceiveTriggerEvent("firstShowDialog")
            else
                self:OnReceiveTriggerEvent("gameStart")
            end
        end)

        self.dialogRoot = self.rootTrans:FindChildWithName("mark")
        if App.modPlatform == MOD_PLATFORM.Math then
            self.newGuideDec = self.VisElement.transform:FindChildWithName("新UI")
            self.newGuideDec.parent = self.dialogRoot
            local newGuideDecRect = self.newGuideDec:GetComponent(typeof(CS.UnityEngine.RectTransform))
            self.newGuideDec.localPosition = CS.UnityEngine.Vector3(0, -2.28, 0)
            self.newGuideDec.localScale = CS.UnityEngine.Vector3(2, 2, 2)
        end

        self.dialogRoot.gameObject:SetActive(false)
        self.close = self.dialogRoot:FindChildWithName("Close")
        ---@type CS.UnityEngine.UI.Button
        self.closeBtn = self.close:GetComponent(typeof(CS.UnityEngine.UI.Button))

        local closeHandle = function()
            self:hideDialog()
            self.tipView.gameObject:SetActive(true)

            self.observerService:Fire("EVENT_BUSINESS_GAME_PREVIEW_CLOSE")
            -- self:Trigger("closeComplete")
        end

        self.commonService:AddEventListener(self.closeBtn, "onClick", closeHandle)
        self.title1 = self.dialogRoot:FindChildWithName("Title1")
        self.title1Image = self.title1:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.titleBottom1 = self.title1:FindChildWithName("bottom")
        self.titleBtn1 = self.title1:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.titleBtn1, "onClick", function()
            self:changeTab(1)
            self:playQuestionByIndex(self.questionIndex)

            if self.showAudioSource then
                self.audioService:StopAudioSource(self.showAudioSource)
                self.showAudioSource = nil
            end
        end)
        self.title2 = self.dialogRoot:FindChildWithName("Title2")
        self.title2Image = self.title2:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.titleBottom2 = self.title2:FindChildWithName("bottom")
        self.titleBtn2 = self.title2:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.titleBtn2, "onClick", function()
            self:changeTab(2)
            if self.questionAudioSource then
                self.audioService:StopAudioSource(self.questionAudioSource)
                self.questionAudioSource = nil
            end
        end)
        self.title1Image.color = CS.UnityEngine.Color(1, 1, 1, 1)
        self.title2Image.color = CS.UnityEngine.Color(1, 1, 1, 0.5)
        self.play = self.dialogRoot:FindChildWithName("Play")
        ---@type CS.UnityEngine.UI.Button
        self.playBtn = self.play.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.palyAnim = self.play:GetComponent(typeof(CS.UnityEngine.Animator))
        self.commonService:AddEventListener(self.playBtn, "onClick", function()
            if self.isPlaying then
                self.palyAnim:SetBool("play", false)
                self.isPlaying = false
                self.audioService:StopAudioSource(self.questionAudioSource)
            else
                self.palyAnim:SetBool("play", true)
                self.isPlaying = true
                self:playQuestionByIndex(self.questionIndex)
            end
        end)
        self.dialogContentBg = self.dialogRoot:FindChildWithName("ContentBg")
        self.dialogContentBgRect = self.dialogContentBg:GetComponent(typeof(CS.UnityEngine.RectTransform))

        self.dialogContent = self.dialogRoot:FindChildWithName("Content")
        self.dialogContentRect = self.dialogContent:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.dialogContentRect.sizeDelta = CS.UnityEngine.Vector2(680, 50)
        self.dialogContentRect.pivot = CS.UnityEngine.Vector2(0.5, 1)
        self.dialogContentRect.anchorMax = CS.UnityEngine.Vector2(0.5, 1)
        self.dialogContentRect.anchorMin = CS.UnityEngine.Vector2(0.5, 1)
        self.dialogContentRect.anchoredPosition = CS.UnityEngine.Vector2(0, -200)

        self.dialogContentTmp = self.dialogContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

        self.left = self.dialogRoot:FindChildWithName("left")
        self.leftBtn = self.left:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.leftBtn, "onClick", function()
            self.hasChange = true
            if self.questionIndex == 1 then
                self.questionIndex = self.maxIndex
            else
                self.questionIndex = self.questionIndex - 1
            end
            self.pageIndexTmp.text = tostring(self.questionIndex) .. "/" .. tostring(self.maxIndex)
            self:setQuestionViewByIndex(self.questionIndex)
            self:playQuestionByIndex(self.questionIndex)
        end)
        self.right = self.dialogRoot:FindChildWithName("right")
        self.rightBtn = self.right:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.rightBtn, "onClick", function()
            self.hasChange = true
            if self.questionIndex == self.maxIndex then
                self.questionIndex = 1
            else
                self.questionIndex = self.questionIndex + 1
            end
            self.pageIndexTmp.text = tostring(self.questionIndex) .. "/" .. tostring(self.maxIndex)
            self:setQuestionViewByIndex(self.questionIndex)
            self:playQuestionByIndex(self.questionIndex)
        end)

        self.pageIndex = self.dialogRoot:FindChildWithName("index")
        self.pageIndexTmp = self.pageIndex:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

        self.descriptionView = self.dialogRoot:FindChildWithName("Description")
        self.descriptionTmp = self.descriptionView:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        -- self.leftBg = self.dialogRoot:FindChildWithName("leftBg")
        self.fromBg = self.dialogRoot:FindChildWithName("fromBg")
        self.fromBgRect = self.fromBg:GetComponent(typeof(CS.UnityEngine.RectTransform))
        -- self.fromBgContentSize = self.fromBg:GetComponent(typeof(CS.UnityEngine.UI.ContentSizeFitter))
        -- self.fromBgContentSize.enabled = false
        self.fromBook = self.fromBg:FindChildWithName("book")
        self.fromBookImage = self.fromBook:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.fromDetail = self.fromBg:FindChildWithName("fromDetail")
        self.fromDetailTmp = self.fromDetail:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        -- self.fromDetailContentSize = self.fromDetail:GetComponent(typeof(CS.UnityEngine.UI.ContentSizeFitter))
        -- self.fromDetailContentSize.enabled = false
        ---@type CS.UnityEngine.RectTransform
        self.fromDetailRect = self.fromDetail:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.fromDetailRect.pivot = CS.UnityEngine.Vector2(0, 0.5)
        self.fromDetailRect.anchoredPosition = CS.UnityEngine.Vector2(82, -12)
        self.fromDetailTmp.text = ""
        self.typeIcon = self.dialogRoot:FindChildWithName("typeIcon")
        self.typeIconImage = self.typeIcon:GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.typeIcon.gameObject:SetActive(false)
        self.fromBg.gameObject:SetActive(false)

        self.readBookLabel = self.dialogRoot:FindChildWithName("readBookLabel")
        self.sentenceLabel = self.dialogRoot:FindChildWithName("sentenceLabel")

        self.sentenceLabel.gameObject:SetActive(false)
        self.readBookLabel.gameObject:SetActive(false)

        -- 视频领读相关UI
        self.videoView = self.dialogRoot:FindChildWithName("videoView")
        local videoBtn = self.videoView.transform:Find("videIcon")
        self.yinboEffect = self.videoView.transform:Find("yinbo")
        self.yinbo_left = self.videoView.transform:Find("yinbo_left")
        self.yinbo_right = self.videoView.transform:Find("yinbo_right")

        videoBtn.gameObject:SetActive(false)
        self.playVideoBtn = videoBtn.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.playVideoBtn, "onClick", function()
            if self.videoLeadReadingInit then
                self:playQuestionByIndex(self.questionIndex)
            end
        end)

        self.newGuideDec = self.dialogRoot:FindChildWithName("新UI")
       
        if self.newGuideDec then
            self.newGuideDec.gameObject:SetActive(false)
            self.commonService:AddEventListener(self.newGuideDec:Find("root/btn - close"):GetComponent(typeof(
                CS.UnityEngine.UI.Button)), "onClick", closeHandle)
        end

        self:setInitStatus()
    end)

    self.observerService:Watch("EVENT_BUSINESS_QUESTION_FROM_INFO", function(key, value)
        local data = value[0]
        local bookImageUrl = data.bookImageUrl
        local bookName = data.bookName
        local bookLevel = data.bookLevel
        g_Log(TAG, "bookImageUrl" .. bookImageUrl)
        self.commonService:StartCoroutine(function()
            self.commonService:Yield(self.commonService:WaitUntil(function()
                return self.rootView
            end))
            self.bookName = data.bookName
            if self.tabIndex == 1 then
                self.fromBg.gameObject:SetActive(true)
            end
            self.httpService:LoadNetWorkTexture(bookImageUrl, function(sprite)
                if sprite then
                    self.commonService:DispatchNextFrame(function()
                        self.fromBookImage.sprite = sprite
                    end)
                end
            end)
            self.fromDetailTmp.text = " " .. bookName .. " " .. bookLevel
            self:SetUIRect()
        end)
    end)
end

function GamePreview:SetBookTypeImage(bookTypeImage)
    if self.hasSetBookTypeImage or (not bookTypeImage) or bookTypeImage == "" then
        return
    end
    self.httpService:LoadNetWorkTexture(bookTypeImage, function(sprite)
        if sprite then
            self.hasSetBookTypeImage = true
            self.commonService:DispatchNextFrame(function()
                self.typeIcon.gameObject:SetActive(true)
                self.typeIconImage.sprite = sprite
                self.gapWidth = 107
                self:SetUIRect()
            end)
        end
    end)
end

function GamePreview:SetUIRect()
    if self.fromDetail and self.fromDetail.gameObject.activeInHierarchy then
        self.fromDetailRect.sizeDelta = CS.UnityEngine.Vector2(self.fromDetailTmp.preferredWidth + 1,
            self.fromDetailRect.sizeDelta.y)
        self.fromBgRect.sizeDelta = CS.UnityEngine.Vector2(self.fromDetailTmp.preferredWidth + self.gapWidth,
            self.fromBgRect.sizeDelta.y)
        self.fromDetailRect.anchoredPosition = CS.UnityEngine.Vector2(self.gapWidth, -12)
    end
end

function GamePreview:setInitStatus()
    if self.newGuideDec then
        if self.isNewGuide then
            self.newGuideDec.gameObject:SetActive(true)
            self.dialogContentBg.gameObject:SetActive(false)
        else
            self.newGuideDec.gameObject:SetActive(false)
            self.dialogContentBg.gameObject:SetActive(true)
        end
    end

    if self.isShowDesc then
        self.descriptionTmp.text = self.description
        self.newGuideDec.transform:Find("root/text"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI)).text =
            self.description
        local status = CS.UnityEngine.PlayerPrefs.GetString(prefsKey)
        if not status or status == "" then
            g_Log("玩法说明", "第一次显示说明")
            self:changeTab(2)
        end
    else
        self:changeTab(1)
        self.title2.gameObject:SetActive(false)
        ---@type CS.UnityEngine.RectTransform
        local titleRect1 = self.title1:GetComponent(typeof(CS.UnityEngine.RectTransform))
        titleRect1.anchorMin = CS.UnityEngine.Vector2(0.5, 0.5)
        titleRect1.anchorMax = CS.UnityEngine.Vector2(0.5, 0.5)
        titleRect1.anchoredPosition = CS.UnityEngine.Vector2(0, 0)
        self.titleBottom1.gameObject:SetActive(false)
        self.titleBottom2.gameObject:SetActive(false)
        self.titleBtn2.enabled = false
    end
end

function GamePreview:changeTab(index)
    if index == 1 then
        self.tabIndex = 1
        if self.isShowDesc then
            self.titleBottom2.gameObject:SetActive(false)
            self.titleBottom1.gameObject:SetActive(true)
        end
        self.title1Image.color = CS.UnityEngine.Color(1, 1, 1, 1)
        self.title2Image.color = CS.UnityEngine.Color(1, 1, 1, 0.5)
        self.descriptionView.gameObject:SetActive(false)
        self.dialogContent.gameObject:SetActive(true)
        self.pageIndex.gameObject:SetActive(true)
        self.left.gameObject:SetActive(true)
        self.right.gameObject:SetActive(true)
        self.play.gameObject:SetActive(true)
        if self.bookName then
            self.fromBg.gameObject:SetActive(true)
            self:SetUIRect()
        end
        local question = self.questionList[self.questionIndex]

        -- g_Log("玩法说明-question", table.dump(question))
        if question then
            local style_id = question.style
            if style_id == 51 then
                self.sentenceLabel.gameObject:SetActive(true)
                self.readBookLabel.gameObject:SetActive(false)
            elseif style_id == 52 then
                self.sentenceLabel.gameObject:SetActive(false)
                self.readBookLabel.gameObject:SetActive(self.lastRewardCount > 0)
            else
                self.sentenceLabel.gameObject:SetActive(false)
                self.readBookLabel.gameObject:SetActive(false)
            end
            -- 初始化视频领读相关UI
            self:InitVideoLeadReadingUI(question)
        end
        -- self.fromBg.gameObject:SetActive(true)
        -- self.leftBg.gameObject:SetActive(true)
    else
        self.tabIndex = 2
        if self.isShowDesc then
            self.titleBottom1.gameObject:SetActive(false)
            self.titleBottom2.gameObject:SetActive(true)
        end
        self.title1Image.color = CS.UnityEngine.Color(1, 1, 1, 0.5)
        self.title2Image.color = CS.UnityEngine.Color(1, 1, 1, 1)
        self.descriptionView.gameObject:SetActive(true)
        self.dialogContent.gameObject:SetActive(false)
        self.pageIndex.gameObject:SetActive(false)
        self.left.gameObject:SetActive(false)
        self.right.gameObject:SetActive(false)
        self.play.gameObject:SetActive(false)
        self.videoView.gameObject:SetActive(false)
        self.fromBg.gameObject:SetActive(false)
        self.sentenceLabel.gameObject:SetActive(false)
        self.readBookLabel.gameObject:SetActive(false)
        -- self.leftBg.gameObject:SetActive(false)
        -- 清理视频领读相关UI
        self:ClearVideoLeadReadingUI()
    end
end

-- 初始化视频领读相关UI
function GamePreview:InitVideoLeadReadingUI(question)
    local style_id = question.style
    if style_id == 51 then
        self.play.gameObject:SetActive(true)
        -- 清理视频领读相关UI
        self.videoView.gameObject:SetActive(false)
        self:ClearVideoLeadReadingUI()
    elseif style_id == 52 then
        -- 是否配置了视频字段--显示视频播放动效节点
        if question.video and question.video ~= "" then
            -- 功能是否可用
            local canUse = false
            self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
                op = "Available",
                callback = function(use)
                    canUse = use
                end
            })
            if self.isNewGuide then
                canUse = false
            end
            -- g_Log("玩法说明-视频领读", canUse)
            if canUse then
                -- 如果有配置视频链接--初始化视频播放窗口
                if self.videoLeadReadingInit then
                    return
                end
                self.videoLeadReadingInit = true
                self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
                    op = "InitView",
                    viewType = 6
                })
                -- 隐藏
                self.videoView.gameObject:SetActive(true)
                self.play.gameObject:SetActive(false)
            else
                self.play.gameObject:SetActive(true)
            end
        end
    end
end

-- 清理视频领读相关UI
function GamePreview:ClearVideoLeadReadingUI()
    if self.videoLeadReadingInit then
        self.videoLeadReadingInit = false
        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
            op = "stop"
        })
    end
end

function GamePreview:showDialog()
    if self.gameStart then
        return
    end
    self.viewPanelShow = true

    CS.UnityEngine.PlayerPrefs.SetString(prefsKey, "1")
    CS.UnityEngine.PlayerPrefs.Save()
    self.tipView.gameObject:SetActive(false)

    self.play.gameObject:SetActive(false)

    local liveId = App.Info.liveId
    local userId = App.Info.userId

    local cacheKey = "game_preview_" .. tostring(liveId) .. "_" .. tostring(userId)
    local showAudio = CS.UnityEngine.PlayerPrefs.GetString(cacheKey)
    if showAudio ~= "1" and self.isShowDesc then
        CS.UnityEngine.PlayerPrefs.SetString(cacheKey, "1")
        CS.UnityEngine.PlayerPrefs.Save()

        -- self.titleBtn2 触发一下点击
        self.titleBtn2.onClick:Invoke()

        if self.showAudio then
            self.showAudioSource = self.audioService:PlayClipOneShot(self.showAudio, function()
                self.showAudioSource = nil
            end)
        elseif self.showAudioUrl then
            self.audioService:GetMp3AudioFromGetUrl(self.showAudioUrl, function()
                g_Log(TAG, "showAudioUrl 下载音频失败")
            end, function(clip)
                self.showAudio = clip
                self.showAudioSource = self.audioService:PlayClipOneShot(self.showAudio, function()
                    self.showAudioSource = nil
                end)
            end)
        end
        return
    end

    if self.isShowDesc then
        if self.tabIndex == 1 then
            if self.first then
                ---播放引导音频
                self.first = false
                self:playFirstAudio()
            else
                ---播放题目音频
                self:playQuestionByIndex(self.questionIndex)
            end
        end
        self.dialogRoot.gameObject:SetActive(true)
        if self.tabIndex == 1 then
            self:SetUIRect()
        else
            self.sentenceLabel.gameObject:SetActive(false)
            self.readBookLabel.gameObject:SetActive(false)
        end
    else
        if self.first then
            ---播放引导音频
            self.first = false
            self:playFirstAudio()
        else
            ---播放题目音频
            self:playQuestionByIndex(self.questionIndex)
        end
        self.dialogRoot.gameObject:SetActive(true)
        self:SetUIRect()
    end
end

function GamePreview:setQuestionViewByIndex(index)
    local question = self.questionList[index]
    local style_id = question.style
    local text = ""
    local cn_text = ""
    if style_id == 51 then
        self.sentenceLabel.gameObject:SetActive(true)
        self.readBookLabel.gameObject:SetActive(false)
        text = question.text_en
        cn_text = question.text_cn
    elseif style_id == 52 then
        self.sentenceLabel.gameObject:SetActive(false)
        self.readBookLabel.gameObject:SetActive(self.lastRewardCount > 0)
        text = question.display
        cn_text = question.text_cn
    else
        self.sentenceLabel.gameObject:SetActive(false)
        self.readBookLabel.gameObject:SetActive(false)
        if question.parse then
            text = question.parse.text
            cn_text = question.parse.cn_text
        elseif question.stem then
            text = question.stem.text
            if question.stem.cn_text then
                cn_text = question.stem.cn_text
            end
        end
    end
    if not text or text == "" then
        table.remove(self.questionList, index)
        self:setQuestionViewByIndex(index)
        local maxCount = #self.questionList
        self.maxIndex = math.min(maxCount, 10)
        self.pageIndexTmp.text = tostring(self.questionIndex) .. "/" .. tostring(self.maxIndex)
        return
    end
    local keyWord = question.word
    local indexArray = question.indexArray
    local text_en = ""
    if indexArray then
        if type(indexArray) == 'string' then
            indexArray = self.jsonService:decode(indexArray)
        end
        if indexArray and type(indexArray) == 'table' and #indexArray > 0 then
            if style_id == 52 then
                text_en = self:GetKeyWordTextByIndex2(text, indexArray)
            else
                text_en = self:GetKeyWordTextByIndex(text, indexArray)
            end
        end
    end
    if (not text_en) or text_en == "" then
        -- g_Log(TAG, self.question.text_en, keyWord)
        if style_id == 52 then
            text_en = self:GetKeyWordText2(text, keyWord)
        else
            text_en = self:GetKeyWordText(text, keyWord)
        end
    end

    self.dialogContentTmp.text =
        "<b>" .. tostring(text_en) .. "</b><br><size=30><color=#666666>" .. tostring(cn_text) .. "</color></size>"

    local preHeight = self.dialogContentTmp.preferredHeight
    if preHeight <= 180 then
        self.dialogContentBgRect.sizeDelta = CS.UnityEngine.Vector2(800, 400)
        self.dialogContentBgRect.anchoredPosition = CS.UnityEngine.Vector2(0, -91)
    else
        self.dialogContentBgRect.sizeDelta = CS.UnityEngine.Vector2(800, preHeight + 272)
        -- self.dialogContentBgRect.anchoredPosition = CS.UnityEngine.Vector2(0, -91)
        ---屏幕高度
        local screenHeight = CS.UnityEngine.Screen.height
        ---面板距离底部距离
        local bottom = (screenHeight - preHeight - 220) / 2 - 91
        if bottom >= 84 then
            self.dialogContentBgRect.anchoredPosition = CS.UnityEngine.Vector2(0, -91)
        else
            self.dialogContentBgRect.anchoredPosition = CS.UnityEngine.Vector2(0, bottom - 175)
        end
    end
    if question.level_name and self.bookName then
        self.fromDetailTmp.text = " " .. self.bookName .. " " .. question.level_name
        self:SetUIRect()
    end
end

---播放引导音频
function GamePreview:playFirstAudio()
    -- if self.firstAudioSource then
    --     self.audioService:StopAudioSource(self.firstAudioSource)
    --     self.firstAudioSource = nil
    -- end
    g_Log(TAG, self.firstAudio)
    self.audioService:GetMp3AudioFromGetUrl(
        "https://static0.xesimg.com/next-studio/ai/tts/2024-05-06/1714991865_2bc475b9-5e0f-4f39-aa57-b02ce2415ad0.mp3",
        function()
            if self.hasChange then
                return
            end
            if self.gameStart then
                return
            end
            self:playQuestionByIndex(self.questionIndex)
        end, function(clip)
            if self.hasChange then
                return
            end
            if self.gameStart then
                return
            end
            self.firstAudioSource = self.audioService:PlayClipOneShot(clip, function()
                g_Log(TAG, "引导播放完成")
                if self.hasChange then
                    return
                end
                if self.gameStart then
                    return
                end
                self:playQuestionByIndex(self.questionIndex)
            end)
        end)
end

-- 显示视频播放动画
function GamePreview:PlayVideoAnim(play)
    if self.yinboEffect then
        self.yinboEffect.gameObject:SetActive(play)
        self.yinbo_left.gameObject:SetActive(not play)
        self.yinbo_right.gameObject:SetActive(not play)
    end
end

function GamePreview:playQuestionByIndex(index)
    if self.questionAudioSource then
        self.audioService:StopAudioSource(self.questionAudioSource)
        self.questionAudioSource = nil
    end
    local style_id = self.questionList[index].style
    local audio = ""
    local video = ""
    if style_id == 51 or style_id == 52 then
        audio = self.questionList[index].audio
        video = self.questionList[index].video
    else
        if self.questionList[index].stem then
            audio = self.questionList[index].stem.audio
        end
    end

    -- 初始化视频领读相关UI
    local question = self.questionList[index]
    if question and self.viewPanelShow then
        self:InitVideoLeadReadingUI(question)
    end

    if audio == "" then
        return
    end

    -- g_Log(TAG, "video", video)
    -- 如果配置了视频
    if video and video ~= "" and self.viewPanelShow then
        if self.videoLeadReadingInit then
            -- 播放视频播放特效
            self:PlayVideoAnim(true)
            self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_COMMAND", {
                op = "PlayVideo",
                viewType = 6,
                question = self.questionList[index],
                callback = function(res)
                    -- 播放完成--隐藏video视图
                    self:PlayVideoAnim(false)
                end
            })
        end
    else
        self.audioService:GetMp3AudioFromGetUrl(self.questionList[index].audio, function(error)
            if index == self.questionIndex then
                self.palyAnim:SetBool("play", false)
            end
        end, function(clip)
            if self.gameStart then
                return
            end
            if index == self.questionIndex then
                self.isPlaying = true
                self.palyAnim:SetBool("play", true)
                self.questionAudioSource = self.audioService:PlayClipOneShot(clip, function()
                    if index == self.questionIndex then
                        self.isPlaying = false
                        self.palyAnim:SetBool("play", false)
                    end
                end)
            end
        end)
    end
end

function GamePreview:hideDialog()
    self.viewPanelShow = false
    ---关闭声音
    if self.questionAudioSource then
        self.audioService:StopAudioSource(self.questionAudioSource)
        self.questionAudioSource = nil
    end
    if self.firstAudioSource then
        self.audioService:StopAudioSource(self.firstAudioSource)
        self.firstAudioSource = nil
    end

    if self.showAudioSource then
        self.audioService:StopAudioSource(self.showAudioSource)
        self.showAudioSource = nil
    end

    self.dialogRoot.gameObject:SetActive(false)
    -- 清理视频领读相关UI
    self:ClearVideoLeadReadingUI()
end

function GamePreview:GetKeyWordTextByIndex(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return text
    end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                else
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#2D6EFF>" .. middleStr .. "</color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return text
end

function GamePreview:GetKeyWordTextByIndex2(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then
        return text
    end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                else
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            frontStr = "<color=#666666><size=18>" .. frontStr .. "</size></color>"
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#000000><size=38>" .. middleStr .. "</size></color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                endStr = "<color=#666666><size=18>" .. endStr .. "</size></color>"
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    -- g_Log(TAG, "使用下标高亮显示")
    return text
end

-- 处理对应重点单词文字
function GamePreview:GetKeyWordText(text, word)
    if not text and not word then
        return ""
    end
    if not word or word == "" then
        return text
    end
    for keyWord in string.gmatch(word, "%w+") do
        local keyWordLower = keyWord:lower()
        local lowerText = text:lower()
        local startIndex, endIndex = string.find(lowerText, keyWordLower)
        if startIndex and endIndex then
            -- local key = string.sub(text, startIndex, endIndex)
            -- g_Log(TAG, "使用关键词高亮显示"..keyWord)
            text = text:gsub('(%f[%a]' .. keyWord .. '[%p]*%f[^%a])', "<color=#2D6EFF>" .. keyWord .. "</color>")
        end
    end
    -- 替换所有出现的关键词
    return text
end

function GamePreview:GetKeyWordText2(text, word)
    if not text and not word then
        return "", ""
    end
    if not word or word == "" then
        return "", ""
    end
    if not text or text == "" then
        return "", ""
    end
    local startIndex, endIndex = string.find(text, word)
    local frontStr = ""
    local endStr = ""
    if startIndex and startIndex > 1 then
        frontStr = string.sub(text, 1, startIndex - 1)
    end
    -- local frontStrReverse = string.reverse(frontStr)
    if endIndex and endIndex + 1 <= #text then
        endStr = string.sub(text, endIndex + 1, #text)
    end
    frontStr = "<color=#666666><size=18>" .. frontStr .. "</size></color>"
    local middleStr = "<color=#000000><size=38>" .. word .. "</size></color>"
    endStr = "<color=#666666><size=18>" .. endStr .. "</size></color>"
    local resultText = frontStr .. middleStr .. endStr
    -- 替换所有出现的关键词
    return resultText
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function GamePreview:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function GamePreview:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function GamePreview:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function GamePreview:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function GamePreview:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function GamePreview:LogicMapIsAsyncRecorver()
    return false
end

-- 开始恢复方法（断线重连的时候用）
function GamePreview:LogicMapStartRecover()
    GamePreview.super:LogicMapStartRecover()
    -- TODO
end

-- 结束恢复方法 (断线重连的时候用)
function GamePreview:LogicMapEndRecover()
    GamePreview.super:LogicMapEndRecover(self)
    -- TODO
end

-- 所有的组件恢复完成
function GamePreview:LogicMapAllComponentRecoverComplete()
end

-- 收到Trigger事件
function GamePreview:OnReceiveTriggerEvent(interfaceId)
    self.commonService:StartCoroutine(function()
        self.commonService:Yield(self.commonService:WaitUntil(function()
            return self.rootView
        end))
        if "firstShowDialog" == interfaceId then
            if App.modPlatform == MOD_PLATFORM.ABCZone then
                self.observerService:Fire("EVENT_ABCZONE_GET_ALL_QUESTION", {
                    callback = function(questionList)
                        self.questionList = {}
                        local maxCount = 0
                        for k, v in pairs(questionList) do
                            if v then
                                maxCount = maxCount + #v
                                for i, m in ipairs(v) do
                                    table.insert(self.questionList, m)
                                end
                            end
                        end
                        self.maxIndex = math.min(maxCount, 10)
                        self.pageIndexTmp.text = tostring(self.questionIndex) .. "/" .. tostring(self.maxIndex)
                        self:setQuestionViewByIndex(self.questionIndex)
                        if self.avatar and self.avatar.bookType then
                            self:SetBookTypeImage(self.avatar.bookType)
                        end
                        self:showDialog()
                    end
                })
            elseif App.modPlatform == MOD_PLATFORM.Math then
                -- if self.avatar and self.avatar.bookType then
                --     self:SetBookTypeImage(self.avatar.bookType)
                -- end
                self:showDialog()
            end
        elseif "closeDialog" == interfaceId then
            self:hideDialog()
            self.tipView.gameObject:SetActive(true)
        elseif "gameStart" == interfaceId then
            self.gameStart = true
            self:hideDialog()
            self.tipView.gameObject:SetActive(false)
            self.rootTrans.gameObject:SetActive(false)
        end
    end)
end

-- 收到GetData事件
function GamePreview:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function GamePreview:Exit()
    GamePreview.super.Exit(self)
end

return GamePreview
