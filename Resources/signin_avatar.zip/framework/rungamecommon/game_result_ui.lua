---  Author: 【孙鹏飞】
---  AuthorID: 【V0047328】
---  CreateTime: 【2025-8-14 14:31:39】
--- 【FSync】
--- 【结算UI】
---

---@diagnostic disable: undefined-global
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class GameResultUI : WorldBaseElement
local GameResultUI = class("game_result_ui_comlogic", WBElement)

local uAddress = "1087671762250087/assets/Prefabs/ResultCanvas.prefab"                  --结算UI
local SHOW_RESULT_COMMON_UI = "SHOW_RESULT_COMMON_UI"                                   --展示结算UI事件
local GET_RECORD_SCORE_DATA = "GET_RECORD_SCORE_DATA"                                   --获取玩家统计分数事件
local GET_CALCULATE_PLAYER_STUDY_SCORE_STATS = "GET_CALCULATE_PLAYER_STUDY_SCORE_STATS" --计算玩家学习成绩

local fsync_activateRoom = "activateRoom"
local game_remote_params = "game_remote_params"

local ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK = "ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK"     --再来一局按钮点击事件
local ON_GAME_RESULT_UI_TUICHU_BTN_CLICK = "ON_GAME_RESULT_UI_TUICHU_BTN_CLICK"             --退出按钮点击事件
local ON_GAME_RESULT_UI_CANCEL_QUEUE_BTN_CLICK = "ON_GAME_RESULT_UI_CANCEL_QUEUE_BTN_CLICK" --取消匹配队列按钮点击事件
local GAME_RESULT_SET_MAIN_PANEL = "GAME_RESULT_SET_MAIN_PANEL"                             --隐藏结算UI事件
local GET_PLAYERS_SCHOOL_INFO = "GET_PLAYERS_SCHOOL_INFO"                                   --获取玩家学校信息

--自己玩家形象UI位置和大小
local ui_SelfPlayerConfig = {
    --队伍只有自己1个玩家
    [1] = {
        pos = Vector3(177, -49, 0),
        scale = Vector3(1, 1, 1)
    },
    --队伍有2个玩家 自己+1个其他玩家
    [2] = {
        pos = Vector3(29, -32, 0),
        scale = Vector3.one
    },
    --队伍有3个玩家 自己+2个其他玩家
    [3] = {
        pos = Vector3(-104, -32, 0),
        scale = Vector3.one
    },
    --队伍有4个玩家 自己+3个其他玩家
    [4] = {
        pos = Vector3(-153, -32, 0),
        scale = Vector3.one
    }
}

--其他玩家形象UI位置和大小
local ui_OtherPlayerConfig = {
    --队伍有1个其他玩家
    [1] = {
        pos = Vector3(603, -37, 0), --otherPlayerContent_otherPlayer 其他玩家位置
        size = Vector2(280, 500)    --otherPlayerContent_otherPlayer  的 CS.UnityEngine.UI.GridLayoutGroup   cellSize  其他玩家大小
    },
    --队伍有2个其他玩家
    [2] = {
        pos = Vector3(463, -37, 0),
        size = Vector2(280, 500)
    },
    --队伍有3个其他玩家
    [3] = {
        pos = Vector3(403, -37, 0),
        size = Vector2(260, 500)
    }
}


---@param worldElement CS.Tal.framesync.WorldElement
function GameResultUI:initialize(worldElement)
    GameResultUI.super.initialize(self, worldElement)
    -- 订阅KEY消息
    self:SubscribeMsgKey(fsync_activateRoom)
    self:SubscribeMsgKey(game_remote_params)
    -- 排队按钮注册
    self:SubscribePeerMsgKey("queue_up_num" .. App.Info.roomId)
    self:SubscribePeerMsgKey("queue_up_succ" .. App.Info.roomId)
end

function GameResultUI:setVisElement(VisElement)
    if VisElement ~= nil then
        self.VisElement = VisElement
    end
    self:InitVariable()
    self:InitService()
    self:InitConfig()
    self:InitListener()
    self:InitView()
    self:InitMatching()
end

function GameResultUI:InitVariable()
    self:resetVariable()
    -- 匹配相关变量
    self.matchingData = nil       -- 匹配数据
    self.needShowMatching = false --是否显示匹配功能
    self.matchingCor = nil        -- 匹配协程
    self.hasJump = false          -- 是否已经跳转
    self.isMatching = false       -- 是否在匹配中

    self.game_id = nil
    self.set_id = nil
    self.plan_id = nil
    self.origin_game_id = nil
    self.teamId = nil

    self.clickAgainCallBack = nil -- 再来一局按钮点击回调
    self.clickCloseCallBack = nil -- 关闭按钮点击回调

    self.otherPlayerItemMap = {}  -- 其他玩家项字典
    self.otherPlayerItemList = {} -- 其他玩家项列表
end

-- 重置变量 再来一局时使用
function GameResultUI:resetVariable()
    self.petExpFromAnswer = 0 -- 从答题中累积的宠物经验
    self.xueshiFromAnswer = 0 -- 从答题中累积的学识
    -- self.addZhishiNum = 0     -- 累积的芝士值
    -- 清空接口请求获取数据
    self.change_score = nil
    self.ranking_before = nil
    self.ranking_after = nil
    self.is_protect = nil
    self.protect_score = nil
    self.is_school_settle = nil
    self.join_school_flag = nil
    self.add_value = nil
    self.has_upgrade = nil
    self.after_level = nil
    self.is_double_game = nil
    self.add_cheese_val = nil
    self.grow_route_info = nil
    self.season_id = nil
    self.jiziNum = nil
end

function GameResultUI:InitService()
    self.gate = CourseEnv.ServicesManager.Gate
    self.BusEventService = CourseEnv.ServicesManager:GetObserverService()
    self.commonService = App:GetService("CommonService")
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    self.UIService = App:GetService("UIService")
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.decorateService = CourseEnv.ServicesManager:GetDecorateService()
    self.lightService = CourseEnv.ServicesManager:GetLightService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.permissionService = CourseEnv.ServicesManager:GetPermissionService()
    self.h5Service = CourseEnv.ServicesManager:GetH5Service()
end

function GameResultUI:InitConfig()

end

function GameResultUI:InitListener()
    --展示结算UI
    self.observerService:Watch(SHOW_RESULT_COMMON_UI, function(key, args)
        local data = args[0] -- 获取事件参数
        if data == nil then
            self:Print("展示结算UI失败 data为nil")
            return
        end
        self.data = data
        self.isShowMVPStage = data.isShowMVPStage           --是否展示mvp舞台 默认展示（如游戏中途展示的时候没有MVP) 同时ui不展示MVP
        self.gameType = data.gameType                       --游戏ID 7q8DJQY69E6TxTBCbwuZw
        self.titleData = data.titleData                     --标题数据
        self.awardData = data.awardData                     --奖励数据
        self.matchData = data.matchData                     --匹配数据
        self.gameData = data.gameData                       --游戏自定义数据
        self.autoCloseCallBack = data.autoCloseCallBack     --自动关闭回调函数
        self.clickCloseCallBack = data.clickCloseCallBack   --点击关闭回调函数
        self.clickAgainCallBack = data.clickAgainCallBack   --点击再来一局回调函数
        self.playerStats = data.playerStats                 --所有玩家统计数据
        self.mvpPlayerUuid = data.mvpPlayerUuid             --MVP玩家UUID
        self.mvpPlayerScoreStats = data.mvpPlayerScoreStats --MVP玩家评分数据
        -- SVP数据
        self.svpPlayerUuid = data.svpPlayerUuid             --SVP玩家UUID
        --请求数据
        self.change_score = data.change_score
        self.ranking_before = data.ranking_before
        self.ranking_after = data.ranking_after
        self.is_protect = data.is_protect
        self.protect_score = data.protect_score
        self.is_school_settle = data.is_school_settle
        self.join_school_flag = data.join_school_flag
        self.add_value = data.add_value
        self.has_upgrade = data.has_upgrade
        self.after_level = data.after_level
        self.is_double_game = data.is_double_game
        self.add_cheese_val = data.add_cheese_val
        self.grow_route_info = data.grow_route_info
        self.season_id = data.season_id
        self.jiziNum = data.jiziNum
        self.playerAvatarSprites = data.playerAvatarSprites --玩家头像

        --获取当前玩家学习成绩
        self.observerService:Fire(GET_CALCULATE_PLAYER_STUDY_SCORE_STATS, {
            uuid = App.Uuid,
            callback = function(playerStudyScoreStats)
                --展示mvp舞台UI
                self:LoadResultUI(data.callBack, playerStudyScoreStats)
            end
        })
    end)

    -- 【英语】 接收学识和宠物经验累积事件
    self.observerService:Watch("add_pet_exp_from_read", function(key, args)
        local value = args[0]
        if value.petExp then
            self.petExpFromAnswer = self.petExpFromAnswer + value.petExp
            self:Print("累积宠物经验:", value.petExp, "总计:", self.petExpFromAnswer)
        end
    end)

    -- 【英语】 接收学识累积事件
    self.observerService:Watch("add_diamond_from_read", function(key, args)
        local value = args[0]
        if value.addDiamond then
            self.xueshiFromAnswer = self.xueshiFromAnswer + value.addDiamond
            self:Print("累积学识:", value.addDiamond, "总计:", self.xueshiFromAnswer)
        end
    end)

    --隐藏结算
    self.BusEventService:Watch("HIDE_MINI_GAME_RESULT_PANEL", function(key, args)
        self:HideResultUI()
    end)

    -- 【数学】接收学识和宠物经验
    self.BusEventService:Watch("game_answer_result_notice", function(key, args)
        local value = args[0]
        if value.isPass then
            self.petExpFromAnswer = self.petExpFromAnswer + 1
            if value.isReadBook then
                self.xueshiFromAnswer = self.xueshiFromAnswer + 1
            end
        end
    end)


end

function GameResultUI:InitView()
    -- --debug
    self.debugService:AddDebugActionWithTitleAndCategory("拍照分享", "test"):connect(function()
        -- 拍照分享
        self.observerService:Fire("ABCZONE_FULL_SCREEN_SHARE_SCREEN", {
            from = "4",
        })
    end)
end

--region 结算UI初始化-----------------------------------------------------------------------------------------------------------------------------

---加载结算UI
---@param callBack function 回调函数
---@param playerStudyScoreStats  table 自己玩家的评分数据 （如：英语格式为 {"100","3","100"} 表示平均开口分100分，朗读句子数3句，句子准确率100%）
function GameResultUI:LoadResultUI(callBack, playerStudyScoreStats)
    self.playerStudyScoreStats = playerStudyScoreStats or {}
    if self.ui then
        self:ShowResultUI()
        if callBack and type(callBack) == "function" then
            callBack()
        end
        return
    end
    self:LoadRemoteUaddress(uAddress, function(success, prefab)
        if success and prefab then
            if self.prefab then
                ResourceManager:ReleaseObject(self.prefab)
                self.prefab = nil
            end
            self.prefab = prefab
            self.ui = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
            self:InitResultUI()
            self:ShowResultUI()
            if callBack and type(callBack) == "function" then
                callBack()
            end
        end
    end)
end

---初始化舞台UI
function GameResultUI:InitResultUI()
    self.ui.gameObject:SetActive(false)
    -- 设置canvas的sortingOrder 挡住玩家头顶UI
    self.ui.transform:GetComponent(typeof(CS.UnityEngine.Canvas)).sortingOrder = 2202--(App.IsStudioClient or App:IsDebug()) and 202 or 2202
    --标题
    self.biaoti = self.ui:Find("left/biaoti")
    self.shengli = self.ui:Find("left/biaoti/shengli")
    self.shibai = self.ui:Find("left/biaoti/shibai")
    self.mingci = self.ui:Find("left/biaoti/mingci")
    self.mingciImg = self.mingci:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.weiwancheng = self.ui:Find("left/biaoti/weiwancheng")
    self.taotai = self.ui:Find("left/biaoti/taotai")
    self.pingju = self.ui:Find("left/biaoti/pingju")
    --比分
    self.bifen = self.ui:Find("left/bifen")
    --蓝方
    self.baiBlue = self.bifen:Find("baiBlue")
    self.shiBlue = self.bifen:Find("shiBlue")
    self.geBlue = self.bifen:Find("geBlue")
    self.baiBlueImg = self.baiBlue:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.shiBlueImg = self.shiBlue:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.geBlueImg = self.geBlue:GetComponent(typeof(CS.UnityEngine.UI.Image))
    --红方
    self.baiRed = self.bifen:Find("baiRed")
    self.shiRed = self.bifen:Find("shiRed")
    self.geRed = self.bifen:Find("geRed")
    self.baiRedImg = self.baiRed:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.shiRedImg = self.shiRed:GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.geRedImg = self.geRed:GetComponent(typeof(CS.UnityEngine.UI.Image))
    --评分数据
    self.Scores = self.ui:Find("left/bgdown/Scores")
    self.ScoresItem = self.ui:Find("left/bgdown/ScoresItem")
    self.ScoresItem.gameObject:SetActive(false) -- 确保模板是隐藏的
    self.CountList = {}
    self.currentScoresData = GAME_RESULT_SCORE_DATA_CONFIG[App.modPlatform]
    for index, key in ipairs(self.currentScoresData) do
        self.CountList[key] = self:createScoreItem()
        self.CountList[key].TitleTxt.text = GAME_RESULT_DATA_DISPLAY[key].display
        self.CountList[key].UnitTxt.text = GAME_RESULT_DATA_DISPLAY[key].unit
    end

    --学习表现
    self.SSS = self.ui:Find("left/bgdown/biaoxian/SSS")
    self.SSSImg = self.SSS:GetComponent(typeof(CS.UnityEngine.UI.Image))

    --奖励
    --学识
    self.xueshi = self.ui:Find("left/jianglibg/jiangliParent/xueshi")
    self.xueshiTxt = self.xueshi:Find("xueshiTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.xueshiImg = self.xueshi:Find("xueshiImg"):GetComponent(typeof(CS.UnityEngine.UI.Image))
    --芝士
    self.zhishi = self.ui:Find("left/jianglibg/jiangliParent/zhishi")
    self.zhishiTxt = self.zhishi:Find("zhishiTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.zhishiImg = self.zhishi:Find("zhishiImg"):GetComponent(typeof(CS.UnityEngine.UI.Image))
    --宠物经验
    -- self.petExp = self.ui:Find("left/jianglibg/jiangliParent/chongwujingyan")
    -- self.petExpTxt = self.petExp:Find("chongwujingyanTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    -- self.petExpImg = self.petExp:Find("chongwujingyanImg"):GetComponent(typeof(CS.UnityEngine.UI.Image))

    --自己形象
    self.SelfPlayer = self.ui:Find("SelfPlayer")
    self.avartImg_selfPlayer = self.SelfPlayer:Find("avartImg"):GetComponent(typeof(CS.UnityEngine.UI.Image))
    self.mvp_selfPlayer = self.SelfPlayer:Find("mvp")
    self.svp_selfPlayer = self.SelfPlayer:Find("svp")
    self.schoolTxt_selfPlayer = self.SelfPlayer:Find("schoolTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.schoolbg_selfPlayer = self.SelfPlayer:Find("schoolbg")
    self.nameTxt_selfPlayer = self.SelfPlayer:Find("nameTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    --游戏数据
    self.chengjiContent_selfPlayer = self.SelfPlayer:Find("chengjiContent")
    --成绩项item 自己和对应的其他玩家都使用同一个模板
    self.chengjiItem = self.SelfPlayer:Find("chengjiItem")
    self.chengjiItem.gameObject:SetActive(false) -- 确保模板是隐藏的

    --其他玩家形象
    self.OtherPlayers = self.ui:Find("OtherPlayers")
    self.otherPlayerContent_otherPlayer = self.OtherPlayers:Find("Viewport/Content")
    self.otherPlayerItem_otherPlayer = self.OtherPlayers:Find("otherPlayerItem")
    self.otherPlayerItem_otherPlayer.gameObject:SetActive(false) -- 确保模板是隐藏的

    --分享拍照按钮
    self.fenxiangBtn = self.ui:Find("fenxiangBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.fenxiangBtn, "onClick", function()
        self:OnFenxiangBtnClick()
    end)
    -- self.fenxiangBtn.gameObject:SetActive(false)

    --退出按钮
    self.tuichuBtn = self.ui:Find("bottom/tuichuBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.tuichuBtn, "onClick", function()
        self:OnTuichuBtnClick()
    end)
    self.tuichu_text = self.tuichuBtn.gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))

    --再来一局按钮
    self.zailaiyiju = self.ui:Find("bottom/zailaiyiju")
    self.zailaiyiju.gameObject:SetActive(false)
    self.zailaiyijuBtn = self.zailaiyiju:Find("zailaiyijuBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.zailaiyijuBtn, "onClick", function()
        self:OnZailaiyijuBtnClick()
    end)
    self.zailaiyijuBtn.transform:Find("Text"):GetComponent(typeof(CS.UnityEngine.UI.Text)).text = "x1 再来一局"

    --匹配队列UI
    self.queue = self.zailaiyiju:Find("queue")
    self.queue.gameObject:SetActive(false)
    self.canclQueueBtn = self.queue:Find("Button"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.canclQueueBtn, "onClick", function()
        self:OnCancleQueueBtnClick()
    end)

    -- 匹配队列文本UI
    self.queueStrsRoot = self.queue:Find("str")
    self.queueList = self.queue:Find("list")

    --配置
    self.Config = self.ui:Find("Config")
    --音效
    self.jiesuanbgm = self.Config:Find("jiesuanbgm").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
    --蓝色0-9
    self.blue = self.Config:Find("blue")
    self.blueSprites = {}
    for i = 0, 9 do
        self.blueSprites[i] = self.blue:Find(tostring(i)):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    end
    --红色0-9
    self.red = self.Config:Find("red")
    self.redSprites = {}
    for i = 0, 9 do
        self.redSprites[i] = self.red:Find(tostring(i)):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    end
    ---名次1-10
    self.mingciCfg = self.Config:Find("mingci")
    self.mingciSprites = {}
    for i = 1, 10 do
        self.mingciSprites[i] = self.mingciCfg:Find(tostring(i)):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    end
    --表现 S SS SSS A B C
    self.biaoxianCfg = self.Config:Find("biaoxian")
    self.biaoxianSprites = {}
    self.biaoxianSprites["S"] = self.biaoxianCfg:Find("S"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.biaoxianSprites["SS"] = self.biaoxianCfg:Find("SS"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.biaoxianSprites["SSS"] = self.biaoxianCfg:Find("SSS"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.biaoxianSprites["A"] = self.biaoxianCfg:Find("A"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.biaoxianSprites["B"] = self.biaoxianCfg:Find("B"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
    self.biaoxianSprites["C"] = self.biaoxianCfg:Find("C"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
end

function GameResultUI:createScoreItem()
    local item = CS.UnityEngine.GameObject.Instantiate(self.ScoresItem, self.Scores)
    item.transform:SetParent(self.Scores.transform)
    item.transform.localScale = CS.UnityEngine.Vector3.one
    item.transform.localPosition = CS.UnityEngine.Vector3.zero
    local TitleTxt = item.transform:Find("Title"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    local CountTxt = item.transform:Find("Count"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    local UnitTxt = item.transform:Find("Unit"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    local bg = item.transform:Find("bg")
    bg.gameObject:SetActive(false)

    CountTxt.resizeTextForBestFit = true --开启最佳适应 防止超框
    TitleTxt.text = ""
    UnitTxt.text = ""
    CountTxt.text = ""
    item.gameObject:SetActive(true)
    return {
        item = item,
        TitleTxt = TitleTxt, --文字内容
        CountTxt = CountTxt, --分数
        UnitTxt = UnitTxt    --单位
    }
end

--展示结算UI
function GameResultUI:ShowResultUI()
    -- 先清理所有之前创建的UI元素
    self:ClearChengjiItems()
    self:ClearOtherPlayerItems()

    self:SetTitleInfo()
    self:GetReward()
    self:SetSelfPlayer()
    self:SetOtherPlayers()
    self:TuichuBtnTextCountDown()
    self:SetMatchingBtn()
    self:PlayBackgroundMusic()
    self.ui.gameObject:SetActive(true)
end

--隐藏结算UI
function GameResultUI:HideResultUI()
    self:StopBackgroundMusic()
    self.ui.gameObject:SetActive(false)
end

--endregion


--region 按钮事件-----------------------------------------------------------------------------------------------------------------------------

--分享按钮点击
function GameResultUI:OnFenxiangBtnClick()
    self:Print("分享按钮点击")
    -- 拍照分享
    self.observerService:Fire("ABCZONE_FULL_SCREEN_SHARE_SCREEN", {
        from = "4"
    })
end

--退出按钮点击
function GameResultUI:OnTuichuBtnClick()
    self:Print("退出按钮点击")
    local Tuichu = function()
        self:HideResultUI()
        if self.clickCloseCallBack then
            self.clickCloseCallBack()
        end
        App:GameReturn()
        self:Fire(ON_GAME_RESULT_UI_TUICHU_BTN_CLICK)
        self.observerService:Fire(GAME_RESULT_SET_MAIN_PANEL, { isShow = true })
    end

    --如果在匹配中 先取消匹配在退出
    if self.isMatching then
        self:CancelMatching(Tuichu)
    else
        Tuichu()
    end
end

--再来一局按钮点击
function GameResultUI:OnZailaiyijuBtnClick()
    self:Print("再来一局按钮点击")
    self:reportData("resule_play_again", "再来一次", {
        param_one = self.game_id
    })
    if self.clickAgainCallBack then
        self.clickAgainCallBack()
    end
    self:resetVariable()
    -- 开始匹配
    self:StartMatching()
    self:Fire(ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK)
    self.observerService:Fire(GAME_RESULT_SET_MAIN_PANEL, { isShow = true })
end

--匹配队列按钮点击（取消排队）
function GameResultUI:OnCancleQueueBtnClick()
    self:Print("取消匹配队列按钮点击")
    self.canclQueueBtn.interactable = false
    self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(1)
        self.canclQueueBtn.interactable = true
    end)
    self:CancelMatching()
    self:Fire(ON_GAME_RESULT_UI_CANCEL_QUEUE_BTN_CLICK)
end

--endregion

--region 标题信息-----------------------------------------------------------------------------------------------------------------------------

---设置标题信息
function GameResultUI:SetTitleInfo()
    if self.titleData == nil then
        self:Print("标题类型为空")
        return
    end
    local titleType = self.titleData.titleType

    self.weiwancheng.gameObject:SetActive(false)
    self.shengli.gameObject:SetActive(false)
    self.shibai.gameObject:SetActive(false)
    self.taotai.gameObject:SetActive(false)
    self.mingci.gameObject:SetActive(false)
    self.pingju.gameObject:SetActive(false)

    --设置标题类型 1未完成 2淘汰 3胜利 4失败 5名次
    if titleType == 1 then
        self.weiwancheng.gameObject:SetActive(true)
    elseif titleType == 2 then
        self.taotai.gameObject:SetActive(true)
    elseif titleType == 3 then
        self.shengli.gameObject:SetActive(true)
    elseif titleType == 4 then
        self.shibai.gameObject:SetActive(true)
    elseif titleType == 5 then
        self.mingci.gameObject:SetActive(true)
        -- 设置名次显示
        self:SetMingci()
    elseif titleType == 6 then
        self.pingju.gameObject:SetActive(true)
    end

    -- 设置比分显示
    self:SetTeamScore()
end

---设置名次显示
function GameResultUI:SetMingci()
    if self.titleData == nil then
        self:Print("标题类型为空")
        return
    end
    local mingci = self.titleData.mingci
    if mingci == nil then
        self.mingci.gameObject:SetActive(false)
        return
    end

    -- 检查名次是否在有效范围内
    if mingci < 1 or mingci > #self.mingciSprites or not self.mingciSprites[mingci] then
        self:Print("名次超出范围或精灵不存在，名次:", mingci)
        self.mingci.gameObject:SetActive(false)
        return
    end
    -- 使用名次精灵数组设置图片
    self.mingciImg.sprite = self.mingciSprites[mingci]
    self.mingci.gameObject:SetActive(true)
end

---设置比分
function GameResultUI:SetTeamScore()
    if self.titleData == nil then
        self:Print("标题类型为空")
        return
    end
    local teamScore = self.titleData.teamScore
    if teamScore == nil then
        self.bifen.gameObject:SetActive(false)
        return
    end
    -- 使用新的比分显示方法
    self:SetTeamScoreDisplay(teamScore)
    self.bifen.gameObject:SetActive(true)
end

---设置队伍比分显示
---@param teamScore table 队伍比分数组 {蓝方分数, 红方分数}
function GameResultUI:SetTeamScoreDisplay(teamScore)
    if not teamScore or #teamScore < 2 then
        self:Print("teamScore数据无效")
        return
    end

    local blueScore = teamScore[1] or 0
    local redScore = teamScore[2] or 0
    -- 设置蓝方比分显示
    self:SetScoreDisplay(blueScore, true)
    -- 设置红方比分显示
    self:SetScoreDisplay(redScore, false)
end

---设置单方比分显示
---@param score number 分数
---@param isBlue boolean 是否为蓝色方 true=蓝色 false=红色
function GameResultUI:SetScoreDisplay(score, isBlue)
    local baiImg, shiImg, geImg

    if isBlue then
        baiImg = self.baiBlueImg
        shiImg = self.shiBlueImg
        geImg = self.geBlueImg
    else
        baiImg = self.baiRedImg
        shiImg = self.shiRedImg
        geImg = self.geRedImg
    end

    -- 只隐藏对应颜色的位数
    if isBlue then
        self.baiBlue.gameObject:SetActive(false)
        self.shiBlue.gameObject:SetActive(false)
        self.geBlue.gameObject:SetActive(false)
    else
        self.baiRed.gameObject:SetActive(false)
        self.shiRed.gameObject:SetActive(false)
        self.geRed.gameObject:SetActive(false)
    end

    if score < 10 then
        -- 1位数：只显示个位
        if isBlue then
            self.geBlue.gameObject:SetActive(true)
        else
            self.geRed.gameObject:SetActive(true)
        end
        geImg.sprite = self:numberToSprite(score, isBlue)
    elseif score < 100 then
        -- 2位数：显示十位和个位
        if isBlue then
            self.shiBlue.gameObject:SetActive(true)
            self.geBlue.gameObject:SetActive(true)
        else
            self.shiRed.gameObject:SetActive(true)
            self.geRed.gameObject:SetActive(true)
        end

        local shiWei = math.floor(score / 10) % 10 -- 十位数字
        local geWei = score % 10                   -- 个位数字

        shiImg.sprite = self:numberToSprite(shiWei, isBlue)
        geImg.sprite = self:numberToSprite(geWei, isBlue)
    else
        -- 3位数：显示百位、十位和个位
        if isBlue then
            self.baiBlue.gameObject:SetActive(true)
            self.shiBlue.gameObject:SetActive(true)
            self.geBlue.gameObject:SetActive(true)
        else
            self.baiRed.gameObject:SetActive(true)
            self.shiRed.gameObject:SetActive(true)
            self.geRed.gameObject:SetActive(true)
        end

        local baiWei = math.floor(score / 100) % 10 -- 百位数字
        local shiWei = math.floor(score / 10) % 10  -- 十位数字
        local geWei = score % 10                    -- 个位数字

        baiImg.sprite = self:numberToSprite(baiWei, isBlue)
        shiImg.sprite = self:numberToSprite(shiWei, isBlue)
        geImg.sprite = self:numberToSprite(geWei, isBlue)
    end
end

---数字转换为精灵
---@param number number 数字
---@param isBlue boolean 是否为蓝色方 true=蓝色 false=红色
function GameResultUI:numberToSprite(number, isBlue)
    local digit = number % 10 -- 获取个位数字
    if isBlue then
        return self.blueSprites[digit]
    else
        return self.redSprites[digit]
    end
end

--endregion

--region 匹配按钮&&退出按钮-----------------------------------------------------------------------------------------------------------------------------

---退出按钮文本倒计时
function GameResultUI:TuichuBtnTextCountDown()
    self.tuichu_text.text = "退出"
    self.tuichu_text.fontStyle = CS.UnityEngine.FontStyle.Bold;

    -- 不需要显示再来一局
    if self.needShowMatching ~= true then
        return
    end
    if self.tuiChuCountDownCor then
        self.commonService:StopCoroutineSafely(self.tuiChuCountDownCor)
    end
    self.tuiChuCountDownCor = self.commonService:StartCoroutine(function()
        local countDown = 30
        while countDown > 0 do
            --改文本 （退出（30s））
            self.tuichu_text.text = "退出(" .. countDown .. "s)"
            self.commonService:YieldSeconds(1)
            countDown = countDown - 1

            if self.powerEnough == false then
                self.tuichu_text.text = "退出"
                return
            end
        end
        -- 执行退出返回主场景
        self:OnTuichuBtnClick()
    end)
end

---设置匹配按钮显示
function GameResultUI:SetMatchingBtn()
    if self.matchData == nil then
        self:Print("匹配数据为空！！！！！")
        return
    end

    local checkMatchingBtn = function()
        self:RequestHasPower(function(hasPower)
            self:GameMatchingReq(function(needShowMatching)
                -- 体力够用或者需要显示再来一局 暂时用or 判断
                if hasPower == true or needShowMatching == true then
                    self:Print("结果页：体力够用", hasPower, needShowMatching)
                    self.zailaiyiju.gameObject:SetActive(true)
                else
                    self:Print("结果页：体力不足", hasPower, needShowMatching)
                    self.zailaiyiju.gameObject:SetActive(false)
                end
            end)
        end)
    end

    --不显示按钮 这种情况页要检查一次 暂时保留原来逻辑 ??????
    if self.needShowMatching == true and self.matchData.closeBtnType ~= 3 and self.gameMode ~= 2 and self.gameMode ~= 1 then
        checkMatchingBtn()
        self:Print("SetMatchingBtn checkMatchingBtn 根据体力判断 需要显示再来一局按钮")
        --1 = 3秒后自动关闭(不显示关闭按钮 退出按钮)
    elseif self.matchData.closeBtnType == 1 then
        self.zailaiyiju.gameObject:SetActive(false)
        self.tuichuBtn.gameObject:SetActive(false)
        local time = 3
        if self.has_upgrade then
            time = 6
        end
        self.commonService:DispatchAfter(time, function()
            self:OnTuichuBtnClick()
            if self.autoCloseCallBack then
                self.autoCloseCallBack()
            end
        end)
        --   2 = 只显示关闭按钮
    elseif self.matchData.closeBtnType == 2 then
        self.tuichuBtn.gameObject:SetActive(true)
        self.zailaiyiju.gameObject:SetActive(false)
        --   3 = 显示关闭和再来一局按钮
    elseif self.matchData.closeBtnType == 3 then
        self.tuichuBtn.gameObject:SetActive(true)
        checkMatchingBtn()
    end

    self:Print("SetMatchingBtn 匹配按钮显示类型:", self.matchData.closeBtnType)
    self:Print("SetMatchingBtn 游戏模式:", self.gameMode)
end

--endregion


--region 个人玩家数据-----------------------------------------------------------------------------------------------------------------------------

---根据UUID获取玩家信息并设置显示
function GameResultUI:SetSelfPlayer()
    -- 设置学习表现评级
    self:SetSelfPlayerStudyScoreSSS()
    -- 设置个人学习成绩
    self:SetSelfPlayerStudyScore()
    -- 设置个人信息
    self:SetPlayerInfo(App.Uuid, self.avartImg_selfPlayer, self.nameTxt_selfPlayer, self.schoolTxt_selfPlayer,
        self.schoolbg_selfPlayer)
    -- 设置MVP/SVP状态
    self:SetPlayerMVPAndSVP(App.Uuid, self.mvp_selfPlayer, self.svp_selfPlayer)
    -- 个人游戏数据展示（清理已在ShowResultUI中统一处理）
    self:SetPlayerGameData(App.Uuid, self.chengjiContent_selfPlayer, function(dataKey)
        return self:CreateChengjiItemForPlayer(App.Uuid, dataKey, self.chengjiContent_selfPlayer)
    end)
end

---设置个人学习表现评级
function GameResultUI:SetSelfPlayerStudyScoreSSS()
    if self.playerStudyScoreStats == nil then
        self:Print("玩家学习成绩为空")
        return
    end

    local grade = self:CalculateStudyGrade()
    -- 设置对应的评级图片
    if grade and self.biaoxianSprites[grade] then
        self.SSSImg.sprite = self.biaoxianSprites[grade]
        self.SSS.gameObject:SetActive(true)
        self:Print("学习表现评级:", grade)
    else
        self.SSS.gameObject:SetActive(false)
        self:Print("未达到评级标准或评级不存在")
    end
end

---计算学习成绩等级
---@return string|nil 返回等级字符串 SSS/SS/S/A/B 或 nil
function GameResultUI:CalculateStudyGrade()
    -- 英语
    if App.modPlatform == MOD_PLATFORM.ABCZone then
        -- 获取三个关键数据
        local avgScore = self.playerStudyScoreStats.avgScore or GAME_RESULT_DATA_DISPLAY.avgScore.default or
            0 -- 开口平均分
        local readCount = self.playerStudyScoreStats.readSentenceCount or
            GAME_RESULT_DATA_DISPLAY.readSentenceCount.default or
            0 -- 朗读句子数
        local accuracyRate = self.playerStudyScoreStats.sentenceAccuracyRate or
            GAME_RESULT_DATA_DISPLAY.sentenceAccuracyRate.default or
            0 -- 句子准确率%
        -- SSS级：开口平均分>=95，朗读句子数>=7，朗读准确率>=100%
        if avgScore >= 95 and readCount >= 7 and accuracyRate >= 100 then
            return "SSS"
        end

        -- SS级：开口平均分>=90，朗读句子数>=7，朗读准确率>=90%
        if avgScore >= 90 and readCount >= 7 and accuracyRate >= 90 then
            return "SS"
        end

        -- S级：开口平均分>=80，朗读句子数>=7，朗读准确率>=80%
        if avgScore >= 80 and readCount >= 7 and accuracyRate >= 80 then
            return "S"
        end

        -- A级：开口平均分>=70，朗读句子数>=5，朗读准确率>=70%
        if avgScore >= 70 and readCount >= 5 and accuracyRate >= 70 then
            return "A"
        end

        -- B级：开口平均分>=60，朗读句子数>=3，朗读准确率>=60%
        if avgScore >= 60 and readCount >= 3 and accuracyRate >= 60 then
            return "B"
        end
        -- C级：不满足以上任何条件
        -- 根据图片显示，C级是"-"，表示不显示具体数值
        return "C"
    elseif App.modPlatform == MOD_PLATFORM.Math then
        --TODO 数学平台
        return "C"
    elseif App.modPlatform == MOD_PLATFORM.Math then
        --TODO 语文平台

        return "C"
    end
end

---设置个人学习成绩
function GameResultUI:SetSelfPlayerStudyScore()
    if self.playerStudyScoreStats == nil then
        self:Print("玩家学习成绩为空")
        return
    end
    --学习表现 评分数据
    for index, key in ipairs(self.currentScoresData) do
        local value = self.playerStudyScoreStats[key]
        if not value then
            self:Print("评分数据不存在 key= ", key)
            value = GAME_RESULT_DATA_DISPLAY[key].default
            if GAME_RESULT_DATA_DISPLAY[key].default then
                value = 0
                self:Print("评分数据不存在 key= 请配置GAME_RESULT_DATA_DISPLAY 默认值为0 ", key)
            end
        end
        self.CountList[key].CountTxt.text = GAME_RESULT_DATA_DISPLAY[key].displayformat and
        GAME_RESULT_DATA_DISPLAY[key].displayformat(value) or tostring(value)
    end
end

---个人获得奖励显示 学识、芝士、宠物经验
function GameResultUI:GetReward()
    -- 处理学识数据
    local xueshiNum = 0
    if self.awardData and self.awardData.xueshi then
        xueshiNum = self.awardData.xueshi
    else
        xueshiNum = self.xueshiFromAnswer
    end

    -- 处理芝士数据
    local zhishiNum = 0
    if self.awardData and self.awardData.zhishi then
        zhishiNum = self.awardData.zhishi
    else
        --zhishiNum = self.addZhishiNum
        zhishiNum = self.add_cheese_val or 0
    end

    -- 处理宠物经验数据
    local petExpNum = 0
    if self.awardData and self.awardData.petExp then
        petExpNum = self.awardData.petExp
    else
        petExpNum = self.petExpFromAnswer
    end

    -- 显示学识奖励
    if xueshiNum > 0 then
        self.xueshiTxt.text = tostring(xueshiNum)
        self.xueshi.gameObject:SetActive(true)
        self:Print("显示学识奖励:", xueshiNum)
    else
        self.xueshiTxt.text = "0"
        -- self.xueshi.gameObject:SetActive(false)  -- 可以选择隐藏或显示0
    end

    -- 显示芝士奖励
    if zhishiNum > 0 then
        self.zhishiTxt.text = tostring(zhishiNum)
        self.zhishi.gameObject:SetActive(true)
        self:Print("显示芝士奖励:", zhishiNum)
    else
        self.zhishiTxt.text = "0"
        -- self.zhishi.gameObject:SetActive(false)  -- 可以选择隐藏或显示0
    end

    --TODO 宠物经验？？？？？
    -- if petExpNum > 0 then
    --     self.petExpTxt.text = tostring(petExpNum)
    --     self.petExp.gameObject:SetActive(true)
    --     self:Print("显示宠物经验奖励:", petExpNum)
    -- else
    --     self.petExpTxt.text = "0"
    --     -- self.petExp.gameObject:SetActive(false)  -- 可以选择隐藏或显示0
    -- end

    -- 从开局消息监听是否为读课文模式 这里暂时不处理
    if self.activeQuestionType ~= nil and self.activeQuestionType == 1 then
        -- contentType = 5
    end

    self:Print("奖励统计完成 - 学识:", xueshiNum, "芝士:", zhishiNum, "宠物经验:", petExpNum)
end

--endregion




--region 其他玩家数据-----------------------------------------------------------------------------------------------------------------------------

---设置其他玩家形象
function GameResultUI:SetOtherPlayers()
    self:Print("创建其他玩家形象")

    -- 清除之前创建的其他玩家项
    self:ClearOtherPlayerItems()

    -- 获取同队玩家
    local teammates = self:GetTeammates()
    local teammatesCount = teammates and #teammates or 0

    -- 根据队伍总人数设置自己和其他玩家的位置
    local totalPlayers = teammatesCount + 1 -- 包括自己
    self:SetPlayersUIPosition(totalPlayers, teammatesCount)

    -- 如果有其他玩家，创建其他玩家UI
    if teammates and #teammates > 0 then
        for i = 1, #teammates do
            local playerUuid = teammates[i]
            self:CreateOtherPlayerItem(playerUuid, i)
        end
    else
        self:Print("没有同队玩家，只显示自己")
    end

    self:SetOtherPlayerAddFriendBtnStatus()
end

---获取同队玩家
---@return table|nil 返回同队玩家UUID列表
function GameResultUI:GetTeammates()
    if not self.playerStats then
        self:Print("玩家统计数据为空")
        return nil
    end

    local gameConfig = GAME_RESULT_DATA_CONFIG[self.gameType]
    if gameConfig == nil then
        self:Print("获取游戏配置失败 gameType:", self.gameType)
        return
    end

    local teammates = nil

    --个人类型游戏
    if gameConfig.game_type == 1 then
        teammates = {}
        return teammates
    end

    --团队类型游戏
    local rule = gameConfig.game_teammates_rule
    if rule == nil then
        self:Print("获取游戏队友获取规则失败 gameType:", self.gameType)
        return
    end

    --团队游戏
    local get_type = rule.get_type
    local teamTypeKey = gameConfig.teamTypeKey
    if not teamTypeKey then
        self:Print("获取游戏队友获取规则失败 teamTypeKey= 请配置GAME_RESULT_DATA_CONFIG ", teamTypeKey)
        return nil
    end

    local sortKey = nil 
    --团队类型游戏 不区分阵营类，直接使用排序关键字
    if get_type == 1 then
        sortKey = rule.sortKey
    --团队类型游戏 根据当前玩家阵营获取队友排序关键字
    elseif get_type == 2 then
        local sortKeys = rule.sortKey
        if not sortKeys then
            self:Print("获取游戏队友获取规则失败 sortKeys= 请配置GAME_RESULT_DATA_CONFIG ", sortKeys)
            return nil
        end

        local selfTeamType = self.playerStats[App.Uuid][teamTypeKey]
        if not selfTeamType then
            self:Print("获取游戏队友获取规则失败 selfTeamType= 请配置GAME_RESULT_DATA_CONFIG ", selfTeamType)
            return nil
        end
        sortKey = sortKeys[selfTeamType]
        if not sortKey then
            self:Print("获取游戏队友获取规则失败 sortKey= 请配置GAME_RESULT_DATA_CONFIG ", sortKey)
            return nil
        end
    else
        self:Print("获取游戏队友获取规则失败 get_type= 请配置GAME_RESULT_DATA_CONFIG ", get_type)
        return 
    end

    teammates = self:GetTeamTypeGameTeammates(teamTypeKey, sortKey)

    self:Print("找到同队玩家数量:", #teammates)
    return teammates
end

---获取团队类型游戏队友
---@param teamTypeKey string 队伍类型关键字
---@param sortKey string 排序关键字
---@return table 队友列表
function GameResultUI:GetTeamTypeGameTeammates(teamTypeKey, sortKey)
    local teammates = {}

    local selfTeamType = nil
    -- 获取自己的身份
    if self.playerStats[App.Uuid] and self.playerStats[App.Uuid][teamTypeKey] then
        selfTeamType = self.playerStats[App.Uuid][teamTypeKey]
    else
        selfTeamType = 1 -- 默认值
    end
    -- 遍历所有玩家，找到同队伍的队友
    for uuid, playerData in pairs(self.playerStats) do
        if uuid ~= App.Uuid and playerData[teamTypeKey] == selfTeamType then
            table.insert(teammates, uuid)
        end
    end

    if GAME_RESULT_DATA_DISPLAY[sortKey] == nil then
        self:Print("获取游戏关键项目数据失败 GAME_RESULT_DATA_DISPLAY[sortKey]= 请配置GAME_RESULT_DATA_DISPLAY ", sortKey)
        return {}
    end
    -- 根据击败人数进行排序（从高到低）
    local keySortRule = GAME_RESULT_DATA_DISPLAY[sortKey].key_sort_rule 
    if not keySortRule then
        self:Print("获取游戏关键项目数据失败 keySortRule= 请配置GAME_RESULT_DATA_DISPLAY ", keySortRule)
        return {}
    end

    if #teammates > 1 then
        table.sort(teammates, function(a, b)
            local scoreA = self.playerStats[a][sortKey] or 0
            local scoreB = self.playerStats[b][sortKey] or 0

            if keySortRule == 1 or keySortRule == nil then
                return scoreA > scoreB --值越大是mvp
            elseif keySortRule == 2 then
                return scoreA < scoreB --值越小是mvp
            end
            return scoreA > scoreB     --默认值越大是mvp
        end)
        self:Print("队友已按", sortKey, "从高到低排序, 数量:", #teammates)
    end
    return teammates
end

---设置玩家UI位置
---@param totalPlayers number 总玩家数（包括自己）
---@param otherPlayersCount number 其他玩家数量
function GameResultUI:SetPlayersUIPosition(totalPlayers, otherPlayersCount)
    -- 设置自己的位置和大小
    local selfConfigIndex = math.min(totalPlayers, #ui_SelfPlayerConfig)
    local selfConfig = ui_SelfPlayerConfig[selfConfigIndex]
    if selfConfig then
        self.SelfPlayer.transform.localPosition = selfConfig.pos
        self.SelfPlayer.transform.localScale = selfConfig.scale
        self:Print("设置自己UI位置, 总人数:", totalPlayers, "位置:", selfConfig.pos)
    end

    -- 设置其他玩家容器的位置和GridLayoutGroup配置
    if otherPlayersCount > 0 then
        -- 根据其他玩家数量获取配置
        local otherConfigIndex = math.min(otherPlayersCount, #ui_OtherPlayerConfig)
        local otherConfig = ui_OtherPlayerConfig[otherConfigIndex]
        if otherConfig then
            -- 设置OtherPlayers的位置
            self.OtherPlayers.transform.localPosition = otherConfig.pos
            -- 设置GridLayoutGroup的cellSize
            if otherConfig.size then
                local gridLayoutGroup = self.otherPlayerContent_otherPlayer:GetComponent(typeof(CS.UnityEngine.UI
                    .GridLayoutGroup))
                if gridLayoutGroup then
                    gridLayoutGroup.cellSize = Vector2(otherConfig.size.x, otherConfig.size.y)
                    self:Print("设置其他玩家GridLayoutGroup, cellSize:", otherConfig.size.x, otherConfig.size.y)
                else
                    self:Print("找不到GridLayoutGroup组件")
                end
            end

            self:Print("设置其他玩家容器位置, 其他玩家数量:", otherPlayersCount, "位置:", otherConfig.pos)
        end
        self.OtherPlayers.gameObject:SetActive(true)
    else
        self.OtherPlayers.gameObject:SetActive(false)
    end
end

---创建其他玩家项
---@param playerUuid string 玩家UUID
---@param index number 玩家索引
function GameResultUI:CreateOtherPlayerItem(playerUuid, index)
    if not self.otherPlayerItem_otherPlayer or not self.otherPlayerContent_otherPlayer then
        self:Print("其他玩家模板或容器不存在")
        return nil
    end

    -- 复制模板创建新的玩家项
    local newItem = CS.UnityEngine.Object.Instantiate(self.otherPlayerItem_otherPlayer,
        self.otherPlayerContent_otherPlayer)
    newItem.transform:SetParent(self.otherPlayerContent_otherPlayer.transform)
    newItem.transform.localScale = CS.UnityEngine.Vector3.one
    -- GridLayoutGroup会自动处理位置和大小，不需要手动设置

    -- 获取UI组件
    local avartImg = newItem.transform:Find("avartImg"):GetComponent(typeof(CS.UnityEngine.UI.Image))
    local mvp = newItem.transform:Find("mvp")
    local svp = newItem.transform:Find("svp")
    local schoolTxt = newItem.transform:Find("schoolTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    local schoolbg = newItem.transform:Find("schoolbg")
    local nameTxt = newItem.transform:Find("nameTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    local chengjiContent = newItem.transform:Find("chengjiContent")
    local addFrindBtn = newItem.transform:Find("addFrindBtm"):GetComponent(typeof(CS.UnityEngine.UI.Button))

    -- 设置玩家信息
    self:SetPlayerInfo(playerUuid, avartImg, nameTxt, schoolTxt, schoolbg)

    -- 设置MVP/SVP状态
    self:SetPlayerMVPAndSVP(playerUuid, mvp, svp)

    -- 设置游戏数据
    self:SetPlayerGameData(playerUuid, chengjiContent, function(dataKey)
        return self:CreateChengjiItemForPlayer(playerUuid, dataKey, chengjiContent)
    end)

    -- 添加好友按钮事件
    if addFrindBtn then
        self.commonService:AddEventListener(addFrindBtn, "onClick", function()
            self:OnAddFriendBtnClick(playerUuid, addFrindBtn)
        end)
        addFrindBtn.gameObject:SetActive(false)
    end

    newItem.gameObject:SetActive(true)

    -- 保存到列表中便于清理
    if not self.otherPlayerItemList then
        self.otherPlayerItemList = {}
    end
    table.insert(self.otherPlayerItemList, newItem)

    self:Print("创建其他玩家项成功, UUID:", playerUuid)

    if not self.otherPlayerItemMap then
        self.otherPlayerItemMap = {}
    end
    self.otherPlayerItemMap[playerUuid] = { item = newItem, addFrindBtn = addFrindBtn }

    return newItem
end

---设置其他玩家加好友按钮显示状态
function GameResultUI:SetOtherPlayerAddFriendBtnStatus()
    if not self.otherPlayerItemMap then
        self:Print("其他玩家项不存在")
        return
    end

    local union_ids = {}
    local addFrindBtnMapByUserId = {}
    local addFrindBtnMapByUnionId = {}

    for playerUuid, item in pairs(self.otherPlayerItemMap) do
        local avatar = self.avatarService:GetAvatarByUUID(playerUuid)
        if avatar then
            local UnionId = avatar:GetProperty("UnionId") or avatar.UnionId
            if UnionId and UnionId ~= "" then
                addFrindBtnMapByUnionId[tostring(UnionId)] = item.addFrindBtn
                table.insert(union_ids, UnionId)
                -- self:Print("SetOtherPlayerAddFriendBtnStatus 添加玩家UnionId, UUID:", playerUuid, "UnionId:", UnionId)
            else
                self:Print("SetOtherPlayerAddFriendBtnStatus 找不到玩家UnionId, UUID:", playerUuid)
            end

            local userId = avatar:GetProperty("UserId")
            if userId and userId ~= "" then
                addFrindBtnMapByUserId[tostring(userId)] = item.addFrindBtn
                -- self:Print("SetOtherPlayerAddFriendBtnStatus 添加玩家UserId, UUID:", playerUuid, "UserId:", userId)
            else
                self:Print("SetOtherPlayerAddFriendBtnStatus 找不到玩家UserId, UUID:", playerUuid)
            end
        else
            self:Print("SetOtherPlayerAddFriendBtnStatus 找不到玩家头像, UUID:", playerUuid)
        end
    end

    if #union_ids == 0 then
        self:Print("SetOtherPlayerAddFriendBtnStatus 没有其他玩家UnionId, 不显示加好友按钮")
        return
    end

    self.observerService:Fire(GET_PLAYERS_SCHOOL_INFO, {
        union_ids = union_ids,
        callback = function(data)
            if data and data.list and #data.list > 0 then
                for _, v in ipairs(data.list) do
                    self:Print("SetOtherPlayerAddFriendBtnStatus 获取学校信息成功, UUID:", "data= ", table.dump(v))
                    local userId = v.user_id
                    local union_id = v.union_id
                    ---UnionId 有时候是空字符串
                    if union_id and union_id ~= "" then
                        local addFrindBtn = addFrindBtnMapByUnionId[tostring(union_id)]
                        self:Print("SetOtherPlayerAddFriendBtnStatus 获取玩家UnionId, UUID:", "union_id= ", union_id)
                        self:Print("SetOtherPlayerAddFriendBtnStatus 获取玩家UnionId, UUID:", "union_id= ", addFrindBtn)
                        if addFrindBtn then
                            addFrindBtn.gameObject:SetActive(v.is_friend == 0)
                        end
                    end
                    --执行2次有2次吧，结果准确点
                    if userId and userId ~= "" then
                        local addFrindBtn = addFrindBtnMapByUserId[tostring(userId)]
                        self:Print("SetOtherPlayerAddFriendBtnStatus 获取玩家UserId, UUID:", "userId= ", userId)
                        self:Print("SetOtherPlayerAddFriendBtnStatus 获取玩家UserId, UUID:", "addFrindBtn= ", addFrindBtn)
                        if addFrindBtn then
                            addFrindBtn.gameObject:SetActive(v.is_friend == 0)
                        end
                    end
                end
            else
                self:Print("SetOtherPlayerAddFriendBtnStatus 获取学校信息失败, 不显示加好友按钮")
            end
        end
    })
end

--endregion

--region 通用设置玩家信息-----------------------------------------------------------------------------------------------------------------------------

---通用设置玩家信息方法
---@param playerUuid string 玩家UUID
---@param avartImg CS.UnityEngine.UI.Image 头像图片组件
---@param nameTxt CS.UnityEngine.UI.Text 名字文本组件
---@param schoolTxt CS.UnityEngine.UI.Text 学校文本组件
---@param schoolbg Transform 学校背景组件
function GameResultUI:SetPlayerInfo(playerUuid, avartImg, nameTxt, schoolTxt, schoolbg)
    if not self.playerStats[playerUuid] then
        self:Print("找不到玩家数据, UUID:", playerUuid)
        return
    end

    -- 设置玩家名字
    local avatar = self.avatarService:GetAvatarByUUID(playerUuid)
    if avatar then
        local userName = avatar:GetProperty("AvatarName") or avatar.nickName or "未知玩家"
        nameTxt.text = userName
    else
        nameTxt.text = "未知玩家"
    end

    -- 设置学校
    local schoolName = self.playerStats[playerUuid][GAME_RESULT_DATA_KEYS.SCHOOL]
    if schoolName == nil or schoolName == "" then
        schoolbg.gameObject:SetActive(false)
        schoolTxt.gameObject:SetActive(false)
        self:Print("学校名称空 不显示学校名称")
    else
        self:RefreshLimitText(schoolTxt, schoolName, 300)
        schoolbg.gameObject:SetActive(true)
        schoolTxt.gameObject:SetActive(true)
        self:Print("学校名称不空 显示学校名称")
    end

    -- 设置头像
    self:SetPlayerAvatar(playerUuid, avartImg)
end

---通用设置玩家头像方法
---@param playerUuid string 玩家UUID
---@param avartImg CS.UnityEngine.UI.Image 头像图片组件
function GameResultUI:SetPlayerAvatar(playerUuid, avartImg)
    if self.playerStats[playerUuid] == nil then
        self:Print("玩家数据为空, UUID:", playerUuid)
        return
    end

    if self.playerAvatarSprites[playerUuid] then
        avartImg.sprite = self.playerAvatarSprites[playerUuid]
        self:Print("玩家头像设置成功, UUID:", playerUuid)
        return
    end

    local avatarUrl = nil
    if self.playerStats[playerUuid][GAME_RESULT_DATA_KEYS.AVATAR_URL] then
        avatarUrl = self.playerStats[playerUuid][GAME_RESULT_DATA_KEYS.AVATAR_URL]
    end

    if not avatarUrl or avatarUrl == "" then
        self:Print("玩家头像URL为空，使用默认头像, UUID:", playerUuid)
        return
    end

    -- 下载网络头像
    self.httpService:LoadNetWorkTexture(avatarUrl, function(sprite)
        if sprite and avartImg then
            avartImg.sprite = sprite
            self:Print("玩家头像设置成功, UUID:", playerUuid)
        else
            self:Print("玩家头像设置失败, UUID:", playerUuid)
        end
    end)
end

---通用设置玩家MVP/SVP状态方法
---@param playerUuid string 玩家UUID
---@param mvp Transform MVP标识
---@param svp Transform SVP标识
function GameResultUI:SetPlayerMVPAndSVP(playerUuid, mvp, svp)
    mvp.gameObject:SetActive(false)
    svp.gameObject:SetActive(false)

    if self.isShowMVPStage == false then
        self:Print("不展示mvp舞台, UUID: 不展示MVPui 标签UI", playerUuid)
        return
    end

    ---单人游戏只有自己
    if self.mvpPlayerUuid == playerUuid then
        mvp.gameObject:SetActive(true)
    end
    if self.svpPlayerUuid == playerUuid then
        svp.gameObject:SetActive(true)
    end
end

---通用设置玩家游戏数据方法
---@param playerUuid string 玩家UUID
---@param chengjiContent Transform 成绩内容容器
---@param createItemFunc function 创建成绩项的函数
function GameResultUI:SetPlayerGameData(playerUuid, chengjiContent, createItemFunc)
    if not self.playerStats then
        self:Print("玩家统计数据为空")
        return
    end

    if not self.playerStats[playerUuid] then
        self:Print("找不到玩家游戏数据, UUID:", playerUuid)
        return
    end

    local gameConfig = GAME_RESULT_DATA_CONFIG[self.gameType]
    if gameConfig == nil then
        self:Print("获取游戏配置失败 gameType:", self.gameType)
        return
    end

    local dataConfig = nil

    -- 获取数据配置
    local rule = gameConfig.game_data_rule

    local get_type = rule.get_type
    if get_type == nil then
        self:Print("获取游戏数据配置失败 get_type= 请配置GAME_RESULT_DATA_CONFIG ", get_type)
        return
    end

    if get_type == 1 then
        -- 不根据队伍类型获取数据配置
        dataConfig = self:GetGameDataConfig(playerUuid, nil)
    elseif get_type == 2 then
        -- 根据队伍类型获取数据配置
        local teamTypeKey = gameConfig.teamTypeKey
        if teamTypeKey == nil then
            self:Print("获取游戏数据配置失败 teamTypeKey= 请配置GAME_RESULT_DATA_CONFIG ", teamTypeKey)
            return
        end
        dataConfig = self:GetGameDataConfig(playerUuid, teamTypeKey)
    end

    -- 通用逻辑：遍历数据配置创建成绩项（所有游戏都执行）
    if dataConfig == nil then
        self:Print("找不到数据配置")
        return
    end

    for index, key in ipairs(dataConfig) do
        createItemFunc(key)
    end
end

---获取团队类型游戏玩家游戏数据配置
---@param playerUuid string 玩家UUID
---@param teamTypeKey string|nil 队伍类型关键字 nil表示不根据队伍类型获取数据配置
---@return table|nil 返回数据配置
function GameResultUI:GetGameDataConfig(playerUuid, teamTypeKey)
    local dataConfig = nil
    if teamTypeKey then
        local playerTeamType = nil
        if self.playerStats[playerUuid] and self.playerStats[playerUuid][teamTypeKey] then
            playerTeamType = self.playerStats[playerUuid][teamTypeKey]
        end
        if not playerTeamType then
            self:Print("获取游戏数据失败 playerTeamType= ", playerUuid, "teamTypeKey= ", teamTypeKey, "playerTeamType= ", playerTeamType)
            return nil
        end
        dataConfig = GAME_RESULT_DATA_CONFIG[self.gameType].game_data_rule.game_data[playerTeamType]
    else
        dataConfig = GAME_RESULT_DATA_CONFIG[self.gameType].game_data_rule.game_data
    end
    self:Print("获取游戏数据配置 dataConfig= ", table.dump(dataConfig), "playerUuid= ", playerUuid, "teamTypeKey= ", teamTypeKey)
    return dataConfig
end

---通用创建成绩项方法
---@param playerUuid string 玩家UUID
---@param dataKey string 数据键值
---@param chengjiContent Transform 成绩内容容器
---@return table|nil 返回创建的UI项
function GameResultUI:CreateChengjiItemForPlayer(playerUuid, dataKey, chengjiContent)
    -- 获取数据，不存在时使用默认值0
    local dataValue = 0
    if self.playerStats[playerUuid] and self.playerStats[playerUuid][dataKey] then
        dataValue = self.playerStats[playerUuid][dataKey]
    else
        dataValue = GAME_RESULT_DATA_DISPLAY[dataKey].default
        if dataValue == nil then
            self:Print("玩家数据中不存在该键值，使用默认值0, UUID:", playerUuid, "dataKey:", dataKey)
            dataValue = 0
        end
    end

    -- 获取显示配置，不存在时使用默认值
    local display = ""
    local unit = ""
    if GAME_RESULT_DATA_DISPLAY[dataKey] then
        local displayInfo = GAME_RESULT_DATA_DISPLAY[dataKey]
        display = displayInfo.display or ""
        unit = displayInfo.unit or ""
    else
        self:Print("显示配置中不存在该键值，使用默认显示:", dataKey)
        display = dataKey -- 使用键值作为显示名称
    end

    local formatDataValue = GAME_RESULT_DATA_DISPLAY[dataKey].displayformat and
    GAME_RESULT_DATA_DISPLAY[dataKey].displayformat(dataValue) or tostring(dataValue)

    -- 拼接显示文本：如 "得分：34分"
    local displayText = display .. "：" .. formatDataValue .. unit

    -- 检查UI模板
    if not self.chengjiItem then
        self:Print("成绩项模板不存在")
        return nil
    end

    -- 检查容器
    if not chengjiContent then
        self:Print("成绩内容容器不存在")
        return nil
    end

    -- 复制模板创建新的成绩项
    local newItem = CS.UnityEngine.Object.Instantiate(self.chengjiItem, chengjiContent)
    newItem.transform:SetParent(chengjiContent.transform)
    newItem.transform.localScale = CS.UnityEngine.Vector3.one
    newItem.transform.localPosition = CS.UnityEngine.Vector3.zero

    -- 查找并设置文本
    local defengTxt = newItem.transform:Find("defeng")
    if defengTxt then
        local textComponent = defengTxt:GetComponent(typeof(CS.UnityEngine.UI.Text))
        if textComponent then
            textComponent.text = displayText
        else
            self:Print("defeng节点没有Text组件")
        end
    else
        self:Print("找不到defeng子节点")
    end

    newItem.gameObject:SetActive(true)

    -- 保存到列表中便于清理
    if not self.chengjiItemList then
        self.chengjiItemList = {}
    end
    table.insert(self.chengjiItemList, newItem)

    self:Print("创建成绩项成功, UUID:", playerUuid, "内容:", displayText)
    return newItem
end

---添加好友按钮点击事件
---@param playerUuid string 玩家UUID
---@param addFrindBtn CS.UnityEngine.UI.Button 添加好友按钮
function GameResultUI:OnAddFriendBtnClick(playerUuid, addFrindBtn)
    self:Print("点击添加好友按钮, UUID:", playerUuid)
    addFrindBtn.interactable = false
    self.commonService:DispatchAfter(1, function()
        addFrindBtn.interactable = true
    end)

    local avatar = self.avatarService:GetAvatarByUUID(playerUuid)
    if not avatar then
        self:Print("获取玩家信息失败 App.Uuid= ", playerUuid)
        return
    end

    local UnionId = avatar:GetProperty("UnionId") or avatar.UnionId
    if not UnionId then
        self:Print("获取玩家UnionId失败 App.Uuid= ", playerUuid)
        return
    end
    self:Print("申请加好友 UnionId= ", UnionId)

    local userId = avatar:GetProperty("UserId")
    if not userId then
        self:Print("获取玩家UserId失败 App.Uuid= ", playerUuid)
        return
    end
    self:Print("申请加好友 userId= ", userId)

    local params = {
        friend_union_id = UnionId,
        friend_user_id = userId
    }

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end

            if msg and msg.data then
                if msg.data.code == 0 then
                    self:Print("申请加好友成功!!")
                    --隐藏好友按钮
                    addFrindBtn.gameObject:SetActive(false)
                    return
                else
                    self:Print("申请加好友失败!!")
                end
            end
        end
    end

    local fail = function(res)
        self:Print("申请加好友失败!!", table.dump(res))
    end

    self:HttpRequest("/v3/friend/apply", params, success, fail)
end

---清除其他玩家项
function GameResultUI:ClearOtherPlayerItems()
    if self.otherPlayerItemList then
        --这删不掉
        -- for i = #self.otherPlayerItemList, 1, -1 do
        --     local item = self.otherPlayerItemList[i]
        --     if item then
        --         CS.UnityEngine.Object.Destroy(item)         -- CS.UnityEngine.Object.DestroyImmediate(self.otherPlayerItemList[i])
        --     end
        -- end
        self.otherPlayerItemList = {}
    end
    --删除 下方所有子物体
    if self.otherPlayerContent_otherPlayer then
        local childCount = self.otherPlayerContent_otherPlayer.transform.childCount
        for i = childCount - 1, 0, -1 do
            CS.UnityEngine.Object.Destroy(self.otherPlayerContent_otherPlayer.transform:GetChild(i).gameObject)
        end
    end

    if self.otherPlayerItemMap then
        self.otherPlayerItemMap = {}
    end
end

--endregion

---清除之前创建的成绩项
function GameResultUI:ClearChengjiItems()
    if self.chengjiItemList then
        --这删不掉
        -- for i = #self.chengjiItemList, 1, -1 do
        --     self:Print("清除之前创建的成绩项chengjiItemList222",i,self.chengjiItemList[i])
        --     local item = self.chengjiItemList[i]
        --     if item then
        --         CS.UnityEngine.Object.Destroy(item)                -- CS.UnityEngine.Object.DestroyImmediate(item)
        --     end
        -- end
        self.chengjiItemList = {}
    end

    --删除 下方所有子物体
    if self.chengjiContent_selfPlayer then
        local childCount = self.chengjiContent_selfPlayer.transform.childCount
        for i = childCount - 1, 0, -1 do
            CS.UnityEngine.Object.Destroy(self.chengjiContent_selfPlayer.transform:GetChild(i).gameObject)
        end
    end
end

---文本显示优化 超过限制之后显示省略号
---@param textComponent CS.UnityEngine.UI.Text 文本组件
---@param str string 文本
---@param maxWidth number 最大宽度
function GameResultUI:RefreshLimitText(textComponent, str, maxWidth)
    if not textComponent or not str or not maxWidth then
        self:Print("文本组件或文本为空")
        return
    end
    textComponent.text = str
    local preferredWidth = textComponent.preferredWidth
    if preferredWidth > maxWidth then
        local finalStr = str
        local count = utf8.len(str)
        for i = 2, count, 1 do
            -- 使用 utf8.offset 获取正确的字节位置
            local endPos = utf8.offset(str, i)
            local testStr = str:sub(1, endPos - 1) .. "..."
            textComponent.text = testStr
            if textComponent.preferredWidth > maxWidth then
                -- 同样使用 utf8.offset 获取正确的字节位置
                local prevPos = utf8.offset(str, i - 1)
                finalStr = str:sub(1, prevPos - 1) .. "..."
                break
            end
        end
        textComponent.text = finalStr
    end
end

--region 匹配相关-----------------------------------------------------------------------------------------------------------------------------

---初始化匹配相关
function GameResultUI:InitMatching()
    --切后台时取消匹配
    self.pauseFunction = function(pause)
        self.hasPause = pause
        if self.hasPause and self.hasPause ~= nil then
            if self.isMatching == true then
                self:CancelMatching()
            end
        end
    end

    self.commonService:DispatchAfter(1, function()
        if self.gate.worldController.World.OnApplicationPauseAction == nil then
            self.gate.worldController.World.OnApplicationPauseAction = self.pauseFunction
        else
            self.gate.worldController.World.OnApplicationPauseAction =
                self.gate.worldController.World.OnApplicationPauseAction + self.pauseFunction
        end
    end)

    if App.IsStudioClient then
        self:GameMatchingReq()
    end
end

---开始匹配
function GameResultUI:StartMatching()
    self:Print("开始匹配排队")
    -- 防止多次点击
    if self.isMatching == true then
        self:Print("已经在匹配中，忽略重复点击")
        return
    end
    self.isMatching = true
    self.hasJump = false

    -- 禁用按钮
    self.zailaiyijuBtn.interactable = false

    -- 设置queue初始状态
    self.queue.gameObject:SetActive(false)
    self.queue.transform.localScale = Vector3(0.5, 0.5, 1)
    local cg = self.queue:GetComponent(typeof(CS.UnityEngine.CanvasGroup))
    cg.alpha = 0

    -- 播放动画：显示匹配UI，隐藏再来一局按钮
    local seq = DOTween.Sequence()
    seq:AppendCallback(function()
        self.zailaiyijuBtn.gameObject:SetActive(false)
        self.queue.gameObject:SetActive(true)
    end)
    seq:Append(self.queue.transform:DOScale(1, 0.3))
    seq:Join(DOTween.To(function()
        return cg.alpha
    end, function(x)
        cg.alpha = x
    end, 1, 0.3))

    -- 设置初始文本
    self:SetMatchingText({ "等待" })

    -- 发送排队请求
    self:SendQueueUpRequest()

    -- 启动超时自动取消（12秒后自动取消）
    if self.matchingCor then
        self.commonService:StopCoroutineSafely(self.matchingCor)
    end
    self.matchingCor = self.commonService:StartCoroutine(function()
        self.commonService:YieldSeconds(12)
        self:Print("匹配超时，自动取消")
        self:CancelMatching()
    end)
end

---发送排队请求
function GameResultUI:SendQueueUpRequest()
    local params = {
        game_id = self.game_id,
        room_id = App.Info.roomId,
        plan_id = self.plan_id
    }

    if self.origin_game_id then
        params.game_id = self.origin_game_id
    end

    self:Print("发送排队请求", table.dump(params))

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            self:Print("排队成功：", resp)
            if msg and msg.code == 0 and msg.data then
                local data = {}
                if msg.data.qid then
                    data.qid = tostring(msg.data.qid)
                end
                data.grade = tonumber(msg.data.grade)
                data.level = tonumber(msg.data.level)
                if msg.data.queue_type then
                    data.queue_type = tonumber(msg.data.queue_type)
                end
                self.matchingData = data
                self:Print("排队数据：", table.dump(self.matchingData))
            end
        end
    end

    local fail = function(res)
        self:Print("排队失败：", table.dump(res))
        if res.error and res.error ~= "" then
            local msg = string.gsub(res.error, "%b()", "")
            g_LogError(msg)
        end
    end

    self:HttpRequest("/v3/game/queue-up", params, success, fail)
end

---取消匹配
---@param callback function 取消成功后的回调
function GameResultUI:CancelMatching(callback)
    self:Print("取消匹配排队")

    -- 停止超时协程
    if self.matchingCor then
        self.commonService:StopCoroutineSafely(self.matchingCor)
        self.matchingCor = nil
    end

    -- 隐藏匹配UI，显示再来一局按钮
    self.queue.gameObject:SetActive(false)
    self.zailaiyijuBtn.gameObject:SetActive(true)
    self.zailaiyijuBtn.transform.localScale = Vector3.one

    -- 恢复按钮交互
    self.commonService:DispatchAfter(2, function()
        self.zailaiyijuBtn.interactable = true
    end)

    self.isMatching = false

    -- 发送取消排队请求
    if self.matchingData ~= nil then
        self:SendCancelQueueRequest(callback)
    else
        if callback then
            callback(true)
        end
    end
end

---发送取消排队请求
---@param callback function 回调函数
function GameResultUI:SendCancelQueueRequest(callback)
    local params = {
        game_id = tostring(self.game_id),
        room_id = App.Info.roomId,
        plan_id = tostring(self.plan_id),
        team_id = self.teamId and tonumber(self.teamId) or nil,
        user_id = tostring(App.Info.userId)
    }

    local data = self.matchingData
    if data ~= nil then
        params.qid = data.qid
        params.grade = data.grade
        params.level = data.level
        params.queue_type = data.queue_type
    end

    if self.origin_game_id then
        params.game_id = self.origin_game_id
    end

    self:Print("发送取消排队请求", table.dump(params))

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                self:Print("已取消排队")
                self.matchingData = nil
                if callback then
                    callback(true)
                end
                return
            end
        end
        if callback then
            callback(false)
        end
    end

    local fail = function(res)
        g_LogError("取消排队失败")
        g_LogError(table.dump(res))
        if callback then
            callback(false)
        end
    end

    self:HttpRequest("/v3/game/queue-cancel", params, success, fail)
end

---设置匹配文本显示
---@param strs table 字符串数组，如 {"1", "/", "5"}
function GameResultUI:SetMatchingText(strs)
    if not self.queueStrsRoot or not self.queueList then
        self:Print("匹配文本UI不存在")
        return
    end

    -- 隐藏所有配置的文本
    for i = 0, self.queueStrsRoot.childCount - 1, 1 do
        self.queueStrsRoot:GetChild(i).gameObject:SetActive(false)
    end

    -- 设置显示的文本
    for i = 1, #strs, 1 do
        if self.queueList.childCount >= i then
            local img = self.queueList:GetChild(i - 1):GetComponent(typeof(CS.UnityEngine.UI.Image))
            img.gameObject:SetActive(true)

            local tr = self.queueStrsRoot:Find(strs[i])
            if tr == nil then
                if strs[i] == "/" then
                    tr = self.queueStrsRoot:GetChild(10) -- "/" 符号在第11个位置（索引10）
                end
            end

            if tr then
                img.sprite = tr:GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite
                img:SetNativeSize()
            end
        end
    end
end

---数字转字符串数组
---@param number number 数字
---@return table 字符串数组
function GameResultUI:NumberToStringArray(number)
    local str = tostring(number)
    local array = {}
    for i = 1, #str do
        local char = str:sub(i, i)
        table.insert(array, char)
    end
    return array
end

---请求体力是否足够
---@param callBack function 回调函数
function GameResultUI:RequestHasPower(callBack)
    if App.IsStudioClient then
        callBack(true)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = "https://app.chuangjing.com/next-api/v3/user/power/is-enough",
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = {
                game_id = 86
            }
        }, function(res)
            local resp = res.responseString
            local data = self.jsonService:decode(res.responseString)
            if data.data then
                g_Log("lsh消耗体力是否足够" .. tostring(data.data.is_enough))
                self.powerEnough = data.data.is_enough
                if self.powerEnough == true then
                    g_Log("结果页：体力够用")
                else
                    g_Log("结果页：体力不足")
                end
            else
                g_Log("结果页：体力请求出错")
            end

            callBack(self.powerEnough)
        end)
    end
end

---求判断是否需要显示再来一局（初始化会调用的接口）
---@param callBack function 回调函数
function GameResultUI:GameMatchingReq(callBack)
    if App.IsStudioClient then
        self.needShowMatching = true
        if callBack then
            callBack(self.needShowMatching)
        end
        return
    end

    --请求判断是否需要通用再来一局的排队
    local url = "/v3/game/get-game-by-id"

    local params = {
        game_id = tonumber(self.game_id)
    }
    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
                -- once_again
                if msg.data.once_again == 1 then
                    -- 这里同时要判断防沉迷
                    self.needShowMatching = true
                    CourseEnv.ServicesManager:GetObserverService():Fire("EVENT_GET_ANTI_ADDICTION_CONTINUOUS_STATE", {
                        callBack = function(isLimit)
                            if isLimit then
                                g_LogError("防沉迷限制再来一局")
                                self.needShowMatching = false
                            end
                        end
                    })
                    local appVersion = App.Info.appVersionNumber
                    if appVersion then
                        if tonumber(appVersion) < 10800 then
                            self.needShowMatching = false
                        end
                    end
                    if callBack then
                        callBack(self.needShowMatching)
                    end
                    return
                end
            end
            if msg and msg.code == 0 then
                if callBack then
                    callBack(self.needShowMatching)
                end
                return
            end
        end
    end

    self:HttpRequest(url, params, success, function(res)
        -- fail
        g_LogError("get-game_by_id fail")
        g_LogError(table.dump(res))
        if callBack then
            callBack(false)
        end
    end)
end

--endregion

--region 背景音乐-----------------------------------------------------------------------------------------------------------------------------

---播放背景音乐
function GameResultUI:PlayBackgroundMusic()
    self:StopBackgroundMusic()
    self.jiesuanbgmAudioSource = self.audioService:PlayClipLoop(self.jiesuanbgm)
end

---停止背景音乐
function GameResultUI:StopBackgroundMusic()
    if self.jiesuanbgmAudioSource then
        self.audioService:StopAudioClip(self.jiesuanbgmAudioSource)
        self.jiesuanbgmAudioSource = nil
    end
end

--endregion

--region TOOls-----------------------------------------------------------------------------------------------------------------------------

-- http请求地址封装
---@param request string 请求地址
---@param params table 请求参数
---@param success function 成功回调
---@param fail function 失败回调
function GameResultUI:HttpRequest(request, params, success, fail)
    local url = "https://app.chuangjing.com/abc-api" .. request
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041" .. request
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

---格式化时间
---@param seconds number 时间
---@return number 分钟
---@return number 秒钟
function GameResultUI:FormatTime(seconds)
    if seconds == nil or seconds < 0 then
        return "0'00''"
    end
    local minutes = math.floor(seconds / 60)
    local remainingSeconds = seconds % 60
    -- -- 格式化分钟和秒钟
    -- local formattedTime = string.format("%d'%02d''", minutes, remainingSeconds)
    -- return formattedTime

    return minutes, remainingSeconds
end

---埋点
---@param eventId string 事件ID
---@param label string 标签
---@param value table 值
---@param action string 动作
function GameResultUI:reportData(eventId, label, value, action)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(eventId, "67881", "Special-Interaction", label,
            action, value)
    else
        g_Log("埋点数据", eventId, label)
    end
end

---埋点
---@param eventId string 事件ID
---@param action string 动作
function GameResultUI:reportLog(eventId, action)
    local param = {}
    param["modName"] = App.modName
    param["liveId"] = App.Info.liveId
    param["userId"] = App.Info.userId
    param["eventId"] = eventId
    param["eventtype"] = eventId
    param["action"] = action
    if self.game_id then
        param["param_one"] = self.game_id
    end
    if self.set_id then
        param["param_two"] = self.set_id
    end
    if self.plan_id then
        param["param_three"] = self.plan_id
    end
    APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
end

---打印日志
function GameResultUI:Print(...)
    g_Log("【结算UI】", ...)
end

--endregion

--region IRC消息接收-----------------------------------------------------------------------------------------------------------------------------

---接收Peer消息（用于排队更新）
---@param key string 消息key
---@param value string 消息值
function GameResultUI:ReceivePeerMessage(key, value)
    if not self.queue then
        return
    end

    local content = value
    local res = nil
    if content and type(content) == 'string' then
        res = self.jsonService:decode(content)
    end

    local data = self.matchingData

    -- 数学不需要判断
    if App.modPlatformId ~= MOD_PLATFORM.Math then
        if data == nil then
            -- 数据为空，跳过
        else
            if ((data.qid and res.qid == data.qid) or data.queue_type == 0) or data.qid == "" then
                -- 匹配
            else
                self:Print("data排队消息不匹配:")
                self:Print(table.dump(data))
                self:Print(table.dump(res))
                return
            end
        end
    end

    -- 排队人数更新
    if key == ("queue_up_num" .. App.Info.roomId) then
        if self.matchingCor then
            self.commonService:StopCoroutineSafely(self.matchingCor)
            self.matchingCor = nil
        end

        if value and type(value) == 'string' then
            local data = self.jsonService:decode(value)
            local userId = tostring(data.user_id)
            if userId == tostring(App.Info.userId) then
                -- 更新显示：num/max_num
                local num = self:NumberToStringArray(data.num)
                local max = self:NumberToStringArray(data.max_num)
                local concat = {}

                for i = 1, #num do
                    table.insert(concat, num[i])
                end
                table.insert(concat, "/")
                for i = 1, #max do
                    table.insert(concat, max[i])
                end

                self:SetMatchingText(concat)
                self:Print("更新排队人数:", data.num, "/", data.max_num)
            end
        end

        -- 排队成功，跳转游戏
    elseif key == ("queue_up_succ" .. App.Info.roomId) then
        local data = self.jsonService:decode(value)
        local gameId = data.game_id
        local userId = tostring(data.user_id)
        local joinRoomScheme = self.jsonService:decode(data.join_room_scheme)

        if (userId == tostring(App.Info.userId)) and not self.hasJump then
            if self.matchingCor then
                self.commonService:StopCoroutineSafely(self.matchingCor)
                self.matchingCor = nil
            end

            self.hasJump = true
            self:Print("排队成功，准备跳转游戏")

            local request = {
                ["planId"] = data.plan_id,
                ["paramDic"] = {
                    roomId = joinRoomScheme.room_id,
                    byPass = self.jsonService:encode({
                        game_id = gameId
                    })
                },
                ["isGameScene"] = true
            }

            APIBridge.RequestAsync("app.api.jump.switch", request, function(res)
                self:Print("跳转游戏完成")
            end)
        end
    end
end

---接收IRC消息
---@param key string 消息key
---@param value table 消息数组
function GameResultUI:ReceiveMessage(key, value)
    if key == fsync_activateRoom then
        local lastMsg = value[#value]
        if lastMsg then
            self:Print("activateRoom " .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if msg.question_type then
                    self.activeQuestionType = tonumber(msg.question_type)
                else
                    self.activeQuestionType = 0
                end

                if msg.game_type then
                    self.gameMode = tonumber(msg.game_type)
                    self:Print("游戏模式" .. self.gameMode)
                end

                self.game_id = msg.game_id
                self.set_id = msg.set_id
                self.plan_id = msg.plan_id
                self.origin_game_id = msg.origin_game_id
                self:GameMatchingReq()
            end
        end
    elseif key == game_remote_params then
        local lastMsg = value[#value]
        if lastMsg then
            self:Print("game_remote_params " .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if msg.game_id then
                    self.game_id = msg.game_id
                end
                if msg.set_id then
                    self.set_id = msg.set_id
                end
                if msg.plan_id then
                    self.plan_id = msg.plan_id
                end
            end
        end
    end
end

--endregion

return GameResultUI
