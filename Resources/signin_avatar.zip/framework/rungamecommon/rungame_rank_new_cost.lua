---
---  Author: 【彩滨滨】
---  AuthorID: 【246276】
---  CreateTime: 【2023-6-20 15:30:46】
--- 【FSync】
--- 【跑酷游戏客户端】
--- 客户端协议定义：
--- state:1 玩家加入
--- state:2 玩家答完一道题
--- state:3 玩家退出
------ 服务端协议定义：
--- state:1 10道题目，10种随机地形序列，开启3倒计时
--- state:2 服务端通知自己等待超过60秒
--- state:3 
--- state:4 刷新实时排行榜
--- state:5 一名玩家已完成，所有玩家开始15秒倒计时
--- state:6 游戏结束,并推送排行榜
--- state:7 n名玩家加入游戏
--- state:8 1名玩家提前完成游戏

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local RunGameElement = class("rungame_comlogic", WBElement)

local Fsync_Server_KEY = "runGame_server_key"
local Fsync_Client_KEY = "runGame_client_key"
local Tag = "RunGameRankNewCost"

---@param worldElement CS.Tal.framesync.WorldElement
function RunGameElement:initialize(worldElement)
    RunGameElement.super.initialize(self, worldElement)

    g_Log(Tag .. "初始化跑酷公共逻辑")
    -- 隐藏按住说话
    CourseEnv.ServicesManager:GetUIService():SetHidenVoiceBtnWithID()
    APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
        open = false,
        isShow = false,
        topSafeArea = 0
    }, function()

    end)
    --订阅KEY消息
    self:SubscribeMsgKey(Fsync_Server_KEY)
    self:SubscribeMsgKey(Fsync_Server_KEY .. "1")
    self:SubscribeMsgKey(Fsync_Server_KEY .. "3")
    self:SubscribeMsgKey("activateRoom")
    -- 添加初始化完成埋点
    self:reportLog("RunGameInitFinish")

    -- 延迟1s后
    self.commonService:DispatchAfter(1, function()
        self:answerQuestion()
        --显示能量条
        --self.nengliang.gameObject:SetActive(true)
        self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_INIT_SLIDER", {
            notShow = false,
            numerator = self.initEnergy,
            denominator = self.maxEnergy
        })
        self.currentEnergy = self.initEnergy
    end)
end

function RunGameElement:setVisElement(parent,VisElement)
    self.parent = parent
    self.VisElement = VisElement
    self:initService()
    self:initConfig()
    self:initListener()
    self:InitView()
    g_Log("完成初始化操作" .. self.VisElement.name)
end

function RunGameElement:initService()
    self.commonService = App:GetService("CommonService")
    self.observerService =  CourseEnv.ServicesManager:GetObserverService()
    self.joyService = CourseEnv.ServicesManager:GetJoystickService()
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
end

function RunGameElement:initConfig()
    self.level_array_string = self.configService:GetConfigValueByConfigKey(self.VisElement, "level_array_string")
    self.workSpace = CS.UnityEngine.GameObject.Find("Workspace")
    self.level_array_obj = self.workSpace.transform:FindInAll(self.level_array_string )
    self.endAudio = self.configService:GetAssetByConfigKey(self.VisElement, "EndAudio", true)
    self.finishAudio = self.configService:GetAssetByConfigKey(self.VisElement, "FinishAudio", true)
    self.countDownAudio = self.configService:GetAssetByConfigKey(self.VisElement, "count_down_audio",true)
    self.questionNum = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "questionNum"))
    self.randomTerr = self.configService:GetConfigValueByConfigKey( self.VisElement ,"randomTerr")
    self.question_array_string = self.configService:GetConfigValueByConfigKey(self.VisElement, "questionObj_array_string")
    self.startImage = self.configService:GetAssetByConfigKey(self.VisElement, "startImage", true)  
    -- 获取能量条满音频
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/paokuRes/"
    ResourceManager:LoadAudioClipWithExName(ResourcePathRoot .. "audios/energyFullAudio.mp3", function(audioclip)
        self.energyFullAudio = audioclip
    end)

    -- 加速倍数
    self.speedFactor = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "speedFactor"))
    -- 加速时长
    self.speedTime = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "speedTime"))
    -- 加速技能消耗
    self.speedCost = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "speedCost"))
    -- 单次开口通过加分
    self.singleAdd = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "singleAdd"))
    -- 是否是休闲赛模式
    self.isCasual = self.configService:GetConfigValueByConfigKey( self.VisElement ,"isCasual")

    self.setId = 1
    self.url = "https://app.chuangjing.com/next-api"
    if App.Info.configMap.env ~= "online" then
        self.url = "https://app-test.chuangjing.com/next-api"
    end
    local fps = App.Info.configMap.frame_num
    if fps == nil then
        fps = 15
    end
    self.fps = fps
    CourseEnv.ServicesManager.Gate:SetSendFPS(fps)
    -- 开始倒计时相关
    self.isRun = false
    self.questionObj = {}
    self.curQuestionIndex = 1
    -- 结束倒计时先关
    self.yellowNumImage = {}
    for i = 0, 9 do
        ---@type CS.UnityEngine.Sprite
        self.yellowNumImage[i] = self.configService:GetAssetByConfigKey(self.VisElement, "num_" .. i, true)
    end
    self.audio = self.configService:GetAssetByConfigKey(self.VisElement, "countDownAudio")
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(false)
    self.hasStartPlay = false
    -- 是否展示过段位结算页
    self.isShowRankPanel = false
    -- 开口次数
    self.openMouseCount = 0
    self.doneQuestion = 0
    self.isInitialized = false
    self.state = 0 -- 3 开始结算 4 结算完自己 5提前结算 6 最终结算完
    -- 游戏已经开始
    self.gameStart = false
    -- 当前人物前进最大距离
    self.maxDistance = 0
    -- 查找起始点
    self.startPos = CS.UnityEngine.GameObject.Find("SpawnServices")
    -- 当前能量值
    self.currentEnergy = 0
    self.initEnergy = 100
    self.maxEnergy = 150
    self.isWeak = false
    -- 当前复活点
    self.curRecoverPos = 0
    -- 游戏开始时间
    self.startTime = os.time()
    -- 埋点辅助
    self.finishCount = 0
    self.endCountsReported = false
    -- 复活点通过记录：checkpointId -> set(goName)
    self.checkpointPassers = {}
    -- 汇总/埋点去重
    self.recoverSummaryReported = false
    self.speakReported = false
end

function RunGameElement:initListener()
    -- 监听到底部答题面板高度变化
    self.observerService:Watch("Bottom_Answer_Panel_Size",function(key, value)
        if value[0] and value[0].height then
            g_Log("冲刺跑酷:底部答题面板高度变化" .. value[0].height)
            self.commonService:Yield(
                self.commonService:WaitUntil(function()
                    return self.nengliang ~= nil
                end)
            )
            self.nengliang.anchoredPosition = Vector2(self.nengliang.anchoredPosition.x, value[0].height)
        end
    end)
    -- 添加中途退出埋点上报
    self.observerService:Watch("quitVerify",function()
        local param = {}
        param["modName"] = App.modName
        param["liveId"] = App.Info.liveId
        param["userId"] = App.Info.userId
        param["openMouseCount"] = self.openMouseCount
        param["doneQuestion"] = self.doneQuestion
        param["questionNum"] = self.questionNum
        param["eventId"] = "GameQuitMidway"
        param["eventtype"] = "GameQuitMidway"
        param["time"] = os.time() - self.startTime
        g_LogError("跑酷:中途退出上报" .. table.dump(param))
        APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
    end)
    local recovers = self.level_array_obj:Find("复活点").gameObject:GetComponentsInChildren(typeof(CS.UnityEngine.Transform))
    -- 缓存复活点位置，按子节点名数字顺序
    self.recoverPoints = {}
    for i = 0, recovers.Length - 1 do
        local recover = recovers[i]
        local index = tonumber(recover.name)
        if index then
            self.recoverPoints[index] = recover.position
            CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(recover.gameObject, function(other)
                -- 记录所有玩家对该复活点的首次通过（基于 GO 名称去重）
                if self.checkpointPassers == nil then
                    self.checkpointPassers = {}
                end
                if self.checkpointPassers[index] == nil then
                    self.checkpointPassers[index] = {}
                end
                if self.checkpointPassers[index][other.name] == nil then
                    self.checkpointPassers[index][other.name] = true
                end

                -- 仅当是自己时，刷新自身当前复活点进度
                if other.name == self.selfAvatar.VisElement.gameObject.name then
                    g_Log("刷新复活点")
                    if index > self.curRecoverPos then
                        self.curRecoverPos = index
                    end
                end
            end)
        end
    end

    self.observerService:Watch("TP2LastPoint",function()
        -- local objStr = "关卡布置/复活点/" .. tostring(self.doneQuestion)
        -- local point = worldElement.transform:Find(objStr).transform.position
        local point = self.level_array_obj:Find("复活点/" .. tostring(self.curRecoverPos)).transform.position

        if self.selfAvatar then
            self.selfAvatar:TeleportAndNotice(point,true)
            g_Log("客户端:掉落，传送回上一个点" .. "point-" .. self.curRecoverPos)
        end
        self.observerService:Fire("isCloseAudio",{isCloseAudio=false})
    end)
    self.observerService:Watch("startSettle",function()
        g_Log("客户端:触发退出逻辑")
        -- 未结算
        if self.state < 3 then
            local reportData = {}
            reportData.setId = self.setId
            reportData.rank = 8
            reportData.score = 0
            reportData.award = 0
            reportData.is_run = true
            reportData.isFailed = true
            self.parent:Trigger("startRankPanel")
            if self.isShowRankPanel == false then
                self.isShowRankPanel = true
                self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",reportData)
            end
        else
            -- 已经结算
            self.parent:Trigger("startRankPanel")
            if self.isShowRankPanel == false then
                self.isShowRankPanel = true
                self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",{})
            end
        end
        self.state = 5
        self:EndCountDownEnd()
        self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
            status = 2})
        self.commonService:DispatchAfter(3,function()
            self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                status = 2})
        end)
    end)

    local collider = self.level_array_obj:Find("终点/终点触发区域")
    if collider ~= nil then
        -- 终点位置缓存
        self.endPointPos = collider.transform.position
    end
    local finalObj = self.level_array_obj:Find("终点")
    CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(collider.gameObject, function(other)
        if other.name == self.selfAvatar.VisElement.gameObject.name then
            if self.hasFinished == true then
                return
            end
            g_Log("碰撞到终点，完成游戏")
            -- 到终点关闭横幅
            if finalObj ~= nil then
                finalObj.gameObject:SetActive(false)
            end
            self:SendCustomMessage(Fsync_Client_KEY, { state = 4,UserId = App.Properties.UserId})
            self.hasFinished = true
            self.finishCount = 1
            self:closeAnswerQuestion()
        end
    end)
end

function RunGameElement:reportLog(eventId)
    local param = {}
    param["modName"] = App.modName
    param["liveId"] = App.Info.liveId
    param["userId"] = App.Info.userId
    param["eventId"] = eventId
    param["eventtype"] = eventId
    APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
end

-- 结束时上报：开口次数
function RunGameElement:reportSpeakCountEnd()
    if self.speakReported == true then
        return
    end
    local param = {}
    param["modName"] = App.modName
    param["liveId"] = App.Info.liveId
    param["userId"] = App.Info.userId
    param["eventId"] = "parkour_speak_count"
    param["eventtype"] = "parkour_speak_count"
    param["openMouseCount"] = self.openMouseCount or 0
    g_Log("跑酷:结束上报开口次数 openMouseCount=" .. tostring(param["openMouseCount"]))
    APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
    self.speakReported = true
end

-- 结束时上报：复活点通过次数（每个通过的复活点上报一条）
function RunGameElement:reportCheckpointPassesEnd()
    if self.recoverSummaryReported == true then
        return
    end
    if self.checkpointPassers == nil then
        return
    end
    local hasAny = false
    for id, passerSet in pairs(self.checkpointPassers) do
        local count = 0
        if passerSet ~= nil then
            for _ in pairs(passerSet) do
                count = count + 1
            end
        end
        if count > 0 then
            hasAny = true
            local param = {}
            param["modName"] = App.modName
            param["liveId"] = App.Info.liveId
            param["userId"] = App.Info.userId
            param["eventId"] = "parkour_respawnPointId_passCount"
            param["eventtype"] = "parkour_respawnPointId_passCount"
            param["recoverPointId"] = id
            param["passCount"] = count
            g_Log("跑酷:结束上报复活点通过 id=" .. tostring(id) .. ", count=" .. tostring(count))
            APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
        end
    end
    if hasAny then
        self.recoverSummaryReported = true
    end
end
-- 游戏结束上报：通关次数与开口次数
-- 删除 reportEndCounts（已由细分埋点替代）

function RunGameElement:InitView()
    -- 隐藏按钮
    -- CourseEnv.ServicesManager:GetUIService():hidenCommonMenu()
    CourseEnv.ServicesManager:GetUIService():SetHidenFollowBtnWithID()

    if not App.IsStudioClient then
        -- self.level_array_obj:Find("复活点").gameObject:SetActive(false)
    end

    -- 添加调试快捷按钮
    if App:IsDebug() == false then
        self.VisElement.transform:Find("屏幕画布/传送").gameObject:SetActive(false)
    else
        self.VisElement.transform:Find("屏幕画布/传送").gameObject:SetActive(false)
    end
    -- 等待人数
    self.loading = self.VisElement.transform:Find("屏幕画布/背景").gameObject
    self.loading:SetActive(false)
    -- 提醒关闭弹窗
    self.root = self.VisElement.gameObject
    self.rootTrans = self.root.transform
    self.tipDialog = self.rootTrans:FindChildWithName("跑酷超时提醒弹窗")
    self.dialogTitle = self.tipDialog:FindChildWithName("Title")
    self.dialogTitleTmp = self.dialogTitle:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogTitleTmp.text = ""
    self.dialogConfirm = self.tipDialog:FindChildWithName("Confirm")
    self.dialogConfirmBtn= self.dialogConfirm:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.dialogConfirmText = self.dialogConfirm:FindChildWithName("text")
    self.dialogConfirmTmp = self.dialogConfirmText:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogConfirmTmp.text = "确定"
    self.dialogConfirmTmp.color = CS.UnityEngine.Color(1,1,1,1)
    self.dialogContent = self.tipDialog:FindChildWithName("Content")
    self.dialogContentTmp = self.dialogContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogContentTmp.text = "小伙伴失联了哦，退回到首页重新开始吧~"
    self.commonService:AddEventListener(self.dialogConfirmBtn, "onClick", function()
        self.tipDialog.gameObject:SetActive(false)
        App:GameReturn()
    end)
    self.tipDialog.gameObject:SetActive(false)
    -- 结束页面
    self.endPanel = self.VisElement.transform:Find("屏幕画布/结束").gameObject
    self.endPanel:SetActive(false)
    self.endPanelexitBtn = self.VisElement.transform:Find("屏幕画布/结束/结束页面/退出按钮").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.endPanelexitBtn, "onClick", function()
        App:GameReturn()
    end)
    if self.isCasual == "True" then
        self.endPanelexitBtn.gameObject:SetActive(true)
    end
    -- 开始页面
    self.startPanel = self.VisElement.transform:Find("屏幕画布/开始页面").gameObject
    self.startPanel:GetComponentsInChildren(typeof(CS.UnityEngine.UI.Image))[0].sprite = self.startImage
    self.startPanel:SetActive(false)
    -- 观战按钮
    self.obBtn = self.VisElement.transform:Find("屏幕画布/观战").gameObject
    self.obBtn:SetActive(false)

    -- 获取能量条UI
    self.nengliangRoot = self.VisElement.transform:Find("新跑酷UI/Asset")
    local canvas = self.nengliangRoot.gameObject:GetComponent(typeof(CS.UnityEngine.Canvas))
    canvas.sortingOrder = 1000

    self.nengliang = self.nengliangRoot:Find("nengliang")
    self.nengliang.localScale = CS.UnityEngine.Vector3(0.7, 0.7, 1)
    self.nengliang.gameObject:SetActive(false)

    local rectTransform = self.nengliang:GetComponent(typeof(CS.UnityEngine.RectTransform))
    rectTransform.pivot = Vector2(0.5, 0);
    rectTransform.anchorMin = Vector2(0.5, 0);
    rectTransform.anchorMax = Vector2(0.5, 0);
    rectTransform.anchoredPosition = Vector2(0, 200);

    self.nengliangtiao = self.nengliang:Find("nengliangtiao")
    self.nengliangtiaoRect = self.nengliangtiao:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.nengliangzhi = self.nengliang:Find("nengliangzhi")

    self.nengliangzhi:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition = Vector2(169.1, 30.2)

    self.nengliangText1 = self.nengliang:Find("text1").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.nengliangText2 = self.nengliang:Find("text2").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

    self.nengliangtiaoAnim = self.nengliang:Find("mask/anim")
    self.nengliangtiaoAim = self.nengliang:Find("nengliangtiao/aim")

    self.nengliang.gameObject:SetActive(false)
    -- 冲刺按钮UI（已停用）
     self.speedBtnRoot = self.nengliangRoot:Find("speedBtn")
     self.speedBtnRoot.gameObject:SetActive(false)
    --self.speedBtnDisable = self.speedBtnRoot:Find("disable")
    -- self.speedBtnDisable.gameObject:SetActive(true)
    -- self.speedBtnNormal = self.speedBtnRoot:Find("normal")
    -- self.speedBtnNormal.gameObject:SetActive(false)
    -- self.speedBtn = self.speedBtnRoot:Find("btn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    -- -- self.speedBtn.gameObject:SetActive(false)
    -- -- 添加按钮事件
    -- self.commonService:AddEventListener(self.speedBtn, "onClick", function()
    --     if self.currentEnergy < 100 then
    --         CourseEnv.ServicesManager:GetUIService().commonMenu:ShowToast("开口充能后才能冲刺呀！",
    --                             2)
    --     else
    --         -- 点击加速按钮
    --         g_LogError("点击加速按钮,开始加速")
    --         self.remainSpeedTime = self.speedTime
    --         self:AddEnergy(-self.speedCost)
    --     end
    -- end)
end

function RunGameElement:GetRecoverPosition()
    for i = 1, 10 do
        -- body
    end

    -- 获取self.level_array_obj的所有子节点
    local children = self.level_array_obj:GetComponentsInChildren(typeof(CS.UnityEngine.Transform))
    for i = 0, children.Length - 1 do
        local child = children[i]
        local pos = child.position
        local startPos = self.startPos.transform.position
        local distance = Vector3.Distance(pos, startPos)

    end
end

-- 开始倒计时开始
function RunGameElement:StartCountStart()
    if self.isRun then return end
    self.isRun = true
    self:Clear()
    self.countDownCanvas = self.VisElement.gameObject.transform:Find("倒计时UI/Asset/CountDownCanvas")
    self.effect = self.countDownCanvas:Find("countdown_321_go")
    self.effect.gameObject:SetActive(true)
    if self.finishAudio then
        self.audioService:PlayClipOneShot(self.countDownAudio)
    else
        g_LogError("开始倒计时音频未配置")
    end
    
    -- 倒计时播放完后开始赛车
    self.seq = DOTween:Sequence()
    self.seq:AppendInterval(4)
    self.seq:AppendCallback(function()
        self.effect.gameObject:SetActive(false)
        self:Clear()
        self.isRun = false
        self:StartCountDownEnd()
    end)
end

-- 开始倒计时结束
function RunGameElement:StartCountDownEnd()
    g_Log("客户端:倒计时完成，正式开始游戏")
    self.level_array_obj:Find("空气墙/起始点控制空气墙").gameObject:SetActive(false)
    self.parent:Trigger("CountDownEnd")

    self.gameStart = true
    -- 开始游戏，正式开始持续答题
    self:answerQuestion()
    -- 显示能量条
    --self.nengliang.gameObject:SetActive(true)
    self:ReduceEnergy()
end

function RunGameElement:Clear()
    if self.seq then
        self.seq:Kill()
        self.seq = nil
    end
end

-- 结束倒计时开始
function RunGameElement:EndCountDownStart(countDownNum)
    if countDownNum == 10 then
        if self.hasStartPlay == false then
            self.hasStartPlay = true
            if self.audio then
                self.audioSource = self.audioService:PlayClipOneShot(self.audio)
            end
            APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
                open = false,
                isShow = false,
                topSafeArea = 0
            }, function()
        
            end)
             -- 隐藏按住说话按钮
            CourseEnv.ServicesManager:GetUIService():SetHidenVoiceBtnWithID()
        end
    end
    self.countDown = countDownNum
    g_Log("客户端:开始结束前倒计时" .. self.countDown)
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(true)
    local num1 = math.floor(self.countDown / 10)
    local num2 = self.countDown % 10
    self.VisElement.transform:Find("屏幕画布/背景图片/数字3"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite = self.yellowNumImage[num1]
    self.VisElement.transform:Find("屏幕画布/背景图片/数字4"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite = self.yellowNumImage[num2]
end

-- 结束倒计时结束
function RunGameElement:EndCountDownEnd()
    g_Log("客户端:结束结束前倒计时")
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(false)
    if self.audioSource then
        self.audioService:StopAudioClip(self.audioSource)
    end
end

function RunGameElement:updateWaitingNum(num,totalNum)
    if self.loading then
        self.loading.transform:Find("标题"):GetComponent(typeof(CS.UnityEngine.UI.Text)).text = "等待好友加入挑战 " .. num .. "/" .. totalNum
        self.loading.transform:Find("正文"):GetComponent(typeof(CS.UnityEngine.UI.Text)).text = num .. "个小伙伴，已经进入挑战啦~"
    end
end

function RunGameElement:uploadCostTL()
    local totalUrl = self.url .. "/v3/user/power/cost"
    local param = {
        game_id = 7
    }

    APIBridge.RequestAsync('api.httpclient.request', {
        ["url"] = totalUrl,
        ["headers"] = {
            ["Content-Type"] = "application/json"
        },
        ["data"] = param
    }, function(res)
        if res ~= nil and res.responseString ~= nil and res.isSuccessed then
            local resp = res.responseString
            local msg = nil
            if type(resp) == "string" then msg = self.jsonService:decode(resp) end
            if msg and msg.msg == "success" then
                if msg.code == 0 then
                    local data = msg.data
                    if data then
                        g_Log("上报自己消耗体力成功")
                    end
                end
            else
                g_Log("上报自己消耗体力失败-")
            end
        else
            g_Log("客户端:上报消耗体力失败")
        end
    end)
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function RunGameElement:ReceiveMessage(key, value, isResume)

    if key == Fsync_Server_KEY or key == Fsync_Server_KEY .. "1" or key == Fsync_Server_KEY .. "3" then
        g_Log("客户端:收到服务端消息-key:" .. key)
        for key, msg in pairs(value) do
            local lastMsg = msg
            g_Log("客户端:收到服务端消息" .. "key-" .. key .. "value-" .. lastMsg)
            local status = CourseEnv.ServicesManager:GetJsonService():decode(lastMsg)
            if status and status.state then
                if status.state == 1 then
                    if self.isInitialized == false then
                        -- 添加游戏开局埋点
                        self:reportLog("RunGameStart")
                        self.startTime = os.time()
                        self.url = status.Url
                        self.setId = status.setId
                        self:uploadCostTL()
                        -- 取消展示人数
                        if  self.loading then
                            self.loading:SetActive(false)
                        end
                        -- 取消开始页面
                        if self.startPanel then
                            self.startPanel:SetActive(true)
                            self.commonService:DispatchAfter(3,function()
                                self.startPanel:SetActive(false)
                                self:StartCountStart()
                            end)
                        end
                        
                        self.commonService:StartCoroutine(function()
                            self.commonService:Yield(
                                self.commonService:WaitUntil(function()
                                return self.selfAvatar ~= nil
                            end))
                            
                            self.parent:Trigger("runGameStart")
                        end)

                        self.isInitialized = true
                    end
                elseif status.state == 2 then
                    CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
                    self.tipDialog.gameObject:SetActive(true)
                elseif status.state == 3 then
                    if self.randomTerr == "True" then
                        g_Log("客户端:收到服务端随机地形序列" .. "random-" .. table.dump(status.random))
                        self:build(status.random)
                    end
                elseif status.state == 4 then
                    self.observerService:Fire("RefleshRankUI", status.rank)
                elseif status.state == 5 then
                    if self.state ~= 5 and status.countDownNum >= 0 then
                        self:EndCountDownStart(status.countDownNum)
                    end
                elseif status.state == 6 then
                    self:EndCountDownEnd()
                    -- 游戏结束：上报开口次数与复活点通过次数
                    self:reportSpeakCountEnd()
                    self:reportCheckpointPassesEnd()
                    self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                        status = 2})
                    self.commonService:DispatchAfter(3,function()
                        self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                            status = 2})
                    end)
                    CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
                    self:closeAnswerQuestion()

                    if self.isCasual == "True" then
                        if self.state < 3 then
                            local gameResultData = status.totalScores
                            gameResultData.useTime = 21474836473
                            gameResultData.gameId = status.totalScores.gameId
                            gameResultData.petExp = self.doneQuestion
                            gameResultData.autoClose = false
                            for _, value in pairs(status.totalScores.rankList) do
                                if value.userId ==  App.Uuid then
                                    gameResultData.useTime = value.score
                                    gameResultData.setId = self.setId
                                    gameResultData.score = value.score
                                    gameResultData.rank = value.rank
                                    gameResultData.award = value.cheese
                                    gameResultData.isFinish = value.isFinish
                                    break
                                end
                            end
                            gameResultData.clickCloseCallBack = function()
                                App:GameReturn()
                            end
                            g_Log("玩家答题时间-" .. gameResultData.useTime .. "秒")
                            gameResultData.rankListType = 1
                            gameResultData.titleType = 1
                            gameResultData.contentType = 1
                            gameResultData.closeBtnType = 2
                            local passRate = 0
                            if self.openMouseCount > 0 then
                                passRate = self.doneQuestion / self.openMouseCount
                            end
                            
                            if passRate >= 0 and passRate <= 1 then
                                gameResultData.passRate = passRate
                            end
                            gameResultData.rankList = nil
                            self.observerService:Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)
                            if self.endAudio then
                                self.audioService:PlayClipOneShot(self.endAudio,function ()
                                
                                end)
                            end
                        else
                            g_Log("客户端:已经上报过结果，游戏已经结束")
                            -- -- 延时1秒
                            -- App:GetService("CommonService"):DispatchAfter(2,function()
                            --     self.observerService:Fire("HIDE_MINI_GAME_RESULT_PANEL")
                            --     self.endPanel:SetActive(true)
                            --     if self.finishAudio then
                            --         self.audioService:PlayClipOneShot(self.finishAudio,function ()
                                
                            --         end)
                            --     end
                            -- end)
                        end
                    else
                        if self.state < 3 then
                            g_Log("客户端:时间到，游戏已经结束")
                            self.endPanel:SetActive(true)
                            if self.finishAudio then
                                self.audioService:PlayClipOneShot(self.finishAudio,function ()
                            
                                end)
                            end
                            self.commonService:DispatchAfter(3,function()
                                g_Log("3S后提交自己游戏结果")
                                self.endPanel:SetActive(false)
                                local gameResultData = status.totalScores
                                gameResultData.useTime = 21474836473
                                gameResultData.gameId = status.totalScores.gameId
                                gameResultData.petExp = self.doneQuestion
                                gameResultData.autoClose = false
                                for _, value in pairs(status.totalScores.rankList) do
                                    if value.userId ==  App.Uuid then
                                        gameResultData.useTime = value.score
                                        gameResultData.setId = self.setId
                                        gameResultData.score = value.score
                                        gameResultData.rank = value.rank
                                        gameResultData.award = value.cheese
                                        gameResultData.isFinish = value.isFinish
                                        break
                                    end
                                end
                                gameResultData.autoCloseCallBack = function()
                                    g_Log("自动关闭自己结算页开始段位结算")
                                    self.parent:Trigger("startRankPanel")
                                    if self.isShowRankPanel == false then
                                        self.isShowRankPanel = true
                                        self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",{})
                                    end
                                end
                                g_Log("玩家答题时间-" .. gameResultData.useTime .. "秒")
                                gameResultData.rankListType = 1
                                gameResultData.titleType = 1
                                gameResultData.contentType = 1
                                gameResultData.closeBtnType = 1
                                local passRate = 0
                                if self.openMouseCount > 0 then
                                    passRate = self.doneQuestion / self.openMouseCount
                                end
                                if passRate >= 0 and passRate <= 1 then
                                    gameResultData.passRate = passRate
                                end
                                gameResultData.rankList = nil
                                self.observerService:Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)
                                if self.endAudio then
                                    self.audioService:PlayClipOneShot(self.endAudio,function ()
                                    
                                    end)
                                end
                            end)
                        elseif self.state  == 3 then
                            g_Log("客户端:已经上报过结果，游戏已经结束")
                            -- 延时1秒
                            App:GetService("CommonService"):DispatchAfter(3,function()
                                self.obBtn:SetActive(false)
                                self.observerService:Fire("HIDE_MINI_GAME_RESULT_PANEL")
                                self.endPanel:SetActive(true)
                                if self.finishAudio then
                                    self.audioService:PlayClipOneShot(self.finishAudio,function ()
                                
                                    end)
                                end
                                self.commonService:DispatchAfter(3,function()
                                    g_Log("3S后开始结算段位")
                                    self.endPanel:SetActive(false)
                                    self.parent:Trigger("startRankPanel")
                                    if self.isShowRankPanel == false then
                                        self.isShowRankPanel = true
                                        self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",{})
                                    end

                                end)
                            end)
                        elseif self.state == 4 then
                            g_Log("客户端:已经上报过结果，游戏已经结束")
                            -- 延时1秒
                            App:GetService("CommonService"):DispatchAfter(1,function()
                                self.obBtn:SetActive(false)
                                self.observerService:Fire("HIDE_MINI_GAME_RESULT_PANEL")
                                self.endPanel:SetActive(true)
                                if self.finishAudio then
                                    self.audioService:PlayClipOneShot(self.finishAudio,function ()
                                
                                    end)
                                end
                                self.commonService:DispatchAfter(3,function()
                                    g_Log("3S后开始结算段位")
                                    self.endPanel:SetActive(false)
                                    self.parent:Trigger("startRankPanel")
                                    if self.isShowRankPanel == false then
                                        self.isShowRankPanel = true
                                        self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",{})
                                    end    
                                end)
                            end)
                        end
                    end
                    
                    self.state = 6
                    -- 隐藏控制按钮
                    self.joyId = self.joyService:setHidenJoyWithID()
                    self.jumpId = self.joyService:setHidenJumpWithID()
                    -- 关闭观战
                    self.obBtn:SetActive(false)
                elseif status.state == 7 then
                    local num = status.playerNum
                    local totalNum = status.totalNum
                    -- T展示人数
                    if self.isInitialized == false then
                        self.loading:SetActive(true)
                    end
                    self:updateWaitingNum(num,totalNum)
                elseif status.state == 8 then
                    g_Log("结算收到上报自己积分消息")
                    local reportPoint = self.jsonService:decode(status.reportPoint)
                    if reportPoint.userId ==  App.Properties.UserId then
                        self.state = 3
                        --停止题目预播
                        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
                        { op = "Stop" })  --在游戏结算的时候调用
                        g_Log("上报自己积分" .. table.dump(reportPoint))
                        -- 展示结果页
                        local gameResultData = {}
                        gameResultData.setId = self.setId
                        gameResultData.rank = reportPoint.rank
                        gameResultData.award = reportPoint.award
                        gameResultData.score = reportPoint.score


                        gameResultData.isFinish = true
                        gameResultData.useTime = reportPoint.score
                        gameResultData.rankList = {}
                        gameResultData.petExp = self.doneQuestion
                        gameResultData.autoClose = true
                        gameResultData.rankListType = 1
                        gameResultData.titleType = 1
                        gameResultData.contentType = 1
                        gameResultData.closeBtnType = 1
                        local passRate = 0
                        if self.openMouseCount > 0 then
                            passRate = self.doneQuestion / self.openMouseCount
                        end
                        if passRate >= 0 and passRate <= 1 then
                            gameResultData.passRate = passRate
                        end
                        if self.isCasual ~= "True" then
                            gameResultData.autoCloseCallBack = function()
                                g_Log("3S后自动关闭自己结算页并开始观战")
                                if self.state < 5 then
                                    self.obBtn:SetActive(true)
                                end
                                
                                self.observerService:Fire("isWatchBattle",{isWatchBattle = true})
                                self.state = 4
                            end
                        else
                            gameResultData.closeBtnType = 2
                            gameResultData.clickCloseCallBack = function()
                                App:GameReturn()
                            end
                        end

                        -- 延时1秒
                        App:GetService("CommonService"):DispatchAfter(1,function()
                            self.observerService:Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)
                            self.observerService:Fire("isWatchBattle",{isWatchBattle = true})
                            if self.endAudio then
                                self.audioService:PlayClipOneShot(self.endAudio,function ()
                                
                                end)
                            end
                        end)

                        -- 展示App评分
                        -- 延时2秒
                        App:GetService("CommonService"):DispatchAfter(2,function()
                            if gameResultData.rank <= 3 then
                                self:appEvaluate()
                            end

                        end)
                    end
                elseif status.state == 9 then
                    -- 虚弱状态切换：通过 uuid 定位 avatar
                    if status.uuid and status.isWeak ~= nil then
                        if status.uuid ~= App.Uuid then
                            local avatar = self:GetAvatarByUUID(status.uuid)
                            if avatar then
                                if status.isWeak == true then
                                    avatar:PlayDetectWeak(false)
                                    avatar:SetMoveSpeedFactor(0.3)                              
                                else
                                    avatar:PlayDetectNormal(false)
                                    avatar:SetMoveSpeedFactor(1.0)
                                end
                            end
                        end
                    end
                end
            end
        end
    elseif key == "activateRoom" then 
        g_Log("客户端:收到激活房间消息")
        g_Log(table.dump(value))
        for key, msg in pairs(value) do
            local lastMsg = CourseEnv.ServicesManager:GetJsonService():decode(msg)
            if lastMsg and lastMsg.set_id then
                self.setId = tonumber(lastMsg.set_id)
            end
        end
    end
end
-- 生成随机地形
function RunGameElement:build(random)
    if self.hasBuild then
        return
    end
    for key, value in pairs(random) do
        -- local objStr = "关卡布置/跑道/跑道" .. tostring(key)
        -- local objStrPrefab = "关卡布置/预制关卡/关卡" .. tostring(value)
        -- local pos = self.VisElement.transform:Find(objStr).transform.position
        -- local obj = self.VisElement.transform:Find(objStrPrefab)

        local pos = self.level_array_obj:Find("跑道/跑道" .. tostring(key)).transform.position
        local obj = self.level_array_obj:Find("预制关卡/关卡" .. tostring(value))
        if obj then
            obj.transform.position = pos
            g_Log("设置关卡" .. value .. "位置" .. key)
            
        end
    end
    self.hasBuild = true
end
-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function RunGameElement:SendCustomMessage(key, body)
    self:SendMessage(key,body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:SelfAvatarCreated(avatar)
    
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:SelfAvatarPrefabLoaded(avatar)
    avatar.VisElement.gameObject.layer = CS.UnityEngine.LayerMask.NameToLayer("areaTrigger")
    g_Log("客户端:发送加入游戏消息")
    self:SendCustomMessage(Fsync_Client_KEY, { state = 1,UserId = App.Properties.UserId ,AvatarName = App.Properties.AvatarName})
    self:initQuestions()
    -- self:AddVoice()
    -- 开启人物冲刺相关逻辑
    -- 开启加速鞋计时器
    self.selfAvatar = avatar

    -- 以下冲刺计时与特效逻辑已停用
    -- self.remainSpeedTime = 0
    -- self.hasSpeedEffect = false
    -- self.globalShoeTimer = self.commonService:RegisterGlobalTimer(0.1, function()
    --     if self.remainSpeedTime > 0 then
    --         if self.hasSpeedEffect == false then
    --             self.hasSpeedEffect = true
    --             -- 打开特效
    --             self.selfAvatar:SetRushState()
    --             g_LogError("开始冲刺")
    --         end
    --         self.remainSpeedTime = self.remainSpeedTime - 0.1
    --     else
    --         if self.hasSpeedEffect == true then
    --             self.hasSpeedEffect = false
    --             -- 关闭特效
    --             self.selfAvatar:SetNormalState()
    --             g_LogError("结束冲刺")
    --         end
    --     end
    -- end, false)
end

function RunGameElement:AddVoice()
    self.showChat = false
    local appVersion = App.Info.appVersionNumber
    if appVersion then
        if tonumber(appVersion) < 10510 then
            return 
        end
    end
    self.showChat = true

    --强制显示
    CourseEnv.ServicesManager:GetUIService().voiceBtnHidenStateTable = {}
    CourseEnv.ServicesManager:GetUIService().commonMenu.VisitorToLogin = true
    CourseEnv.ServicesManager:GetUIService().commonMenu.voiceBtn.gameObject:SetActive(true)

    APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
        open = true,
        isShow = true,
        topSafeArea = 40.0/750,
    }, function()

    end)

    local ori = APIBridge.RequestAsync
    APIBridge.RequestAsync = function(api, request, callBack)
        if api == 'app.buss.menu.autoPlayChat' and (not request.topSafeArea or request.topSafeArea == 0) then
            request.topSafeArea = 40.0/750
        end

        ori(api, request, callBack)
    end
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:AvatarCreated(avatar)

end

-- 拉题
--- func desc api:http://yapi.xesv5.com/project/2041/interface/api/73881
---@param num number 题目数量
---@param type number 题目类型 1:单词 2:句子 3:选择
function RunGameElement:initQuestions()
    self.commonService:StartCoroutine(function ()
        self.commonService:Yield(self.commonService:WaitUntil(function()
            return self.recoverComplete == true
        end))

        self.parent:Trigger("getQuestionsEnd")
    end)
end

function RunGameElement:answerQuestion()
    g_Log("openDialog")
    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", {
        status = 1,
        awardCount = 1,
        showAwardType = 2,
        isShowVideo = true,
        noLeadReading = false,
        callBack = function(score, isFinal, isNoSpeaking, isPass)
            self.openMouseCount = self.openMouseCount + 1
            if isFinal then
                self.answerOn = false
                -- self:Fire("showSkillUI")
                if isPass then
                    -- 答题通过：大于60分才按实际分数加能量
                    if score and score > 60 then
                        self:AddEnergy(score)
                    end
                    self.doneQuestion = self.doneQuestion + 1
                else
                    
                end
            else
            end
        end
    })
end

function RunGameElement:closeAnswerQuestion()
    g_Log("closeDialog")
    self.nengliangRoot.gameObject:SetActive(false)
    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", {
        status = 0,
        awardCount = 1,
        showAwardType = 2,
        callBack = function(score, isFinal, isNoSpeaking, isPass)
            
        end
    })
end

function RunGameElement:AddEnergy(energy)
    self.currentEnergy = self.currentEnergy + energy
    if self.currentEnergy >= self.maxEnergy then
        self.currentEnergy = self.maxEnergy
        -- 能量已满
        if self.energyFullAudio then
            self.audioService:PlayClipOneShot(self.energyFullAudio,function ()
            end)
        end
    end
    if self.currentEnergy <= 0 then
        self.currentEnergy = 0
        if self.isWeak == false then
            self.isWeak = true
            if self.selfAvatar then
                self.selfAvatar:SetMoveSpeedFactor(0.3)
                self.selfAvatar:PlayDetectWeak(false)
            end
            self:Fire("show_energy_zero")
            -- 广播弱状态（使用 uuid 同步给他端）
            self:SendCustomMessage(Fsync_Client_KEY, { state = 9, uuid = App.Uuid, isWeak = true })
        end
    end
    if self.currentEnergy > 0 and self.isWeak == true then
            self.isWeak = false
            if self.selfAvatar then
                self.selfAvatar:SetMoveSpeedFactor(1.0)
                self.selfAvatar:PlayDetectNormal(false)
            end
            self:Fire("hide_energy_zero")
            -- 广播恢复状态（使用 uuid 同步给他）
            self:SendCustomMessage(Fsync_Client_KEY, { state = 9, uuid = App.Uuid, isWeak = false })
    end 

    -- 更改按钮状态（已停用）
    -- if self.speedBtnDisable and self.speedBtnNormal then
    --     self.speedBtnDisable.gameObject:SetActive(self.currentEnergy < self.speedCost)
    --     self.speedBtnNormal.gameObject:SetActive(self.currentEnergy >= self.speedCost)
    -- end

    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_INIT_SLIDER", {
        numerator = self.currentEnergy,
        denominator = self.maxEnergy
    })

    -- self.nengliangText1.text = "<color=red>" .. self.currentEnergy .. "</color>" .. "/" .. 100
    -- self.nengliangText2.text = "/" .. 100

    -- local lastValue = self.nengliangtiaoRect.sizeDelta.x
    -- local newValue = self.currentEnergy * (413.1 / 100)
    -- self.nengliangtiaoRect.sizeDelta = Vector2(self.currentEnergy * (413.1 / 100),
    --     self.nengliangtiaoRect.sizeDelta.y)
    -- if self.seqEnergy then
    --     self.seqEnergy:Kill()
    --     self.seqEnergy = nil
    -- end
    -- if lastValue > newValue then
    --     -- 减少
    --     self.nengliangtiaoAnim.position = Vector3(self.nengliangtiaoAim.position.x,
    --         self.nengliangtiaoAnim.position.y, self.nengliangtiaoAnim.position.z)
    -- else
    --     -- 增加
    --     -- self.nengliangtiaoAnim.position = Vector3(self.nengliangtiaoAim.position.x, self.nengliangtiaoAnim.position.y, self.nengliangtiaoAnim.position.z)

    --     -- 延迟运动

    --     self.seqEnergy = DOTween:Sequence()
    --     self.seqEnergy:Append(self.nengliangtiaoAnim:DOMoveX(self.nengliangtiaoAim.position.x, 0.5))
    -- end
end

-- 调用App评分
function RunGameElement:appEvaluate()
    if self.appEvaluateFinish == nil then
        self.appEvaluateFinish = true
        -- APIBridge.RequestAsync("app.buss.appEvaluate.show", {})
    end
end

function RunGameElement:ReduceEnergy()
    -- 每秒消耗能量
    self.commonService:StartCoroutine(function ()
        if self.gameStart and not self.hasFinished then
            self:AddEnergy(-7)
            self.commonService:YieldSeconds(1)
            self:ReduceEnergy()
        end
    end)
end

function RunGameElement:Tick()
    if not self.selfAvatar then
        return
    end
    
    if self.hasFinished == true then
        return
    end
    if self.tickIndex == nil then
        self.tickIndex = 0
    end

    self.tickIndex = self.tickIndex + 1

    if not self.gameStart then
        return
    end
    if self.tickIndex % 15 ~= 0 then
        return
    end

    if not self.startPos then
        return
    end

    -- 上报按复活点与到下一目标点的直线距离
    local selfPos = self.selfAvatar.VisElement.transform.position
    local checkpointIndex = self.curRecoverPos or 0
    local nextPos = nil
    local nextIndex = checkpointIndex + 1
    if self.recoverPoints and self.recoverPoints[nextIndex] ~= nil then
        nextPos = self.recoverPoints[nextIndex]
    elseif self.endPointPos ~= nil then
        nextPos = self.endPointPos
    end
    if nextPos == nil then
        return
    end
    local toNext = Vector3.Distance(selfPos, nextPos)
    self:SendCustomMessage(Fsync_Client_KEY, { state = 2, UserId = App.Properties.UserId, Checkpoint = checkpointIndex, ToNext = toNext })
end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function RunGameElement:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function RunGameElement:LogicMapStartRecover()
    RunGameElement.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function RunGameElement:LogicMapEndRecover()
    RunGameElement.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function RunGameElement:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

--收到Trigger事件
function RunGameElement : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function RunGameElement : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function RunGameElement:Exit()
    g_Log("客户端:退出游戏消息")
    -- 退出兜底上报（若未上报）
    self:reportSpeakCountEnd()
    self:reportCheckpointPassesEnd()
    self:SendCustomMessage(Fsync_Client_KEY, { state = 3,UserId = App.Properties.UserId})
    
    if self.globalShoeTimer then
        self.commonService:UnregisterGlobalTimer(self.globalShoeTimer)
    end

    -- 退出时恢复速度与提示
    if self.isWeak == true then
        if self.selfAvatar and self.selfAvatar.SetMoveSpeedFactor then
            self.selfAvatar:SetMoveSpeedFactor(1.0)
        end
        if self.observerService then
            self.observerService:Fire("hide_energy_zero")
        end
    end

    RunGameElement.super.Exit(self)
end

return RunGameElement
 

