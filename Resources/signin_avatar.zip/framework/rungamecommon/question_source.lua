---
---  Author: 【王德】
---  AuthorID: 【102030】
---  CreateTime: 【2023-12-19 16:16:23】
--- 【FSync】
--- 【题目来源】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_9fa0018b_6135_48cf_83b7_a88bf2100fdb : WorldBaseElement
local QuestionSource = class("QuestionSource", WBElement)
local TAG = "题目来源"

---@param worldElement CS.Tal.framesync.WorldElement
function QuestionSource:initialize(worldElement)
    QuestionSource.super.initialize(self, worldElement)
 
end

function QuestionSource:setVisElement(parent,VisElement)
    if App.modPlatformId == MOD_PLATFORM.Preview then
        return
    end
    self.parent = parent
    self.VisElement = VisElement
    self.reTryCount = 2
    self:InitService()
    self:getQuestionsFrom() 
    self.observerService:Watch("unity.api.page.show", function()
        self:getQuestionsFrom() 
    end)
end

function QuestionSource:InitService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type UIService
    self.uiService = CourseEnv.ServicesManager:GetUIService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function QuestionSource:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function QuestionSource:SendCustomMessage(key, body)
    self:SendMessage(key,body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionSource:SelfAvatarCreated(avatar)
    self.avatar = avatar
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionSource:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function QuestionSource:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function QuestionSource:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function QuestionSource:LogicMapStartRecover()
    QuestionSource.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function QuestionSource:LogicMapEndRecover()
    QuestionSource.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function QuestionSource:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

--收到Trigger事件
function QuestionSource : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function QuestionSource : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------
function QuestionSource:getQuestionsFrom()
    self.domain = "https://app.chuangjing.com/abc-api"
    local url = self.domain .. "/v3/book/get-user-data"
    if App.IsStudioClient then
        url = "http://yapi.xesv5.com/mock/2041/v3/book/get-user-data"
    end
    local params = {
       
    }

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                if msg.data then
                    local bookName = msg.data.book_name
                    local bookImage = msg.data.book_image
                    local levelName = msg.data.level_name
                    if bookName == nil or bookImage == nil then
                        return
                    end
                    if self.recoverComplete and self.avatar then
                        self.observerService:Fire("EVENT_BUSINESS_QUESTION_FROM_INFO",{
                            bookName = bookName,
                            bookImageUrl = bookImage,
                            bookLevel = levelName
                        })
                    else
                        self.commonService:StartCoroutine(function ()
                            self.commonService:Yield(self.commonService:WaitUntil(function ()
                                return self.recoverComplete and self.avatar
                            end))
                            self.observerService:Fire("EVENT_BUSINESS_QUESTION_FROM_INFO",{
                                bookName = bookName,
                                bookImageUrl = bookImage,
                                bookLevel = levelName
                            })
                        end)
                    end
                    
                end
            else
                g_Log(TAG, "获取题目来源失败" .. (2 - self.reTryCount))
                self.commonService:DispatchAfter(3, function()
                    self.reTryCount = self.reTryCount - 1
                    if self.reTryCount > 0 then
                        self:getQuestionsFrom()
                    end
                end)
            end
        end
    end
    local fail = function(err)
        if not err then
            err = ""
        end
        if type(err) == "table" then
            err = table.dump(err)
        end
        g_Log(TAG, err .. " 获取题目来源失败 fail " .. (2 - self.reTryCount))
        self.commonService:DispatchAfter(3, function()
            self.reTryCount = self.reTryCount - 1
            if self.reTryCount > 0 then
                self:getQuestionsFrom()
            end
        end)
    end
    self.hasReport = true
    self:HttpRequest(url, params, success, fail)
end


function QuestionSource:HttpRequest(url, params, success, fail)
    if App.IsStudioClient then
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

-- 脚本释放
function QuestionSource:Exit()
    QuestionSource.super.Exit(self)
end

return QuestionSource
 

