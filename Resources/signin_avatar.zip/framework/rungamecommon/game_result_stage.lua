---  Author: 【孙鹏飞】
---  AuthorID: 【V0047328】
---  CreateTime: 【2025-8-14 14:31:39】
--- 【FSync】
--- 【MVP展示】




local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class GameResultStage : WorldBaseElement
local GameResultStage = class("game_result_stage_comlogic", WBElement)

local Quaternion = CS.UnityEngine.Quaternion
local Vector3 = CS.UnityEngine.Vector3
local DOTween = CS.DG.Tweening.DOTween
local Ease = CS.DG.Tweening.Ease

local uAddress = "1089491762426239/assets/Prefabs/Stage2.prefab" -- "1086021761909084/assets/Prefabs/Stage.prefab"

local SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST = "SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST"     --展示段位页事件 带请求
local SHOW_GAME_RANK_RESULT_PANEL = "SHOW_GAME_RANK_RESULT_PANEL"                         --展示段位页事件
local GAME_RANK_RESULT_PANEL_CLOSE_BTN_CLICK = "GAME_RANK_RESULT_PANEL_CLOSE_BTN_CLICK"   --段位页关闭按钮点击事件

local SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST = "SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST" --展示mvp舞台结果页事件 带请求
local SHOW_TEAM_MINI_GAME_RESULT_PANEL_NEW = "SHOW_TEAM_MINI_GAME_RESULT_PANEL_NEW"       --展示队伍mvp舞台结果页事件
local HIDE_MINI_GAME_RESULT_PANEL = "HIDE_MINI_GAME_RESULT_PANEL"                         --隐藏mvp舞台结果页事件

local SHOW_MVP_STAGE_UI = "SHOW_MVP_STAGE_UI"                                             --展示mvp舞台UI事件
local HIDE_MVP_STAGE_UI = "HIDE_MVP_STAGE_UI"                                             --隐藏mvp舞台UI事件
local ON_GAME_RESULT_UI_TUICHU_BTN_CLICK = "ON_GAME_RESULT_UI_TUICHU_BTN_CLICK"           --退出按钮点击事件
local ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK = "ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK"   --再来一局按钮点击事件
local SHOW_RESULT_COMMON_UI = "SHOW_RESULT_COMMON_UI"                                     --展示结算UI事件 提前结算使用

local GET_RECORD_SCORE_DATA = "GET_RECORD_SCORE_DATA"                                     --获取玩家统计分数事件
local GET_CALCULATE_PLAYER_STUDY_SCORE_STATS = "GET_CALCULATE_PLAYER_STUDY_SCORE_STATS"   --计算玩家学习成绩
local GAME_RESULT_SET_MAIN_PANEL = "GAME_RESULT_SET_MAIN_PANEL"                           --游戏结算设置主面板显示/隐藏事件
local JUMP_ANIMATION_FRAME = 46                                                           --跳上场景中央的MVP展示台上动画时长
local JUMP_ANIMATION_FRAME_TOP = 30                                                       --最高时间
local MVP_WAIT_FRAME = 60                                                                 --弹出mvp等待帧率时长
local fsync_activateRoom = "activateRoom"                                                 --激活房间
local process_game_result = "process_game_result"                                         --服务器发送-处理游戏结果
local game_remote_params = "game_remote_params"                                           --游戏远程参数

---@param worldElement CS.Tal.framesync.WorldElement
function GameResultStage:initialize(worldElement)
    GameResultStage.super.initialize(self, worldElement)
    -- 订阅KEY消息
    self:SubscribeMsgKey(fsync_activateRoom)
    self:SubscribeMsgKey(process_game_result)
    self:SubscribeMsgKey(game_remote_params)

    self:RegisterDownloadUaddress(uAddress)
end

function GameResultStage:setVisElement(VisElement)
    if VisElement ~= nil then
        self.VisElement = VisElement
    end

    self:InitVariable()
    self:InitService()
    self:InitConfig()
    self:InitListener()
    self:InitView()
end

--初始化变量
function GameResultStage:InitVariable()
    self:resetVariable()
    self.cloneAvatarMap = {}
    self.cloneAvatarHeadMap = {}
    self.animatorMap = {}        -- 缓存animator组件 (uuid -> animator)
    self.playerRank = {}         -- rank -> cloneAvatar
    self.playerRankAnimator = {} -- rank -> animator (用于ShowStageEffect)
    --不一定对 ai
    -- gameMode = 1 (单人)：单人练习模式，不需要匹配
    -- gameMode = 2 (双人)：排位对战模式，有段位系统
    -- gameMode = 3 (四人)：休闲模式，支持再来一局匹配功能
    self.gameMode = 3 -- 游戏模式
end

-- 重置变量 再来一局时使用
function GameResultStage:resetVariable()
    self.hasRequest = false
    -- 清空接口请求获取数据
    self.change_score = nil
    self.ranking_before = nil
    self.ranking_after = nil
    self.is_protect = nil
    self.protect_score = nil
    self.is_school_settle = nil
    self.join_school_flag = nil
    self.add_value = nil
    self.has_upgrade = nil
    self.after_level = nil
    self.is_double_game = nil
    self.add_cheese_val = nil
    self.grow_route_info = nil
    self.season_id = nil
    self.jiziNum = nil
end

function GameResultStage:InitService()
    self.gate = CourseEnv.ServicesManager.Gate
    self.BusEventService = CourseEnv.ServicesManager:GetObserverService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.commonService = App:GetService("CommonService")
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    self.UIService = App:GetService("UIService")
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.decorateService = CourseEnv.ServicesManager:GetDecorateService()
    self.lightService = CourseEnv.ServicesManager:GetLightService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.permissionService = CourseEnv.ServicesManager:GetPermissionService()
end

function GameResultStage:InitConfig()

end

function GameResultStage:InitListener()
    ---展示mvp舞台
    self.observerService:Watch(SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST, function(key, args)
        local data = args[0] -- 获取事件参数
        if data == nil then
            self:Print("展示mvp舞台失败 data为nil")
            return
        end

        local showStage = function()
            if self.hasRequest then
                self:FillDataAndShowStage(data)
            else
                self.hasRequest = true
                self:requestPersonSettle(args[0], function()
                    self:FillDataAndShowStage(data)
                end)
            end
        end

        if data.delayTime and data.delayTime > 0 then
            self.commonService:DispatchAfter(data.delayTime, function()
                showStage()
            end)
        else
            showStage()
        end
    end)
    --客户端展示队伍结果页 展示mvp舞台  需要修改数据格式了！！！！！
    self.BusEventService:Watch(SHOW_TEAM_MINI_GAME_RESULT_PANEL_NEW, function(key, args)
        if self.teamReslutData then
            self:Print("客户端展示队伍结果页", table.dump(self.teamReslutData))
            self.BusEventService:Fire(SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST, self.teamReslutData)
        end
    end)
    -- 监听游戏段位页显示消息
    -- 这里暂时保留，有直接调用段页的情况，所有需要保留
    self.BusEventService:Watch(SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST, function(key, args)
        self:Print("展示段位页", table.dump(args[0]))
        local data =
        {
            change_score = self.change_score,     --变化值
            is_protect = self.is_protect,         --是否保护分
            protect_score = self.protect_score,   --保分分数
            ranking_before = self.ranking_before, --变化前排位信息 {level = 7,level_name ="巅峰",section_score = 6,section_name = "1"}
            ranking_after = self.ranking_after,   --变化后排位信息 {level = 7,level_name ="巅峰",section_score = 6,section_name = "1"}

            rank = self.titleData.mingci,         --排名

            type = args[0].type,                  -- 1：个人赛段位结算，2：团队赛段位结算
            isFailed = args[0].isFailed,          -- 个人赛专用字段 是否未通过，未通过左上角显示未通过，否则显示第几名
            isTeamWin = args[0].isTeamWin,        -- 团队赛专用字段 是否胜利 目前规则加分就是显示胜利，可传可不传

            ishowDaojishi = true,                 --是否显示倒计时 兼容 之后新版本需要显示倒计时 老版本不显的

            --新需求这里不需要返回按钮显示直接隐藏即可
            btnCallBack = function(returnBtn, againBtn)
                returnBtn.gameObject:SetActive(false)
                againBtn.gameObject:SetActive(true)
            end
        }
        if self.hasRequest then
            self.BusEventService:Fire(SHOW_GAME_RANK_RESULT_PANEL, data)
        else
            self.hasRequest = true
            self:requestPersonSettle(args[0], function()
                self.BusEventService:Fire(SHOW_GAME_RANK_RESULT_PANEL, data)
            end)
        end
    end)

    --计算玩家学习成绩
    self.observerService:Watch(GET_CALCULATE_PLAYER_STUDY_SCORE_STATS, function(key, args)
        local data = args[0] -- 获取事件参数
        if data == nil then
            self:Print("计算玩家学习成绩失败 uuid为nil")
            return
        end
        local uuid = data.uuid
        local callback = data.callback
        local playerStudyScoreStats = self:CalculatePlayerStudyScoreStats(uuid)
        if callback and type(callback) == "function" then
            callback(playerStudyScoreStats)
        end
    end)

    --段位页关闭按钮点击 或者5秒倒计时结束
    self.observerService:Watch(GAME_RANK_RESULT_PANEL_CLOSE_BTN_CLICK, function(key, args)
        self:ShowMvpStageUI()
    end)

    --隐藏mvp舞台
    self.observerService:Watch(HIDE_MVP_STAGE_UI, function(key, args)
        self:HideMvpStageAudios()
    end)
    -- 退出按钮点击
    self.observerService:Watch(ON_GAME_RESULT_UI_TUICHU_BTN_CLICK, function(key, args)
        self:HideMvpStage()
    end)
    --再来一局按钮点击
    self.observerService:Watch(ON_GAME_RESULT_UI_ZAILAIYIJU_BTN_CLICK, function(key, args)
        self:HideMvpStage()
        self:resetVariable()
    end)
    --隐藏结算
    --TODO 其他地咋调用的？？？？
    self.BusEventService:Watch(HIDE_MINI_GAME_RESULT_PANEL, function(key, args)
        self:HideMvpStage()
    end)
    --展示结算UI
    self.observerService:Watch(SHOW_RESULT_COMMON_UI, function(key, args)
        self:HideAllPlayerHead()
    end)


    --监听玩家加入房间 克隆所有玩家 这里提前克隆，游戏结束会销毁玩家
    self.gate.OnUserJoinRoom:connect(function(uuid)
        self:AsyncGetAvatar(uuid, AvatarLoadType.AllLoaded, function()
            local avatar = self.avatarService:GetAvatarByUUID(uuid)
            self.commonService:StartCoroutine(function()
                --等待avatar动画初始化完成
                self.commonService:Yield(self.commonService:WaitUntil(function()
                    return avatar.Animator and avatar.Animator.isInitialized == true
                end))

                local avatarUuid = avatar.avatarUuid
                if self.cloneAvatarMap == nil then
                    self.cloneAvatarMap = {}
                end
                local cloneAvatar = self.cloneAvatarMap[avatarUuid]
                if cloneAvatar ~= nil then
                    CS.UnityEngine.GameObject.Destroy(cloneAvatar)
                end

                local avatarRect = avatar.Body.transform.parent
                local bodyTrans = avatar.BodyTrans
                --等待RoleCanvas创建完成
                self:FindInAllUntil(bodyTrans, "RoleCanvas", function(roleCanvas)
                    cloneAvatar = CS.UnityEngine.GameObject.Instantiate(avatarRect.gameObject)
                    cloneAvatar.name = "cloneAvatar" .. avatarUuid
                    self:Print("OnUserJoinRoom==================cloneAvatar", uuid, cloneAvatar.name)
                    --切动画层级
                    local animator = cloneAvatar:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
                    local commonLayer = avatar.AVATAR_ENUM_ANIMATOR.COMMONLAYER
                    local baseLayer1 = avatar.AVATAR_ENUM_ANIMATOR.BASELAYER1
                    if avatar.enableAnimatorOverride then
                        local layerTable = {}
                        layerTable[1] = 1
                        layerTable[2] = 0
                        for layer, weight in pairs(layerTable) do
                            animator:SetLayerWeight(layer, weight)
                        end
                    else
                        local layerTable = {}
                        for i = baseLayer1 + 1, commonLayer - 1 do
                            layerTable[i] = 0
                        end
                        layerTable[baseLayer1] = 1
                        for layer, weight in pairs(layerTable) do
                            animator:SetLayerWeight(layer, weight)
                        end
                    end
                    --动画初始化
                    self.commonService:YieldSeconds(1)
                    local character = cloneAvatar.transform:FindInAll("Character")
                    animator.enabled = false
                    local characterAnimation = character.gameObject:GetComponent(typeof(CS.UnityEngine.Animation))
                    if not characterAnimation then
                        characterAnimation = character.gameObject:AddComponent(typeof(CS.UnityEngine.Animation))
                    end
                    self.commonService:DispatchNextFrame(function()
                        cloneAvatar:SetActive(false)
                    end)
                    self.cloneAvatarMap[avatarUuid] = cloneAvatar
                    self:Print("OnUserJoinRoom==================cloneAvatar 结束", uuid, cloneAvatar.name)
                end)
            end)
        end)
    end)
    --离开不销毁
    self.gate.OnUserLeaveRoom:connect(function(uuid)

    end)
end

function GameResultStage:InitView()
    --debug
    self.debugService:AddDebugActionWithTitleAndCategory("展示mvp舞台", "test"):connect(function()
        self:Print("展示mvp舞台")
        self.observerService:Fire(SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST, {
            gameType = GAME_RESULT_GAME_TYPE.WOLF_AND_DETECTIVE, --唯一 游戏类型 GAME_RESULT_GAME_TYPE
            isShowMVPStage = true,                               --是否展示mvp舞台 默认展示（如游戏中途展示的时候没有MVP)
            delayTime = 3,                                       --延迟时间 3秒后展示mvp舞台 默认不延迟
            --排位数据
            rankData = {
                isShowRankPanel = false, --是否展示段位页 默认不展示
                type = 1,                -- 1：个人赛段位结算，2：团队赛段位结算
                isFailed = false,        -- 个人赛专用字段 是否未通过，未通过左上角显示未通过，否则显示第几名
                isTeamWin = true,        -- 团队赛专用字段 是否胜利 目前规则加分就是显示胜利，可传可不传
            },
            --标题数据
            titleData = {
                titleType = 3,          --标题类型1 未完成  2 淘汰 3 胜利 4 失败 5 名次  6 平局
                teamScore = { 24, 12 }, --队伍比分 {蓝方分数, 红方分数}
                mingci = 1,             --名次 titleType == 5 时有效
            },
            --奖励数据
            awardData = {
                zhishi = 10, --芝士 有芝士显示奖励芝士，没有回走服务器请求add_cheese_val 值 默认0
                xueshi = 10, --学识
                petExp = 10, --宠物经验
            },
            --匹配数据
            matchData = {
                closeBtnType = 3, --匹配功能按钮显示类型  1. 3S后自动关闭不显示关闭按钮 2.只显示关闭按钮 3.显示关闭和再来一局按钮
            },
            --游戏自定义数据
            gameData = {
                winner = 1, --狼人获胜情况 (rank = 1) 侦探获胜情况 (rank = 2)
                -- useTime = 68, -- 用时
                -- isFinish = false, -- 是否完成

            },
            --服务器请求参数
            requestParams = {
                rank = 3,          --排名
                score = 55,        --个人得分
                team = nil,        --团队胜负 暂时用不到
                is_run = false,    --是否逃跑
                is_captor = false, --是否是抓捕者

                -- game_id = game_id, 游戏id  比传
                -- set_id = set_id,游戏局id  口语特工队 传 波数（第几波就穿几）
                -- plan_id = plan_id,场次ID
                -- award = ,--奖励的芝士数
            },
            autoCloseCallBack = function()
                g_LogColorMsg("最终结算界面-自动关闭回调")
            end,
            clickCloseCallBack = function()
                g_LogColorMsg("最终结算界面-点击关闭回调")
            end,
            clickAgainCallBack = function()
                g_LogColorMsg("最终结算界面-点击再来一局回调")
            end,
        })
    end)
    self.debugService:AddDebugActionWithTitleAndCategory("构造发送结算测试数据", "test"):connect(function()
        self:Print("构造发送结算测试数据")

        -- self.observerService:Fire('RECORD_GAME_SCORE_DATA', {
        --     key = GAME_RESULT_DATA_KEYS.SCORE,
        --     value = 100,
        --     type = 1,
        -- })
        -- self.observerService:Fire('RECORD_GAME_SCORE_DATA', {
        --     key = GAME_RESULT_DATA_KEYS.SCORE,
        --     value = 50,
        --     type = 1,
        -- })

        self.observerService:Fire('RECORD_GAME_SCORE_DATA', {
            key = GAME_RESULT_DATA_KEYS.IDENTITY, -- 个人得分
            value = 1,
            type = 2,
        })
        self.observerService:Fire('RECORD_GAME_SCORE_DATA', {
            key = GAME_RESULT_DATA_KEYS.PERSON_SCORE, -- 个人得分
            value = 100,
            type = 2,
        })
        self.observerService:Fire('RECORD_GAME_SCORE_DATA', {
            key = GAME_RESULT_DATA_KEYS.BREAK_TIME, -- 破译总时长
            value = 3,
            type = 3,                               -- 累加统计
        })

        self.observerService:Fire('RECORD_GAME_SCORE_DATA', {
            key = GAME_RESULT_DATA_KEYS.HIT_NUM, -- 击倒人数
            value = 1,
            type = 3,                            -- 累加统计
        })

        self.observerService:Fire('RECORD_GAME_SCORE_DATA', {
            key = GAME_RESULT_DATA_KEYS.ELIMINATE_NUM, -- 淘汰人数
            value = 1,
            type = 3,                                  -- 累加统计
        })
    end)
end

--region 舞台初始化-----------------------------------------------------------------------------------------------------------------------------

--- ========================================
--- 填充相关数据并展示舞台
--- ========================================
---@param data table 数据对象，结构如下：
---```lua
--- {
---     gameType = GAME_RESULT_GAME_TYPE.WOLF_AND_DETECTIVE,   -- 游戏类型 GAME_RESULT_GAME_TYPE
---     isShowMVPStage = true, --是否展示mvp舞台 默认展示（如游戏中途展示的时候没有MVP)  同时ui不展示MVP
---     -- ============ 排位数据 ============
---     rankData = {
---        type = 1,           -- 1：个人赛段位结算，2：团队赛段位结算
---        isFailed = false,   -- 个人赛专用字段 是否未通过，未通过左上角显示未通过，否则显示第几名
---        isTeamWin = true, -- 团队赛专用字段 是否胜利 目前规则加分就是显示胜利，可传可不传
---     }
---
---     -- ============ 标题数据 ============
---     titleData = {
---         titleType = 1,                  -- [必填] 标题类型：1 未完成  2 淘汰 3 胜利 4 失败 5 名次  6 平局
---         teamScore = { 24, 122 },        -- [可选] 队伍比分 {蓝方分数, 红方分数}
---         mingci = 1,                     -- [可选] 名次(仅当 titleType == 5 时有效)
---     },
---
---     -- ============ 奖励数据 ============
---     awardData = {
---         zhishi = 10,                     -- [可选] 芝士数量  芝士 有芝士显示奖励芝士，没有回走服务器请求add_cheese_val 值 默认0
---         xueshi = 10,                    -- [可选] 学识数量
---         petExp = 10,                    -- [可选] 宠物经验值
---     },
---
---     -- ============ 匹配数据 ============
---     matchData = {
---         closeBtnType = 3,               -- [必填] 按钮显示类型：
---                                         --   1 = 3秒后自动关闭(不显示关闭按钮)
---                                         --   2 = 只显示关闭按钮
---                                         --   3 = 显示关闭和再来一局按钮
---     },
---
--- 服务器请求参数
---     requestParams = {
---         rank = 3,--排名
---         score = 55, --个人得分
---         team = nil,--团队胜负 暂时用不到
---         is_run = false,--是否逃跑
---         is_captor = false,--是否是抓捕者
---
---         [暂时] 游戏id
---         --game_id = game_id, 游戏id
---         --set_id = set_id,游戏局id  口语特工队 传 波数（第几波就穿几）
---         --plan_id = plan_id,场次ID
---         --award = ,--奖励的芝士数
---     }
---     -- ============ 游戏自定义数据 ============
---     gameData = {
---         winner = 1,                     -- [可选] 狼人侦探游戏  获胜情况(1=狼人获胜, 2=侦探获胜)
---                                         -- [可选] 枪战精英游戏  -1 平局  1team1 获胜  2team2 获胜
---         -- useTime = 68,                -- [可选] 用时(秒)
---         -- isFinish = false,            -- [可选] 是否完成
---     },
---
---     -- ============ 回调函数 ============
---     autoCloseCallBack = function()      -- [可选] 自动关闭时的回调  最终结算界面-自动关闭回调
---         g_LogColorMsg("自动关闭回调")
---     end,
---
---     clickCloseCallBack = function()     -- [可选] 点击关闭按钮的回调  最终结算界面-点击关闭回调
---         g_LogColorMsg("点击关闭回调")
---     end,
---
---     clickAgainCallBack = function()     -- [可选] 点击再来一局的回调  最终结算界面-点击再来一局回调
---         g_LogColorMsg("点击再来一局回调")
---     end,
--- }
---```
function GameResultStage:FillDataAndShowStage(data)
    data.has_upgrade = self.has_upgrade
    data.after_level = self.after_level
    data.add_value = self.add_value
    data.join_school_flag = self.join_school_flag
    data.is_school_settle = self.is_school_settle
    data.is_double_game = self.is_double_game
    data.jiziNum = self.jiziNum
    self.data = data

    self.isShowMVPStage = data.isShowMVPStage         --是否展示mvp舞台 默认展示（如游戏中途展示的时候没有MVP) 同时ui不展示MVP
    self.gameType = data.gameType                     --游戏类型 GAME_RESULT_GAME_TYPE
    self.rankData = data.rankData                     --排位数据
    self.titleData = data.titleData                   --标题数据
    self.awardData = data.awardData                   --奖励数据
    self.matchData = data.matchData                   --匹配数据
    self.gameData = data.gameData                     --游戏自定义数据
    self.autoCloseCallBack = data.autoCloseCallBack   --自动关闭回调函数
    self.clickCloseCallBack = data.clickCloseCallBack --点击关闭回调函数
    self.clickAgainCallBack = data.clickAgainCallBack --点击再来一局回调函数

    self.observerService:Fire(GAME_RESULT_SET_MAIN_PANEL, { isShow = false })
    --初始化数据
    self.config = GAME_RESULT_DATA_CONFIG[self.gameType]

    self:Print("FillDataAndShowStage data" .. table.dump(self.data))
    self:Print("FillDataAndShowStage rankData " .. table.dump(self.rankData))
    self:Print("FillDataAndShowStage titleData " .. table.dump(self.titleData))
    self:Print("FillDataAndShowStage awardData " .. table.dump(self.awardData))
    self:Print("FillDataAndShowStage matchData " .. table.dump(self.matchData))
    self:Print("FillDataAndShowStage gameData " .. table.dump(self.gameData))

    --获取玩家统计数据
    self.observerService:Fire(GET_RECORD_SCORE_DATA, {
        callback = function(playerStats, playerAvatarSprites)
            self.playerStats = playerStats or {}
            self.playerAvatarSprites = playerAvatarSprites or {}

            self:Print("获取玩家统计数据====== ", table.dump(self.playerStats))
            if data.isShowMVPStage then
                self:ShowMvpStage(data.callBack)
            else
                self:ShowResultCommonUI(data.callBack)
            end
        end
    })
end

--展示mvp舞台
function GameResultStage:ShowMvpStage(callBack)
    if self.isShow then
        return
    end
    self.isShow = true
    -- self:Print("获取玩家统计数据====== ", table.dump(self.playerStats))
    -- 获取MVP结算玩家和相关信息
    self:GetMVPPlayersByGameType()
    --展示mvp舞台UI
    self:LoadStage(function()
        if callBack and type(callBack) == "function" then
            callBack()
        end
    end)
end

--隐藏mvp舞台
function GameResultStage:HideMvpStage()
    if not self.isShow then
        return
    end
    self.isShow = false
    --隐藏所有克隆玩家
    for _, cloneAvatar in pairs(self.cloneAvatarMap) do
        CS.UnityEngine.GameObject.Destroy(cloneAvatar)
    end
    self.cloneAvatarMap = {}
    self.animatorMap = {}        -- 清空animator缓存
    self.playerRank = {}
    self.playerRankAnimator = {} -- 清空rank->animator映射
    self.vfx_caidaiA.gameObject:SetActive(false)
    self:HideMvpStageAudios()
    -- CS.UnityEngine.GameObject.Destroy(self.stagePrefab.gameObject)
    -- self.stagePrefab = nil
    self.stagePrefab.gameObject:SetActive(false)
end

--隐藏mvp舞台音效
function GameResultStage:HideMvpStageAudios()
    if self.bgAudioSource then
        self.audioService:StopAudioClip(self.bgAudioSource)
        self.bgAudioSource = nil
    end
    if self.tiaoAudioSource then
        self.audioService:StopAudioClip(self.tiaoAudioSource)
        self.tiaoAudioSource = nil
    end
    if self.guzhuangAudioSource then
        self.audioService:StopAudioClip(self.guzhuangAudioSource)
        self.guzhuangAudioSource = nil
    end
end

--初始化舞台
function GameResultStage:LoadStage(callBack)
    if self.stagePrefab then
        --克隆其他玩家
        self:ClonePlayerAvatars()
        if callBack and type(callBack) == "function" then
            callBack()
        end
        return
    end
    self:LoadRemoteUaddress(uAddress, function(success, prefab)
        if success and prefab then
            if self.prefab then
                ResourceManager:ReleaseObject(self.prefab)
                self.prefab = nil
            end
            self.prefab = prefab
            self.stagePrefab = CS.UnityEngine.Object.Instantiate(prefab, self.VisElement.transform).transform
            --初始化舞台
            self:InitStage()
            --克隆其他玩家
            self:ClonePlayerAvatars()
            --初始化
            if callBack and type(callBack) == "function" then
                callBack()
            end
        end
    end)
end

--初始化舞台
function GameResultStage:InitStage()
    self.stagePrefab.gameObject:SetActive(false)
    self.Pos0 = self.stagePrefab:Find("Pos0").transform
    self.Pos1 = self.stagePrefab:Find("Pos1").transform
    self.Pos2 = self.stagePrefab:Find("Pos2").transform
    self.Pos3 = self.stagePrefab:Find("Pos3").transform
    self.PosList = { self.Pos0, self.Pos1, self.Pos2, self.Pos3 }
    self.CameraGO = self.stagePrefab:Find("CameraGO").gameObject
    self.PosStart = self.stagePrefab:Find("PosStart").transform
    self.PosTop = self.stagePrefab:Find("PosTop").transform
    --设置到很远位置
    self.stagePrefab.transform.position = Vector3(23.28, 84.26321, -1000) --Vector3(0,0,0)
    self.stagePrefab.transform.rotation = Quaternion.Euler(0, 0, 0)
    self.stagePrefab.transform.localScale = Vector3(1, 1, 1)
    --音效
    self.qingzhubgm = self.stagePrefab:Find("Config/qingzhubgm").gameObject:GetComponent(typeof(CS.UnityEngine
        .AudioSource)).clip
    self.guzhuang = self.stagePrefab:Find("Config/guzhuang").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource))
        .clip
    self.tiao = self.stagePrefab:Find("Config/tiao").gameObject:GetComponent(typeof(CS.UnityEngine.AudioSource)).clip
    --特效
    self.vfx_caidaiA = self.stagePrefab:Find("vfx_caidaiA").gameObject
    --控制器替换
    self.Controller = self.stagePrefab:Find("Controller").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
        .runtimeAnimatorController
    --设置canvas的sortingOrder 挡住玩家头顶UI
    self.Canvas = self.stagePrefab:Find("Canvas"):GetComponent(typeof(CS.UnityEngine.Canvas))
    self.Canvas.sortingOrder = 2200 --(App.IsStudioClient or App:IsDebug()) and 200 or 2200

    self.idleClip = self.stagePrefab:Find("idle").gameObject:GetComponent(typeof(CS.UnityEngine.Animation)).clip
    self.kongfanClip = self.stagePrefab:Find("kongfan").gameObject:GetComponent(typeof(CS.UnityEngine.Animation)).clip
    self.qingzhuClip = self.stagePrefab:Find("qingzhu").gameObject:GetComponent(typeof(CS.UnityEngine.Animation)).clip
    self.tiaowuClip = self.stagePrefab:Find("tiaowu").gameObject:GetComponent(typeof(CS.UnityEngine.Animation)).clip

    self:Print("idleClip length: " .. self.idleClip.length)
    self:Print("kongfanClip length: " .. self.kongfanClip.length)
    self:Print("qingzhuClip length: " .. self.qingzhuClip.length)
    self:Print("tiaowuClip length: " .. self.tiaowuClip.length)
end

--endregion

--region 克隆玩家形象-----------------------------------------------------------------------------------------------------------------------------


--获取所有玩家的avatar并克隆玩家形象
function GameResultStage:ClonePlayerAvatars()
    self.playerRank = {}
    self.playerRankAnimator = {}
    self.animatorMap = {}

    local allAvatar = self:GetShowPlayerList()
    local totalAvatars = 0

    -- 计算总数
    for i, avatar in pairs(allAvatar) do
        totalAvatars = totalAvatars + 1
    end

    if totalAvatars == 0 then
        self.stagePrefab.gameObject:SetActive(true)
        return
    end

    -- 使用协程等待所有avatar克隆完成
    self.commonService:StartCoroutine(function()
        local completedCount = 0

        -- 开始克隆所有玩家
        for i, avatar in pairs(allAvatar) do
            --赛选排名
            self:ClonePlayerAvatar(avatar.avatarUuid, i, function()
                completedCount = completedCount + 1
            end)
        end

        -- 等待所有克隆完成
        coroutine.yield(self.commonService:WaitUntil(function()
            return completedCount >= totalAvatars
        end))

        --等一帧率 播放动画
        self:YieldEndFrame()

        --播放MVP展示音效
        self:ShowStageEffect()
    end)
end

--获取要展示的玩家列表
function GameResultStage:GetShowPlayerList()
    local showPlayerList = {}

    -- 1. 首先添加MVP玩家
    if self.mvpPlayerUuid then
        local mvpAvatar = self.avatarService:GetAvatarByUUID(self.mvpPlayerUuid)
        if mvpAvatar then
            table.insert(showPlayerList, mvpAvatar)
            self:Print("添加MVP玩家:", self.mvpPlayerUuid)
        else
            self:Print("未找到MVP玩家的Avatar:", self.mvpPlayerUuid)
        end
    end

    -- 2. 然后添加队友排名列表中的玩家
    if self.teammateRankingLists then
        for i, teammate in ipairs(self.teammateRankingLists) do
            local teammateAvatar = self.avatarService:GetAvatarByUUID(teammate.uuid)
            if teammateAvatar then
                table.insert(showPlayerList, teammateAvatar)
                self:Print("添加第", i, "名队友:", teammate.uuid)
            else
                self:Print("未找到队友的Avatar:", teammate.uuid)
            end
        end
    end

    self:Print("展示玩家列表总数:", #showPlayerList)
    for i, player in ipairs(showPlayerList) do
        self:Print("第", i, "名玩家:", player.avatarUuid)
    end
    return showPlayerList
end

-- ---递归激活所有子物体
-- ---@param transform UnityEngine.Transform 要激活的物体
-- function GameResultStage:ActivateAllChildren(transform)
--     if transform == nil then
--         return
--     end

--     -- 激活当前物体
--     if not transform.gameObject.activeSelf then
--         transform.gameObject:SetActive(true)
--     end

--     -- 递归激活所有子物体
--     local childCount = transform.childCount
--     for i = 0, childCount - 1 do
--         local child = transform:GetChild(i)
--         self:ActivateAllChildren(child)
--     end
-- end

---克隆其他玩家
function GameResultStage:ClonePlayerAvatar(uuid, rank, onComplete)
    -- print("克隆其他玩家 uuid= ", uuid)
    self.commonService:StartCoroutine(function()
        coroutine.yield(self.commonService:WaitUntil(function()
            return self.avatarService:GetAvatarByUUID(uuid) ~= nil
        end))

        --这里提前克隆过了，再做一次容错吧
        local cloneAvatar = self.cloneAvatarMap[uuid]
        if cloneAvatar == nil then
            self:Print("cloneAvatar获取失败 uuid= ", uuid)  
            if onComplete and type(onComplete) == "function" then
                onComplete()
            end
            return
        end
        --设置克隆玩家的朝向
        local body = cloneAvatar.transform:Find("__Body")
        if body == nil then
            self:Print("未找到__Body节点 uuid= ", uuid)
            if onComplete and type(onComplete) == "function" then
                onComplete()
            end
            return
        end
        body.localRotation = Quaternion.Euler(0, 0, 0)
        --游戏逻辑里有隐藏玩家的处理，这里需要激活
        body.gameObject:SetActive(true)

        local character = body.transform:Find("Character")
        if character then
            character.gameObject:SetActive(true)
        else
            self:Print("未找到Character节点 uuid= ", uuid)
            if onComplete and type(onComplete) == "function" then
                onComplete()
            end
            return
        end
        -- 递归激活所有子物体
        -- self:ActivateAllChildren(cloneAvatar.transform)

        -- 在SetActive(false)之前先获取必要的组件和引用
        local animator = cloneAvatar:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
        if animator == nil then
            self:Print("动画组件获取失败 uuid= ", uuid)
            if onComplete and type(onComplete) == "function" then
                onComplete()
            end
            return
        end

        -- 缓存animator引用，避免后续重复获取
        self.animatorMap[uuid] = animator
        -- animator.enabled = false

        -- 获取或添加Animation组件
        local characterAnimation = character.gameObject:GetComponent(typeof(CS.UnityEngine.Animation))
        if not characterAnimation then
            characterAnimation = character.gameObject:AddComponent(typeof(CS.UnityEngine.Animation))
        end

        --延迟一帧播放动画
        self:YieldEndFrame()
        characterAnimation:AddClip(self.idleClip,"idle")
        characterAnimation:Play("idle")


        cloneAvatar:SetActive(false)
        self:SetPlayerRank(uuid, rank, characterAnimation)

        --昵称 这里防止改2d 的 判断一下
        local roleCanvas = cloneAvatar.transform:FindInAll("RoleCanvas")
        if roleCanvas then
            roleCanvas.transform.localRotation = Quaternion.Euler(0, 0, 0)
            self.cloneAvatarHeadMap[uuid] = roleCanvas
            ---暂时不展示角色头像 需要兼容的问题太多，很多游戏都是后往RoleCanvas 上克隆UI很难处理，以后再处理
            roleCanvas.gameObject:SetActive(false)
        end

        --克隆时需要特殊隐藏物体
        local clone_role_special_hide_object = GAME_RESULT_DATA_CONFIG[self.gameType].clone_role_special_hide_object
        if clone_role_special_hide_object then
            for _, object in ipairs(clone_role_special_hide_object) do
                local obj = cloneAvatar.transform:FindInAll(object)
                if obj then
                    obj.gameObject:SetActive(false)
                end
            end
        end
        cloneAvatar:SetActive(true)
        -- 克隆完成回调
        if onComplete and type(onComplete) == "function" then
            onComplete()
        end
    end)
end

--根据排名设置 玩家到self.PosLis中的位置
function GameResultStage:SetPlayerRank(uuid, rank, animator)
    local pos = self.PosList[rank]
    local cloneAvatar = self.cloneAvatarMap[uuid]
    if cloneAvatar == nil then
        self:Print("克隆玩家失败 uuid= ", uuid)
        return
    end

    -- animator 现在作为参数传入，不再在这里获取
    if animator == nil then
        self:Print("动画组件为空 uuid= ", uuid)
        return
    end
    --特殊处理mvp玩家位置旋转
    if rank == 1 then
        cloneAvatar.transform:SetParent(self.PosStart, true)
        cloneAvatar.transform.position = self.PosStart.position -- + Vector3.up * 0.63
        cloneAvatar.transform.localRotation = Quaternion.Euler(0, 0, 0)
    else
        cloneAvatar.transform:SetParent(pos, true)
        cloneAvatar.transform.position = pos.position -- + Vector3.up * 0.63
        cloneAvatar.transform.localRotation = Quaternion.Euler(0, 0, 0)
    end
    --播放静止动画
    -- animator:SetBool("isIdle", true)
    -- animator.runtimeAnimatorController = self.Controller

    self.playerRank[rank] = cloneAvatar
    self.playerRankAnimator[rank] = animator -- 同时缓存animator供ShowStageEffect使用
end

--展示舞台
function GameResultStage:ShowStageEffect()
    -- 所有克隆完成后激活舞台
    self.stagePrefab.gameObject:SetActive(true)
    --播放背景音乐
    if self.bgAudioSource then
        self.audioService:StopAudioClip(self.bgAudioSource)
        self.bgAudioSource = nil
    end
    self.bgAudioSource = self.audioService:PlayClipLoop(self.qingzhubgm)
    --玩家
    for rank, cloneAvatar in pairs(self.playerRank) do
        -- 使用缓存的animator，避免在这里重新获取
        local animator = self.playerRankAnimator[rank]
        if animator == nil then
            self:Print("警告：rank ", rank, " 的animator未找到，尝试重新获取")
            -- animator = cloneAvatar:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
        end
        local pos = self.PosList[rank]
        if rank == 1 then
            --播放跳跃动画
            -- animator:SetBool("kongfan", true)
            animator:AddClip(self.kongfanClip,"kongfan")
            animator:CrossFade("kongfan",0.3)

            --持续做胜利动作
            -- animator:SetBool("tiaowu", true)

            -- 抛物线运动动画
            local seq = DOTween:Sequence()
            -- 第一段：1秒内从PosStart上升到最高点PosTop，速度逐渐减小到0 self.PosTop.position
            local posTop = self.PosStart.position + Vector3(0, 1.5, -1)
            seq:Append(cloneAvatar.transform:DOMove(posTop, JUMP_ANIMATION_FRAME_TOP / 30):SetEase(Ease.OutCubic))
            -- 第二段：0.5秒从PosTop到pos，速度越来越快
            seq:Append(cloneAvatar.transform:DOMove(pos.position, (JUMP_ANIMATION_FRAME - JUMP_ANIMATION_FRAME_TOP) / 30)
                :SetEase(Ease.InCubic))
            -- 动画完成后的回调
            seq:AppendCallback(function()
                -- animator:SetBool("kongfan", false)
                animator:AddClip(self.tiaowuClip,"tiaowu")
                animator:CrossFade("tiaowu",0.3)

                self.tiaoAudioSource = self.audioService:PlayClipOneShot(self.tiao)
                seq:Kill()
            end)
            self:StartCoroutine(function()
                self:YieldSeconds(JUMP_ANIMATION_FRAME / 30) -- 等待动画时长
                --播放庆祝特效
                self.vfx_caidaiA.gameObject:SetActive(true)
                self:YieldSeconds((MVP_WAIT_FRAME) / 30)
                --展示段位页
                if self.rankData.isShowRankPanel then
                    self.observerService:Fire(SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST, {
                        type = self.rankData.type,
                        isFailed = self.rankData.isFailed,
                        isTeamWin = self.rankData.isTeamWin,
                    })
                    --隐藏mvp舞台音频
                    self:HideMvpStageAudios()
                else
                    self:ShowMvpStageUI()
                end
            end)
        else
            self:StartCoroutine(function()
                self:YieldSeconds(JUMP_ANIMATION_FRAME / 30) -- 等待动画时长
                --持续做鼓掌动作
                -- animator:SetBool("qingzhu", true)
                animator:AddClip(self.qingzhuClip,"qingzhu")
                animator:CrossFade("qingzhu",0.3)
                self.guzhuangAudioSource = self.audioService:PlayClipOneShot(self.guzhuang)
            end)
        end
    end
end

--展示mvp舞台UI
function GameResultStage:ShowMvpStageUI()
    self.observerService:Fire(SHOW_MVP_STAGE_UI, {
        callBack = function()

        end,
        isShowMVPStage = self.isShowMVPStage,                                          --是否展示mvp舞台
        gameType = self.gameType,                                                      --游戏ID 7q8DJQY69E6TxTBCbwuZw
        titleData = self.titleData,                                                    --标题数据
        gameData = self.gameData,                                                      --游戏自定义数据
        awardData = self.awardData,                                                    --奖励数据
        matchData = self.matchData,                                                    --匹配数据
        autoCloseCallBack = self.autoCloseCallBack,                                    --自动关闭回调函数
        clickCloseCallBack = self.clickCloseCallBack,                                  --点击关闭回调函数
        clickAgainCallBack = self.clickAgainCallBack,                                  --点击再来一局回调函数
        -- showMvpStageCallBack = self.showMvpStageCallBack, --舞台展示回调函数
        playerStats = self.playerStats,                                                --所有玩家统计数据
        -- MVP数据
        mvpPlayerUuid = self.mvpPlayerUuid,                                            --MVP玩家UUID
        mvpPlayerScoreStats = self:CalculatePlayerStudyScoreStats(self.mvpPlayerUuid), --MVP玩家评分数据
        -- SVP数据
        svpPlayerUuid = self.svpPlayerUuid,                                            --SVP玩家UUID

        --请求数据
        change_score = self.change_score,
        ranking_before = self.ranking_before,
        ranking_after = self.ranking_after,
        is_protect = self.is_protect,
        protect_score = self.protect_score,
        is_school_settle = self.is_school_settle,
        join_school_flag = self.join_school_flag,
        add_value = self.add_value,
        has_upgrade = self.has_upgrade,
        after_level = self.after_level,
        is_double_game = self.is_double_game,
        add_cheese_val = self.add_cheese_val,
        grow_route_info = self.grow_route_info,
        season_id = self.season_id,
        jiziNum = self.jiziNum,

        playerAvatarSprites = self.playerAvatarSprites, --玩家头像
    })
end

--展示提前结算UI
function GameResultStage:ShowResultCommonUI(callBackShowUI)
    self.observerService:Fire(SHOW_RESULT_COMMON_UI, {
        callBack = function()
            if callBackShowUI and type(callBackShowUI) == "function" then
                callBackShowUI()
            end
        end,
        isShowMVPStage = self.isShowMVPStage,           --是否展示mvp舞台 默认展示（如游戏中途展示的时候没有MVP) 同时ui不展示MVP
        gameType = self.gameType,                       --游戏类型 GAME_RESULT_GAME_TYPE
        titleData = self.titleData,                     --标题数据
        awardData = self.awardData,                     --奖励数据
        matchData = self.matchData,                     --匹配数据
        gameData = self.gameData,                       --游戏自定义数据
        autoCloseCallBack = self.autoCloseCallBack,     --自动关闭回调函数
        clickCloseCallBack = self.clickCloseCallBack,   --点击关闭回调函数
        clickAgainCallBack = self.clickAgainCallBack,   --点击再来一局回调函数
        playerStats = self.playerStats,                 --所有玩家统计数据
        mvpPlayerUuid = self.mvpPlayerUuid,             --MVP玩家UUID
        mvpPlayerScoreStats = self.mvpPlayerScoreStats, --MVP玩家评分数据
        svpPlayerUuid = self.svpPlayerUuid,             --SVP玩家UUID
        --请求数据
        change_score = self.change_score,
        ranking_before = self.ranking_before,
        ranking_after = self.ranking_after,
        is_protect = self.is_protect,
        protect_score = self.protect_score,
        is_school_settle = self.is_school_settle,
        join_school_flag = self.join_school_flag,
        add_value = self.add_value,
        has_upgrade = self.has_upgrade,
        after_level = self.after_level,
        is_double_game = self.is_double_game,
        add_cheese_val = self.add_cheese_val,
        grow_route_info = self.grow_route_info,
        season_id = self.season_id,
        jiziNum = self.jiziNum,
        playerAvatarSprites = self.playerAvatarSprites, --玩家头像
    })
end

--隐藏所有玩家头像
function GameResultStage:HideAllPlayerHead()
    if self.cloneAvatarHeadMap == nil then
        return
    end
    for uuid, roleCanvas in pairs(self.cloneAvatarHeadMap) do
        roleCanvas.gameObject:SetActive(false)
    end
    self.cloneAvatarHeadMap = {}
end

--endregion

--region 根据不同游戏模式获取谁是MVP-----------------------------------------------------------------------------------------------------------------------------

---获取MVP结算玩家和相关信息
function GameResultStage:GetMVPPlayersByGameType()
    self:Print("获取MVP结算玩家和相关信息GetMVPPlayersByGameType====== ", table.dump(self.playerStats))

    local gameConfig = GAME_RESULT_DATA_CONFIG[self.gameType]
    if gameConfig == nil then
        self:Print("获取游戏配置失败 gameType:", self.gameType)
        return
    end

    local rule = gameConfig.game_mvp_and_svp_rule
    if rule == nil then
        self:Print("获取游戏MVP和SVP配置失败 gameType:", self.gameType)
        return
    end

    local get_type = rule.get_type
    if get_type == nil then
        self:Print("获取游戏MVP和SVP配置失败 gameType:", self.gameType, "get_type= ", rule.get_type)
        return
    end

    --个人类型游戏
    if gameConfig.game_type == 1 then
        self:GetPersonalTypeGameMVP(rule)
        --团队类型游戏
    elseif gameConfig.game_type == 2 then
        local teamTypeKey = gameConfig.teamTypeKey
        if teamTypeKey == nil then
            self:Print("获取游戏配置失败 gameType:", self.gameType, "teamTypeKey= ", teamTypeKey)
            return
        end
        --狼人获胜情况 (rank = 1) 侦探获胜情况 (rank = 2)
        -- winner --获胜方  -1 平局  1team1 获胜  2team2 获胜  3team3 获胜  4team4 获胜
        self:GetTeamTypeGameMVPAndSVP(self.gameData.winner, rule, teamTypeKey)
    end
end

---获取团队类型游戏 MVP和SVP玩家
---@param winner string 获胜方  -1 平局  1team1 获胜  2team2 获胜  3team3 获胜  4team4 获胜
---@param rule table 游戏MVP和SVP配置规则 game_mvp_and_svp_rule
---@param teamTypeKey string 队伍类型关键字
function GameResultStage:GetTeamTypeGameMVPAndSVP(winner, rule, teamTypeKey)
    if winner == nil or self.playerStats == nil then
        self:Print("获取MVP玩家和相关信息失败 winner= ", winner, "self.playerStats= ", self.playerStats)
        return
    end

    local MVPkey = nil
    local SVPkey = nil
    if rule.get_type == 1 then
        MVPkey = rule.mvpKey
        SVPkey = rule.svpKey
    elseif rule.get_type == 2 then
        local mvpKeys = rule.mvpKey
        if mvpKeys then
            MVPkey = mvpKeys[winner]
        end
        local svpKeys = rule.svpKey
        if svpKeys then
            SVPkey = svpKeys[winner]
        end
    else
        self:Print("获取团队类型游戏MVP玩家和相关信息失败 get_type= ", rule.get_type)
    end

    if MVPkey then
        local winnerPlayerStats = table.choose(self.playerStats, function(uuid, data)
            return data[teamTypeKey] == winner
        end)
        -- 获取MVP玩家
        self.mvpPlayerUuid = self:GetHighestScoreWinner(winnerPlayerStats, MVPkey)
        -- 获取MVP玩家的队友排名（不包含MVP玩家，最多3个）
        self.teammateRankingLists = self:GetMVPTeammateRankingLists(winnerPlayerStats, MVPkey)
        self:Print("MVP玩家 uuid= ", self.mvpPlayerUuid)
        self:Print("MVP玩家的队友排名列表= ", table.dump(self.teammateRankingLists))
    end

    if SVPkey then
        --失败玩家统计数据
        local loserPlayerStats = table.choose(self.playerStats, function(uuid, data)
            return data[teamTypeKey] ~= winner
        end)
        --SVP玩家
        self.svpPlayerUuid = self:GetHighestScoreWinner(loserPlayerStats, SVPkey)
        self:Print("SVP玩家 uuid= ", self.svpPlayerUuid)
    end
end

---获取个人类型游戏 MVP和SVP玩家
---@param rule table 游戏MVP和SVP配置规则 game_mvp_and_svp_rule
function GameResultStage:GetPersonalTypeGameMVP(rule)
    if self.playerStats == nil then
        self:Print("获取MVP玩家和相关信息失败 self.playerStats= ", self.playerStats)
        return
    end
    -- 没有队友
    self.teammateRankingLists = nil

    ---【排名类游戏，特殊处理】如果self.playerStats 有统计每个玩家的rank 字段，则使用rank字段的排序，确定MVP玩家，否则使用得分确定MVP玩家
    --- 否则会导致mvp不一致 如泡泡炸弹人游戏，玩家得分相同，但是排名不同，会导致mvp不一致
    local rankList = {}
    for uuid, data in pairs(self.playerStats) do
        if data[GAME_RESULT_DATA_KEYS.RANK] then
            table.insert(rankList, {
                uuid = uuid,
                rank = data[GAME_RESULT_DATA_KEYS.RANK]
            })
        end
    end

    if #rankList > 0 then
        table.sort(rankList, function(a, b)
            return a.rank < b.rank --值越小是mvp 排名越靠前
        end)
        self.mvpPlayerUuid = rankList[1].uuid
        self:Print("获取个人类型游戏MVP玩家和相关信息成功 MVP玩家 uuid= ", self.mvpPlayerUuid)
        return
    end

    --使用MVPkey 获取MVP玩家
    if rule.get_type == 1 then
        -- 获取MVP玩家 只展示击败人数最多的一个玩家 没有队友
        local MVPkey = rule.mvpKey
        if MVPkey then
            self.mvpPlayerUuid = self:GetHighestScoreWinner(self.playerStats, MVPkey)
            self:Print("获取个人类型游戏MVP玩家和相关信息成功 MVP玩家 uuid= ", self.mvpPlayerUuid)
        else
            self:Print("获取个人类型游戏 获取MVP玩家和相关信息失败 MVPkey= ", MVPkey)
        end
    else
        self:Print("获取个人类型游戏 获取MVP玩家和相关信息失败  get_type= ", rule.get_type ~= 1)
        return
    end
end

---获取MVP玩家的队友排名（不包含MVP玩家，按得分从高到低，最多3个）
---@param winnerPlayerStats table 获胜方玩家统计数据
---@param sortKey string 排序关键字
---@return table 队友排名列表，格式：[{uuid=玩家UUID, person_score=得分, ...}, ...]
function GameResultStage:GetMVPTeammateRankingLists(winnerPlayerStats, sortKey)
    if not winnerPlayerStats then
        return {}
    end

    local mvpUuid = self.mvpPlayerUuid
    local teammates = {}

    -- 筛选队友（不包含自己）
    for uuid, data in pairs(winnerPlayerStats) do
        if uuid ~= mvpUuid then
            table.insert(teammates, {
                uuid = uuid,
                data = data
            })
        end
    end

    local keySortRule = GAME_RESULT_DATA_DISPLAY[sortKey].key_sort_rule
    if not keySortRule then
        self:Print("获取游戏关键项目数据失败 keySortRule= 请配置GAME_RESULT_DATA_DISPLAY ", keySortRule)
        return {}
    end
    -- 按得分从高到低排序
    table.sort(teammates, function(a, b)
        if keySortRule == 1 or keySortRule == nil then
            return (a.data[sortKey] or 0) > (b.data[sortKey] or 0) --值越大是mvp
        elseif keySortRule == 2 then
            return (a.data[sortKey] or 0) < (b.data[sortKey] or 0) --值越小是mvp
        end
        return (a.data[sortKey] or 0) > (b.data[sortKey] or 0)     --默认值越大是mvp
    end)

    -- 限制数量为3个
    local result = {}
    local maxCount = math.min(3, #teammates)
    for i = 1, maxCount do
        table.insert(result, teammates[i])
    end

    self:Print("队友排名数量:", #result)
    for i, teammate in ipairs(result) do
        self:Print("第", i, "名队友:", teammate.uuid, "得分:", teammate.data[sortKey] or 0)
    end

    return result
end

---获取获胜方中得分最高的玩家
---@param winnerPlayerStats table 获胜方玩家统计数据 格式：[uuid] = {sortKey=得分, ...}
---@param sortKey string 排序关键字
---@return string|nil 返回得分最高的玩家UUID，如果没有则返回nil
function GameResultStage:GetHighestScoreWinner(winnerPlayerStats, sortKey)
    if not winnerPlayerStats then
        return nil
    end

    if GAME_RESULT_DATA_DISPLAY[sortKey] == nil then
        self:Print("获取游戏关键项目数据失败 gameKey= 请配置GAME_RESULT_DATA_DISPLAY ", sortKey)
        return nil
    end

    -- 将获胜方玩家转换为数组格式
    local winnerPlayers = {}
    for uuid, data in pairs(winnerPlayerStats) do
        local defaultScore = nil
        defaultScore = GAME_RESULT_DATA_DISPLAY[sortKey].default or 0 -- 默认值为0
        local score = data[sortKey] or defaultScore                   -- 获取得分

        table.insert(winnerPlayers, {
            uuid = uuid,
            [sortKey] = score,
            data = data
        })
    end

    -- 如果没有获胜方玩家，返回nil
    if #winnerPlayers == 0 then
        self:Print("没有找到获胜方玩家 sortKey= ", sortKey)
        return nil
    end

    local keySortRule = GAME_RESULT_DATA_DISPLAY[sortKey].key_sort_rule
    if not keySortRule then
        self:Print("获取游戏关键项目数据失败 keySortRule= 请配置GAME_RESULT_DATA_DISPLAY ", keySortRule)
        return nil
    end

    -- 找到最高得分 或者最低得分
    local maxScore = nil
    if keySortRule == 1 or keySortRule == nil then
        maxScore = -math.huge
    elseif keySortRule == 2 then
        --最大正整数
        maxScore = math.huge
    end

    for _, player in ipairs(winnerPlayers) do
        if keySortRule == 1 or keySortRule == nil then
            if player[sortKey] > maxScore then
                maxScore = player[sortKey]
            end
        elseif keySortRule == 2 then
            if player[sortKey] < maxScore then
                maxScore = player[sortKey]
            end
        end
    end

    -- 筛选出得分最高的玩家们 或者最低得分的玩家们
    local highestScorePlayers = {}
    for _, player in ipairs(winnerPlayers) do
        if player[sortKey] == maxScore then
            table.insert(highestScorePlayers, player)
        end
    end

    -- 如果没有找到任何最高得分玩家，返回nil
    if #highestScorePlayers == 0 then
        self:Print("没有找到任何最高得分玩家 sortKey= ", sortKey)
        return nil
    end

    -- 如果只有一个最高得分玩家，直接返回
    if #highestScorePlayers == 1 then
        self:Print("找到唯一最高得分玩家:", highestScorePlayers[1].uuid)
        return highestScorePlayers[1].uuid
    end

    -- 多个玩家得分相同的情况
    -- 1. 如果"我"在其中，优先返回"我"
    local myUuid = App.Uuid
    for _, player in ipairs(highestScorePlayers) do
        if player.uuid == myUuid then
            self:Print("多人同分，优先返回自己:", myUuid)
            return myUuid
        end
    end

    -- 2. "我"不在其中，对比学习成绩
    local bestStudyPlayers = {}
    local maxStudyScore = -1

    for _, player in ipairs(highestScorePlayers) do
        -- 计算学习成绩
        local studyStats = self:CalculatePlayerStudyScoreStats(player.uuid)
        local studyScore = studyStats.totalScore or 0

        if studyScore > maxStudyScore then
            maxStudyScore = studyScore
            bestStudyPlayers = { player }
        elseif studyScore == maxStudyScore then
            table.insert(bestStudyPlayers, player)
        end
    end

    -- 如果学习成绩也有多个相同的，随机选择一个
    if #bestStudyPlayers > 1 then
        math.randomseed(os.time())
        local randomIndex = math.random(1, #bestStudyPlayers)
        self:Print("学习成绩也相同，随机选择:", bestStudyPlayers[randomIndex].uuid)
        return bestStudyPlayers[randomIndex].uuid
    elseif #bestStudyPlayers == 1 then
        self:Print("按学习成绩选择:", bestStudyPlayers[1].uuid)
        return bestStudyPlayers[1].uuid
    else
        -- 兜底：如果没有学习成绩数据，随机选择一个最高得分玩家
        math.randomseed(os.time())
        local randomIndex = math.random(1, #highestScorePlayers)
        self:Print("无学习成绩数据，随机选择:", highestScorePlayers[randomIndex].uuid)
        return highestScorePlayers[randomIndex].uuid
    end
end

---获取所有玩家中总分最高的玩家
---@return string 玩家UUID  nil表示没有总分最高的玩家
function GameResultStage:GetHighestScorePlayer()
    local highestScore = 0
    local highestScorePlayer = nil
    for uuid, data in pairs(self.playerStats) do
        local score = self:CalculatePlayerStudyScoreStats(uuid)
        if score.totalScore > highestScore then
            highestScore = score.totalScore
            highestScorePlayer = uuid
        end
    end
    if not highestScorePlayer then
        self:Print("没有总分最高的玩家，默认返回自己")
        return App.Uuid
    end
    self:Print("总分最高的玩家 uuid= ", highestScorePlayer)
    return highestScorePlayer
end

--计算某个玩家学习成绩
---@param uuid string 玩家UUID
---@return table 玩家学习成绩
function GameResultStage:CalculatePlayerStudyScoreStats(uuid)
    local stats = nil
    --如果是英语
    if App.modPlatform == MOD_PLATFORM.ABCZone then
        stats = {
            avgScore = 0,             -- 平均开口分
            readSentenceCount = 0,    -- 朗读句子数
            sentenceAccuracyRate = 0, -- 句子准确率
            totalScore = 0,           -- 总分
        }

        local playerStats = self.playerStats[uuid]
        if not playerStats then
            self:Print("CalculatePlayerStudyScoreStats 玩家学习成绩数据为空 uuid= ", uuid)
            return stats
        end
        -- 数据太大-优化到服务端计算
        -- 平均分取整
        stats.avgScore = playerStats[GAME_RESULT_DATA_KEYS.AVG_SCORE] or GAME_RESULT_DATA_KEYS.AVG_SCORE.default or 0

        -- 朗读句子数
        stats.readSentenceCount = playerStats[GAME_RESULT_DATA_KEYS.READ_SENTENCE_COUNT] or
            GAME_RESULT_DATA_KEYS.READ_SENTENCE_COUNT.default or 0

        -- 句子准确率（通过的句子占比）取整
        stats.sentenceAccuracyRate = playerStats[GAME_RESULT_DATA_KEYS.SENTENCE_ACCURACY_RATE] or
            GAME_RESULT_DATA_KEYS.SENTENCE_ACCURACY_RATE.default or 0
        -- 总分
        stats.totalScore = playerStats[GAME_RESULT_DATA_KEYS.TOTAL_SCORE] or GAME_RESULT_DATA_KEYS.TOTAL_SCORE.default or
            0
    elseif App.modPlatform == MOD_PLATFORM.Math then
        stats = {
            avgScore = 0, -- 平均分
        }

        local playerStats = self.playerStats[uuid]
        if not playerStats or #playerStats == 0 then
            return stats
        end

        -- TODO: 实现数学平台的统计计算逻辑
        -- 例如：计算平均分等
    elseif App.modPlatform == MOD_PLATFORM.Chinese then
        stats = {
            readSentenceCount = 0, -- 朗读句子数
        }

        local playerStats = self.playerStats[uuid]
        if not playerStats or #playerStats == 0 then
            return stats
        end

        -- TODO: 实现语文平台的统计计算逻辑
        -- 例如：计算朗读句子数等
    end
    self:Print("CalculatePlayerStudyScoreStats====== ", table.dump(stats))
    return stats
end

--endregion

--region 请求结算-----------------------------------------------------------------------------------------------------------------------------
-- {
-- 	"stat": 1,
-- 	"code": 0,
-- 	"msg": "success",
-- 	"data": {
-- 		"user_id": 1090000075, // 用户ID
-- 		"change_score": 0, //变化值
-- 		"is_protect": false, //是否是保分局
-- 		"protect_score": 0, // //保分分数
-- 		"ranking_before": { //变化前排位信息
-- 			"level": 1, // 等级
-- 			"level_name": "磐石", // 等级名称
-- 			"section_num": 1, // 段位
-- 			"section_name": "1", // 段位名称
-- 			"section_score": 0 // 段位星星
-- 		},
-- 		"ranking_after": { //变化后排位信息
-- 			"level": 1,
-- 			"level_name": "磐石",
-- 			"section_num": 1,
-- 			"section_name": "1",
-- 			"section_score": 2
-- 		},
-- 		"add_cheese_val": 20, //  添加的芝士数
-- 		"ext_info": "{\"sub_way_more_histoey\":false}", //  扩展字段 sub_way_more_histoey：地铁跑酷是否超过历史最高分 false 否 true 是
-- 		"has_upgrade": false, //  是否升级
-- 		"after_level": 0, // 升级后的级别
-- 		"add_value": 75, //  加的经验值
-- 		"join_school_flag": false, //  是否加入学校
-- 		"is_school_settle": true, //  是否有学校结算
-- 		"is_double_game": false, //  是否双倍经验
-- 		"grow_route_info": { //  成长之路信息
-- 			"user_id": 1090000264, // 用户ID
-- 			"after_stage": 6, //  结算后的阶段
-- 			"after_step": 5, //结算后的经验值
-- 			"locking_award_img": "", //  结算后解锁中的奖励图片
-- 			"cost_emp_val": 140, //  获得奖励需要的总经验值
-- 			"cur_emp_val": 63, //  已经得到的经验值
-- 			"before_stage":5, //  结算前的阶段
-- 			"before_step":5, // 结算前解锁中的奖励
-- 			"before_emp_val":4, // 结算前的经验值
-- 			"award_num":20 ,//  奖励数量
-- 			"can_own_list": [ //  获得的奖励列表
-- 				{
-- 					"stage": 1, //  阶段
-- 					"step": 1, //  奖励
-- 					"award_img": "wfrwgrg", //  奖励图片
-- 					"cost_emp_val": 20, //  奖励需要耗费的经验值
-- 					"award_num":20 //  奖励数量
-- 				},
-- 				{
-- 					"stage": 1,
-- 					"step": 2,
-- 					"award_img": "wfrwgrg",
-- 					"cost_emp_val": 20,
-- 					"award_num":20 //  奖励数量
-- 				}
-- 			],
-- 			"is_full": false ,//  是否已经满级
-- 			"big_award_img":"cdwvwdvwdvwdv" //  大奖图片 未加入学校的时候使用
-- 		},
-- 		"season_id":4 ,//  赛季id
-- 		"word_num":2 //  获得的字数量
-- 	},
-- 	"traceId": "pts_adsbdf_9"
-- }
---请求结算
---@param data table 数据
---@param callback function 回调函数
function GameResultStage:requestPersonSettle(data, callback)
    local game_id = tonumber(self.game_id)
    local set_id = tonumber(self.set_id)
    local plan_id = tonumber(self.plan_id)

    if data.game_id then
        self.game_id = game_id
        game_id = tonumber(data.game_id)
    end
    if data.set_id then
        set_id = tonumber(data.set_id)
    end
    if data.plan_id then
        plan_id = tonumber(data.plan_id)
    end


    -- 入参说明：
    -- {
    -- "game_id":86, //。游戏id  比传
    -- "set_id":2, //。游戏局id  口语特工队 传 波数（第几波就穿几）
    -- "plan_id":202, // 场次ID
    -- "rank":1, //。排名
    -- "score":20, //得分。地跌跑酷时传积分
    -- "award":10, // 奖励的芝士数
    -- "team":1, //。团队胜负 暂时用不到
    -- "is_run":false, // 是否逃跑
    -- "is_captor":false  // 是否是抓捕者
    -- }
    local params = {
        game_id = game_id,
        set_id = set_id,
        plan_id = plan_id,

        rank = data.requestParams.rank,
        score = data.requestParams.score,
        award = data.awardData.zhishi,

        team = data.requestParams.team,
        is_run = data.requestParams.is_run,
        is_captor = data.requestParams.is_captor
    }


    self:Print("上报自己积分入参", table.dump(params))

    -- 成功回调
    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end

            self:Print("上报自己积分结果", table.dump(msg))

            if msg and msg.msg == "success" then
                if msg.code == 0 then
                    local data = msg.data
                    if data then
                        -- 填充数据
                        -- 返回值说明：
                        -- "change_score":3,
                        -- "ranking_before":{"level":"1","level_name":"磐石","level_score":0},
                        -- "ranking_after":{"level":"1","level_name":"磐石","level_score":3}
                        self:Print("上报自己积分成功")

                        if self.change_score == nil then
                            self.change_score = data.change_score
                        end
                        if self.ranking_before == nil then
                            self.ranking_before = data.ranking_before
                        end
                        if self.ranking_after == nil then
                            self.ranking_after = data.ranking_after
                        end
                        if self.is_protect == nil then
                            self.is_protect = data.is_protect
                        end
                        if self.protect_score == nil then
                            self.protect_score = data.protect_score
                        end
                        if self.is_school_settle == nil then
                            self.is_school_settle = data.is_school_settle
                        end
                        if self.join_school_flag == nil then
                            self.join_school_flag = data.join_school_flag
                        end
                        if self.add_value == nil then
                            self.add_value = data.add_value
                        end
                        if self.has_upgrade == nil then
                            self.has_upgrade = data.has_upgrade
                        end
                        if self.after_level == nil then
                            self.after_level = data.after_level
                        end
                        if self.is_double_game == nil then
                            self.is_double_game = data.is_double_game
                        end
                        if self.add_cheese_val == nil then
                            self.add_cheese_val = data.add_cheese_val
                        end
                        if self.grow_route_info == nil then
                            self.grow_route_info = data.grow_route_info
                        end
                        if self.season_id == nil then
                            self.season_id = data.season_id
                        end
                        if self.jiziNum == nil then
                            self.jiziNum = data.word_num
                        end
                    end
                end
                if callback then
                    callback()
                end
            else
                self:Print("上报自己积分失败")
                if callback then
                    callback()
                end
            end
        end
    end

    -- 失败回调
    local fail = function(res)
        self:Print("上报自己积分请求失败", table.dump(res))
        if callback then
            callback()
        end
    end

    self:HttpRequest("/v3/game/person-settle", params, success, fail)
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function GameResultStage:ReceiveMessage(key, value, isResume)
    if key == fsync_activateRoom then
        local lastMsg = value[#value]
        if lastMsg and not self.activeQuestionType then
            self:Print("activateRoom " .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if msg.question_type then
                    self.activeQuestionType = tonumber(msg.question_type)
                else
                    self.activeQuestionType = 0
                end

                if msg.game_type then
                    self.gameMode = tonumber(msg.game_type)
                    self:Print("游戏模式" .. self.gameMode)
                end

                self.game_id = msg.game_id
                self.set_id = msg.set_id
                self.plan_id = msg.plan_id
            end
        end
    elseif key == process_game_result then
        local lastMsg = value[#value]
        if lastMsg then
            self:Print("团队游戏，展示结果页消息" .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if self.teamResultsHasShow == true then
                    return
                end
                self.teamResultsHasShow = true
                if msg.isSuccessed then
                    -- 解析团队游戏结果并进行展示
                    -- /v3/game/team-settle 接口
                    self.msg = msg
                    local result = self:buildResultData(msg)
                    -- if msg.contentType then
                    --     result["contentType"] = msg.contentType ---- TODO删掉？？？ 内容类别：1.包含用时、芝士、经验 2.包含芝士、经验 3.包含经验 4.包含芝士 5.包含芝士、学识、经验
                    -- end
                    -- 延迟两秒显示结果页
                    if msg.delay then
                        if msg.delay >= 0 then
                            self.commonService:DispatchAfter(msg.delay, function()
                                self:Print("团队游戏，展示结果页消息成功")
                                self.BusEventService:Fire(SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST, result)
                            end)
                        else
                            self.teamReslutData = result
                        end
                    else
                        self:Print("团队游戏，展示结果页消息成功")
                        self.BusEventService:Fire(SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST, result)
                    end
                else
                    self:Print("团队游戏，展示结果页消息失败")
                end
            end
        end
    elseif key == game_remote_params then
        local lastMsg = value[#value]
        if lastMsg then
            self:Print("game_remote_params " .. lastMsg)
            local msg = self.jsonService:decode(lastMsg)
            if msg then
                if msg.game_id then
                    self.game_id = msg.game_id
                end
                if msg.set_id then
                    self.set_id = msg.set_id
                end
                if msg.plan_id then
                    self.plan_id = msg.plan_id
                end
            end
        end
    end
end

-- ## 五.结算模块
-- -- 显示个人结算界面
-- resultModule:ShowPersonalResult({
--     rank = 1,             -- 排名，必填
--     award = 100,          -- 奖励，必填
--     score = 500,          -- 分数，必填
--     rankListType = 1,     -- 排行榜类型，可选，默认1
--     titleType = 1,        -- 标题类型，可选，默认1
--     contentType = 1,      -- 内容类型，可选，默认1
--     closeBtnType = 2,     -- 关闭按钮类型，可选，默认2
--     clickCloseCallBack = function() -- 关闭按钮回调，可选
--         -- 自定义关闭逻辑，默认调用App:GameReturn()
--     end
-- })
-- 参数说明：
-- | 参数 | 类型 | 说明 | 是否必填 |
-- |------|------|------|----------|
-- | rank | number | 玩家排名 | 是 |
-- | award | number | 玩家获得的奖励 | 是 |
-- | score | number | 玩家得分 | 是 |
-- | rankListType | number | 排行榜类型 | 否，默认1 |
-- | titleType | number | 标题类型 | 否，默认1 |
-- | contentType | number | 内容类型 | 否，默认1 |
-- | closeBtnType | number | 关闭按钮类型 | 否，默认2 |
-- | clickCloseCallBack | function | 关闭按钮回调函数 | 否，默认调用App:GameReturn() |

-- #### 3.结算界面样式类型说明
-- **排行榜类型(rankListType)**
-- - 1: 标准排行榜
-- - 2: 简洁排行榜
-- **标题类型(titleType)**
-- - 1: "游戏结束"
-- - 2: "挑战成功"
-- **内容类型(contentType)**
-- - 1: 显示排名+得分
-- - 2: 仅显示得分
-- **关闭按钮类型(closeBtnType)**
-- - 1: "继续"
-- - 2: "确定"

-- #### 4.使用示例
-- ```lua
-- -- 初始化游戏管理器
-- GameModuleManager = CourseEnv.InitGameManager()
-- -- 获取结算模块
-- local resultModule = GameModuleManager:GetGameResultModule()

-- -- 游戏结束时显示结算界面
-- local function endGame()
--     resultModule:ShowPersonalResult({
--         rank = 2,
--         award = 50,
--         score = 350,
--         clickCloseCallBack = function()
--             -- 回到大厅
--             App:GameReturn()
--         end
--     })
-- end
-- -- 在游戏结束条件满足时调用
-- self.commonService:DispatchAfter(60, function()
--     -- 60秒后游戏结束
--     endGame()
-- end)
-- ```

-- **注意**：团队游戏结算需要通过服务端触发，客户端只负责展示结算界面。
-- remote相关代码说明：结算模块服务端逻辑  [结算服务端](game_remote_template.md)
-- #### 5.团队游戏结算（服务端触发）
-- 团队游戏的结算需要通过服务端模块触发，客户端接收结算数据并展示UI。
-- ##### 服务端结算触发流程
-- 1. 创建结算参数
-- ```lua
-- -- 构建团队结算参数
-- local settleParams = {
--     -- 普通游戏结算参数
--     comm_game_settle_param = {
--         -- 必填：玩家结算信息，包含每个玩家的分数和排名
--         game_result = {
--             {
--                 point = 500,  -- 玩家得分
--                 rank = 1,     -- 玩家排名
--                 user_id = "12345" -- 玩家ID
--             },
--             {
--                 point = 350,
--                 rank = 2,
--                 user_id = "67890"
--             }
--             -- 可添加更多玩家
--         }
--     },
--     -- 校际PK结算参数（可选）
--     school_pk_settle_param = {
--         -- 学校/班级PK相关参数
--     },
--     -- 可选：分组结果展示（例如：红队获胜）
--     groupResult = {
--         winGroup = "红队",
--         loseGroup = "蓝队"
--     },
--     -- 可选：延迟显示结算UI的时间（单位：秒）
--     delay = 3
-- }
-- ```
-- 2. 触发结算事件
-- ```lua
-- -- 触发结算事件
-- Observer:Fire("report_game_result", settleParams)
-- ```

-- ##### 结算参数说明
-- | 参数 | 类型 | 说明 | 是否必填 |
-- |------|------|------|----------|
-- | comm_game_settle_param | table | 普通游戏结算参数 | 是 |
-- | comm_game_settle_param.game_result | array | 玩家结算信息数组 | 是 |
-- | school_pk_settle_param | table | 校际PK结算参数 | 否 |
-- | groupResult | table | 分组结果展示 | 否 |
-- | delay | number | 延迟显示结算UI的时间(秒) | 否 |
-- 团队游戏结算的完整服务端实现请参考：[结算服务端](game_remote_template.md)
-- #### 6.结算服务端实现示例

-- ```lua
-- -- 游戏结束时触发团队结算
-- local function endGameWithTeamResult()
--     -- 构建结算数据
--     local settleParams = {
--         comm_game_settle_param = {
--             game_result = {
--                 {
--                     point = 500,
--                     rank = 1,
--                     user_id = "12345" -- 获取玩家实际ID
--                 },
--                 {
--                     point = 350,
--                     rank = 2,
--                     user_id = "67890"
--                 }
--             }
--         },
--         groupResult = {
--             winGroup = "红队",
--             loseGroup = "蓝队"
--         }
--     }

--     -- 触发结算
--     Observer:Fire("report_game_result", settleParams)
-- end

-- -- 监听结算处理完成事件
-- Observer:Watch("finish_report_game_result", function(key, args)
--     if args.isSuccessed then
--         -- 结算成功，可以进行后续操作
--         print("结算成功")
--     else
--         -- 结算失败
--         print("结算失败")
--     end
-- end)
-- ```

-- -- 游戏结算
-- module.showResult = function(winTeam)
--     local result = {}
--     local match = module.gameData
--     for i, member in ipairs(match.members) do
--         local t = {}
--         t.point = math.floor(member.killCount)
--         t.rank = 1
--         t.score = member.killCount
--         t.user_id = tonumber(member.userId)
--         -- "team":1, // team为团队输赢(1团队赢 2团队输 3平局)
--         local symbol = 2
--         if winTeam == member.teamType then
--             symbol = 1
--         elseif winTeam == -1 then
--             symbol = 3
--         end
--         t.team = symbol
--         t.is_run = not PlayerManager.IsOnline(member.uuid)
--         table.insert(result, t)
--     end

--     module.print("showResult result = " .. table.dump(result))
--     Observer:Fire("report_game_result", {
--         comm_game_settle_param = result,
--         delay = -1
--     })
-- end



-- 入参数说明：
-- 请求格式：
-- {
--     "params": "vdwvwfbwfbfwbwbwbb"  // 入参数的json编码后的数据
-- }
--
-- params json编码前格式如下：
-- {
--     "game_id": 86,                    // 游戏id
--     "plan_id": 202,                   // 场次ID
--     "set_id": 2345,                   // 对战局id，校园pk时为pk ID
--
--     // 通用游戏结算的参数
--     "comm_game_settle_param": [
--         {
--             "point": 6,               // 用户奖励
--             "rank": 1,                // 用户排名(用户队内排名)
--             "score": 10,              // 用户成绩
--             "user_id": 1090000909,    // 用户ID
--             "team": 1,                // 团队输赢 (1=团队赢, 2=团队输)
--             "is_run": false,          // 是否逃跑 (true=是, false=否)
--             "is_captor": false,       // 是否是抓捕者 (true=是, 仅躲猫猫需要)
--             "is_fail": true           // 是否被淘汰 (true=是, false=否)
--         },
--         {
--             "point": 6,
--             "rank": 2,
--             "score": 10,
--             "user_id": 1090000908,
--             "team": 1,
--             "is_run": false,
--             "is_captor": false,
--             "is_fail": true
--         }
--     ],
--
--     // 校园争霸结算的入参数 学校列表
--     "school_pk_settle_param": [
--         {
--             "school_id": 844582,                      // 学校ID
--             "user_list": [1090003355],                // 参加对战的用户
--             "score": 4,                               // 得分
--             "remained_user_list": [1090003355]        // 结束时留下的人id
--         },
--         {
--             "school_id": 844766,
--             "user_list": [1090004869, 1090000278, 1090002813],
--             "score": 3,
--             "remained_user_list": [1090000278, 1090002813]
--         }
--     ]
-- }

-- 服务器返回数据
-- {
-- 	"stat": 1,
-- 	"code": 0,
-- 	"msg": "success",
-- 	"data": {
-- 		"user_level_list": [
--             {
-- 				"user_id": 1090000286, //用户id
-- 				"change_score": 2, //变化值
-- 				"is_protect": true, //是否是保分局
-- 				"protect_score": 1, //保分分数
-- 				"ranking_before": { //变化前排位信息
-- 					"level": 1, // 等级
-- 					"level_name": "磐石", // 等级名称
-- 					"section_num": 1, // 段位
-- 					"section_name": "1", // 段位名称
-- 					"section_score": 0 // 段位星星
-- 				},
-- 				"ranking_after": { //变化后排位信息
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 2
-- 				}
-- 			},
-- 			{
-- 				"user_id": 1090000287,
-- 				"change_score": 2,
-- 				"is_protect": true, //是否是保分局
-- 				"protect_score": 1, //保分分数
-- 				"ranking_before": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 0
-- 				},
-- 				"ranking_after": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 2
-- 				}
-- 			},
-- 			{
-- 				"user_id": 1090000288,
-- 				"change_score": 1,
-- 				"is_protect": true, //是否是保分局
-- 				"protect_score": 1, //保分分数
-- 				"ranking_before": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 0
-- 				},
-- 				"ranking_after": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 1
-- 				}
-- 			},
-- 			{
-- 				"user_id": 1090000289,
-- 				"change_score": 1,
-- 				"is_protect": true, //是否是保分局
-- 				"protect_score": 1, //保分分数
-- 				"ranking_before": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 0
-- 				},
-- 				"ranking_after": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 1
-- 				}
-- 			},
-- 			{
-- 				"user_id": 1090000282,
-- 				"change_score": 0,
-- 				"is_protect": true, //是否是保分局
-- 				"protect_score": 1, //保分分数
-- 				"ranking_before": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 3
-- 				},
-- 				"ranking_after": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 3
-- 				}
-- 			},
-- 			{
-- 				"user_id": 1090000283,
-- 				"change_score": 0,
-- 				"is_protect": true, //是否是保分局
-- 				"protect_score": 1, //保分分数
-- 				"ranking_before": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 2
-- 				},
-- 				"ranking_after": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 2
-- 				}
-- 			},
-- 			{
-- 				"user_id": 1090000284,
-- 				"change_score": 0,
-- 				"is_protect": true, //是否是保分局
-- 				"protect_score": 1, //保分分数
-- 				"ranking_before": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 2
-- 				},
-- 				"ranking_after": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 2
-- 				}
-- 			},
-- 			{
-- 				"user_id": 1090000285,
-- 				"change_score": 0,
-- 				"is_protect": true, //是否是保分局
-- 				"protect_score": 1, //保分分数
-- 				"ranking_before": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 2
-- 				},
-- 				"ranking_after": {
-- 					"level": 1,
-- 					"level_name": "磐石",
-- 					"section_num": 1,
-- 					"section_name": "1",
-- 					"section_score": 2
-- 				}
-- 			}
-- 		],
-- 		"school_upgrade_info": { //  学校升级信息 ,只有当list 中存在且has_upgrade 是true 时才弹升级弹窗
-- 			"is_school_settle": true, // 该游戏是否参与学校经验值结算 true 是 false 否 否的时候结算页面保持现状
-- 			"is_double_game": true, //是否是双倍经验的游戏
-- 			"is_battle_time": true, //  是否是对决期 true 是 对决期时 额外加的经验值是1
-- 			"list": [
--                 {
-- 					"user_id": 1090000001, // 用户ID
-- 					"has_upgrade": true, //  true 触发升级 false 没触发
-- 					"after_level": 2, //  升级后的level
-- 					"add_value": 3, //  增加的经验值
-- 					"join_flag": true, // 是否加入学校 true 是 false 否
-- 					"grow_route_info": { //  成长之路信息
-- 						"user_id": 1090000264, // 用户ID
-- 						"after_stage": 6, //  结算后的阶段
-- 						"after_step": 5, //结算后的经验值
-- 						"locking_award_img": "", //  结算后解锁中的奖励图片
-- 						"cost_emp_val": 140, //  获得奖励需要的总经验值
-- 						"cur_emp_val": 63, //  已经得到的经验值
-- 						"before_stage":5, //  结算前的阶段
-- 		            	"before_step":5, // 结算前解锁中的奖励
-- 		            	"before_emp_val":4,// 结算前的经验值
-- 		            	"award_num":20, //  奖励数量
-- 						"can_own_list": [ //  获得的奖励列表
-- 							{
-- 								"stage": 1, //  阶段
-- 								"step": 1, //  奖励
-- 								"award_img": "wfrwgrg", //  奖励图片
-- 								"cost_emp_val": 20, //  奖励需要耗费的经验值
-- 								"award_num":20 //  奖励数量
-- 							},
-- 							{
-- 								"stage": 1,
-- 								"step": 2,
-- 								"award_img": "wfrwgrg",
-- 								"cost_emp_val": 20
-- 							}
-- 						],
-- 						"is_full": false, //  是否已经满级
-- 						"big_award_img":"cdwvwdvwdvwdv" //  大奖图片 未加入学校的时候使用
-- 					}
-- 				},
-- 				{
-- 					"user_id": 1090000002,
-- 					"has_upgrade": true,
-- 					"after_level": 2,
-- 					"add_value": 3,
-- 					"join_flag": true
-- 				},
-- 				{
-- 					"user_id": 1090000003,
-- 					"has_upgrade": true,
-- 					"after_level": 2,
-- 					"add_value": 3,
-- 					"join_flag": true
-- 				}
-- 			],
-- 			"season_id":4 //  赛季
-- 		},
-- 		"add_word_list":[ // 获得的字
-- 		    {
-- 		        "user_id": 1090000001, //  用户ID
-- 		        "word_num":2 // 字个数
-- 		    },
-- 		    {
-- 		        "user_id": 1090000002,
-- 		        "word_num":1
-- 		    },
-- 		    ]
-- 	},
-- 	"traceId": "629ed8f3-391d-4a9f-81ee-5e3b2ed06b45"
-- }

-- App:GetService("CommonService"):AddEventListener(self.gBtn, "onClick", function()
-- g_LogColorMsg("点击了测试按钮")
-- self.BusEventService:Fire("SHOW_MINI_GAME_RESULT_PANEL_NEW", {
--     titleType = 4, -- 1.第几名 2.获胜 3.失败 4.已出局 5.平局 6.已完成 7.已淘汰 8.成功离开 9.尚未结束 10.吃鸡胜利 11.吃鸡失败
--     contentType = 4, -- 内容类别：1.包含用时、芝士、经验 2.包含芝士、经验 3.包含经验 4.包含芝士 5.包含芝士、学识、经验
--     closeBtnType = 3, -- 1. 3S后自动关闭不显示关闭按钮 2.显示关闭按钮 3.显示关闭和再来一局按钮

--     rank = 7,
--     rankList = { -- rankListType = 2时需要传递此参数
--     {
--         user_id = App.Info.userId,
--         avatarName = "avatarName",
--         score = 99
--     }, {
--         user_id = App.Info.userId,
--         avatarName = "avatarName",
--         score = 100
--     }, {
--         user_id = App.Info.userId,
--         avatarName = "avatarName",
--         score = 101
--     }, {
--         user_id = App.Info.userId,
--         avatarName = "avatarName",
--         score = 102
--     }},

--     useTime = 68, -- 用时
--     isFinish = false, -- 是否完成
--     award = 10, -- 芝士
--     xueshi = 10, -- 学识
--     petExp = 10, -- 宠物经验

--     is_school_settle = true, -- 该游戏是否参与校园经验加成
--     join_school_flag = true, -- 是否加入学校
--     add_value = 6, -- 增加的学校经验值
--     is_double_game = true, -- 是否双倍加分
--     school_extra_score = 1, -- 学校额外增加的经验值
--     has_upgrade = true, -- 学校是否升级
--     after_level = 3, -- 学校升级后等级

--     autoCloseCallBack = function()
--         g_LogColorMsg("自动关闭回调")
--     end,
--     clickCloseCallBack = function()
--         g_LogColorMsg("点击关闭回调")
--     end,
--     clickAgainCallBack = function()
--         g_LogColorMsg("点击再来一局回调")
--     end,
--     -- 重来一局额外参数
--     game_id = 1,
--     opt_source = 1
-- })
-- end)

-- 构建服务器返回的结算结果数据，返回结果数据用于展示结果页
-- -@param groupResult table 分组结果展示
-- -@param comm_game_settle_param table 通用游戏结算的参数
-- -@param school_pk_settle_param table 校园争霸结算的参数
-- -@param school_upgrade_info table 学校升级信息
-- -@param user_level_list table 用户段位数据
-- -@param add_word_list table 用户集字数据
-- -@param gameType number 游戏类型
-- -@param winner number 获胜方
-- -@return table 结果数据



-- module.showResult = function(winTeam)
--     local result = {}
--     local match = module.gameData
--     for i, member in ipairs(match.members) do
--         local t = {}
--         t.point = math.floor(member.killCount)--奖励芝士
--         t.rank = 1--排名
--         t.score = member.killCount --得分
--         t.user_id = tonumber(member.userId) -- 用户ID
--         -- "team":1, // team为团队输赢(1团队赢 2团队输 3平局)
--         local symbol = 2
--         if winTeam == member.teamType then
--             symbol = 1
--         elseif winTeam == -1 then
--             symbol = 3
--         end
--         t.team = symbol
--         t.is_run = not PlayerManager.IsOnline(member.uuid) -- 是否在线
--         t.teamType = member.teamType -- 队伍类型 队伍team1 队伍team2 。。。。
--         table.insert(result, t)
--     end

--     module.print("showResult result = " .. table.dump(result))
--     Observer:Fire("report_game_result", {
--         comm_game_settle_param = result, --普通游戏结算参数
--         delay = -1, --延迟显示结算UI的时间(秒)
--         gameType = 3, --游戏类型 GAME_RESULT_GAME_TYPE
--         team1Score = module.gameData.team1.score, --队伍1得分
--         team2Score = module.gameData.team2.score, --队伍2得分
--         winner = winTeam, -- -1  平局  1team1 获胜  2team2 获胜
--     })
-- end

-- 构建服务器返回的结算结果数据，返回结果数据用于展示结果页
---@param msg table
---@return table 结果数据
function GameResultStage:buildResultData(msg)
    -- self:Print("开始构建结果数据")
    -- local result = {}
    -- result["contentType"] = 2
    -- if groupResult ~= nil then
    --     for i, group in ipairs(groupResult) do
    --         for i, v in ipairs(group) do
    --             if tostring(v.user_id) == tostring(App.Info.userId) then
    --                 result["rankList"] = group
    --                 local score = v.point
    --                 local isWin = false
    --                 if v.team == 1 then
    --                     isWin = true
    --                     result["titleType"] = 2
    --                 elseif v.team == 2 then
    --                     isWin = false
    --                     result["titleType"] = 3
    --                 elseif v.team == 3 then
    --                     isWin = true
    --                     result["titleType"] = 5
    --                 else
    --                     result["titleType"] = 1
    --                 end
    --                 result["rank"] = i
    --                 result["award"] = score
    --                 if self.gameMode == 2 then
    --                     result["closeBtnType"] = 1
    --                     result["autoCloseCallBack"] = function()
    --                         self:Print("显示排位信息")
    --                         self:showRankInfo(i, isWin)
    --                     end
    --                 else
    --                     result["closeBtnType"] = 2
    --                     result["clickCloseCallBack"] = function()
    --                         App:GameReturn()
    --                     end
    --                 end
    --                 break
    --             end
    --         end
    --     end
    -- elseif comm_game_settle_param ~= nil then
    --     for i, v in ipairs(comm_game_settle_param) do
    --         if tostring(v.user_id) == tostring(App.Info.userId) then
    --             local score = v.point
    --             local isWin = false
    --             if v.team == 1 then
    --                 isWin = true
    --                 result["titleType"] = 2
    --             elseif v.team == 2 then
    --                 isWin = false
    --                 result["titleType"] = 3
    --             elseif v.team == 3 then
    --                 isWin = true
    --                 result["titleType"] = 5
    --             else
    --                 result["titleType"] = 1
    --             end
    --             result["rank"] = v.rank
    --             result["award"] = score
    --             if self.gameMode == 2 then
    --                 result["closeBtnType"] = 1
    --                 result["autoCloseCallBack"] = function()
    --                     self:Print("显示排位信息")
    --                     self:showRankInfo(v.rank, isWin)
    --                 end
    --             else
    --                 result["closeBtnType"] = 2
    --                 result["clickCloseCallBack"] = function()
    --                     App:GameReturn()
    --                 end
    --             end
    --             break
    --         end
    --     end
    -- elseif school_pk_settle_param ~= nil then
    --     local selfTeamScore = 0
    --     local otherTeamScore = 0
    --     for _, v in ipairs(school_pk_settle_param) do
    --         if v.user_list then
    --             local isSelfIn = false
    --             for _, userid in ipairs(v.user_list) do
    --                 if tostring(userid) == tostring(App.Info.userId) then
    --                     isSelfIn = true
    --                 end
    --             end
    --             if isSelfIn then
    --                 selfTeamScore = v.score
    --             else
    --                 otherTeamScore = v.score
    --             end
    --         end
    --     end

    --     if selfTeamScore > otherTeamScore then
    --         result["titleType"] = 2
    --     elseif selfTeamScore < otherTeamScore then
    --         result["titleType"] = 3
    --     elseif selfTeamScore == otherTeamScore then
    --         result["titleType"] = 5
    --     else
    --         result["titleType"] = 1
    --     end
    --     result["award"] = selfTeamScore
    --     if self.gameMode == 2 then
    --     else
    --         result["closeBtnType"] = 2
    --         result["clickCloseCallBack"] = function()
    --             App:GameReturn()
    --         end
    --     end
    -- else
    --     g_LogError("团队结果页透传数据为空")
    -- end

    -- -- 解析校园数据
    -- if school_upgrade_info then
    --     result["is_school_settle"] = school_upgrade_info.is_school_settle
    --     if school_upgrade_info.list and type(school_upgrade_info.list) == "table" then
    --         self:Print("学校数据1" .. table.dump(school_upgrade_info.list))
    --     elseif school_upgrade_info.list and type(school_upgrade_info.list) == "string" then
    --         school_upgrade_info.list = self.jsonService:decode(school_upgrade_info.list)
    --     else
    --         school_upgrade_info.list = {}
    --     end
    --     for i, v in ipairs(school_upgrade_info.list) do
    --         if tostring(v.user_id) == tostring(App.Info.userId) then
    --             result["join_school_flag"] = v.join_flag
    --             result["add_value"] = v.add_value
    --             result["has_upgrade"] = v.has_upgrade
    --             result["after_level"] = v.after_level
    --             self.grow_route_info = v.grow_route_info
    --             self.season_id = school_upgrade_info.season_id
    --             break
    --         end
    --     end
    --     if school_upgrade_info.is_battle_time and result["titleType"] == 2 then
    --         result["school_extra_score"] = 1
    --     end

    --     result["is_double_game"] = school_upgrade_info.is_double_game
    --     self:Print("学校数据2" .. table.dump(school_upgrade_info.list))
    -- end
    -- self:Print("构建结果数据" .. table.dump(result))
    -- -- 解析段位数据
    -- if self.gameMode == 2 then
    --     for i, v in ipairs(user_level_list) do
    --         if tostring(v.user_id) == tostring(App.Info.userId) then
    --             self.myLevelInfo = v
    --             break
    --         end
    --     end
    -- end

    -- -- 解析集字数据
    -- if add_word_list then
    --     for i, v in ipairs(add_word_list) do
    --         if tostring(v.user_id) == tostring(App.Info.userId) then
    --             result["jiziNum"] = v.word_num
    --             break
    --         end
    --     end
    -- end



    local result =
    {
        gameType = nil,        --游戏类型 GAME_RESULT_GAME_TYPE
        isShowMVPStage = true, --是否展示mvp舞台 默认展示（如游戏中途展示的时候没有MVP)
        --排位数据
        rankData = {
            isShowRankPanel = false, --是否展示段位页 默认不展示
            type = 2,                -- 1：个人赛段位结算，2：团队赛段位结算
            isFailed = false,        -- 个人赛专用字段 是否未通过，未通过左上角显示未通过，否则显示第几名
            isTeamWin = true,        -- 团队赛专用字段 是否胜利 目前规则加分就是显示胜利，可传可不传
        },
        --标题数据
        titleData = {
            titleType = 3,   --标题类型 1 未完成  2 淘汰 3 胜利 4 失败 5 名次  6 平局
            teamScore = nil, --队伍比分 {蓝方分数, 红方分数}
            mingci = nil,    --名次 titleType == 5 时有效  排位排名显示第几名
        },
        --奖励数据
        awardData = {
            zhishi = nil, --芝士 有芝士显示奖励芝士，没有回走服务器请求add_cheese_val 值 默认0
            xueshi = nil, --学识
            petExp = nil, --宠物经验
        },
        --匹配数据
        matchData = {
            closeBtnType = 2, --匹配功能按钮显示类型  1. 3S后自动关闭不显示关闭按钮 2.只显示关闭按钮 3.显示关闭和再来一局按钮
        },
        --游戏自定义数据
        gameData = {
            winner = nil,
            -- useTime = 68, -- 用时
            -- isFinish = false, -- 是否完成
        },
        --请求参数
        requestParams = {
            -- rank = nil, --排名
            -- score = nil, --个人得分
            -- team = nil, --团队胜负 暂时用不到
            -- is_run = false, --是否逃跑
            -- is_captor = false, --是否是抓捕者
            -- game_id = nil, --游戏id
            -- set_id = nil, --游戏局id
            -- plan_id = nil, --场次ID
        },
        autoCloseCallBack = function()
            -- g_LogColorMsg("最终结算界面-自动关闭回调")
        end,
        clickCloseCallBack = function()
            -- g_LogColorMsg("最终结算界面-点击关闭回调")
        end,
        clickAgainCallBack = function()
            -- g_LogColorMsg("最终结算界面-点击再来一局回调")
        end,
    }

    result.gameType = self.msg.gameType

    if self.msg.comm_game_settle_param ~= nil then
        for i, v in ipairs(self.msg.comm_game_settle_param) do
            if tostring(v.user_id) == tostring(App.Info.userId) then
                local isWin = false
                if v.team == 1 then                ---team为团队输赢(1团队赢 2团队输 3平局)
                    isWin = true
                    result.titleData.titleType = 3 ---胜利
                elseif v.team == 2 then
                    isWin                      = false
                    result.titleData.titleType = 4 ---失败
                elseif v.team == 3 then
                    isWin                      = true
                    result.titleData.titleType = 6 ---平局
                else
                    result.titleData.titleType = 3 --- 胜利
                end
                result.titleData.mingci = v.rank   --排名
                result.awardData.zhishi = v.point  ----奖励芝士

                if self.gameMode == 2 then
                    result.matchData.closeBtnType = 1      --3S后自动关闭不显示关闭按钮
                    result.rankData.isShowRankPanel = true --是否展示段位页 默认不展示
                    result.rankData.type = 2
                    result.rankData.isTeamWin = isWin
                    result.rankData.isFailed = false
                else
                    result.matchData.closeBtnType = 2 --2.显示关闭按钮
                end

                -- 计算队伍比分
                if self.msg.team1Score ~= nil and self.msg.team2Score ~= nil then
                    result.titleData.teamScore = self:getTeamScore(self.msg.team1Score, self.msg.team2Score, isWin)
                end

                --队伍获胜方
                result.gameData.winner = self.msg.winner -- -1 平局  1team1 获胜  2team2 获胜
                --平局 人物自己队伍获胜
                if result.gameData.winner == -1 then
                    result.gameData.winner = v.teamType ----玩家自己队伍获胜
                end

                break
            end
        end
    end

    -- 解析段位数据
    if self.msg.user_level_list ~= nil then
        if self.gameMode == 2 then
            for i, v in ipairs(self.msg.user_level_list) do
                if tostring(v.user_id) == tostring(App.Info.userId) then
                    self.myLevelInfo = v
                    break
                end
            end
        end
    end

    self:Print("构建结果数据" .. table.dump(result))
    return result
end

---分队伍比分 {蓝方分数, 红方分数} 自己一定是蓝队
---@param team1Score number 1队伍分数
---@param team2Score number 2队伍分数
---@param isWin boolean 是否胜利
---@return table {蓝方分数, 红方分数}
function GameResultStage:getTeamScore(team1Score, team2Score, isWin)
    if isWin then
        if team1Score > team2Score then
            return { team1Score, team2Score }
        else
            return { team2Score, team1Score }
        end
    else
        if team1Score > team2Score then
            return { team2Score, team1Score }
        else
            return { team1Score, team2Score }
        end
    end
end

--endregion


-- http请求地址封装
---@param request string 请求地址
---@param params table 请求参数
---@param success function 成功回调
---@param fail function 失败回调
function GameResultStage:HttpRequest(request, params, success, fail)
    local url = "https://app.chuangjing.com/next-api" ..
        request --    local url = "https://app.chuangjing.com/abc-api" .. request
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041" .. request
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

---打印日志
function GameResultStage:Print(...)
    g_Log("【MVP展示】", ...)
end

return GameResultStage
