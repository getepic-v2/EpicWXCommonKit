---  Author: 【孙鹏飞】
---  AuthorID: 【V0047328】
---  CreateTime: 【2025-8-14 14:31:39】
--- 【FSync】
--- 【分数统计】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class GameResultScroe : WorldBaseElement
local GameResultScroe = class("game_result_score_comlogic", WBElement)


--region 游戏配置-----------------------------------------------------------------------------------------------------------------------------
local RECORD_GAME_SCORE_DATA = "RECORD_GAME_SCORE_DATA"                         --统计数据请求
local RECORD_GAME_SCORE_DATA_TOSERVER = "RECORD_GAME_SCORE_DATA_TOSERVER"       --统计数据请求到服务器
local RECORD_GAME_SCORE_DATA_BACK_CLIENT = "RECORD_GAME_SCORE_DATA_BACK_CLIENT" --统计数据返回客户端
local GET_RECORD_SCORE_DATA = "GET_RECORD_SCORE_DATA"                           --获取玩家统计数据
local GET_ALL_RECORD_GAME_SCORE_DATA = "GET_ALL_RECORD_GAME_SCORE_DATA"         --获取所有玩家统计数据
local BACK_ALL_RECORD_GAME_SCORE_DATA = "BACK_ALL_RECORD_GAME_SCORE_DATA"       --返回所有玩家统计数据
local GET_PLAYERS_SCHOOL_INFO = "GET_PLAYERS_SCHOOL_INFO"                       --获取玩家学校信息

GAME_RESULT_GAME_OVER_TIME = 999999 --游戏结束时间 约 277.78 小时 = 约 11.57 天 超过这个值认为游戏未完成
--游戏类型
GAME_RESULT_GAME_TYPE = {
    WOLF_AND_DETECTIVE = 1,   --狼人与侦探  7q8DJQY69E6TxTBCbwuZw
    RUN_GAME = 2,             --酷跑
    GUN_BATTLE_ELITE = 3,     --枪战精英
    BUBBLE_BOMBER_SINGLE = 4, --泡泡炸弹人 单人
    BUBBLE_BOMBER_TEAM = 5,   --泡泡炸弹人 多人
    KART_RACE = 6,            --赛车
    PUBG = 7,                 --吃鸡
    HIDE_AND_SEEK = 8,        --躲猫猫
}

-- 游戏结果数据字段常量定义
GAME_RESULT_DATA_KEYS = {
    --【通用】
    SCHOOL = 'school',        --学校
    AVATAR_URL = 'avatarUrl', --头像URL
    RANK = 'rank',            -- 排名  当游戏有统计这个字段时，mvp 玩家会根据该字段确定，不走默认规则处理

    --【英语】
    SCORE = 'score',                                 -- 英语 App.modPlatform 开口分数
    AVG_SCORE = 'avgScore',                          -- 平均开口分
    READ_SENTENCE_COUNT = 'readSentenceCount',       -- 朗读句子数
    SENTENCE_ACCURACY_RATE = 'sentenceAccuracyRate', -- 句子准确率
    TOTAL_SCORE = 'totalScore',                      -- 总分

    --【英语】狼人与侦探  -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    PERSON_SCORE = 'person_score',         -- 个人得分
    IDENTITY = 'identity',                 -- 身份 (狼人 侦探)  0 未区分 1 狼人 2 侦探
    HIT_NUM = 'hit_num',                   -- 命中次数（攻击+技能）    -- 狼人数据
    ELIMINATE_NUM = 'eliminate_num',       -- 淘汰人数    -- 狼人数据
    BREAK_TIME = 'break_time',             -- 破译总时长   -- 侦探数据
    RESCUE_NUM = 'rescue_num',             -- 救援次数（倒地到起来）   -- 侦探数据
    --【英语】酷跑 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    PERSON_PASS_TIME = 'person_pass_time', -- 个人通关时间
    --【英语】枪战精英 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    TEAM_TYPE = 'team_type',               -- 所在队伍 1 team1   2 team2
    KILL_NUM = 'kill_num',                 -- 击败人数
    ASSIST_KILL_NUM = 'assist_kill_num',   -- 协助击败人数
    --【英语】泡泡炸弹人单人-- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    -- KILL_NUM = 'kill_num',  -- 击败人数
    PROP_USE_NUM = 'prop_use_num',   -- 使用道具次数
    SURVIVAL_TIME = 'survival_time', -- 生存时间
    --【英语】泡泡炸弹人 多人-- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    -- TEAM_TYPE = 'team_type', -- 所在队伍 1 team1   2 team2  team3 team4
    -- KILL_NUM = 'kill_num',  -- 击败人数
    -- PROP_USE_NUM = 'prop_use_num',  -- 使用道具次数
    -- SURVIVAL_TIME = 'survival_time',  -- 生存时间
    --【英语】赛车 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    PASS_TIME = 'pass_time', -- 通关时间
    --【英语】吃鸡 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    -- TEAM_TYPE = 'team_type', -- 所在队伍 1 team1   2 team2  team3 team4
    -- KILL_NUM = 'kill_num',  -- 击败人数
    -- ASSIST_KILL_NUM = 'assist_kill_num',  -- 协助击败人数
    RESCUE_PLAYER_COUNT = 'rescue_player_count', -- 救援人数
    --【英语】躲猫猫 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    -- IDENTITY = 'identity',           -- 身份 (追 躲)  0 未区分 1 追 2 躲
    -- ELIMINATE_NUM = 'eliminate_num', -- 【追】淘汰人数
    -- SURVIVAL_TIME = 'survival_time', -- 【躲】生存时间



    --【数学】

    --【语文】
}

-- 游戏结果数据字段显示配置
GAME_RESULT_DATA_DISPLAY = {
    --【通用】
    -- [GAME_RESULT_DATA_KEYS.SCHOOL] = {
    --     display = "学校",
    --     unit = ""
    -- },
    -- [GAME_RESULT_DATA_KEYS.AVATAR_URL] = {
    --     display = "头像",
    --     unit = ""
    -- },
    -- [GAME_RESULT_DATA_KEYS.SCORE] = {
    --     display = "开口分数",
    --     unit = "分"
    -- },
    [GAME_RESULT_DATA_KEYS.AVG_SCORE] = {
        display = "平均开口分",
        unit = "分",
        default = 0 --获取不到时的默认值
    },
    [GAME_RESULT_DATA_KEYS.READ_SENTENCE_COUNT] = {
        display = "朗读句子数",
        unit = "句",
        default = 0 --获取不到时的默认值
    },
    [GAME_RESULT_DATA_KEYS.SENTENCE_ACCURACY_RATE] = {
        display = "句子准确率",
        unit = "%",
        default = 0 --获取不到时的默认值
    },

    --【英语】狼人与侦探  -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_DATA_KEYS.PERSON_SCORE] = {
        display = "个人得分",
        unit = "分",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1\
    },
    -- [GAME_RESULT_DATA_KEYS.IDENTITY] = {
    --     display = "身份",
    --     unit = ""
    -- },
    [GAME_RESULT_DATA_KEYS.HIT_NUM] = {
        display = "命中次数",
        unit = "次",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    [GAME_RESULT_DATA_KEYS.ELIMINATE_NUM] = {
        display = "淘汰人数",
        unit = "人",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    [GAME_RESULT_DATA_KEYS.BREAK_TIME] = {
        display = "破译时长",
        unit = "秒",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    [GAME_RESULT_DATA_KEYS.RESCUE_NUM] = {
        display = "救援次数",
        unit = "次",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    --【英语】酷跑 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_DATA_KEYS.PERSON_PASS_TIME] = {
        display = "通关时间",
        unit = nil, --不显示单位
        default = math.huge, --获取不到时的默认值
        key_sort_rule = 2,   ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
        --格式化显示时间 【displayformat 格式化显示时调用】
        ---@param time number 时间 单位秒
        ---@return string 格式化后的时间 "00:00:00" 分：秒：百分秒
        displayformat = function(time)
            ---- 999999 秒 = 约 277.78 小时 = 约 11.57 天
            if time == nil or time == -1 or time == 0 or time == "" or time >= GAME_RESULT_GAME_OVER_TIME then
                return "未完成"
            end
            return tostring(time) .. "秒"
            -- local minute = math.floor(time / 60)
            -- local second = math.floor(time % 60)
            -- local centiseconds = math.floor((time % 1) * 100) -- 百分秒 0-99
            -- return string.format("%02d:%02d.%02d", minute, second, centiseconds)
        end,
    },
    --【英语】枪战精英 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    -- [GAME_RESULT_DATA_KEYS.TEAM_TYPE] = {
    --     display = "所在队伍",
    --     unit = "",
    --     default = 0 --获取不到时的默认值
    -- },
    [GAME_RESULT_DATA_KEYS.KILL_NUM] = {
        display = "击败人数",
        unit = "人",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    [GAME_RESULT_DATA_KEYS.ASSIST_KILL_NUM] = {
        display = "协助击败人数",
        unit = "人",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    --【英语】泡泡炸弹人单人-- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_DATA_KEYS.PROP_USE_NUM] = {
        display = "使用道具次数",
        unit = "次",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    [GAME_RESULT_DATA_KEYS.SURVIVAL_TIME] = {
        display = "生存时间",
        unit = "秒",
        default = -1,     --获取不到时的默认值
        displayformat = function(time)
            if time == nil or time<= 0 then
               return  "~"
            end
            return time
        end,
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    --【英语】赛车 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_DATA_KEYS.PASS_TIME] = {
        display = "通关时间",
        unit = nil,          --不显示单位
        default = math.huge, --获取不到时的默认值
        --格式化显示时间 【displayformat 格式化显示时调用】
        ---@param time number 时间 单位秒
        ---@return string 格式化后的时间 "00:00:00" 分：秒：百分秒
        displayformat = function(time)
            -- g_Log("game_result_score.lua displayformat time:", time)
            ---- 999999 秒 = 约 277.78 小时 = 约 11.57 天
            if time == nil or time == -1 or time == 0 or time == "" or time >= GAME_RESULT_GAME_OVER_TIME then
                return "未完成"
            end
            local minute = math.floor(time / 60)
            local second = math.floor(time % 60)
            local centiseconds = math.floor((time % 1) * 100) -- 百分秒 0-99
            return string.format("%02d:%02d.%02d", minute, second, centiseconds)
        end,
        key_sort_rule = 2, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },
    --【英语】吃鸡 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_DATA_KEYS.RESCUE_PLAYER_COUNT] = {
        display = "救援人数",
        unit = "人",
        default = 0,       --获取不到时的默认值
        key_sort_rule = 1, ---MVP关键数据key 数据排序规则 1值越大是mvp  2值越小是mvp  默认1
    },

}

--MVP舞台界面学习项 数据配置
GAME_RESULT_STAGE_DATA_CONFIG = {
    --英语 playerStats
    [MOD_PLATFORM.ABCZone] = {
        GAME_RESULT_DATA_KEYS.AVG_SCORE,
        GAME_RESULT_DATA_KEYS.READ_SENTENCE_COUNT,
    },
    --数学
    [MOD_PLATFORM.Math] = {

    },
    --语文
    [MOD_PLATFORM.Chinese] = {

    }
}

--MVP结算界面学习项 数据配置
GAME_RESULT_SCORE_DATA_CONFIG = {
    --英语 playerStats
    [MOD_PLATFORM.ABCZone] = {
        GAME_RESULT_DATA_KEYS.AVG_SCORE,
        GAME_RESULT_DATA_KEYS.READ_SENTENCE_COUNT,
        GAME_RESULT_DATA_KEYS.SENTENCE_ACCURACY_RATE,
    },
    --数学
    [MOD_PLATFORM.Math] = {

    },
    --语文
    [MOD_PLATFORM.Chinese] = {

    }
}



--游戏结果数据统计配置
GAME_RESULT_DATA_CONFIG = {
    --【英语】狼人与侦探 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- -
    [GAME_RESULT_GAME_TYPE.WOLF_AND_DETECTIVE] = {
        game_type = 2,                                --游戏类型 1单人   2 团队
        teamTypeKey = GAME_RESULT_DATA_KEYS.IDENTITY, --队伍类型区分关键字
        --游戏MVP和SVP获取规则
        game_mvp_and_svp_rule = {
            get_type = 1,                                --根据teamTypeKey 获取队伍类型区分关键字
            mvpKey = GAME_RESULT_DATA_KEYS.PERSON_SCORE, --MVP关键数据关键字
            svpKey = GAME_RESULT_DATA_KEYS.PERSON_SCORE, --SVP关键数据关键字 不写则不显示SVP
        },
        --游戏数据key
        game_data_rule = {
            get_type = 2, --根据teamTypeKey 获取队伍类型区分关键字
            game_data = {
                -- 身份 (狼人 侦探)  0 未区分 1 狼人 2 侦探
                --狼人数据
                [1] = {
                    GAME_RESULT_DATA_KEYS.PERSON_SCORE, -- 个人得分
                    GAME_RESULT_DATA_KEYS.HIT_NUM,   -- 命中次数（攻击+技能）
                    GAME_RESULT_DATA_KEYS.ELIMINATE_NUM, -- 淘汰人数
                },
                --侦探数据
                [2] = {
                    GAME_RESULT_DATA_KEYS.PERSON_SCORE, -- 个人得分
                    GAME_RESULT_DATA_KEYS.BREAK_TIME, -- 破译总时长
                    GAME_RESULT_DATA_KEYS.RESCUE_NUM, -- 救援次数（倒地到起来）
                },
            },
        },
        --游戏队友获取规则
        game_teammates_rule = {
            get_type = 1,                                 --根据teamTypeKey 获取队伍类型区分关键字
            sortKey = GAME_RESULT_DATA_KEYS.PERSON_SCORE, --排序关键字
        },
        --克隆时需要特殊隐藏物体
        clone_role_special_hide_object = {
          "道具"
        },
    },
    --【英语】酷跑 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_GAME_TYPE.RUN_GAME] = {
        game_type = 1,                                       --游戏类型 1单人   2 团队
        game_mvp_and_svp_rule = {
            get_type = 1,                                    --根据teamTypeKey 获取队伍类型区分关键字
            mvpKey = GAME_RESULT_DATA_KEYS.PERSON_PASS_TIME, --MVP关键数据关键字
            svpKey = nil,                                    --SVP关键数据关键字 不写则不显示SVP
        },
        --游戏数据
        game_data_rule = {
            get_type = 1,                               --根据teamTypeKey 获取队伍类型区分关键字
            game_data = {
                GAME_RESULT_DATA_KEYS.PERSON_PASS_TIME, --个人通关时间
            },
        },
    },
    --【英语】枪战精英 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_GAME_TYPE.GUN_BATTLE_ELITE] = {
        game_type = 2,                                 --游戏类型 1单人   2 团队
        teamTypeKey = GAME_RESULT_DATA_KEYS.TEAM_TYPE, --队伍类型区分关键字
        --游戏MVP和SVP获取规则
        game_mvp_and_svp_rule = {
            get_type = 1,                            --根据teamTypeKey 获取队伍类型区分关键字
            mvpKey = GAME_RESULT_DATA_KEYS.KILL_NUM, --MVP关键数据关键字
            svpKey = GAME_RESULT_DATA_KEYS.KILL_NUM, --SVP关键数据关键字 不写则不显示SVP
        },
        --游戏数据key
        game_data_rule = {
            get_type = 2, --根据teamTypeKey 获取队伍类型区分关键字
            game_data = {
                --蓝队数据
                [1] = {
                    GAME_RESULT_DATA_KEYS.KILL_NUM, --击败人数
                    -- GAME_RESULT_DATA_KEYS.ASSIST_KILL_NUM, --协助击败人数
                },
                [2] = {
                    GAME_RESULT_DATA_KEYS.KILL_NUM, --击败人数
                    -- GAME_RESULT_DATA_KEYS.ASSIST_KILL_NUM, --协助击败人数
                },
            },
        },
        --游戏队友获取规则
        game_teammates_rule = {
            get_type = 1,                             --根据teamTypeKey 获取队伍类型区分关键字
            sortKey = GAME_RESULT_DATA_KEYS.KILL_NUM, --排序关键字
        },
    },
    --【英语】泡泡炸弹人 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_GAME_TYPE.BUBBLE_BOMBER_SINGLE] = {
        game_type = 1,                               --游戏类型 1单人   2 团队
        game_mvp_and_svp_rule = {
            get_type = 1,                            --根据teamTypeKey 获取队伍类型区分关键字
            mvpKey = GAME_RESULT_DATA_KEYS.KILL_NUM, --MVP关键数据关键字
            svpKey = nil,                            --SVP关键数据关键字 不写则不显示SVP
        },
        --游戏数据key
        game_data_rule = {
            get_type = 1,                            --根据teamTypeKey 获取队伍类型区分关键字
            game_data = {
                GAME_RESULT_DATA_KEYS.KILL_NUM,      --击败人数
                GAME_RESULT_DATA_KEYS.PROP_USE_NUM,  --使用道具次数
                GAME_RESULT_DATA_KEYS.SURVIVAL_TIME, --生存时间
            },
        },
    },
    --【英语】泡泡炸弹人 多人-- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_GAME_TYPE.BUBBLE_BOMBER_TEAM] = {
        game_type = 2,                                 --游戏类型 1单人   2 团队
        teamTypeKey = GAME_RESULT_DATA_KEYS.TEAM_TYPE, --队伍类型区分关键字
        game_mvp_and_svp_rule = {
            get_type = 1,                              --根据teamTypeKey 获取队伍类型区分关键字
            mvpKey = GAME_RESULT_DATA_KEYS.KILL_NUM,   --MVP关键数据关键字
            svpKey = nil,                              --SVP关键数据关键字 不写则不显示SVP
        },
        --游戏数据key
        game_data_rule = {
            get_type = 1,                            --根据teamTypeKey 获取队伍类型区分关键
            game_data = {
                GAME_RESULT_DATA_KEYS.KILL_NUM,      --击败人数
                GAME_RESULT_DATA_KEYS.PROP_USE_NUM,  --使用道具次数
                GAME_RESULT_DATA_KEYS.SURVIVAL_TIME, --生存时间
            },
        },
        game_teammates_rule = {
            get_type = 1,                             --根据teamTypeKey 获取队伍类型区分关键字
            sortKey = GAME_RESULT_DATA_KEYS.KILL_NUM, --排序关键字
        },
    },
    --【英语】赛车 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_GAME_TYPE.KART_RACE] = {
        game_type = 1,                                --游戏类型 1单人   2 团队
        game_mvp_and_svp_rule = {
            get_type = 1,                             --根据teamTypeKey 获取队伍类型区分关键字
            mvpKey = GAME_RESULT_DATA_KEYS.PASS_TIME, --MVP关键数据关键字
            svpKey = nil,                             --SVP关键数据关键字 不写则不显示SVP
        },
        --游戏数据key
        game_data_rule = {
            get_type = 1,                        --根据teamTypeKey 获取队伍类型区分关键字
            game_data = {
                GAME_RESULT_DATA_KEYS.PASS_TIME, --通关时间
            },
        },
    },
    --【英语】吃鸡 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_GAME_TYPE.PUBG] = {
        game_type = 2,                                 --游戏类型 1单人   2 团队
        teamTypeKey = GAME_RESULT_DATA_KEYS.TEAM_TYPE, --队伍类型区分关键字
        game_mvp_and_svp_rule = {
            get_type = 1,                              --根据teamTypeKey 获取队伍类型区分关键字
            mvpKey = GAME_RESULT_DATA_KEYS.KILL_NUM,   --MVP关键数据关键字
            svpKey = nil,                              --SVP关键数据关键字 不写则不显示SVP
        },
        --游戏数据key
        game_data_rule = {
            get_type = 1,                                  --根据teamTypeKey 获取队伍类型区分关键字
            game_data = {
                GAME_RESULT_DATA_KEYS.KILL_NUM,            --击败人数
                GAME_RESULT_DATA_KEYS.RESCUE_PLAYER_COUNT, --救援人数
            },
        },
        game_teammates_rule = {
            get_type = 1,                             --根据teamTypeKey 获取队伍类型区分关键字
            sortKey = GAME_RESULT_DATA_KEYS.KILL_NUM, --排序关键字
        },
    },
    --【英语】躲猫猫 -- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- ---- -- -- --
    [GAME_RESULT_GAME_TYPE.HIDE_AND_SEEK] = {
        game_type = 2,                                --游戏类型 1单人   2 团队
        teamTypeKey = GAME_RESULT_DATA_KEYS.IDENTITY, --队伍类型区分关键字
        --游戏MVP和SVP获取规则
        game_mvp_and_svp_rule = {
            get_type = 2,                                  --根据teamTypeKey 获取队伍类型区分关键字
            mvpKey = {
                [1] = GAME_RESULT_DATA_KEYS.ELIMINATE_NUM, --【追】淘汰人数
                [2] = GAME_RESULT_DATA_KEYS.SURVIVAL_TIME, --【躲】生存时间
            },
            svpKey = {
                [1] = GAME_RESULT_DATA_KEYS.ELIMINATE_NUM, --【追】淘汰人数
                [2] = GAME_RESULT_DATA_KEYS.SURVIVAL_TIME, --【躲】生存时间
            },
        },
        --游戏数据key
        game_data_rule = {
            get_type = 2, --根据teamTypeKey 获取队伍类型区分关键字
            game_data = {
                [1] = {
                    GAME_RESULT_DATA_KEYS.ELIMINATE_NUM, -- 【追】淘汰人数
                },
                [2] = {
                    GAME_RESULT_DATA_KEYS.SURVIVAL_TIME, -- 【躲】生存时间
                },
            },
        },
        --游戏队友获取规则
        game_teammates_rule = {
            get_type = 2,
            sortKey = {
                [1] = GAME_RESULT_DATA_KEYS.ELIMINATE_NUM, --【追】淘汰人数
                [2] = GAME_RESULT_DATA_KEYS.SURVIVAL_TIME, --【躲】生存时间
            },
        },
    },

}
--endregion


---@param worldElement CS.Tal.framesync.WorldElement
function GameResultScroe:initialize(worldElement)
    GameResultScroe.super.initialize(self, worldElement)
    self:SubscribeMsgKey(BACK_ALL_RECORD_GAME_SCORE_DATA)
    self:SubscribeMsgKey(RECORD_GAME_SCORE_DATA_BACK_CLIENT) --统计数据返回客户端
end

function GameResultScroe:setVisElement(VisElement)
    if VisElement ~= nil then
        self.VisElement = VisElement
    end

    self:InitVariable()
    self:InitService()
    self:InitConfig()
    self:InitListener()
    self:InitView()
    self:Print("GameResultScroe:setVisElement====== ")
end

function GameResultScroe:InitService()
    self.gate = CourseEnv.ServicesManager.Gate
    self.BusEventService = CourseEnv.ServicesManager:GetObserverService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.commonService = App:GetService("CommonService")
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    self.UIService = App:GetService("UIService")
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    self.decorateService = CourseEnv.ServicesManager:GetDecorateService()
    self.lightService = CourseEnv.ServicesManager:GetLightService()
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.permissionService = CourseEnv.ServicesManager:GetPermissionService()
end

function GameResultScroe:InitVariable()
    self.playerStats = {}         --玩家统计
    self.playerAvatarSprites = {} --玩家头像
    self:ResetVariable()
end

function GameResultScroe:ResetVariable()

end

function GameResultScroe:InitConfig()

end

function GameResultScroe:InitListener()
    --监听统计数据请求
    --用法方式: Observer:Fire(RECORD_GAME_SCORE_DATA, { key = "统计项", value = 数值, type = 类型 })
    -- key: 统计项  GAME_RESULT_DATA_KEYS  中常量
    -- value: 数值
    -- type: 1=累计多次统计  2=替换唯一值  3=从0开始累加统计
    self.observerService:Watch(RECORD_GAME_SCORE_DATA, function(key, args)
        local data = args[0] -- 获取事件参数
        local key = data.key
        local value = data.value
        local type = data.type
        self:RecordData(key, value, type)
    end)

    --监听获取所有玩家统计数据
    self.observerService:Watch(GET_RECORD_SCORE_DATA, function(key, args)
        local data = args[0] -- 获取事件参数
        self.callback = data.callback
        -- self:Print("GET_ALL_RECORD_GAME_SCORE_DATA 获取所有玩家统计数据=======")
        self:GetAllData()
    end)

    --监听获取学校信息
    self.observerService:Watch(GET_PLAYERS_SCHOOL_INFO, function(key, args)
        local data = args[0] -- 获取事件参数
        local callback = data.callback
        local union_ids = data.union_ids
        self:TryGetSchoolInforByUnionIds(union_ids, function(data)
            if callback then
                callback(data)
            end
        end)
    end)

    --监听玩家加入房间 提前预加载学校信息
    self.gate.OnUserJoinRoom:connect(function(uuid)
        if App.Uuid == uuid then
            if self.isInit then
                return
            end
            self.isInit = true

            self.commonService:StartCoroutine(function()
                self.commonService:Yield(self.commonService:WaitUntil(function()
                    return self.avatarService:GetAvatarByUUID(uuid) ~= nil
                end))
                local avatar = self.avatarService:GetAvatarByUUID(uuid)
                local UnionId = avatar:GetProperty("UnionId") or avatar.UnionId
                -- self:Print("OnUserJoinRoom==================", uuid, UnionId)
                local union_ids = {
                    UnionId,
                }
                if App.IsStudioClient then
                    union_ids = {
                        "1y25bknrot71m",
                        "1y25bknrot73q",
                        "1y1vh3q4028zd",
                        "1y25bknrot71u"
                    }
                end
                --获取玩家学校名称
                -- "user_id": 1090052439,
                -- "school_id": 844688,
                -- "school_name": "北京一中",
                -- "grade": "一年级",
                -- "class": "1",
                -- "real_name": "饥饿饥饿",
                -- "birth_year": 2019,
                -- "predicting_grade": "一年级",
                -- "nickname": "明显明理的泰",
                -- "avatar": "https://static0.xesimg.com/next-app/avatar/avatar11.png",
                -- "union_id": "1y25bknrot71m"
                -- "avatar_2d": "https://hw.xesimg.com/iosabczone/nextunityimage/2025/09/22/1090052439_1758540290907_1758540290AvatarImage.png"
                local recordSchoolData = function(schoolName, avatarUrl)
                    self:RecordData(GAME_RESULT_DATA_KEYS.SCHOOL, schoolName, 2)
                    self:RecordData(GAME_RESULT_DATA_KEYS.AVATAR_URL, avatarUrl, 2)
                end
                self:TryGetSchoolInforByUnionIds(union_ids, function(data)
                    if data and data.list and #data.list > 0 then
                        for _, item in ipairs(data.list) do
                            --判断是否是自己
                            if App.IsStudioClient then
                                if item.union_id == "1y25bknrot71m" then
                                    recordSchoolData(item.school_name, item.avatar_2d)
                                end
                            else
                                --这里返回数据可能为空，所有不判断了，只有一个玩家 无所谓了
                                -- if item.union_id == UnionId then
                                recordSchoolData(item.school_name, item.avatar_2d)
                                -- end
                            end
                        end
                    end
                end)
            end)
        end
    end)
end

function GameResultScroe:InitView()

end

--region 统计数据-----------------------------------------------------------------------------------------------------------------------------

---统计数据 到服务器
---@param key string 键
---@param value string 值
---@param type number 类型 1表示累计统计  2表示替换唯一值  3表示从0开始累加统计
function GameResultScroe:RecordData(key, value, type)
    self:Print("RecordData 统计数据 到服务器=======", key, value, type)
    -- 本地记录数据
    -- self:RecordPlayerData(App.Uuid, key, value, type)
    -- 发送到服务器
    self:SendCustomMessage(RECORD_GAME_SCORE_DATA_TOSERVER, {
        key = key,
        value = value,
        type = type,
    })
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function GameResultScroe:ReceiveMessage(key, value, isResume)
    -- ✅ 先打印所有收到的消息，看是否有收到
    self:Print("=== ReceiveMessage 收到消息 ===", "key:", key, "value数量:", #value, "isResume:", isResume)
    if key == BACK_ALL_RECORD_GAME_SCORE_DATA then
        -- self:Print("✅ 匹配到 BACK_ALL_RECORD_GAME_SCORE_DATA 消息")
        for i = 1, #value, 1 do
            local data = self.jsonService:decode(value[i])
            if data and data.uuid == App.Uuid then
                -- 还原数据：将分离的数组和字典合并回混合table
                self.playerStats = self:UnwrapPlayerStatsFromReceive(data.value)
                -- -- 递归打印函数
                -- local function recursiveDump(tbl, indent, visited)
                --     indent = indent or ""
                --     visited = visited or {}

                --     -- 防止循环引用
                --     if visited[tbl] then
                --         self:Print(indent .. "[循环引用]")
                --         return
                --     end
                --     visited[tbl] = true

                --     for k, v in pairs(tbl) do
                --         local keyStr = tostring(k)
                --         if type(v) == "table" then
                --             self:Print(indent .. "key: " .. keyStr .. " (table) {")
                --             recursiveDump(v, indent .. "  ", visited)
                --             self:Print(indent .. "}")
                --         else
                --             self:Print(indent ..
                --             "key: " .. keyStr .. ", value: " .. tostring(v) .. " (" .. type(v) .. ")")
                --         end
                --     end
                -- end

                -- self:Print("========== 递归Dump self.playerStats 开始 ==========")
                -- recursiveDump(self.playerStats)
                -- self:Print("========== 递归Dump self.playerStats 结束 ==========")

                if self.callback then
                    self.callback(self.playerStats)
                end
            end
        end
    end

    if key == RECORD_GAME_SCORE_DATA_BACK_CLIENT then
        for i = 1, #value, 1 do
            local data = self.jsonService:decode(value[i])
            if data then
                local value = data.value
                local uuid = data.uuid
                local key = data.key
                local type = data.type
                if key == GAME_RESULT_DATA_KEYS.AVATAR_URL then
                    self:LoadAvatarBodySprite(uuid, value)
                end
            end
        end
    end
end

--region 获取玩家头像-----------------------------------------------------------------------------------------------------------------------------

---下载网络头像
---@param uuid string 玩家UUID
---@param avatarUrl string 头像URL
function GameResultScroe:LoadAvatarBodySprite(uuid, avatarUrl)
    self.httpService:LoadNetWorkTexture(avatarUrl, function(sprite)
        if sprite then
            self.playerAvatarSprites[uuid] = sprite
            -- self:Print("LoadAvatarBodySprite 加载头像成功======", uuid)
        end
    end)
end

--获取所有玩家统计数据
function GameResultScroe:GetAllData(callBack)
    -- self:Print("GetAllData 获取所有玩家统计数据=======")
    self:SendCustomMessage(GET_ALL_RECORD_GAME_SCORE_DATA, { modPlatform = App.ModPlatform or 2 })
end

--还原数据：将分离的数组和字典合并回混合table
---@param wrappedData table 包装的数据
---@return table 还原后的玩家统计数据
function GameResultScroe:UnwrapPlayerStatsFromReceive(wrappedData)
    local playerStats = {}
    for uuid, data in pairs(wrappedData) do
        playerStats[uuid] = {}

        -- 合并数组部分
        if data.__array then
            for k, v in pairs(data.__array) do
                playerStats[uuid][k] = v
            end
        end

        -- 合并字典部分
        if data.__dict then
            for k, v in pairs(data.__dict) do
                playerStats[uuid][k] = v
            end
        end

        local arrayCount = data.__array and #data.__array or 0
        local dictCount = 0
        if data.__dict then
            for _ in pairs(data.__dict) do
                dictCount = dictCount + 1
            end
        end
        -- self:Print("还原玩家 " .. uuid .. " 数据: 数组项=" .. arrayCount .. ", 字典项=" .. dictCount)
    end
    return playerStats
end

--endregion

--region 获取学校名称-----------------------------------------------------------------------------------------------------------------------------

---获取学校名称（带重试机制）
---@param union_ids string 用户ID
---@param callback function 回调函数
---@param retryCount number 重试次数
function GameResultScroe:TryGetSchoolInforByUnionIds(union_ids, callback, retryCount)
    retryCount = retryCount or 0
    local MAX_RETRY = 10
    if retryCount > MAX_RETRY then
        g_LogError("获取学校名称失败,重试次数超过最大次数")
        if callback then
            callback(nil)
        end
        return
    end
    self:GetSchoolInforByUnionIds(union_ids, function(data)
        if (data == nil) then
            self.commonService:DispatchAfter(0.2, function()
                self:TryGetSchoolInforByUnionIds(union_ids, callback, retryCount + 1)
            end)
        else
            -- 成功时调用原始回调
            if callback then
                callback(data)
            end
        end
    end)
end

---根据用户ID获取学校名称
---@param union_ids string 用户ID
---@return string 学校名称
function GameResultScroe:GetSchoolInforByUnionIds(union_ids, callback)
    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                self:Print("获取学校名称成功", table.dump(msg.data))
                callback(msg.data)
            end
        end
    end

    local fail = function(res)
        self:Print("获取学校名称失败", table.dump(res))
        callback(nil)
    end

    local ids = {}
    for _, union_id in ipairs(union_ids) do
        table.insert(ids, union_id)
    end
    local params = {
        union_ids = ids,
    }
    self:Print("获取学校名称请求参数", table.dump(params))
    self:HttpRequest("/v3/school_pk/user_school_by_unionids", params, success, fail)
end

--endregion

--region tools工具函数-----------------------------------------------------------------------------------------------------------------------------

-- http请求地址封装
---@param request string 请求地址 /v3/brain-pk/count
---@param params table 请求参数
---@param success function 成功回调
---@param fail function 失败回调
function GameResultScroe:HttpRequest(request, params, success, fail)
    local url = "https://app.chuangjing.com/abc-api" .. request
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041" .. request
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

-- 发送KEY-VALUE 消息
-- @param key 自定义/协议key
-- @param body  table 消息体
function GameResultScroe:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

--隐藏mvp舞台
---打印日志
function GameResultScroe:Print(...)
    g_Log("【分数统计】", ...)
end

--endregion
return GameResultScroe
