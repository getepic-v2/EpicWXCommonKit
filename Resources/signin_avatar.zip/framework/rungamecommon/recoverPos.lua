local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

local RecoverPos = class("recoverPos", WBElement)

---@param worldElement CS.Tal.framesync.WorldElement
function RecoverPos:initialize(worldElement)
    RecoverPos.super.initialize(self, worldElement)

end

function RecoverPos:setVisElement(parent, VisElement)
    self.VisElement = VisElement
    self.parent = parent
    self.root = self.VisElement.gameObject
    self.commonService = App:GetService("CommonService")
    self.observerService =  CourseEnv.ServicesManager:GetObserverService()
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/recoverPos/"
    local micPrefabPath = ResourcePathRoot .. "assets/Prefabs/huifu.prefab"
    local picturePathRoot = ResourcePathRoot .. "testures/"

    ResourceManager:LoadGameObjectWithExName(micPrefabPath, function(go)
        self.rootUI = GameObject.Instantiate(go)
        self.rootUI.transform:SetParent(self.root.transform)
        self.rootUI.transform.localPosition = Vector3.zero
        self.rootUI.transform.localScale = Vector3.one
        self.rootUI.transform.localRotation = Quaternion.identity
        self.rootUI.transform.name = "recoverPos"
        local recoverPosRenderer = self.rootUI.transform:Find("Canvas"):GetComponent(typeof(CS.UnityEngine.Canvas))
        recoverPosRenderer.sortingOrder = 200

        self.btn = self.VisElement.transform:Find("recoverPos/Canvas/Button"):GetComponent(typeof(CS.UnityEngine.UI.Button))
        self.commonService:AddEventListener(self.btn, "onClick", function()
            self.observerService:Fire("TP2LastPoint")
        end)
    end)

end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function RecoverPos:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function RecoverPos:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function RecoverPos:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function RecoverPos:SelfAvatarPrefabLoaded(avatar)
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function RecoverPos:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function RecoverPos:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function RecoverPos:LogicMapStartRecover()
    RecoverPos.super:LogicMapStartRecover()
    -- TODO
end
-- 结束恢复方法 (断线重连的时候用)
function RecoverPos:LogicMapEndRecover()
    RecoverPos.super:LogicMapEndRecover(self)
    -- TODO
end
-- 所有的组件恢复完成
function RecoverPos:LogicMapAllComponentRecoverComplete()

end

-- 收到Trigger事件
function RecoverPos:OnReceiveTriggerEvent(interfaceId)
end
-- 收到GetData事件
function RecoverPos:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function RecoverPos:Exit()
    RecoverPos.super.Exit(self)
end

return RecoverPos