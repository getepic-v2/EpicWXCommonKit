---
---  Author: 【彩滨滨】
---  AuthorID: 【246276】
---  CreateTime: 【2023-6-20 15:30:46】
--- 【FSync】
--- 【跑酷游戏客户端】
--- 客户端协议定义：
--- state:1 玩家加入
--- state:2 玩家答完一道题
--- state:3 玩家退出
------ 服务端协议定义：
--- state:1 10道题目，10种随机地形序列，开启3倒计时
--- state:2 服务端通知自己等待超过60秒
--- state:3 
--- state:4 刷新实时排行榜
--- state:5 一名玩家已完成，所有玩家开始15秒倒计时
--- state:6 游戏结束,并推送排行榜
--- state:7 n名玩家加入游戏
--- state:8 1名玩家提前完成游戏

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local RunGameElement = class("rungame_comlogic", WBElement)

local Fsync_Server_KEY = "runGame_server_key"
local Fsync_Client_KEY = "runGame_client_key"

local runGameMiji = require("rungamecommon/rungame_miji")

---@param worldElement CS.Tal.framesync.WorldElement
function RunGameElement:initialize(worldElement)
    RunGameElement.super.initialize(self, worldElement)

    g_Log("初始化跑酷公共逻辑")
    -- 隐藏按住说话
    CourseEnv.ServicesManager:GetUIService():SetHidenVoiceBtnWithID()
    APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
        open = false,
        isShow = false,
        topSafeArea = 0
    }, function()

    end)
    --订阅KEY消息
    self:SubscribeMsgKey(Fsync_Server_KEY)
    self:SubscribeMsgKey(Fsync_Server_KEY .. "1")
    self:SubscribeMsgKey(Fsync_Server_KEY .. "3")
    self:SubscribeMsgKey("activateRoom")
    -- 添加初始化完成埋点
    self:reportLog("RunGameInitFinish")
end

function RunGameElement:setVisElement(parent,VisElement)
    self.parent = parent
    self.VisElement = VisElement
    self:initPaoKuMiji()
    self:initService()
    self:initConfig()
    self:initListener()
    self:InitView()
    g_Log("完成初始化操作" .. self.VisElement.name)
end

function RunGameElement:initPaoKuMiji()
    CourseEnv.ServicesManager.Gate:AddElementType("runGameMiji", runGameMiji)
    local dict = CS.Tal.framesync.VisualProperty();
    dict:Add("type", "runGameMiji")
    -- self.miji = CourseEnv.ServicesManager.Gate:CreateElementWithProperties(dict, Vector3.zero, Vector3.zero, Vector3.zero, "WorldElement")
    -- self.miji:setVisElement(self.VisElement)
end

function RunGameElement:initService()
    self.commonService = App:GetService("CommonService")
    self.observerService =  CourseEnv.ServicesManager:GetObserverService()
    self.joyService = CourseEnv.ServicesManager:GetJoystickService()
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
end

function RunGameElement:initConfig()
    self.level_array_string = self.configService:GetConfigValueByConfigKey(self.VisElement, "level_array_string")
    self.workSpace = CS.UnityEngine.GameObject.Find("Workspace")
    self.level_array_obj = self.workSpace.transform:FindInAll(self.level_array_string )
    self.endAudio = self.configService:GetAssetByConfigKey(self.VisElement, "EndAudio", true)
    self.finishAudio = self.configService:GetAssetByConfigKey(self.VisElement, "FinishAudio", true)
    self.countDownAudio = self.configService:GetAssetByConfigKey(self.VisElement, "count_down_audio",true)
    self.questionNum = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "questionNum"))
    self.randomTerr = self.configService:GetConfigValueByConfigKey( self.VisElement ,"randomTerr")
    self.question_array_string = self.configService:GetConfigValueByConfigKey(self.VisElement, "questionObj_array_string")
    self.startImage = self.configService:GetAssetByConfigKey(self.VisElement, "startImage", true)  
 
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/paokuRes/"
    local picturePathRoot = ResourcePathRoot .. "images/"
    ResourceManager:LoadSpriteWithExName(picturePathRoot .. "endImage.png", function(sprite)
        if sprite then
            self.VisElement.transform:Find("屏幕画布/结束/结束页面").gameObject:GetComponentsInChildren(typeof(CS.UnityEngine.UI.Image))[0].sprite = sprite
        end
    end)

    -- 替换读课文题板
    local newPanelprefab = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/3dQuestionPanel/assets/Prefabs/M_tiban.prefab"
    ResourceManager:LoadGameObjectWithExName(newPanelprefab, function(go)
        self.newPanelPrefab = GameObject.Instantiate(go)
        self.newPanelPrefab:SetActive(false)
    end)

    self.setId = 1
    self.url = "https://app.chuangjing.com/next-api"
    if App.Info.configMap.env ~= "online" then
        self.url = "https://app-test.chuangjing.com/next-api"
    end
    local fps = App.Info.configMap.frame_num
    if fps == nil then
        fps = 15
    end
    CourseEnv.ServicesManager.Gate:SetSendFPS(fps)
    -- 开始倒计时相关
    self.isRun = false
    self.questionObj = {}
    self.curQuestionIndex = 1
    -- 结束倒计时先关
    self.yellowNumImage = {}
    for i = 0, 9 do
        ---@type CS.UnityEngine.Sprite
        self.yellowNumImage[i] = self.configService:GetAssetByConfigKey(self.VisElement, "num_" .. i, true)
    end
    self.audio = self.configService:GetAssetByConfigKey(self.VisElement, "countDownAudio")
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(false)
    self.hasStartPlay = false
    -- 是否展示过段位结算页
    self.isShowRankPanel = false
    -- 开口次数
    self.openMouseCount = 0
    -- 记录当前答得第几道题
    self.currentQuestionIndex = 0
    self.doneQuestion = 0
    self.isInitialized = false
    self.state = 0 -- 3 开始结算 4 结算完自己 5提前结算 6 最终结算完
    -- 游戏开始时间
    self.startTime = os.time()
    -- 当前是否在答题
    self.isAnswer = false
    -- 埋点辅助：题板通过记录（panelIndex -> set(uuid)），以及去重标记
    self.panelPassers = {}
    self.recoverSummaryReported = false
    self.speakReported = false
end

function RunGameElement:initListener()
    self.lastRewardCount = -1
    self.observerService:Watch("on_change_last_reward_count", function(key, params)
        local data = params[0]
        if data then
            self.lastRewardCount = data.count or -1
        end
        g_Log("跑酷排位:on_change_last_reward_count" .. self.lastRewardCount)
        if not self.tableAllTipsTrans then
            return
        end
        g_Log("跑酷排位:tableAllTipsTrans count " .. #self.tableAllTipsTrans)
        for i, trans in ipairs(self.tableAllTipsTrans) do
            trans.gameObject:SetActive(self.lastRewardCount > 0)
        end
    end)
    -- 添加中途退出埋点上报
    self.observerService:Watch("quitVerify",function()
        local param = {}
        param["modName"] = App.modName
        param["liveId"] = App.Info.liveId
        param["userId"] = App.Info.userId
        param["openMouseCount"] = self.openMouseCount
        param["doneQuestion"] = self.doneQuestion
        param["questionNum"] = self.questionNum
        param["eventId"] = "GameQuitMidway"
        param["eventtype"] = "GameQuitMidway"
        param["time"] = os.time() - self.startTime
        g_LogError("跑酷排位:中途退出上报" .. table.dump(param))
        APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
    end)

    -- 复活点统计在本脚本不使用（此脚本以“题板通过次数”上报）
    
    self.observerService:Watch("TP2LastPoint",function()
        -- local objStr = "关卡布置/复活点/" .. tostring(self.doneQuestion)
        -- local point = worldElement.transform:Find(objStr).transform.position
        local point = self.level_array_obj:Find("复活点/" .. tostring(self.doneQuestion)).transform.position

        if self.selfAvatar then
            self.selfAvatar:TeleportAndNotice(point,true)
            g_Log("客户端:掉落，传送回上一个点" .. "point-" .. self.doneQuestion)
        end
        -- 如果在答题，结束答题状态
        self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
            status = 2})
        self.observerService:Fire("isCloseAudio",{isCloseAudio=false})

        if self.isAnswer == true then
            self.isAnswer = false
        end

        if self.isStartTeacherView then
            --开始题目预播
            self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
            { op = "Start" }) --开启题目预播 --建议在游戏321倒计时结束的时候调用
        end
    end)
    self.observerService:Watch("startSettle",function()
        g_Log("客户端:触发退出逻辑")
        -- 未结算
        if self.state < 3 then
            local reportData = {}
            reportData.setId = self.setId
            reportData.rank = 8
            reportData.score = 0
            reportData.award = 0
            reportData.is_run = true
            reportData.isFailed = true
            self.parent:Trigger("startRankPanel")
            -- self.miji:ShowMIJI(false)
            --停止题目预播
            self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
            { op = "Stop" })  --在游戏结算的时候调用
            self.isStartTeacherView = false
            if self.isShowRankPanel == false then
                self.isShowRankPanel = true
                self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",reportData)
            end
        else
            -- 已经结算
            self.parent:Trigger("startRankPanel")
            -- self.miji:ShowMIJI(false)
            --停止题目预播
            self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
            { op = "Stop" })  --在游戏结算的时候调用
            self.isStartTeacherView = false
            if self.isShowRankPanel == false then
                self.isShowRankPanel = true
                self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",{})
            end
        end

        self.state = 5
        self:EndCountDownEnd()
        self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
            status = 2})
        self.commonService:DispatchAfter(3,function()
            self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                status = 2})
        end)
    end)
end

function RunGameElement:reportLog(eventId)
    local param = {}
    param["modName"] = App.modName
    param["liveId"] = App.Info.liveId
    param["userId"] = App.Info.userId
    param["eventId"] = eventId
    param["eventtype"] = eventId
    APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
end

function RunGameElement:reportData(eventId, label, value, action)
    if not App.IsStudioClient then
        NextStudioComponentStatisticsAPI.ComponentStatisticsWithParam(eventId, "67881", "Special-Interaction", label,
            action, value)
    end
end

-- 结束时上报：开口次数
function RunGameElement:reportSpeakCountEnd()
    if self.speakReported == true then
        return
    end
    local param = {}
    param["modName"] = App.modName
    param["liveId"] = App.Info.liveId
    param["userId"] = App.Info.userId
    param["eventId"] = "parkour_speak_count"
    param["eventtype"] = "parkour_speak_count"
    param["openMouseCount"] = self.openMouseCount or 0
    g_Log("跑酷排位:结束上报开口次数 openMouseCount=" .. tostring(param["openMouseCount"]))
    APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
    self.speakReported = true
end

-- 结束时上报：题板通过次数（每个题板上报唯一玩家人数）
function RunGameElement:reportCheckpointPassesEnd()
    if self.recoverSummaryReported == true then
        return
    end
    if self.panelPassers == nil then
        return
    end
    local hasAny = false
    for id, passerSet in pairs(self.panelPassers) do
        local count = 0
        if passerSet ~= nil then
            for _ in pairs(passerSet) do
                count = count + 1
            end
        end
        if count > 0 then
            hasAny = true
            local param = {}
            param["modName"] = App.modName
            param["liveId"] = App.Info.liveId
            param["userId"] = App.Info.userId
            param["eventId"] = "parkour_respawnPointId_passCount"
            param["eventtype"] = "parkour_respawnPointId_passCount"
            param["recoverPointId"] = id
            param["passCount"] = count
            g_Log("跑酷排位:结束上报题板通过 id=" .. tostring(id) .. ", count=" .. tostring(count))
            APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
        end
    end
    if hasAny then
        self.recoverSummaryReported = true
    end
end

function RunGameElement:InitView()
    -- 隐藏按钮
    -- CourseEnv.ServicesManager:GetUIService():hidenCommonMenu()
    CourseEnv.ServicesManager:GetUIService():SetHidenFollowBtnWithID()

    if not App.IsStudioClient then
        self.level_array_obj:Find("复活点").gameObject:SetActive(false)
    end

    -- 添加调试快捷按钮
    if App:IsDebug() == false then
        self.VisElement.transform:Find("屏幕画布/传送").gameObject:SetActive(false)
    else
        -- 获取传送按钮RectTransform
        local rect = self.VisElement.transform:Find("屏幕画布/传送"):GetComponent(typeof(CS.UnityEngine.RectTransform))
        -- 向左移动200像素
        rect.anchoredPosition = CS.UnityEngine.Vector2(rect.anchoredPosition.x - 200, rect.anchoredPosition.y)
        
        self.gBtn = self.VisElement.transform:Find("屏幕画布/传送").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
        App:GetService("CommonService"):AddEventListener(self.gBtn, "onClick", function()
            -- local objStr = "关卡布置/复活点/" .. tostring(self.doneQuestion + 1)
            -- local point = self.VisElement.transform:Find(objStr).transform.position
            local point = self.level_array_obj:Find("复活点/" .. tostring(self.doneQuestion + 1)).transform.position
            if self.selfAvatar then
                self.selfAvatar:TeleportAndNotice(point)
                g_Log("客户端:测试，传送到下个答题点" .. "point-" .. self.doneQuestion + 1)
            end
        end)
    end
    -- 等待人数
    self.loading = self.VisElement.transform:Find("屏幕画布/背景").gameObject
    self.loading:SetActive(false)
    -- 提醒关闭弹窗
    self.root = self.VisElement.gameObject
    self.rootTrans = self.root.transform
    self.tipDialog = self.rootTrans:FindChildWithName("跑酷超时提醒弹窗")
    self.dialogTitle = self.tipDialog:FindChildWithName("Title")
    self.dialogTitleTmp = self.dialogTitle:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogTitleTmp.text = ""
    self.dialogConfirm = self.tipDialog:FindChildWithName("Confirm")
    self.dialogConfirmBtn= self.dialogConfirm:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.dialogConfirmText = self.dialogConfirm:FindChildWithName("text")
    self.dialogConfirmTmp = self.dialogConfirmText:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogConfirmTmp.text = "确定"
    self.dialogConfirmTmp.color = CS.UnityEngine.Color(1,1,1,1)
    self.dialogContent = self.tipDialog:FindChildWithName("Content")
    self.dialogContentTmp = self.dialogContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogContentTmp.text = "小伙伴失联了哦，退回到首页重新开始吧~"
    self.commonService:AddEventListener(self.dialogConfirmBtn, "onClick", function()
        self.tipDialog.gameObject:SetActive(false)
        App:GameReturn()
    end)
    self.tipDialog.gameObject:SetActive(false)
    -- 结束页面
    self.endPanel = self.VisElement.transform:Find("屏幕画布/结束").gameObject
    self.endPanel:SetActive(false)
    self.endPanelexitBtn = self.VisElement.transform:Find("屏幕画布/结束/结束页面/退出按钮").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.endPanelexitBtn, "onClick", function()
        App:GameReturn()
    end)
    -- 开始页面
    self.startPanel = self.VisElement.transform:Find("屏幕画布/开始页面").gameObject
    self.startPanel:GetComponentsInChildren(typeof(CS.UnityEngine.UI.Image))[0].sprite = self.startImage
    self.startPanel:SetActive(false)
    -- 观战按钮
    self.obBtn = self.VisElement.transform:Find("屏幕画布/观战").gameObject
    self.obBtn:SetActive(false)
end

-- 开始倒计时开始
function RunGameElement:StartCountStart()
    if self.isRun then return end
    self.isRun = true
    self:Clear()
    self.countDownCanvas = self.VisElement.gameObject.transform:Find("倒计时UI/Asset/CountDownCanvas")
    self.effect = self.countDownCanvas:Find("countdown_321_go")
    self.effect.gameObject:SetActive(true)
    if self.finishAudio then
        self.audioService:PlayClipOneShot(self.countDownAudio)
    else
        g_LogError("开始倒计时音频未配置")
    end
    
    -- 倒计时播放完后开始赛车
    self.seq = DOTween:Sequence()
    self.seq:AppendInterval(4)
    self.seq:AppendCallback(function()
        self.effect.gameObject:SetActive(false)
        self:Clear()
        self.isRun = false
        self:StartCountDownEnd()
    end)
end

-- 开始倒计时结束
function RunGameElement:StartCountDownEnd()
    g_Log("客户端:倒计时完成，正式开始游戏")
    self.level_array_obj:Find("空气墙/起始点控制空气墙").gameObject:SetActive(false)
    self.parent:Trigger("CountDownEnd")
    -- self.miji:ShowMIJI(true)
    -- self.miji:ChangeMiJIQuestion(false)
    self:changeNextQuestionUI(self.currentQuestionIndex + 1)
    -- self.miji:playFirstAudio()

    --开始题目预播
    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
    { op = "Start" }) --开启题目预播
    self.isStartTeacherView = true
end

function RunGameElement:Clear()
    if self.seq then
        self.seq:Kill()
        self.seq = nil
    end
end

-- 结束倒计时开始
function RunGameElement:EndCountDownStart(countDownNum)
    if countDownNum == 10 then
        if self.hasStartPlay == false then
            self.hasStartPlay = true
            if self.audio then
                self.audioSource = self.audioService:PlayClipOneShot(self.audio)
            end
            APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
                open = false,
                isShow = false,
                topSafeArea = 0
            }, function()
        
            end)
             -- 隐藏按住说话按钮
            CourseEnv.ServicesManager:GetUIService():SetHidenVoiceBtnWithID()
        end
    end
    self.countDown = countDownNum
    g_Log("客户端:开始结束前倒计时" .. self.countDown)
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(true)
    local num1 = math.floor(self.countDown / 10)
    local num2 = self.countDown % 10
    self.VisElement.transform:Find("屏幕画布/背景图片/数字3"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite = self.yellowNumImage[num1]
    self.VisElement.transform:Find("屏幕画布/背景图片/数字4"):GetComponent(typeof(CS.UnityEngine.UI.Image)).sprite = self.yellowNumImage[num2]
end

-- 结束倒计时结束
function RunGameElement:EndCountDownEnd()
    g_Log("客户端:结束结束前倒计时")
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(false)
    if self.audioSource then
        self.audioService:StopAudioClip(self.audioSource)
    end
end

function RunGameElement:updateWaitingNum(num,totalNum)
    if self.loading then
        self.loading.transform:Find("标题"):GetComponent(typeof(CS.UnityEngine.UI.Text)).text = "等待好友加入挑战 " .. num .. "/" .. totalNum
        self.loading.transform:Find("正文"):GetComponent(typeof(CS.UnityEngine.UI.Text)).text = num .. "个小伙伴，已经进入挑战啦~"
    end
end

function RunGameElement:uploadCostTL()
    local totalUrl = self.url .. "/v3/user/power/cost"
    local param = {
        game_id = 7
    }

    APIBridge.RequestAsync('api.httpclient.request', {
        ["url"] = totalUrl,
        ["headers"] = {
            ["Content-Type"] = "application/json"
        },
        ["data"] = param
    }, function(res)
        if res ~= nil and res.responseString ~= nil and res.isSuccessed then
            local resp = res.responseString
            local msg = nil
            if type(resp) == "string" then msg = self.jsonService:decode(resp) end
            if msg and msg.msg == "success" then
                if msg.code == 0 then
                    local data = msg.data
                    if data then
                        g_Log("上报自己消耗体力成功")
                    end
                end
            else
                g_Log("上报自己消耗体力失败-")
            end
        else
            g_Log("客户端:上报消耗体力失败")
        end
    end)
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function RunGameElement:ReceiveMessage(key, value, isResume)

    if key == Fsync_Server_KEY or key == Fsync_Server_KEY .. "1" or key == Fsync_Server_KEY .. "3" then
        g_Log("客户端:收到服务端消息-key:" .. key)
        for key, msg in pairs(value) do
            local lastMsg = msg
            g_Log("客户端:收到服务端消息" .. "key-" .. key .. "value-" .. lastMsg)
            local status = CourseEnv.ServicesManager:GetJsonService():decode(lastMsg)
            if status and status.state then
                if status.state == 1 then
                    if self.isInitialized == false then
                        -- 添加游戏开局埋点
                        self:reportLog("RunGameStart")
                        self.startTime = os.time()
                        self.url = status.Url
                        self.setId = status.setId
                        self:uploadCostTL()
                        -- 取消展示人数
                        if  self.loading then
                            self.loading:SetActive(false)
                        end
                        -- 取消开始页面
                        if self.startPanel then
                            self.startPanel:SetActive(true)
                            self.commonService:DispatchAfter(3,function()
                                self.startPanel:SetActive(false)
                                self:StartCountStart()
                            end)
                        end
                        
                        self.commonService:StartCoroutine(function()
                            self.commonService:Yield(
                                self.commonService:WaitUntil(function()
                                return self.selfAvatar ~= nil
                            end))
                            
                            self.parent:Trigger("runGameStart")
                        end)

                        self.isInitialized = true
                    end
                elseif status.state == 2 then
                    CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
                    self.tipDialog.gameObject:SetActive(true)
                elseif status.state == 3 then
                    if self.randomTerr == "True" then
                        g_Log("客户端:收到服务端随机地形序列" .. "random-" .. table.dump(status.random))
                        self:build(status.random)
                    end
                elseif status.state == 4 then
                    self.observerService:Fire("RefleshRankUI", status.rank)
                elseif status.state == 5 then
                    if self.state ~= 5 and status.countDownNum >= 0 then
                        self:EndCountDownStart(status.countDownNum)
                    end
                elseif status.state == 6 then
                    self:EndCountDownEnd()
                    -- 游戏结束：上报开口次数与复活点通过次数
                    self:reportSpeakCountEnd()
                    self:reportCheckpointPassesEnd()
                    self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                        status = 2})
                    self.commonService:DispatchAfter(3,function()
                        self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                            status = 2})
                    end)
                    CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
                    if self.state < 3 then
                        g_Log("客户端:时间到，游戏已经结束")
                        self.endPanel:SetActive(true)
                        if self.finishAudio then
                            self.audioService:PlayClipOneShot(self.finishAudio,function ()
                        
                            end)
                        end
                        self.commonService:DispatchAfter(3,function()
                            g_Log("3S后提交自己游戏结果")
                            self.endPanel:SetActive(false)
                            local gameResultData = status.totalScores
                            if self.doneQuestion == self.questionNum then
                                self:reportData("RunGameDone","完成答题",{param_one = 1},"0")
                                gameResultData.isFinish = true
                            else
                                gameResultData.isFinish = false
                            end
                            gameResultData.useTime = 21474836473
                            gameResultData.gameId = status.totalScores.gameId
                            gameResultData.petExp = self.doneQuestion
                            gameResultData.autoClose = false
                            for _, value in pairs(status.totalScores.rankList) do
                                if value.userId ==  App.Uuid then
                                    gameResultData.useTime = value.score
                                    gameResultData.setId = self.setId
                                    gameResultData.score = value.score
                                    gameResultData.rank = value.rank
                                    gameResultData.award = value.cheese
                                    break
                                end
                            end
                            gameResultData.autoCloseCallBack = function()
                                g_Log("自动关闭自己结算页开始段位结算")
                                self.parent:Trigger("startRankPanel")
                                -- self.miji:ShowMIJI(false)
                                --停止题目预播
                                self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
                                { op = "Stop" })  --在游戏结算的时候调用
                                self.isStartTeacherView = false

                                if self.isShowRankPanel == false then
                                    self.isShowRankPanel = true
                                    self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",{})
                                end
                            end
                            g_Log("玩家答题时间-" .. gameResultData.useTime .. "秒")
                            gameResultData.rankListType = 1
                            gameResultData.titleType = 1
                            gameResultData.contentType = 1
                            gameResultData.closeBtnType = 1
                            local passRate = 0
                            if self.openMouseCount > 0 then
                                passRate = self.doneQuestion / self.openMouseCount
                            end
                            if passRate >= 0 and passRate <= 1 then
                                gameResultData.passRate = passRate
                            end
                            gameResultData.rankList = nil
                            self.observerService:Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)
                            if self.endAudio then
                                self.audioService:PlayClipOneShot(self.endAudio,function ()
                                
                                end)
                            end
                        end)
                    elseif self.state  == 3 then
                        g_Log("客户端:已经上报过结果，游戏已经结束")
                        -- 延时1秒
                        App:GetService("CommonService"):DispatchAfter(3,function()
                            self.obBtn:SetActive(false)
                            self.observerService:Fire("HIDE_MINI_GAME_RESULT_PANEL")
                            self.endPanel:SetActive(true)
                            if self.finishAudio then
                                self.audioService:PlayClipOneShot(self.finishAudio,function ()
                            
                                end)
                            end
                            self.commonService:DispatchAfter(3,function()
                                g_Log("3S后开始结算段位")
                                self.endPanel:SetActive(false)
                                self.parent:Trigger("startRankPanel")
                                -- self.miji:ShowMIJI(false)
                                --停止题目预播
                                self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
                                { op = "Stop" })  --在游戏结算的时候调用
                                self.isStartTeacherView = false
                                if self.isShowRankPanel == false then
                                    self.isShowRankPanel = true
                                    self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",{})
                                end
                            end)
                        end)
                    elseif self.state == 4 then
                        g_Log("客户端:已经上报过结果，游戏已经结束")
                        -- 延时1秒
                        App:GetService("CommonService"):DispatchAfter(1,function()
                            self.obBtn:SetActive(false)
                            self.observerService:Fire("HIDE_MINI_GAME_RESULT_PANEL")
                            self.endPanel:SetActive(true)
                            if self.finishAudio then
                                self.audioService:PlayClipOneShot(self.finishAudio,function ()
                            
                                end)
                            end
                            self.commonService:DispatchAfter(3,function()
                                g_Log("3S后开始结算段位")
                                self.endPanel:SetActive(false)
                                self.parent:Trigger("startRankPanel")
                                -- self.miji:ShowMIJI(false)
                                --停止题目预播
                                self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
                                { op = "Stop" })  --在游戏结算的时候调用
                                self.isStartTeacherView = false
                                if self.isShowRankPanel == false then
                                    self.isShowRankPanel = true
                                    self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST",{})
                                end
                            end)
                        end)
                    end
                    self.state = 6
                    -- 隐藏控制按钮
                    self.joyId = self.joyService:setHidenJoyWithID()
                    self.jumpId = self.joyService:setHidenJumpWithID()
                    -- 关闭观战
                    self.obBtn:SetActive(false)
                    -- self.miji:setLooping(false)
                    -- self.miji:ShowMIJI(false)

                    --停止题目预播
                    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
                    { op = "Stop" })  --在游戏结算的时候调用
                    self.isStartTeacherView = false
                elseif status.state == 7 then
                    local num = status.playerNum
                    local totalNum = status.totalNum
                    -- T展示人数
                    if self.isInitialized == false then
                        self.loading:SetActive(true)
                    end
                    self:updateWaitingNum(num,totalNum)
                elseif status.state == 8 then
                    local reportPoint = self.jsonService:decode(status.reportPoint)
                    if reportPoint.userId ==  App.Properties.UserId then
                        self:reportData("RunGameDone","完成答题",{param_one = 0},"0")
                        self.state = 3
                        --停止题目预播
                        self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
                        { op = "Stop" })  --在游戏结算的时候调用
                        g_Log("上报自己积分" .. table.dump(reportPoint))
                        -- 展示结果页
                        local gameResultData = {}
                        gameResultData.setId = self.setId
                        gameResultData.rank = reportPoint.rank
                        gameResultData.award = reportPoint.award
                        gameResultData.score = reportPoint.score

                        gameResultData.isFinish = true
                        gameResultData.useTime = reportPoint.score
                        gameResultData.rankList = {}
                        gameResultData.petExp = self.doneQuestion
                        gameResultData.autoClose = true
                        gameResultData.rankListType = 1
                        gameResultData.titleType = 1
                        gameResultData.contentType = 1
                        gameResultData.closeBtnType = 1
                        local passRate = 0
                        if self.openMouseCount > 0 then
                            passRate = self.doneQuestion / self.openMouseCount
                        end
                        if passRate >= 0 and passRate <= 1 then
                            gameResultData.passRate = passRate
                        end
                        gameResultData.autoCloseCallBack = function()
                            g_Log("3S后自动关闭自己结算页并开始观战")
                            if self.state < 5 then
                                self.obBtn:SetActive(true)
                            end
                            
                            self.observerService:Fire("isWatchBattle",{isWatchBattle = true})
                            self.state = 4
                        end

                        self.observerService:Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)
                        if self.endAudio then
                            self.audioService:PlayClipOneShot(self.endAudio,function ()
                            
                            end)
                        end

                        -- 展示App评分
                        -- 延时2秒
                        App:GetService("CommonService"):DispatchAfter(2,function()
                            if gameResultData.rank <= 3 then
                                self:appEvaluate()
                            end
                        end)
                    end
                end
            end
        end
    elseif key == "activateRoom" then 
        g_Log("客户端:收到激活房间消息")
        g_Log(table.dump(value))
        for key, msg in pairs(value) do
            local lastMsg = CourseEnv.ServicesManager:GetJsonService():decode(msg)
            if lastMsg and lastMsg.set_id then
                self.setId = tonumber(lastMsg.set_id)
            end
        end
    end
end
-- 生成随机地形
function RunGameElement:build(random)
    if self.hasBuild then
        return
    end
    for key, value in pairs(random) do
        -- local objStr = "关卡布置/跑道/跑道" .. tostring(key)
        -- local objStrPrefab = "关卡布置/预制关卡/关卡" .. tostring(value)
        -- local pos = self.VisElement.transform:Find(objStr).transform.position
        -- local obj = self.VisElement.transform:Find(objStrPrefab)

        local pos = self.level_array_obj:Find("跑道/跑道" .. tostring(key)).transform.position
        local obj = self.level_array_obj:Find("预制关卡/关卡" .. tostring(value))
        if obj then
            obj.transform.position = pos
            g_Log("设置关卡" .. value .. "位置" .. key)
            
        end
    end
    self.hasBuild = true
end
-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function RunGameElement:SendCustomMessage(key, body)
    self:SendMessage(key,body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:SelfAvatarCreated(avatar)
    local AvatarService = App:GetService("Avatar")
    ---@type FSyncAvatarCtrl
    self.selfAvatar = AvatarService:GetAvatarByUUID(App.Uuid)
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:SelfAvatarPrefabLoaded(avatar)
    avatar.VisElement.gameObject.layer = CS.UnityEngine.LayerMask.NameToLayer("areaTrigger")
    g_Log("客户端:发送加入游戏消息")
    self:SendCustomMessage(Fsync_Client_KEY, { state = 1,UserId = App.Properties.UserId ,AvatarName = App.Properties.AvatarName})
    self:initQuestions()
    CourseEnv.ServicesManager:GetJoystickService():UnlockCameraMaxSpeed()
    -- self:AddVoice()
end

function RunGameElement:AddVoice()
    self.showChat = false
    local appVersion = App.Info.appVersionNumber
    if appVersion then
        if tonumber(appVersion) < 10510 then
            return 
        end
    end
    self.showChat = true

    --强制显示
    CourseEnv.ServicesManager:GetUIService().voiceBtnHidenStateTable = {}
    CourseEnv.ServicesManager:GetUIService().commonMenu.VisitorToLogin = true
    CourseEnv.ServicesManager:GetUIService().commonMenu.voiceBtn.gameObject:SetActive(true)

    APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
        open = true,
        isShow = true,
        topSafeArea = 40.0/750,
    }, function()

    end)

    local ori = APIBridge.RequestAsync
    APIBridge.RequestAsync = function(api, request, callBack)
        if api == 'app.buss.menu.autoPlayChat' and (not request.topSafeArea or request.topSafeArea == 0) then
            request.topSafeArea = 40.0/750
        end

        ori(api, request, callBack)
    end
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:AvatarCreated(avatar)

end

-- 拉题
--- func desc api:http://yapi.xesv5.com/project/2041/interface/api/73881
---@param num number 题目数量
---@param type number 题目类型 1:单词 2:句子 3:选择
function RunGameElement:initQuestions()
    self.commonService:StartCoroutine(function ()
        self.commonService:Yield(self.commonService:WaitUntil(function()
            return self.recoverComplete == true
        end))

        self.commonService:YieldSeconds(3)

        CourseEnv.ServicesManager:GetObserverService():Fire("EVENT_ABCZONE_QUESTION_MANATER", {
            params = { { qType = 51, qCount = 60 } },
            callBack = function(questions)
                self.questions = questions["51"]
                -- self.miji:setQuestions(self.questions)
                g_Log("跑酷排位:拉取题目成功") -- .. table.dump(self.questions))
                self.parent:Trigger("getQuestionsEnd")
                g_Log("客户端:初始化所有题板")
                local questionIndex = 1
                self.workSpace = CS.UnityEngine.GameObject.Find("Workspace")
                self.question_object_root = self.workSpace.transform:FindInAll(self.question_array_string )
                if self.question_object_root == nil then
                    g_LogError("找不到题目根节点")
                    return
                end
                -- 查找所有子物体
                for i = 0, self.question_object_root.childCount - 1, 1 do
                    local child = self.question_object_root:GetChild(i)
                    if child and string.contains(child.name, "题板") then
                        g_Log("child.name--" .. child.name)
                        -- 新增，更改题板层级
                        child.gameObject.layer = CS.UnityEngine.LayerMask.NameToLayer("NPC")
                        self.questionObj[child.name] = child

                        -- 查找题板子物体
                        local assetChild = child.transform:Find("Asset")
                        if assetChild then
                            if self.newPanelPrefab then
                                local newPanel = GameObject.Instantiate(self.newPanelPrefab)
                                newPanel.name = "Asset"
                                newPanel.transform:SetParent(assetChild.parent)
                                newPanel.transform.localPosition = assetChild.localPosition
                                newPanel.transform.localRotation = assetChild.localRotation
                                newPanel.transform.localScale = assetChild.localScale
                                newPanel.gameObject:SetActive(true)
                                newPanel.gameObject.layer = CS.UnityEngine.LayerMask.NameToLayer("NPC")
                                local kewen = newPanel.transform:Find("Canvas/kewen")
                                local juzi = newPanel.transform:Find("Canvas/juzi")
                                if kewen then
                                    kewen.transform.localPosition = Vector3(kewen.transform.localPosition.x, kewen.transform.localPosition.y, kewen.transform.localPosition.z + 0.1)
                                end
                                if juzi then
                                    juzi.transform.localPosition = Vector3(juzi.transform.localPosition.x, juzi.transform.localPosition.y, juzi.transform.localPosition.z + 0.1)
                                end
                                GameObject.Destroy(assetChild.gameObject)
                            else
                                assetChild.gameObject.layer = CS.UnityEngine.LayerMask.NameToLayer("NPC")
                            end
                        end

                        local canvas = child.transform:Find("场景画布")
                        if canvas then
                            canvas.gameObject:SetActive(false)
                        end
                        
                        local collider = child.transform:Find("碰撞");
                        CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(collider.gameObject, function(other)
                            if other.name == self.selfAvatar.VisElement.gameObject.name then
                                if self.isAnswer == true then
                                    return
                                end

                                self.isAnswer = true
                                g_Log("碰撞到题目，开始答题")
                                self.observerService:Fire("isCloseAudio",{isCloseAudio=true})
                                -- self.curCollider = collider
                                self:answerQuestion()
                            end
                        end)
                        questionIndex = questionIndex + 1
                    end
                end
            end
        })
    end)
end

-- 题目不够时二次拉题
function RunGameElement:getQuestionsAgain()
    CourseEnv.ServicesManager:GetObserverService():Fire("EVENT_ABCZONE_QUESTION_MANATER", {
        params = { { qType = 51, qCount = 60 } },
        callBack = function(questions)
            self.questions = questions["51"]
            -- self.miji:setQuestions(self.questions)
            g_Log("跑酷排位:二次拉取题目成功" .. table.dump(self.questions))
            self:answerQuestion()
        end
    })
end

-- 更改一下个题板读课文样式
function RunGameElement:changeNextQuestionUI(nextQuestionIndex)
    if not self.tableAllTipsTrans then
        self.tableAllTipsTrans  = {}
    end
    local nextQuestion = self.questions[nextQuestionIndex]
    local nextQuestionPanel = self.questionObj["题板_" .. self.curQuestionIndex]
    if nextQuestion and nextQuestionPanel then
        local kewen = nextQuestionPanel.transform:Find("Asset/Canvas/kewen")
        local juzi = nextQuestionPanel.transform:Find("Asset/Canvas/juzi")
        if juzi and kewen then
            if nextQuestion.style_id == 51 then
                juzi.gameObject:SetActive(true)
                kewen.gameObject:SetActive(false)
            elseif nextQuestion.style_id == 52 then
                kewen.gameObject:SetActive(self.lastRewardCount > 0)
                g_Log("跑酷休闲:changeNextQuestionUI  self.lastRewardCount" .. self.lastRewardCount)
                table.insert(self.tableAllTipsTrans,kewen) 
                juzi.gameObject:SetActive(false)
            end
        end
    end
end

function RunGameElement:answerQuestion()
    local answerCount = 0
    self.currentQuestionIndex = self.currentQuestionIndex + 1
    -- if self.currentQuestionIndex == 60 then
    --     g_Log("答题达到最后一题，重新拉题")
    --     self.currentQuestionIndex = 0
    --     self:getQuestionsAgain()
    --     return
    -- end
    -- self.miji:setCurrentQuestionIndex(self.currentQuestionIndex)
    -- self.miji:ChangeMiJIQuestion(false)
    -- self.miji:startAnswer(true)
    --开始调用纠音    --在每次要调用纠音的时候调用
    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND", { op = "StartAnswer" })
    local question = self.questions[self.currentQuestionIndex]
    self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
        status = 1,
        serviceType = "eva",
        noAutoReTry = true,
        showAwardType = 2,
        noChangeChat = not self.showChat,
        noLeadReading = true,
        reTryCount = 1,
        question = question,
        callBack = function(score, isFinal, isNoSpeaking,isPass)
            self.openMouseCount = self.openMouseCount + 1
            if isPass then
                g_Log("通过一关")
                -- 记录题板通过（每人每题板仅计一次）
                local panelIndex = self.curQuestionIndex
                if self.panelPassers == nil then
                    self.panelPassers = {}
                end
                if self.panelPassers[panelIndex] == nil then
                    self.panelPassers[panelIndex] = {}
                end
                if App and App.Uuid and self.panelPassers[panelIndex][App.Uuid] ~= true then
                    self.panelPassers[panelIndex][App.Uuid] = true
                end
                self.observerService:Fire("isCloseAudio",{isCloseAudio=false})
                -- self.curCollider.gameObject:SetActive(false)
                if  self.questionObj["题板_" .. self.curQuestionIndex] ~= nil then
                    self.questionObj["题板_" .. self.curQuestionIndex].gameObject:SetActive(false)
                    self.curQuestionIndex = self.curQuestionIndex + 1
                    self.doneQuestion = self.doneQuestion + 1
                    self:SendCustomMessage(Fsync_Client_KEY, { state = 2,UserId = App.Properties.UserId,doneQuestion = self.doneQuestion })
                    -- 设置下一个题板是否为读课文模式
                    self:changeNextQuestionUI(self.currentQuestionIndex + 1)
                end
                if self.doneQuestion >= self.questionNum then
                    -- self.miji:setLooping(true)
                    -- self.miji:LoopMiJi()
                else
                    -- self.miji:startAnswer(false)
                    --预报下一题
                    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
                    { op = "PlayNextQuestion" })
                end

                if self.isAnswer == true then
                    self.isAnswer = false
                end
            else
                g_Log("得分不够需要重试")
                answerCount = answerCount + 1
                if answerCount == 2 then
                    --预报下一题
                    self.observerService:Fire("EVENT_FOREIGN_TEACHER_VIDEO_PRESEEDING_COMMAND",
                    { op = "PlayNextQuestion" })
                    -- 设置下一个题板是否为读课文模式
                    self:changeNextQuestionUI(self.currentQuestionIndex + 2)
                    self:answerQuestion()
                end
            end
        end
    })
end

-- 调用App评分
function RunGameElement:appEvaluate()
    if self.appEvaluateFinish == nil then
        self.appEvaluateFinish = true
        -- APIBridge.RequestAsync("app.buss.appEvaluate.show", {})
    end
end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function RunGameElement:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function RunGameElement:LogicMapStartRecover()
    RunGameElement.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function RunGameElement:LogicMapEndRecover()
    RunGameElement.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function RunGameElement:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

--收到Trigger事件
function RunGameElement : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function RunGameElement : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function RunGameElement:Exit()
    g_Log("客户端:退出游戏消息")
    -- 退出兜底上报（若未上报）
    self:reportSpeakCountEnd()
    self:reportCheckpointPassesEnd()
    self:SendCustomMessage(Fsync_Client_KEY, { state = 3,UserId = App.Properties.UserId})
    RunGameElement.super.Exit(self)
end

return RunGameElement
 

