---
---  Author: 【彩滨滨】
---  AuthorID: 【246276】
---  CreateTime: 【2023-6-20 15:30:46】
--- 【FSync】
--- 【家园秘籍】

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")
local Util = require(MAIN_SCRIPTS_LOC .. "common/util")
local JiaYuanMiji = class("jiayuan_miji", WBElement)


---@param worldElement CS.Tal.framesync.WorldElement
function JiaYuanMiji:initialize(worldElement)
    JiaYuanMiji.super.initialize(self, worldElement)
end

function JiaYuanMiji:setVisElement(visElement)
    self.VisElement = visElement
    g_Log("初始化家园秘籍")
    self:initService()
    self:initConfig()
    self:initListener()
end

function JiaYuanMiji:initService()
    self.commonService = App:GetService("CommonService")
    self.observerService =  CourseEnv.ServicesManager:GetObserverService()
    self.joyService = CourseEnv.ServicesManager:GetJoystickService()
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
end

function JiaYuanMiji:initConfig()
    -- 家园秘籍
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/paokumiji/"
    local mijiPrefab = ResourcePathRoot .. "assets/Prefabs/jiayuanMiji.prefab"
    local beginAudiopath = ResourcePathRoot .. "arts/audios/listenPlease.mp3"

    ResourceManager:LoadGameObjectWithExName(mijiPrefab, function(go)
        self.mijiPrefab = GameObject.Instantiate(go)
        self.mijiPrefab.transform:SetParent(self.VisElement.gameObject.transform)
        self.mijiPrefab.transform.localPosition = Vector3.zero
        self.mijiPrefab.transform.localScale = Vector3.one
        self.mijiPrefab.transform.localRotation = Quaternion.identity
        self.contentText = self.mijiPrefab.transform:Find("background/content/contentText"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.contentText.text = ""
        self.chineseContentText = self.mijiPrefab.transform:Find("background/content/chineseText"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.chineseContentText.text = ""
        self.chineseContentRect = self.chineseContentText.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
        self.background = self.mijiPrefab.transform:Find("background")

        self.spaakNode  = self.background:Find("Teacher_bg/small_bg/shuohua")
        self.staticNode = self.background:Find("Teacher_bg/small_bg/static")
        self.yinbo = self.background:Find("Teacher_bg/yinbo_2")
        self.bookImage = self.background:Find("bookImage"):GetComponent(typeof(CS.UnityEngine.UI.Image))
        self.bookText = self.background:Find("content/bookText"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.bookText.text = ""
        self.mijiPrefab:SetActive(false)
    end)

    ResourceManager:LoadAudioClipWithExName(beginAudiopath, function(audioclip)
        self.pleaseListenAudio = audioclip
    end)

    -- 是否可用
    self.isEnable = false
    -- 题目数据
    self.questions = {}
    -- 当前答得第几道题
    self.currentQuestionIndex = 0
    -- 当前是否在答题
    self.isAnswering = false
end

function JiaYuanMiji:initListener()
    -- 拉取题目
    self.observerService:Fire("EVENT_ABCZONE_GET_ALL_QUESTION", {
        callback = function(questionList)
            g_Log("家园秘籍：收到所有题目")
            -- self.questions = questionList
            self.questions = questionList["51"]
        end
    })
end

function JiaYuanMiji:playNextQuestion()
    self.currentQuestionIndex = self.currentQuestionIndex + 1
    g_Log("家园秘籍", "+++", self.currentQuestionIndex)
    self:ChangeMiJIQuestion()
    self:playFirstAudio()
end

function JiaYuanMiji:ShowMIJI(isShow)
    if not self.mijiPrefab then
        g_LogError("家园秘籍预制体未加载")
    end

    self.isEnable = isShow
    self.mijiPrefab.gameObject:SetActive(isShow)

    -- 展示跑酷秘籍
    if isShow then
        g_Log("家园秘籍", "展示", self.currentQuestionIndex)
        -- self.currentQuestionIndex = 0
        -- self:playNextQuestion()
        -- if self.currentQuestionIndex == 0 then
        --     self.currentQuestionIndex = 1
        -- end
        self:GetUserReadVipInfo()
        self.currentQuestionIndex = CourseEnv.BaseBusinessManager:GetQuestionManager().questionTypeIndex["51"] + 1

        self:ChangeMiJIQuestion()
        self:playFirstAudio()
    else
        if not Util:IsNil(self.firstAudioSource) then
            self.firstAudioSource.volume = 0
            self.audioService:StopAudioSource(self.firstAudioSource)
            self.firstAudioSource = nil
        end
        if not Util:IsNil(self.questionAudioSource) then
            self.questionAudioSource.volume = 0
            self.audioService:StopAudioSource(self.questionAudioSource)
            self.questionAudioSource = nil
        end
    end
end

function JiaYuanMiji:ChangeMiJIQuestion()
    local question = self.questions[self.currentQuestionIndex]
    if question then
        local keyWord = question.word
        local indexArray = question.indexArray
        local text_en = ""
        local text = question.text_en
        if indexArray then
            if type(indexArray) == 'string' then
                indexArray = self.jsonService:decode(indexArray)
            end
            if indexArray and type(indexArray) == 'table' then
                text_en = self:GetKeyWordTextByIndex(text, indexArray)
            end
        end
        if (not text_en) or text_en == "" then
            text_en = self:GetKeyWordText(text, keyWord)
        end

        self.contentText.text = question.text_en -- "<sprite=0> "  .. tostring(text_en) 
        self.chineseContentText.text = question.text_cn

        -- self.commonService:DispatchNextFrame(function()
        --     if self.contentText.textInfo.lineCount > 1 then
        --         g_Log("家园秘籍", "多行")
        --         -- 设置文本高度
        --         self.contentText.gameObject.transform.sizeDelta = Vector2(self.contentText.gameObject.transform.sizeDelta.x, 72)
        --         -- UI设置中文文本距离顶部的距离
        --         self.chineseContentRect.anchoredPosition = Vector2(0, -120)
        --         -- 设置整体高度
        --         self.background.gameObject.transform.sizeDelta = Vector2(self.background.gameObject.transform.sizeDelta.x, 174)
        --     else
        --         g_Log("家园秘籍", "单行")
        --         self.contentText.gameObject.transform.sizeDelta = Vector2(self.contentText.gameObject.transform.sizeDelta.x, 38)
        --         self.chineseContentRect.anchoredPosition = Vector2(0, -86)
        --         self.background.gameObject.transform.sizeDelta = Vector2(self.background.gameObject.transform.sizeDelta.x, 140)
        --     end
        -- end)
    end
end

function JiaYuanMiji:GetKeyWordTextByIndex(text, index)
    ---根据index 下标数组，将下标范围内的文字变色
    if not text or not index then return text end
    local text = text
    local index = index
    local textSprits = {}
    local lastIndex = nil
    for i, v in ipairs(index) do
        local startIndex = v[1]
        local endIndex = v[2]

        if startIndex and endIndex then
            ---防止下标越界不合法
            if (startIndex > endIndex) or (lastIndex and lastIndex > startIndex) then
                return nil
            end
            local frontStr = ""
            if startIndex > 0 then
                if i == 1 then
                    frontStr = string.sub(text, 1, startIndex)
                else
                    frontStr = string.sub(text, lastIndex, startIndex)
                end
            end
            local middleStr = string.sub(text, startIndex + 1, endIndex + 1)
            middleStr = "<color=#00DEA9>" .. middleStr .. "</color>"
            table.insert(textSprits, frontStr)
            table.insert(textSprits, middleStr)
            local endStr = ""
            if endIndex + 2 <= #text and i == #index then
                endStr = string.sub(text, endIndex + 2, #text)
                table.insert(textSprits, endStr)
            else
                lastIndex = endIndex + 2
            end
        end
    end
    local text = ""
    for i, v in ipairs(textSprits) do
        text = text .. v
    end
    return text
end

-- 处理对应重点单词文字
function JiaYuanMiji:GetKeyWordText(text, word)
    if not text and not word then return "" end
    if not word or word == "" then return text end
    for keyWord in string.gmatch(word, "%w+") do
        local keyWordLower = keyWord:lower()
        local lowerText = text:lower()
        local startIndex, endIndex = string.find(lowerText, keyWordLower)
        if startIndex and endIndex then
            text = text:gsub('(%f[%a]' .. keyWord .. '[%p]*%f[^%a])', "<color=#00DEA9>" .. keyWord .. "</color>")
        end
    end
    -- 替换所有出现的关键词
    return text
end

---播放引导音频
function JiaYuanMiji:playFirstAudio()
    if self.isAnswering or not self.isEnable then
        return
    end

    if self.isPlayingFirstAudio == true then
        return
    end
    self.isPlayingFirstAudio = true

    if self.firstAudioSource then
        self.audioService:StopAudioSource(self.firstAudioSource)
        self.firstAudioSource = nil
    end

    if self.mijiPrefab.gameObject.activeSelf == false then
        self.isPlayingFirstAudio = false
        return
    end

    self.spaakNode.gameObject:SetActive(true)
    self.staticNode.gameObject:SetActive(false)
    self.yinbo.gameObject:SetActive(true)
    self.firstAudioSource = self.audioService:PlayClipOneShot(self.pleaseListenAudio, function()
        g_Log("家园秘籍", "引导播放完成")
        self.spaakNode.gameObject:SetActive(false)
        self.staticNode.gameObject:SetActive(true)
        self.yinbo.gameObject:SetActive(false)
        if self.mijiPrefab.gameObject.activeSelf == false then
            return
        end

        if self.isAnswering then
            self.isPlayingFirstAudio = false
            return
        end

        self.isPlayingFirstAudio = false

        self:playQuestionByIndex(self.currentQuestionIndex)
    end)
end

function JiaYuanMiji:playQuestionByIndex(index)
    if self.isPlayingFirstAudio then
        return
    end

    if self.isAnswering or not self.isEnable then
        return
    end

    if self.questionAudioSource then
        self.audioService:StopAudioSource(self.questionAudioSource)
        self.questionAudioSource = nil
    end

    if self.mijiPrefab.gameObject.activeSelf == false then
        return
    end

    local question = self.questions[index]
    local style_id = question.style_id
    local audio = ""
    if style_id == 51 then
        audio = question.audio
    else
        if question.stem then
            audio = question.stem.audio
        end
    end
    if audio == "" then
        return
    end
    self.audioService:GetMp3AudioFromGetUrl(audio, function(error)
        g_LogError("家园秘籍:" .. "音频获取失败")
    end, function(clip)
        if self.mijiPrefab.gameObject.activeSelf == false then
            return
        end
        if self.isPlayingFirstAudio then
            return
        end

        if self.isAnswering then
            return
        end

        if index == self.currentQuestionIndex then
            self.questionAudioSource = self.audioService:PlayClipOneShot(clip, function()
                -- if self.isPlayingFirstAudio then
                --     return
                -- end

                -- if self.isAnswering then
                --     return
                -- end

                -- if index == self.currentQuestionIndex then
                --     -- 延时3S
                --     self.commonService:DispatchAfter(3,function()
                --         if self.isPlayingFirstAudio then
                --             return
                --         end

                --         if self.isAnswering then
                --             return
                --         end

                --         if index == self.currentQuestionIndex then
                --             self:playFirstAudio()
                --         end
                --     end)
                -- end
            end)
        end
    end)
end

-- 是否开始答题
function JiaYuanMiji:startAnswer(isAnswer)
    self.isAnswering = isAnswer
    if isAnswer then
        if not Util:IsNil(self.firstAudioSource) then
            self.firstAudioSource.volume = 0
            self.audioService:StopAudioSource(self.firstAudioSource)
            self.firstAudioSource = nil
        end
        if not Util:IsNil(self.questionAudioSource) then
            self.questionAudioSource.volume = 0
            self.audioService:StopAudioSource(self.questionAudioSource)
            self.questionAudioSource = nil
        end
    else
        self.isAnswering = isAnswer
        self:playFirstAudio()
    end
end

function JiaYuanMiji:GetUserReadVipInfo(callback)

    if App.modPlatform ~= MOD_PLATFORM.ABCZone then
        return
    end

    local success = function(resp)
        if resp and resp ~= "" then
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.code == 0 then
                g_Log("家园下一题：背课文-查询用户模式用到的状态信息成功！！", table.dump(msg.data))
                if type(msg.data) == "table" then
                    self.vipData = msg.data
                    if self.vipData then
                        self.book_cover = self.vipData.book_cover or ""
                        self.article_info = self.vipData.article_info or {}
                        if self.book_cover ~= "" then
                            local url = self.book_cover .. "?x-oss-process=image/resize,w_312,h_440/quality,q_80"
                            self.httpService:LoadNetWorkTexture(url, function(sprite)
                                g_Log("设置图片", url)
                                self.bookImage.sprite = sprite
                            end, 1)
                        end

                        self.bookText.text = self.vipData.book_name .. self.vipData.level_name
                    end
                    return
                end
            end
        end
        g_Log("家园下一题：背课文-查询用户模式用到的状态信息失败！！")
    end

    local params = {
        mode_type = 1
    }
    self:HttpRequest("/v3/book-article/get-mode-status", params, success, function(res)
        g_Log("家园下一题：背课文-查询用户模式用到的状态信息异常！！ 重试")
    end)
end

function JiaYuanMiji:HttpRequest(request, params, success, fail)
    local url = "https://app.chuangjing.com/abc-api" .. request
    if App.IsStudioClient then
        url = "https://yapi.xesv5.com/mock/2041" .. request
        self.httpService:PostForm(url, params, {}, success, fail)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = params
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                success(resp)
            else
                fail(res)
            end
        end)
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function JiaYuanMiji:ReceiveMessage(key, value, isResume)

end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function JiaYuanMiji:SendCustomMessage(key, body)
    self:SendMessage(key,body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function JiaYuanMiji:SelfAvatarCreated(avatar)
    
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function JiaYuanMiji:SelfAvatarPrefabLoaded(avatar)
    
end


-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function JiaYuanMiji:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function JiaYuanMiji:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function JiaYuanMiji:LogicMapStartRecover()
    JiaYuanMiji.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function JiaYuanMiji:LogicMapEndRecover()
    JiaYuanMiji.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function JiaYuanMiji:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

--收到Trigger事件
function JiaYuanMiji : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function JiaYuanMiji : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function JiaYuanMiji:Exit()
    JiaYuanMiji.super.Exit(self)
end

return JiaYuanMiji
 

