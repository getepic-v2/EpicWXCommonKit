---
---  Author: 【彩滨滨】
---  AuthorID: 【246276】
---  CreateTime: 【2023-6-20 15:30:46】
--- 【FSync】
--- 【跑酷游戏客户端】
--- 客户端协议定义：
--- state:1 玩家加入
--- state:2 玩家答完一道题
--- state:3 玩家退出
------ 服务端协议定义：
--- state:1 10道题目，10种随机地形序列，开启3倒计时
--- state:2 服务端通知自己等待超过60秒
--- state:3 
--- state:4 刷新实时排行榜
--- state:5 一名玩家已完成，所有玩家开始15秒倒计时
--- state:6 游戏结束,并推送排行榜
--- state:7 n名玩家加入游戏
--- state:8 1名玩家提前完成游戏
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local RunGameElement = class("rungame_comlogic", WBElement)
local Skill = require("gameplay/skill")
local Faction = require("gameplay/faction")
local Fsync_Server_KEY = "runGame_server_key"
local Fsync_Client_KEY = "runGame_client_key"

---@param worldElement CS.Tal.framesync.WorldElement
function RunGameElement:initialize(worldElement)
    RunGameElement.super.initialize(self, worldElement)

    g_Log("初始化跑酷公共逻辑")
    -- 隐藏按住说话
    CourseEnv.ServicesManager:GetUIService():SetHidenVoiceBtnWithID()
    APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
        open = false,
        isShow = false,
        topSafeArea = 0
    }, function()

    end)
    -- 订阅KEY消息
    self:SubscribeMsgKey(Fsync_Server_KEY)
    self:SubscribeMsgKey(Fsync_Server_KEY .. "1")
    self:SubscribeMsgKey(Fsync_Server_KEY .. "3")
    self:SubscribeMsgKey("activateRoom")
    -- 添加初始化完成埋点
    self:reportLog("RunGameInitFinish")
    -- 延迟1s后
    self.commonService:DispatchAfter(1, function()
        self:answerQuestion()
        --显示能量条
        --self.nengliang.gameObject:SetActive(true)
        self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_INIT_SLIDER", {
            notShow = false,
            numerator = self.initEnergy,
            denominator = self.maxEnergy
        })
        self.currentEnergy = self.initEnergy
    end)
end

function RunGameElement:setVisElement(parent, VisElement)
    self.parent = parent
    self.VisElement = VisElement
    self:initService()
    self:initConfig()
    self:initListener()
    self:InitView()
    g_Log("完成初始化操作" .. self.VisElement.name)
end

function RunGameElement:initService()
    self.commonService = App:GetService("CommonService")
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    self.joyService = CourseEnv.ServicesManager:GetJoystickService()
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    self.configService = CourseEnv.ServicesManager:GetConfigService()
end

function RunGameElement:initConfig()
    self.level_array_string = self.configService:GetConfigValueByConfigKey(self.VisElement, "level_array_string")
    self.workSpace = CS.UnityEngine.GameObject.Find("Workspace")
    self.level_array_obj = self.workSpace.transform:FindInAll(self.level_array_string)
    self.endAudio = self.configService:GetAssetByConfigKey(self.VisElement, "EndAudio", true)
    self.finishAudio = self.configService:GetAssetByConfigKey(self.VisElement, "FinishAudio", true)
    self.finalCircleAudio = self.configService:GetAssetByConfigKey(self.VisElement, "FinalCircle", true)
    self.EndLineAudio = self.configService:GetAssetByConfigKey(self.VisElement, "EndLineAudio", true)
    self.countDownAudio = self.configService:GetAssetByConfigKey(self.VisElement, "count_down_audio", true)
    self.questionNum = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "questionNum"))
    self.randomTerr = self.configService:GetConfigValueByConfigKey(self.VisElement, "randomTerr")
    self.question_array_string = self.configService:GetConfigValueByConfigKey(self.VisElement,
        "questionObj_array_string")
    self.startImage = self.configService:GetAssetByConfigKey(self.VisElement, "startImage", true)
    -- 获取能量条满音频
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/paokuRes/"
    ResourceManager:LoadAudioClipWithExName(ResourcePathRoot .. "audios/energyFullAudio.mp3", function(audioclip)
        self.energyFullAudio = audioclip
    end)

    -- 加速倍数
    self.speedFactor = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "speedFactor"))
    -- 加速时长
    self.speedTime = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "speedTime"))
    -- 加速技能消耗
    self.speedCost = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "speedCost"))
    -- 单次开口通过加分
    self.singleAdd = tonumber(self.configService:GetConfigValueByConfigKey(self.VisElement, "singleAdd"))
    -- 是否是休闲赛模式
    self.isCasual = self.configService:GetConfigValueByConfigKey(self.VisElement, "isCasual")

    self.setId = 1
    self.url = "https://app.chuangjing.com/next-api"
    if App.Info.configMap.env ~= "online" then
        self.url = "https://app-test.chuangjing.com/next-api"
    end
    local fps = App.Info.configMap.frame_num
    if fps == nil then
        fps = 15
    end
    CourseEnv.ServicesManager.Gate:SetSendFPS(fps)
    -- 开始倒计时相关
    self.isRun = false
    self.questionObj = {}
    self.curQuestionIndex = 1
    -- 结束倒计时先关
    self.yellowNumImage = {}
    for i = 0, 9 do
        ---@type CS.UnityEngine.Sprite
        self.yellowNumImage[i] = self.configService:GetAssetByConfigKey(self.VisElement, "num_" .. i, true)
    end
    self.audio = self.configService:GetAssetByConfigKey(self.VisElement, "countDownAudio")
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(false)
    local strCircle = self.parent.configHandler:GetStringByConfigKey("circleCount")
    self.circleCount = tonumber(strCircle)
    -- 起点
    local objStart = self.parent.configHandler:GetGameObjectByConfigKey("StartPoint")
    if not objStart then
        g_LogError("找不到起点")
    end
    self.transStartPoint = objStart.transform
    -- 终点
    local objEnd = self.parent.configHandler:GetGameObjectByConfigKey("EndPoint")
    if not objEnd then
        g_LogError("找不到终点")
    end

    local handler = self.parent.configHandler:GetListSubConfigHandler("SkillList")
    self.tableSkills = {}
    for k, v in pairs(handler) do
        local skillId = v:GetStringByConfigKey("Skill")
        local rate = tonumber(v:GetStringByConfigKey("Rate"))
        local name = v:GetStringByConfigKey("SkillName")
        self.tableSkills[skillId] = {
            rate = rate,
            name = name
        }
    end
    self.transEndPoint = objEnd.transform
    self.transEndPointAsset = self.transEndPoint:Find("Asset")
    self.transEndPointAsset.gameObject:SetActive(false)
    self.hasStartPlay = false
    -- 是否展示过段位结算页
    self.isShowRankPanel = false
    -- 开口次数
    self.openMouseCount = 0
    self.doneQuestion = 0
    self.isInitialized = false
    self.state = 0 -- 3 开始结算 4 结算完自己 5提前结算 6 最终结算完
    -- 游戏已经开始
    self.gameStart = false
    -- 当前人物前进最大距离
    self.maxDistance = 0
    self.lastDistance = 0
    self.lastNextDistance = 0
    -- 查找起始点
    self.startPos = CS.UnityEngine.GameObject.Find("SpawnServices")
    -- 当前能量值
    self.currentEnergy = 0
    self.initEnergy = 75
    self.maxEnergy = 150
    -- 当前复活点
    -- 游戏开始时间
    self.startTime = os.time()

    self.finishCircleNum = 0
    self.checkPointNum = 0

    self.backFrame = 0

end
function RunGameElement:Reborn()
    if not self.canReborn then
        return
    end
    local trans = self.transStartPoint:Find("碰撞检测")
    if self.transCurCheckPoint then
        trans = self.transCurCheckPoint
    end
    if self.selfAvatar then
        self.selfAvatar:TeleportAndNotice(trans.position, true)
        g_Log("客户端:掉落，传送回上一个点")
    end
    self.observerService:Fire("isCloseAudio", {
        isCloseAudio = false
    })
end
function RunGameElement:initListener()
    -- 监听到底部答题面板高度变化
    self.observerService:Watch("Bottom_Answer_Panel_Size",function(key, value)
        if value[0] and value[0].height then
            g_Log("冲刺跑酷:底部答题面板高度变化" .. value[0].height)
            self.commonService:Yield(
                self.commonService:WaitUntil(function()
                    return self.nengliang ~= nil
                end)
            )
            self.nengliang.anchoredPosition = Vector2(self.nengliang.anchoredPosition.x, value[0].height)
        end
    end)
    -- Skill:OnUse(function(data, isSync)
    --     local name = data.skillName
    --     if name == "Parkour_Sprint" then
    --         if self.currentEnergy < 100 then
    --             CourseEnv.ServicesManager:GetUIService().commonMenu:ShowToast("开口充能后才能冲刺呀！", 2)
    --         else
    --             -- 点击加速按钮
    --             self:Print("点击加速按钮,开始加速")
    --             self.remainSpeedTime = self.speedTime
    --             self:AddEnergy(-self.speedCost)
    --         end
    --     else
    --     end
    -- end)
    -- 添加中途退出埋点上报
    self.observerService:Watch("quitVerify", function()
        local param = {}
        param["modName"] = App.modName
        param["liveId"] = App.Info.liveId
        param["userId"] = App.Info.userId
        param["openMouseCount"] = self.openMouseCount
        param["doneQuestion"] = self.doneQuestion
        param["questionNum"] = self.questionNum
        param["eventId"] = "GameQuitMidway"
        param["eventtype"] = "GameQuitMidway"
        param["time"] = os.time() - self.startTime
        g_LogError("跑酷:中途退出上报" .. table.dump(param))
        APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
    end)

    self.observerService:Watch("TP2LastPoint", function()
        self:Reborn()
    end)
    self.observerService:Watch("startSettle", function()
        g_Log("客户端:触发退出逻辑")
        -- 未结算
        if self.state < 3 then
            local reportData = {}
            reportData.setId = self.setId
            reportData.rank = 8
            reportData.score = 0
            reportData.award = 0
            reportData.is_run = true
            reportData.isFailed = true
            self.parent:Trigger("startRankPanel")
            if self.isShowRankPanel == false then
                self.isShowRankPanel = true
                self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST", reportData)
            end
        else
            -- 已经结算
            self.parent:Trigger("startRankPanel")
            if self.isShowRankPanel == false then
                self.isShowRankPanel = true
                self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST", {})
            end
        end
        self.state = 5
        self:EndCountDownEnd()
        self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
            status = 2
        })
        self.commonService:DispatchAfter(3, function()
            self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                status = 2
            })
        end)
    end)
    local box = self.transEndPoint:Find("碰撞检测")
    -- 添加到达终点监听
    CourseEnv.ServicesManager:GetColliderService():RegisterColliderEnterListener(box.gameObject, function(other)
        if other.name == self.selfAvatar.VisElement.gameObject.name then
            self:Print("触碰终点")
            if self.hasFinished then
                return
            end
            if not self.checkPointNum or not self.maxCheckPointNum then
                return
            end
            if self.checkPointNum < self.maxCheckPointNum then
                self:Print("非法到达终点，没有碰到最后一个检查点" .. " self.checkPointNum = " ..
                               tostring(self.checkPointNum) .. " self.maxCheckPointNum = " ..
                               tostring(self.maxCheckPointNum))
                return
            end
            self.checkPointNum = 0
            self.finishCircleNum = self.finishCircleNum + 1

            self:FinishCircle()
            -- self:closeAnswerQuestion()
        end
    end)

    self.observerService:Watch("Reach_Check_Point", function(key, args)
        local data = args[0]
        if self.checkPointNum > data.checkPointNum then
            -- 逆行
            return
        end
        if self.checkPointNum + 1 == data.checkPointNum then
            self.checkPointNum = data.checkPointNum
            self.transCurCheckPoint = data.transCheckPoint
        end
        self.nextCheckPoint = data.nextCheckPoint
        self.maxCheckPointNum = data.maxNum
        self:SendDistance()
    end)
    self.observerService:Watch("Retrograde_Check_Point", function(key, args)
        if not self.gameStart then
            return
        end
        if self.hasFinished then
            return
        end
        self:Reborn()
    end)
    self.observerService:Watch("Get_Random_Prop", function(key, args)
        local random = math.random(0, 100)
        local skillId = ""
        local name = ""
        for k, v in pairs(self.tableSkills) do
            if v.rate >= random then
                skillId = k
                name = v.name
                break
            else
                random = random - v.rate
            end
        end
        if skillId == "" then
            g_LogError("随机道具出错")
            return
        end
        self:Print("获得技能 id = " .. skillId)
        Skill:Use(App.Uuid, skillId .. "_ButtonExchange")
        self.txtPropName.text = name

        self.transToast.gameObject:SetActive(true)
        self.layoutToast.childAlignment = 1
        self.commonService:DispatchNextFrame(function()
            self.layoutToast.childAlignment = 4
        end)
        if self.toastTask then
            self.commonService:CancelDispatch(self.toastTask)
            self.toastTask = nil
        end
        self.toastTask = self.commonService:DispatchAfter(3, function()
            self.transToast.gameObject:SetActive(false)
            if self.toastTask then
                self.toastTask = nil
            end
        end)
    end)

end
function RunGameElement:FinishCircle()

    if self.finishCircleNum >= self.circleCount then
        self:Print("完赛")
        -- TODO:展示完赛UI + 播放音效
        if self.hasFinished == true then
            return
        end
        self:SendCustomMessage(Fsync_Client_KEY, {
            state = 4,
            UserId = App.Properties.UserId,
            time = self.usedTime
        })
        self.hasFinished = true
        self.observerService:Fire("game_over_run_game_circle")
        self.observerService:Fire("isWatchBattle", {
            isWatchBattle = true
        })
        if self.EndLineAudio then
            self.audioService:PlayClipOneShot(self.EndLineAudio)
        end
        self.transEndPoint.gameObject:SetActive(false)
    else
        self:StartCircle(self.finishCircleNum + 1)
        -- 重新记录检查点
        self.observerService:Fire("Clear_Check_Point")
    end
    self:SendDistance()
end

function RunGameElement:reportLog(eventId)
    local param = {}
    param["modName"] = App.modName
    param["liveId"] = App.Info.liveId
    param["userId"] = App.Info.userId
    param["eventId"] = eventId
    param["eventtype"] = eventId
    APIBridge.RequestAsync('sys.bizLogStatistics', param, nil)
end
function RunGameElement:Print(...)
    g_Log("循环跑酷== ", ...)
end
function RunGameElement:InitView()
    -- 隐藏按钮
    -- CourseEnv.ServicesManager:GetUIService():hidenCommonMenu()
    CourseEnv.ServicesManager:GetUIService():SetHidenFollowBtnWithID()

    if not App.IsStudioClient then
        -- self.level_array_obj:Find("复活点").gameObject:SetActive(false)
    end

    -- 添加调试快捷按钮
    if App:IsDebug() == false then
        self.VisElement.transform:Find("屏幕画布/传送").gameObject:SetActive(false)
    else
        self.VisElement.transform:Find("屏幕画布/传送").gameObject:SetActive(false)
    end
    -- 等待人数
    self.loading = self.VisElement.transform:Find("屏幕画布/背景").gameObject
    self.loading:SetActive(false)
    -- 提醒关闭弹窗
    self.root = self.VisElement.gameObject
    self.rootTrans = self.root.transform
    self.tipDialog = self.rootTrans:FindChildWithName("跑酷超时提醒弹窗")
    self.dialogTitle = self.tipDialog:FindChildWithName("Title")
    self.dialogTitleTmp = self.dialogTitle:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogTitleTmp.text = ""
    self.dialogConfirm = self.tipDialog:FindChildWithName("Confirm")
    self.dialogConfirmBtn = self.dialogConfirm:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.dialogConfirmText = self.dialogConfirm:FindChildWithName("text")
    self.dialogConfirmTmp = self.dialogConfirmText:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogConfirmTmp.text = "确定"
    self.dialogConfirmTmp.color = CS.UnityEngine.Color(1, 1, 1, 1)
    self.dialogContent = self.tipDialog:FindChildWithName("Content")
    self.dialogContentTmp = self.dialogContent:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.dialogContentTmp.text = "小伙伴失联了哦，退回到首页重新开始吧~"
    self.commonService:AddEventListener(self.dialogConfirmBtn, "onClick", function()
        self.tipDialog.gameObject:SetActive(false)
        App:GameReturn()
    end)
    self.tipDialog.gameObject:SetActive(false)
    -- 结束页面
    self.endPanel = self.VisElement.transform:Find("屏幕画布/结束").gameObject
    self.endPanel:SetActive(false)
    self.endPanelexitBtn =
        self.VisElement.transform:Find("屏幕画布/结束/结束页面/退出按钮").gameObject:GetComponent(typeof(
            CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.endPanelexitBtn, "onClick", function()
        App:GameReturn()
    end)
    if self.isCasual == "True" then
        self.endPanelexitBtn.gameObject:SetActive(true)
    end
    -- 开始页面
    self.startPanel = self.VisElement.transform:Find("屏幕画布/开始页面").gameObject
    self.startPanel:GetComponentsInChildren(typeof(CS.UnityEngine.UI.Image))[0].sprite = self.startImage
    self.startPanel:SetActive(false)
    -- 观战按钮
    self.obBtn = self.VisElement.transform:Find("屏幕画布/观战").gameObject
    self.obBtn:SetActive(false)

    -- 获取能量条UI
    self.nengliangRoot = self.VisElement.transform:Find("新跑酷UI/Asset")
    local canvas = self.nengliangRoot.gameObject:GetComponent(typeof(CS.UnityEngine.Canvas))
    canvas.sortingOrder = 1000

    self.nengliang = self.nengliangRoot:Find("nengliang")
    self.nengliang.localScale = CS.UnityEngine.Vector3(0.7, 0.7, 1)

    local rectTransform = self.nengliang:GetComponent(typeof(CS.UnityEngine.RectTransform))
    rectTransform.pivot = Vector2(0.5, 0);
    rectTransform.anchorMin = Vector2(0.5, 0);
    rectTransform.anchorMax = Vector2(0.5, 0);
    rectTransform.anchoredPosition = Vector2(0, 200);

    self.nengliangtiao = self.nengliang:Find("nengliangtiao")
    self.nengliangtiaoRect = self.nengliangtiao:GetComponent(typeof(CS.UnityEngine.RectTransform))
    self.nengliangzhi = self.nengliang:Find("nengliangzhi")

    self.nengliangzhi:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition = Vector2(169.1, 30.2)

    self.nengliangText1 = self.nengliang:Find("text1").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
    self.nengliangText2 = self.nengliang:Find("text2").gameObject:GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

    self.nengliangtiaoAnim = self.nengliang:Find("mask/anim")
    self.nengliangtiaoAim = self.nengliang:Find("nengliangtiao/aim")

    self.nengliang.gameObject:SetActive(false)
    -- 冲刺按钮UI
    self.speedBtnRoot = self.nengliangRoot:Find("speedBtn")
    self.speedBtnRoot.gameObject:SetActive(false)
    self.speedBtnDisable = self.speedBtnRoot:Find("disable")
    self.speedBtnDisable.gameObject:SetActive(true)
    self.speedBtnNormal = self.speedBtnRoot:Find("normal")
    self.speedBtnNormal.gameObject:SetActive(false)
    self.speedBtn = self.speedBtnRoot:Find("btn").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.speedBtn.gameObject:SetActive(false)
    -- 添加按钮事件
    self.commonService:AddEventListener(self.speedBtn, "onClick", function()
        if self.currentEnergy < 100 then
            CourseEnv.ServicesManager:GetUIService().commonMenu:ShowToast("开口充能后才能冲刺呀！", 2)
        else
            -- 点击加速按钮
            g_LogError("点击加速按钮,开始加速")
            self.remainSpeedTime = self.speedTime
            self:AddEnergy(-self.speedCost)
        end
    end)
    -- self:AddEnergy(-100)
    -- self:AddEnergy(75)

    self:InitUI(function()
        self.transCanvas = self.ui.transform:Find("Canvas")
        self.transTimer = self.transCanvas:Find("Timer")
        self.txtTimeMin = self.transTimer:Find("txtTimeMin"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.txtTimeSeconde = self.transTimer:Find("txtTimeSecond"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.txtCircleNum1 = self.transTimer:Find("txtTime (1)"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.txtCircleNum2 = self.transTimer:Find("txtTime (2)"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self:SetTime(0, 0)
        self:SetCircle(1, self.circleCount)
        --- 第几圈
        self.transProgress = self.transCanvas:Find("progress")
        self.transFirstCircle = self.transProgress:Find("FirstRound")
        self.transFirstCircle.gameObject:SetActive(false)
        self.transSecondCircle = self.transProgress:Find("SecondRound")
        self.transSecondCircle.gameObject:SetActive(false)
        self.transFinalCircle = self.transProgress:Find("LastRound")
        self.transFinalCircle.gameObject:SetActive(false)
        self.transProgress.gameObject:SetActive(true)
        --- 逆行提示
        self.transJingshi = self.transCanvas:Find("jingshi")
        self.transJingshi.gameObject:SetActive(false)
        --- 获得道具提示
        self.transToast = self.transCanvas:Find("toast")
        self.transToast.gameObject:SetActive(false)
        self.layoutToast = self.transToast:GetComponent(typeof(CS.UnityEngine.UI.HorizontalLayoutGroup))
        self.txtGetProp = self.transToast:Find("Text (TMP)"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))
        self.txtGetProp.text = "获得道具"
        self.txtPropName = self.transToast:Find("Text (TMP) (1)"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

    end)
end
function RunGameElement:SetTime(min, sec)
    local mten = math.floor(min / 10)
    local m = min % 10
    self.txtTimeMin.text = "<sprite=" .. tostring(mten + 10) .. ">" .. "<sprite=" .. tostring(m + 10) .. ">"
    local sTen = math.floor(sec / 10)
    local s = sec % 10
    self.txtTimeSeconde.text = "<sprite=" .. tostring(sTen + 10) .. ">" .. "<sprite=" .. tostring(s + 10) .. ">"
end
function RunGameElement:SetCircle(c1, c2)
    self.txtCircleNum1.text = "<sprite=" .. tostring(c1 + 10) .. ">"
    self.txtCircleNum2.text = "<sprite=" .. tostring(c2) .. ">"
end
function RunGameElement:InitUI(cb)
    -- 跑酷秘籍
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/runGameCircle/"
    local path = ResourcePathRoot .. "prefab/RunGameCircle.prefab"
    ResourceManager:LoadGameObjectWithExName(path, function(go)
        self.ui = GameObject.Instantiate(go)
        self.ui.transform:SetParent(self.VisElement.gameObject.transform)
        self.ui.transform.localPosition = Vector3.zero
        self.ui.transform.localScale = Vector3.one
        self.ui.transform.localRotation = Quaternion.identity
        if cb then
            cb()
        end
    end)

end

function RunGameElement:GetRecoverPosition()
    for i = 1, 10 do
        -- body
    end

    -- 获取self.level_array_obj的所有子节点
    local children = self.level_array_obj:GetComponentsInChildren(typeof(CS.UnityEngine.Transform))
    for i = 0, children.Length - 1 do
        local child = children[i]
        local pos = child.position
        local startPos = self.startPos.transform.position
        local distance = Vector3.Distance(pos, startPos)

    end
end

-- 开始倒计时开始
function RunGameElement:StartCountStart()
    if self.isRun then
        return
    end
    self:closeAnswerQuestion()
    self.isRun = true
    self:Clear()
    self.countDownCanvas = self.VisElement.gameObject.transform:Find("倒计时UI/Asset/CountDownCanvas")
    self.effect = self.countDownCanvas:Find("countdown_321_go")
    self.effect.gameObject:SetActive(true)
    if self.finishAudio then
        self.audioService:PlayClipOneShot(self.countDownAudio)
    else
        g_LogError("开始倒计时音频未配置")
    end

    -- 倒计时播放完后开始赛车
    self.seq = DOTween:Sequence()
    self.seq:AppendInterval(4)
    self.seq:AppendCallback(function()
        self.effect.gameObject:SetActive(false)
        self:Clear()
        self.isRun = false
        self:StartCountDownEnd()
    end)
end

-- 开始倒计时结束
function RunGameElement:StartCountDownEnd()
    g_Log("客户端:倒计时完成，正式开始游戏")
    self.parent:Trigger("CountDownEnd")
    self.gameStart = true
    self.canReborn = true
    -- 开始游戏，正式开始持续答题
    self:answerQuestion()
    -- 显示能量条
    -- self.nengliang.gameObject:SetActive(true)
    -- self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_INIT_SLIDER", {
    --     notShow = false,
    --     numerator = self.initEnergy,
    --     denominator = self.maxEnergy
    -- })
    -- self.currentEnergy = self.initEnergy
    -- 第一圈
    self:StartCircle(1)
    Faction:Matched({
        ["循环跑酷"] = self.allAvatar
    })
    -- Skill:Use(App.Uuid, "Parkour_Sprint_ButtonExchange")
    self.transStartPoint.gameObject:SetActive(false)
end

function RunGameElement:Clear()
    if self.seq then
        self.seq:Kill()
        self.seq = nil
    end
end

-- 结束倒计时开始
function RunGameElement:EndCountDownStart(countDownNum)
    if countDownNum == 10 then
        if self.hasStartPlay == false then
            self.hasStartPlay = true
            if self.audio then
                self.audioSource = self.audioService:PlayClipOneShot(self.audio)
            end
            APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
                open = false,
                isShow = false,
                topSafeArea = 0
            }, function()

            end)
            -- 隐藏按住说话按钮
            CourseEnv.ServicesManager:GetUIService():SetHidenVoiceBtnWithID()
        end
    end
    self.countDown = countDownNum
    g_Log("客户端:开始结束前倒计时" .. self.countDown)
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(true)
    local num1 = math.floor(self.countDown / 10)
    local num2 = self.countDown % 10
    self.VisElement.transform:Find("屏幕画布/背景图片/数字3"):GetComponent(typeof(CS.UnityEngine.UI.Image))
        .sprite = self.yellowNumImage[num1]
    self.VisElement.transform:Find("屏幕画布/背景图片/数字4"):GetComponent(typeof(CS.UnityEngine.UI.Image))
        .sprite = self.yellowNumImage[num2]
end

-- 结束倒计时结束
function RunGameElement:EndCountDownEnd()
    g_Log("客户端:结束结束前倒计时")
    self.VisElement.transform:Find("屏幕画布/背景图片").gameObject:SetActive(false)
    if self.audioSource then
        self.audioService:StopAudioClip(self.audioSource)
    end
    self.gameStart = false
    self.observerService:Fire("isWatchBattle", {
        isWatchBattle = true
    })
end

function RunGameElement:updateWaitingNum(num, totalNum)
    if self.loading then
        self.loading.transform:Find("标题"):GetComponent(typeof(CS.UnityEngine.UI.Text)).text =
            "等待好友加入挑战 " .. num .. "/" .. totalNum
        self.loading.transform:Find("正文"):GetComponent(typeof(CS.UnityEngine.UI.Text)).text = num ..
                                                                                                      "个小伙伴，已经进入挑战啦~"
    end
end

function RunGameElement:uploadCostTL()
    local totalUrl = self.url .. "/v3/user/power/cost"
    local param = {
        game_id = 7
    }

    APIBridge.RequestAsync('api.httpclient.request', {
        ["url"] = totalUrl,
        ["headers"] = {
            ["Content-Type"] = "application/json"
        },
        ["data"] = param
    }, function(res)
        if res ~= nil and res.responseString ~= nil and res.isSuccessed then
            local resp = res.responseString
            local msg = nil
            if type(resp) == "string" then
                msg = self.jsonService:decode(resp)
            end
            if msg and msg.msg == "success" then
                if msg.code == 0 then
                    local data = msg.data
                    if data then
                        g_Log("上报自己消耗体力成功")
                    end
                end
            else
                g_Log("上报自己消耗体力失败-")
            end
        else
            g_Log("客户端:上报消耗体力失败")
        end
    end)
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function RunGameElement:ReceiveMessage(key, value, isResume)

    if key == Fsync_Server_KEY or key == Fsync_Server_KEY .. "1" or key == Fsync_Server_KEY .. "3" then
        for key, msg in pairs(value) do
            local lastMsg = msg
            local status = CourseEnv.ServicesManager:GetJsonService():decode(lastMsg)
            if status and status.state then
                if status.state == 1 then
                    if self.isInitialized == false then
                        -- 添加游戏开局埋点
                        self:reportLog("RunGameStart")
                        self.startTime = os.time()
                        self.url = status.Url
                        self.setId = status.setId
                        self:uploadCostTL()
                        -- 取消展示人数
                        if self.loading then
                            self.loading:SetActive(false)
                        end
                        -- 取消开始页面
                        if self.startPanel then
                            self.startPanel:SetActive(true)
                            self.commonService:DispatchAfter(3, function()
                                self.startPanel:SetActive(false)
                                self:StartCountStart()
                            end)
                        end

                        self.commonService:StartCoroutine(function()
                            self.commonService:Yield(self.commonService:WaitUntil(function()
                                return self.selfAvatar ~= nil
                            end))

                            self.parent:Trigger("runGameStart")
                        end)

                        self.isInitialized = true
                    end
                elseif status.state == 2 then
                    CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
                    self.tipDialog.gameObject:SetActive(true)
                elseif status.state == 3 then
                    if self.randomTerr == "True" then
                        g_Log("客户端:收到服务端随机地形序列" .. "random-" .. table.dump(status.random))
                        self:build(status.random)
                    end
                elseif status.state == 4 then
                    self.observerService:Fire("RefleshRankUI", status.rank)
                elseif status.state == 5 then
                    if self.state ~= 5 and status.countDownNum >= 0 then
                        self:EndCountDownStart(status.countDownNum)
                    end
                elseif status.state == 6 then
                    self:EndCountDownEnd()
                    self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                        status = 2
                    })
                    self.commonService:DispatchAfter(3, function()
                        self.observerService:Fire("EVENT_BUSINESS_PROP_ANSWER_QUESTION", {
                            status = 2
                        })
                    end)
                    CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
                    self:closeAnswerQuestion()

                    if self.isCasual == "True" then
                        if self.state < 3 then
                            local gameResultData = status.totalScores
                            gameResultData.useTime = 21474836473
                            gameResultData.gameId = status.totalScores.gameId
                            gameResultData.petExp = self.doneQuestion
                            gameResultData.autoClose = false
                            for _, value in pairs(status.totalScores.rankList) do
                                if value.userId == App.Uuid then
                                    gameResultData.useTime = value.score
                                    gameResultData.setId = self.setId
                                    gameResultData.score = value.score
                                    gameResultData.rank = value.rank
                                    gameResultData.award = value.cheese
                                    gameResultData.isFinish = value.isFinish
                                    break
                                end
                            end
                            gameResultData.clickCloseCallBack = function()
                                App:GameReturn()
                            end
                            g_Log("玩家答题时间-" .. gameResultData.useTime .. "秒")
                            gameResultData.rankListType = 1
                            gameResultData.titleType = 1
                            gameResultData.contentType = 1
                            gameResultData.closeBtnType = 2
                            local passRate = 0
                            if self.openMouseCount > 0 then
                                passRate = self.doneQuestion / self.openMouseCount
                            end

                            if passRate >= 0 and passRate <= 1 then
                                gameResultData.passRate = passRate
                            end
                            gameResultData.rankList = nil
                            self.observerService:Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)
                            if self.endAudio then
                                self.audioService:PlayClipOneShot(self.endAudio, function()

                                end)
                            end
                        else
                            g_Log("客户端:已经上报过结果，游戏已经结束")
                            -- 延时1秒
                            -- App:GetService("CommonService"):DispatchAfter(2, function()
                            --     self.observerService:Fire("HIDE_MINI_GAME_RESULT_PANEL")
                            --     self.endPanel:SetActive(true)
                            --     if self.finishAudio then
                            --         self.audioService:PlayClipOneShot(self.finishAudio, function()

                            --         end)
                            --     end
                            -- end)
                        end
                    else
                        if self.state < 3 then
                            g_Log("客户端:时间到，游戏已经结束")
                            self.endPanel:SetActive(true)
                            if self.finishAudio then
                                self.audioService:PlayClipOneShot(self.finishAudio, function()

                                end)
                            end
                            self.commonService:DispatchAfter(3, function()
                                g_Log("3S后提交自己游戏结果")
                                self.endPanel:SetActive(false)
                                local gameResultData = status.totalScores
                                gameResultData.useTime = 21474836473
                                gameResultData.gameId = status.totalScores.gameId
                                gameResultData.petExp = self.doneQuestion
                                gameResultData.autoClose = false
                                for _, value in pairs(status.totalScores.rankList) do
                                    if value.userId == App.Uuid then
                                        gameResultData.useTime = value.score
                                        gameResultData.setId = self.setId
                                        gameResultData.score = value.score
                                        gameResultData.rank = value.rank
                                        gameResultData.award = value.cheese
                                        gameResultData.isFinish = value.isFinish
                                        break
                                    end
                                end
                                gameResultData.autoCloseCallBack = function()
                                    g_Log("自动关闭自己结算页开始段位结算")
                                    self.parent:Trigger("startRankPanel")
                                    if self.isShowRankPanel == false then
                                        self.isShowRankPanel = true
                                        self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST", {})
                                    end
                                end
                                g_Log("玩家答题时间-" .. gameResultData.useTime .. "秒")
                                gameResultData.rankListType = 1
                                gameResultData.titleType = 1
                                gameResultData.contentType = 1
                                gameResultData.closeBtnType = 1
                                local passRate = 0
                                if self.openMouseCount > 0 then
                                    passRate = self.doneQuestion / self.openMouseCount
                                end
                                if passRate >= 0 and passRate <= 1 then
                                    gameResultData.passRate = passRate
                                end
                                gameResultData.rankList = nil
                                self.observerService:Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)
                                if self.endAudio then
                                    self.audioService:PlayClipOneShot(self.endAudio, function()

                                    end)
                                end
                            end)
                        elseif self.state == 3 then
                            g_Log("客户端:已经上报过结果，游戏已经结束")
                            -- 延时1秒
                            App:GetService("CommonService"):DispatchAfter(3, function()
                                self.obBtn:SetActive(false)
                                self.observerService:Fire("HIDE_MINI_GAME_RESULT_PANEL")
                                self.endPanel:SetActive(true)
                                if self.finishAudio then
                                    self.audioService:PlayClipOneShot(self.finishAudio, function()

                                    end)
                                end
                                self.commonService:DispatchAfter(3, function()
                                    g_Log("3S后开始结算段位")
                                    self.endPanel:SetActive(false)
                                    self.parent:Trigger("startRankPanel")
                                    if self.isShowRankPanel == false then
                                        self.isShowRankPanel = true
                                        self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST", {})
                                    end

                                end)
                            end)
                        elseif self.state == 4 then
                            g_Log("客户端:已经上报过结果，游戏已经结束")
                            -- 延时1秒
                            App:GetService("CommonService"):DispatchAfter(1, function()
                                self.obBtn:SetActive(false)
                                self.observerService:Fire("HIDE_MINI_GAME_RESULT_PANEL")
                                self.endPanel:SetActive(true)
                                if self.finishAudio then
                                    self.audioService:PlayClipOneShot(self.finishAudio, function()

                                    end)
                                end
                                self.commonService:DispatchAfter(3, function()
                                    g_Log("3S后开始结算段位")
                                    self.endPanel:SetActive(false)
                                    self.parent:Trigger("startRankPanel")
                                    if self.isShowRankPanel == false then
                                        self.isShowRankPanel = true
                                        self.observerService:Fire("SHOW_MINI_GAME_RANK_PANEL_WITH_RQUEST", {})
                                    end
                                end)
                            end)
                        end
                    end

                    self.state = 6
                    -- 隐藏控制按钮
                    self.joyId = self.joyService:setHidenJoyWithID()
                    self.jumpId = self.joyService:setHidenJumpWithID()
                    -- 关闭观战
                    self.obBtn:SetActive(false)
                elseif status.state == 7 then
                    local num = status.playerNum
                    local totalNum = status.totalNum
                    -- T展示人数
                    if self.isInitialized == false then
                        self.loading:SetActive(true)
                    end
                    self:updateWaitingNum(num, totalNum)
                elseif status.state == 8 then
                    local reportPoint = self.jsonService:decode(status.reportPoint)
                    if reportPoint.userId == App.Properties.UserId then
                        self.state = 3
                        g_Log("上报自己积分" .. table.dump(reportPoint))
                        -- 展示结果页
                        local gameResultData = {}
                        gameResultData.setId = self.setId
                        gameResultData.rank = reportPoint.rank
                        gameResultData.award = reportPoint.award
                        gameResultData.score = reportPoint.score

                        gameResultData.isFinish = true
                        gameResultData.useTime = reportPoint.score
                        gameResultData.rankList = {}
                        gameResultData.petExp = self.doneQuestion
                        gameResultData.autoClose = true
                        gameResultData.rankListType = 1
                        gameResultData.titleType = 1
                        gameResultData.contentType = 1
                        gameResultData.closeBtnType = 1
                        local passRate = 0
                        if self.openMouseCount > 0 then
                            passRate = self.doneQuestion / self.openMouseCount
                        end
                        if passRate >= 0 and passRate <= 1 then
                            gameResultData.passRate = passRate
                        end
                        if self.isCasual ~= "True" then
                            gameResultData.autoCloseCallBack = function()
                                g_Log("3S后自动关闭自己结算页并开始观战")
                                if self.state < 5 then
                                    self.obBtn:SetActive(true)
                                end

                                self.observerService:Fire("isWatchBattle", {
                                    isWatchBattle = true
                                })
                                self.state = 4
                            end
                        else
                            gameResultData.closeBtnType = 2
                            gameResultData.clickCloseCallBack = function()
                                App:GameReturn()
                            end
                        end

                        -- 延时1秒
                        App:GetService("CommonService"):DispatchAfter(1, function()
                            self.observerService:Fire("SHOW_MINI_GAME_RESULT_PANEL_WITH_RQUEST", gameResultData)

                            if self.endAudio then
                                self.audioService:PlayClipOneShot(self.endAudio, function()

                                end)
                            end
                        end)

                        -- 展示App评分
                        -- 延时2秒
                        App:GetService("CommonService"):DispatchAfter(2, function()
                            if gameResultData.rank <= 3 then
                                self:appEvaluate()
                            end

                        end)
                    end
                end
            end
        end
    elseif key == "activateRoom" then
        g_Log("客户端:收到激活房间消息")
        g_Log(table.dump(value))
        for key, msg in pairs(value) do
            local lastMsg = CourseEnv.ServicesManager:GetJsonService():decode(msg)
            if lastMsg and lastMsg.set_id then
                self.setId = tonumber(lastMsg.set_id)
            end
        end
    end
end
-- 生成随机地形
function RunGameElement:build(random)
    if self.hasBuild then
        return
    end
    for key, value in pairs(random) do
        -- local objStr = "关卡布置/跑道/跑道" .. tostring(key)
        -- local objStrPrefab = "关卡布置/预制关卡/关卡" .. tostring(value)
        -- local pos = self.VisElement.transform:Find(objStr).transform.position
        -- local obj = self.VisElement.transform:Find(objStrPrefab)

        local pos = self.level_array_obj:Find("跑道/跑道" .. tostring(key)).transform.position
        local obj = self.level_array_obj:Find("预制关卡/关卡" .. tostring(value))
        if obj then
            obj.transform.position = pos
            g_Log("设置关卡" .. value .. "位置" .. key)

        end
    end
    self.hasBuild = true
end
-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function RunGameElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:SelfAvatarCreated(avatar)
    
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:SelfAvatarPrefabLoaded(avatar)
    Camera.main.fieldOfView = 90
    avatar.VisElement.gameObject.layer = CS.UnityEngine.LayerMask.NameToLayer("areaTrigger")
    g_Log("客户端:发送加入游戏消息")
    self:SendCustomMessage(Fsync_Client_KEY, {
        state = 1,
        UserId = App.Properties.UserId,
        AvatarName = App.Properties.AvatarName
    })
    self:initQuestions()
    -- self:AddVoice()
    -- 开启人物冲刺相关逻辑
    -- 开启加速鞋计时器
    self.selfAvatar = avatar

    self.remainSpeedTime = 0
    self.hasSpeedEffect = false

end

function RunGameElement:AddVoice()
    self.showChat = false
    local appVersion = App.Info.appVersionNumber
    if appVersion then
        if tonumber(appVersion) < 10510 then
            return
        end
    end
    self.showChat = true

    -- 强制显示
    CourseEnv.ServicesManager:GetUIService().voiceBtnHidenStateTable = {}
    CourseEnv.ServicesManager:GetUIService().commonMenu.VisitorToLogin = true
    CourseEnv.ServicesManager:GetUIService().commonMenu.voiceBtn.gameObject:SetActive(true)

    APIBridge.RequestAsync("app.buss.menu.autoPlayChat", {
        open = true,
        isShow = true,
        topSafeArea = 40.0 / 750
    }, function()

    end)

    local ori = APIBridge.RequestAsync
    APIBridge.RequestAsync = function(api, request, callBack)
        if api == 'app.buss.menu.autoPlayChat' and (not request.topSafeArea or request.topSafeArea == 0) then
            request.topSafeArea = 40.0 / 750
        end

        ori(api, request, callBack)
    end
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function RunGameElement:AvatarCreated(avatar)
    if not self.allAvatar then
        self.allAvatar = {}
    end
    avatar.characterCtrl.ignoreZombie = true
    avatar.characterCtrl.gDisableFrameBuffer = true
    table.insert(self.allAvatar, avatar:GetProperty("uuid"))
    if self.gameStart then
        Faction:Matched({
            ["循环跑酷"] = self.allAvatar
        })
    end
end

-- 拉题
--- func desc api:http://yapi.xesv5.com/project/2041/interface/api/73881
---@param num number 题目数量
---@param type number 题目类型 1:单词 2:句子 3:选择
function RunGameElement:initQuestions()
    self.commonService:StartCoroutine(function()
        self.commonService:Yield(self.commonService:WaitUntil(function()
            return self.recoverComplete == true
        end))

        self.parent:Trigger("getQuestionsEnd")
    end)
end

function RunGameElement:answerQuestion()
    g_Log("openDialog")
    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", {
        status = 1,
        awardCount = 1,
        showAwardType = 2,
        callBack = function(score, isFinal, isNoSpeaking, isPass)
            self.openMouseCount = self.openMouseCount + 1
            if isFinal then
                self.answerOn = false
                -- self:Fire("showSkillUI")
                if isPass then
                    -- 答题通过
                    if App.IsStudioClient then
                        self:AddEnergy(score)
                    else
                        self:AddEnergy(score)
                    end
                    self.doneQuestion = self.doneQuestion + 1
                    -- self:Trigger("readSuccessAdd")
                else

                end
            else
            end
        end
    })
end

function RunGameElement:closeAnswerQuestion()
    g_Log("closeDialog")
    self.nengliangRoot.gameObject:SetActive(false)
    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION", {
        status = 0,
        awardCount = 1,
        showAwardType = 2,
        callBack = function(score, isFinal, isNoSpeaking, isPass)

        end
    })
end

function RunGameElement:AddEnergy(energy)
    self.currentEnergy = energy + self.currentEnergy
    if self.currentEnergy >= self.maxEnergy then
        self.currentEnergy = self.maxEnergy
        -- 能量已满
        if self.energyFullAudio then
            self.audioService:PlayClipOneShot(self.energyFullAudio, function()
            end)
        end
    end
    if self.currentEnergy <= 0 then
        self.currentEnergy = 0
        -- 能量已空
    end

    self:SetEnergyEvent(math.floor(self.currentEnergy))
end
function RunGameElement:SetEnergyEvent(energy)
    self.observerService:Fire("EVENT_BUSINESS_BOTTOM_ANSWER_QUESTION_INIT_SLIDER", {
        numerator = energy,
        denominator = self.maxEnergy
    })
end
-- 调用App评分
function RunGameElement:appEvaluate()
    if self.appEvaluateFinish == nil then
        self.appEvaluateFinish = true
        -- APIBridge.RequestAsync("app.buss.appEvaluate.show", {})
    end
end
function RunGameElement:CalculateDistance()
    --- 圈数 * 1000000 + 检查点 * 100000 + 距离上个检查点的距离
    -- self.finishCircleNum = 1
    -- self.checkPointNum = 2
    if not self.transCurCheckPoint then
        self.transCurCheckPoint = self.transStartPoint:Find("碰撞检测")
    end

    local distance = self.finishCircleNum * 1000000 + self.checkPointNum * 100000
    -- 计算当前人物距离
    local selfPos = self.selfAvatar.VisElement.transform.position
    local startPos = self.transCurCheckPoint.position
    distance = Vector3.Distance(selfPos, startPos) + distance
    if distance >= self.lastDistance then
        if distance >= self.maxDistance then
            self.maxDistance = distance
        end
    else
    end

    if self.nextCheckPoint then
        -- 判断逆行
        local nextDistance = self.finishCircleNum * 1000000 + (self.checkPointNum + 1) * 100000
        local nextDistance = nextDistance - Vector3.Distance(selfPos, self.nextCheckPoint.position)
        if nextDistance >= self.lastNextDistance then
            self.backFrame = self.backFrame - 5
            if self.backFrame <= 0 then
                self.backFrame = 0
                if self.transJingshi.gameObject.activeSelf then
                    self:Print("取消逆行")
                    self.transJingshi.gameObject:SetActive(false)
                end
            end
        else
            if self.backFrame > 10 and not self.transJingshi.gameObject.activeSelf then
                self:Print("逆行")
                self.transJingshi.gameObject:SetActive(true)
            end
            self.backFrame = self.backFrame + 1
        end
        self.lastNextDistance = nextDistance
    end
    self.lastDistance = distance
end
function RunGameElement:SendDistance()
    self:CalculateDistance()
    self:SendCustomMessage(Fsync_Client_KEY, {
        state = 2,
        UserId = App.Properties.UserId,
        Distance = self.maxDistance
    })
end
function RunGameElement:Tick()
    if not self.selfAvatar then
        return
    end
    if self.hasFinished == true then
        return
    end
    if self.tickIndex == nil then
        self.tickIndex = 0
    end

    self.tickIndex = self.tickIndex + 1

    if not self.gameStart then
        return
    end
    if self.hasFinished then
        return
    end
    self:RefreshRush()
    if not self.timer then
        self.timer = os.time()
    end
    if self.tickIndex % 10 == 0 then
        self:UpdateTime()
    end
    if self.tickIndex % 3 == 0 then
        self:CalculateDistance()
    end
    if self.tickIndex % 20 ~= 0 then
        return
    end
    self:SendDistance()
end
function RunGameElement:RefreshRush()
    if not self.selfAvatar then
        return
    end
    if self.currentEnergy > 0 then
        if self.hasSpeedEffect == false then
            self.hasSpeedEffect = true
            -- 打开特效
            self.selfAvatar:SetRushState()
            -- Camera.main.fieldOfView = 90
        end
        self:AddEnergy(-Time.deltaTime * 7)
    else
        if self.hasSpeedEffect == true then
            self.hasSpeedEffect = false
            -- 关闭特效
            self.selfAvatar:SetNormalState()
            -- Camera.main.fieldOfView = 80
        end
    end
end
function RunGameElement:UpdateTime()
    local t = os.time() - self.timer
    local min = math.floor(t / 60)
    local sec = math.floor(t) % 60
    self.usedTime = t
    self:SetTime(min, sec)
end

function RunGameElement:StartCircle(num)
    self:Print("第 " .. tostring(num) .. " 圈")
    if not self.circleCount then
        g_LogError("not self.circleCount")
    end
    local isFinal = num >= self.circleCount
    self.transFirstCircle.gameObject:SetActive(num == 1 and not isFinal)
    self.transSecondCircle.gameObject:SetActive(num == 2 and not isFinal)
    self.transFinalCircle.gameObject:SetActive(isFinal)
    self:SetCircle(num, self.circleCount)
    local trans = self.transSecondCircle
    if isFinal then
        trans = self.transFinalCircle
        self.transEndPointAsset.gameObject:SetActive(true)
        if self.finalCircleAudio then
            self.audioService:PlayClipOneShot(self.finalCircleAudio)
        end
    elseif num == 1 then
        trans = self.transFirstCircle
    end
    trans.gameObject:SetActive(true)
    local showAction = CS.DG.Tweening.DOTween:Sequence()
    showAction:Append(trans:DOScale(CS.UnityEngine.Vector3(1, 1, 1), 0.3))
    showAction:AppendInterval(1.5)
    showAction:Append(trans:DOScale(CS.UnityEngine.Vector3(1, 0, 1), 0.3))
    showAction:AppendCallback(function()
        trans.gameObject:SetActive(false)
    end)
end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function RunGameElement:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function RunGameElement:LogicMapStartRecover()
    RunGameElement.super:LogicMapStartRecover()
    -- TODO
end
-- 结束恢复方法 (断线重连的时候用)
function RunGameElement:LogicMapEndRecover()
    RunGameElement.super:LogicMapEndRecover(self)
    -- TODO
end
-- 所有的组件恢复完成
function RunGameElement:LogicMapAllComponentRecoverComplete()
    self.recoverComplete = true
end

-- 收到Trigger事件
function RunGameElement:OnReceiveTriggerEvent(interfaceId)
end
-- 收到GetData事件
function RunGameElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function RunGameElement:Exit()
    g_Log("客户端:退出游戏消息")
    self:SendCustomMessage(Fsync_Client_KEY, {
        state = 3,
        UserId = App.Properties.UserId
    })

    if self.globalShoeTimer then
        self.commonService:UnregisterGlobalTimer(self.globalShoeTimer)
    end

    RunGameElement.super.Exit(self)
end

return RunGameElement

