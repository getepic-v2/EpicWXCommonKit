---
---  Author: 【彩滨滨】
---  AuthorID: 【246276】
---  CreateTime: 【2023-10-27 15:16:50】
--- 【FSync】
--- 【ABC排位赛段位结算】
---  用法如下：
--- Fire事件：SHOW_GAME_RANK_RESULT_PANEL
--- 传参：args[0] = {
--- type = 1 -- 1：个人赛段位结算，2：团队赛段位结算
--- isFailed = false -- 个人赛专用字段 是否未通过，未通过左上角显示未通过，否则显示第几名
--- isTeamWin = true -- 团队赛专用字段 是否胜利 目前规则加分就是显示胜利，可传可不传
--- rank = 1, 排名
--- change_score = -3,
--  is_protect = is_protect, -- 是否保护分
--  protect_score = protect_score, -- 保护分
--  ranking_before = {level=7,level_name="巅峰",section_score=9,section_name="1"},
--  ranking_after = {level = 7,level_name ="巅峰",section_score = 6,section_name = "1"}
-- }

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_da0f2917_b911_4f12_965b_bd5fd11c0d9e : WorldBaseElement
local GameRank = class("game_result_comlogic", WBElement)

local log = function(...) g_Log("排位段位结算页面", ...) end

---@param worldElement CS.Tal.framesync.WorldElement
function GameRank:initialize(worldElement)
    GameRank.super.initialize(self, worldElement)
end

function GameRank:setVisElement(VisElement)
    self.VisElement = VisElement
    self:InitService()
    self:InitConfig()
    self:InitDebugView()
    self:InitEventListener()
end

function GameRank:InitService()
    ---@type Gate
    self.gate = CourseEnv.ServicesManager.Gate
    ---@type ObserverService
    self.BusEventService = CourseEnv.ServicesManager:GetObserverService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type ConfigService
    self.configService = CourseEnv.ServicesManager:GetConfigService()
    ---@type DebugService
    self.debugService = CourseEnv.ServicesManager:GetDebugService()
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type AssetService
    self.assetService = CourseEnv.ServicesManager:GetAssetService()
    ---@type UIService
    self.UIService = App:GetService("UIService")
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type AudioService
    self.audioService = CourseEnv.ServicesManager:GetAudioService()
    ---@type JoystickService
    self.joystickService = CourseEnv.ServicesManager:GetJoystickService()
    ---@type DecorateService
    self.decorateService = CourseEnv.ServicesManager:GetDecorateService()
    ---@type LightService
    self.lightService = CourseEnv.ServicesManager:GetLightService()
end

function GameRank:InitConfig()
    local ResourcePathRoot = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/game_rankPanel/"
    local picturePathRoot = ResourcePathRoot .. "testures/"
    local audioPathRoot = ResourcePathRoot .. "audios/"

    local shengduanweiPrefab = ResourcePathRoot .. "shengduanwei/assets/Prefabs/jiaxing_shengduanwei.prefab"
    local weitongguoPrefab = ResourcePathRoot .. "diaoduanwei/assets/Prefabs/diaoxing.prefab"
    local dianfengaddPrefab = ResourcePathRoot .. "dianfengjiafen/assets/Prefabs/dianfengjiafen.prefab"
    local dianfengjianPrefab = ResourcePathRoot .. "dianfengdiaofen/assets/Prefabs/dianfengdiaofen.prefab"
    local daojishiPrefab = ResourcePathRoot .. "daojishi/assets/Prefabs/daojishi.prefab"
    ResourceManager:LoadGameObjectWithExName(daojishiPrefab, function(go)
        self.daojishiPanel = GameObject.Instantiate(go)
        self.daojishiPanel.transform:SetParent(self.VisElement.gameObject.transform)
        self.daojishiPanel.transform.localPosition = Vector3.zero
        self.daojishiPanel.transform.localScale = Vector3.one
        self.daojishiPanel.transform.localRotation = Quaternion.identity
        self.daojishiPanel:SetActive(false)
    end)

    ResourceManager:LoadGameObjectWithExName(shengduanweiPrefab, function(go)
        self.shengduanweiPanel = GameObject.Instantiate(go)
        self.shengduanweiPanel.transform:SetParent(self.VisElement.gameObject.transform)
        self.shengduanweiPanel.transform.localPosition = Vector3.zero
        self.shengduanweiPanel.transform.localScale = Vector3.one
        self.shengduanweiPanel.transform.localRotation = Quaternion.identity
        self.shengduanweiPanel:SetActive(false)
    end)

    ResourceManager:LoadGameObjectWithExName(weitongguoPrefab, function(go)
        self.weitongguoPanel = GameObject.Instantiate(go)
        self.weitongguoPanel.transform:SetParent(self.VisElement.gameObject.transform)
        self.weitongguoPanel.transform.localPosition = Vector3.zero
        self.weitongguoPanel.transform.localScale = Vector3.one
        self.weitongguoPanel.transform.localRotation = Quaternion.identity
        self.weitongguoPanel:SetActive(false)
    end)

    ResourceManager:LoadGameObjectWithExName(dianfengaddPrefab, function(go)
        self.dianfengaddPanel = GameObject.Instantiate(go)
        self.dianfengaddPanel.transform:SetParent(self.VisElement.gameObject.transform)
        self.dianfengaddPanel.transform.localPosition = Vector3.zero
        self.dianfengaddPanel.transform.localScale = Vector3.one
        self.dianfengaddPanel.transform.localRotation = Quaternion.identity
        self.dianfengaddPanel:SetActive(false)
    end)

    ResourceManager:LoadGameObjectWithExName(dianfengjianPrefab, function(go)
        self.dianfengjianPanel = GameObject.Instantiate(go)
        self.dianfengjianPanel.transform:SetParent(self.VisElement.gameObject.transform)
        self.dianfengjianPanel.transform.localPosition = Vector3.zero
        self.dianfengjianPanel.transform.localScale = Vector3.one
        self.dianfengjianPanel.transform.localRotation = Quaternion.identity
        self.dianfengjianPanel:SetActive(false)
    end)

    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DDDFAudio.mp3", function(audioclip)
        self.DDDFAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DDJFAudio.mp3", function(audioclip)
        self.DDJFAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DDDLAudio.mp3", function(audioclip)
        self.DDDLAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "JSDFAudio.mp3", function(audioclip)
        self.JSDFAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DDDWAudio.mp3", function(audioclip)
        self.DDDWAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DXDWAudio.mp3", function(audioclip)
        self.DXDWAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "JDDWAudio.mp3", function(audioclip)
        self.JDDWAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "JXDWAudio.mp3", function(audioclip)
        self.JXDWAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "JXAudio.mp3", function(audioclip)
        self.JXAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DXAudio.mp3", function(audioclip)
        self.DXAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DXKCAudio.mp3", function(audioclip)
        self.DXKCAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "JXKCAudio.mp3", function(audioclip)
        self.JXKCAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DFDFBGMAudio.mp3", function(audioclip)
        self.DFDFBGMAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DFJFBGMAudio.mp3", function(audioclip)
        self.DFJFBGMAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "DFDLBGMAudio.mp3", function(audioclip)
        self.DFDLBGMAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "JSDFBGMAudio.mp3", function(audioclip)
        self.JSDFBGMAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "JiaXBGMAudio.mp3", function(audioclip)
        self.JiaXBGMAudio = audioclip
    end)
    ResourceManager:LoadAudioClipWithExName(audioPathRoot .. "JianXBGMAudio.mp3", function(audioclip)
        self.JianXBGMAudio = audioclip
    end)
    self.noYellowImageList = {}
    self.dfNumImageList = {}
    for i = 0, 9 do
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "numYellow_" .. i .. ".png", function(sprite)
            self.noYellowImageList[i] = sprite
        end)
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "numWhite_" .. i .. ".png", function(sprite)
            self.dfNumImageList[i] = sprite
        end)
    end

    self.RankImageList = {}
    self.RankNameImageList = {}
    for i = 1, 7 do
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "rank_" .. i .. ".png", function(sprite)
            self.RankImageList[i] = sprite
        end)
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "rank_name_" .. i .. ".png", function(sprite)
            self.RankNameImageList[i] = sprite
        end)
    end
    
    self.SectionImageList = {}
    for i = 1, 5 do
        ResourceManager:LoadSpriteWithExName(picturePathRoot .. "rank_little_" .. i .. ".png", function(sprite)
            self.SectionImageList[i] = sprite
        end)
    end

    -- 加载失败底图
    ResourceManager:LoadSpriteWithExName(picturePathRoot .. "shibaiditu.png", function(sprite)
        self.shibaiditu = sprite
    end)
end

function GameRank:InitDebugView()


    -- TODO 测试数据
    self.change_score = -3
    self.ranking_before = {level=6,level_name="巅峰",section_score=1,section_name="1",section_total_score = 6}
    self.ranking_after = {level = 5,level_name ="巅峰",section_score = 3,section_name = "5",section_total_score = 5}
    local protect_score = 1
    local is_protect = true
    
    self.gBtn = self.VisElement.transform:Find("屏幕画布/按钮属性").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
    App:GetService("CommonService"):AddEventListener(self.gBtn, "onClick", function()
        if self.canvasRect then
            self.canvasRect.gameObject:SetActive(false)
        end
        
        if self.canvasRect then
            self.canvasRect.gameObject:SetActive(true)
        end
        self.BusEventService:Fire("SHOW_GAME_RANK_RESULT_PANEL",{change_score = self.change_score,
                                is_protect = is_protect,
                                protect_score = protect_score,
                                ranking_before = self.ranking_before,
                                ranking_after = self.ranking_after,
                                rank = 1,
                                isFailed = false,
                                type = 2,
                                isTeamWin = true})
    end)
    self.VisElement.transform:Find("屏幕画布").gameObject:GetComponent(typeof(CS.UnityEngine.Canvas)).sortingOrder = 2000
    
    self.gBtn.gameObject:SetActive(false)
end

function GameRank:InitEventListener()
    self.BusEventService:Watch("SHOW_GAME_RANK_RESULT_PANEL", function(key, args) 
        log("SHOW_GAME_RANK_RESULT_PANEL", table.dump(args[0]))
        if not App.IsStudioClient then
            CourseEnv.ServicesManager.Gate.controlElement:forbidLostLoading()
        end
        self.ishowDaojishi = args[0].ishowDaojishi --是否显示倒计时
        local sortOrder = 1200

        local change_score = args[0].change_score
        local is_protect = args[0].is_protect
        if not is_protect then
            is_protect = false
        end
        local protect_score = args[0].protect_score
        if not protect_score or is_protect == false then
            protect_score = 0
        end
        local ranking_before = args[0].ranking_before
        local ranking_after = args[0].ranking_after
        local rank = args[0].rank
        local isFailed = args[0].isFailed
        
        local isTeamWin = args[0].isTeamWin
        if change_score == nil or ranking_before == nil or ranking_after == nil 
            or type(ranking_before) ~= 'table' or type(ranking_after) ~= 'table'
            or ranking_before.level < 1 or ranking_after.level < 1 then
            g_LogError("请求段位信息有误,直接返回英语角")
            App:GameReturn()
            return
        end

        local type = args[0].type
        
        if not ranking_before.section_total_score then
            ranking_before.section_total_score = 10
        end
        if not ranking_after.section_total_score then
            ranking_after.section_total_score = 10
        end
        -- 添加获取退出按钮和再来一局按钮callBack
        local btnCallBack = args[0].btnCallBack
        if change_score > 0 then
            -- 巅峰加分
            if ranking_before.level == 7 then
                self.canvasRect = self.dianfengaddPanel.transform:Find("Canvas")
                self.canvas = self.canvasRect.gameObject:GetComponent(typeof(CS.UnityEngine.Canvas))
                self.canvas.sortingOrder = sortOrder

                self.closeBtn = self.canvasRect:Find("dianfeng/zhezhao/anjian/tuichu")
                self.againBtn = self.canvasRect:Find("dianfeng/zhezhao/anjian/zailianyiju")
                if btnCallBack then
                    btnCallBack(self.closeBtn, self.againBtn)
                end
                -- -- 添加返回按钮事件
                -- self.commonService:AddEventListener(self.closeBtn, "onClick", function()
                --     log("回到ABCZone")
                --     self.dianfengaddPanel:SetActive(false)
                --     App:GameReturn()
                -- end)

                self.animatior = self.canvasRect:Find("dianfeng").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                -- 判断个人赛团队赛
                local diyiming = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/mingci/mc/diyiming")
                local huosheng = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/mingci/mc/huosheng")
                local shibai = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/mingci/mc/shibai")
                local jingyan = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/jingyan")
                local jingyan2 = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/jingyan2")

                if type and type == 2 then
                    if diyiming and jingyan then
                        diyiming.gameObject:SetActive(false)
                        jingyan.gameObject:SetActive(false)
                        huosheng.gameObject:SetActive(true)
                        jingyan2.gameObject:SetActive(true)
                    end
                    if change_score - protect_score == 0 or isTeamWin == false then
                        shibai.gameObject:SetActive(true)
                        huosheng.gameObject:SetActive(false)
                        local image = jingyan2:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                        if image and self.shibaiditu then
                            image.sprite = self.shibaiditu
                        end
                    end
                    -- 设置第几名
                    local rankText = jingyan2:Find("text/Text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                    if rankText and rank then
                        -- rank 转汉字
                        local numChinese = self:num2Chinese(rank)
                        rankText.text = "第" .. numChinese .. "名"
                    end
                    -- 设置加几分
                    local jingyanText = jingyan2:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                    if jingyanText then
                        if (change_score - protect_score) >= 0 then
                            jingyanText.text = "+" .. (change_score - protect_score)
                            g_Log("设置加分")
                        else
                            jingyanText.text = (change_score - protect_score)
                            g_Log("设置减分")
                        end
                    end
                else
                    if diyiming and jingyan then
                        diyiming.gameObject:SetActive(true)
                        jingyan.gameObject:SetActive(true)
                        huosheng.gameObject:SetActive(false)
                        jingyan2.gameObject:SetActive(false)
                    end

                    if change_score - protect_score == 0 then
                        local image = jingyan:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                        if image and self.shibaiditu then
                            image.sprite = self.shibaiditu
                        end
                    end

                    self.rankImage = diyiming:Find("3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    -- 1.设置第几名
                    if self.rankImage and rank then
                        g_Log("设置名次")
                        self.rankImage.sprite = self.noYellowImageList[rank]
                    end
                    -- 2.设置加几分
                    self.jingyan = jingyan:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                    if self.jingyan then
                        if (change_score - protect_score) >= 0 then
                            self.jingyan.text = "+" .. (change_score - protect_score)
                            g_Log("设置加分")
                        else
                            self.jingyan.text = (change_score - protect_score)
                            g_Log("设置减分")
                        end
                    end
                end

                -- 设置额外加分
                if is_protect and protect_score > 0 then
                    local protectText1 = self.canvasRect:Find("dianfeng/zhezhao/shouchangjiaxing/scjx-1/scjx-1-1/Rectangle 34625025/Rectangle 34625025 (1)/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                    if protectText1 then
                        protectText1.text = protect_score
                    end
                    local protectText2 = self.canvasRect:Find("dianfeng/zhezhao/shouchangjiaxing/scjx-2/scjx-2-2/Rectangle 34625025/Rectangle 34625025 (1)/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                    if protectText2 then
                        protectText2.text = protect_score
                    end
                end

                -- 3.设置加分前状态 
                -- 巅峰段位
                local xiaoduanweiNumQian = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_01/qian_1").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumBai = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_02/bai_1").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumShi = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_03/shi_1").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumGe = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_04/ge_1").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumAdd = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_05/+").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumQian1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_01/qian_2").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumBai1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_02/bai_2").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumShi1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_03/shi_2").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumGe1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_04/ge_2").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumAdd1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_05/+").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))

                self:DianfengNum(xiaoduanweiNumQian, xiaoduanweiNumBai, xiaoduanweiNumShi, xiaoduanweiNumGe, xiaoduanweiNumAdd, ranking_before.section_score)
                self:DianfengNum(xiaoduanweiNumQian1, xiaoduanweiNumBai1, xiaoduanweiNumShi1, xiaoduanweiNumGe1, xiaoduanweiNumAdd1, ranking_after.section_score)

                if ranking_before.section_score < 10000 then
                    xiaoduanweiNumAdd1.gameObject:SetActive(false)
                end

                local MaskRect = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask"):GetComponent(typeof(CS.UnityEngine.RectTransform))
                -- 设置锚点
                if ranking_after.section_score > 9999 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(-30, 0)
                elseif ranking_after.section_score > 999 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(-16, 0)
                elseif ranking_after.section_score > 99 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(-1, 0)
                elseif ranking_after.section_score > 9 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(16, 0)
                elseif ranking_after.section_score >= 0 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(30, 0)
                end
                
                self.dianfengaddPanel:SetActive(true)
                self.commonService:StartCoroutine(function()
                    self.commonService:YieldSeconds(2.75)
                    self:ShowDaojishi()
                    if ranking_after.section_score > 9999 then
                        xiaoduanweiNumAdd1.gameObject:SetActive(true)
                    end

                    if is_protect and protect_score > 0 then
                        if type and type == 2 then
                            self.canvasRect:Find("dianfeng/zhezhao/shouchangjiaxing/scjx-1").gameObject:SetActive(false)
                            self.canvasRect:Find("dianfeng/zhezhao/shouchangjiaxing/scjx-2").gameObject:SetActive(true)
                        else
                            self.canvasRect:Find("dianfeng/zhezhao/shouchangjiaxing/scjx-1").gameObject:SetActive(true)
                            self.canvasRect:Find("dianfeng/zhezhao/shouchangjiaxing/scjx-2").gameObject:SetActive(false)
                        end
                    else
                        self.canvasRect:Find("dianfeng/zhezhao/shouchangjiaxing/scjx-1").gameObject:SetActive(false)
                        self.canvasRect:Find("dianfeng/zhezhao/shouchangjiaxing/scjx-2").gameObject:SetActive(false)
                    end
                    
                    self.animatior:Play("shouchangjiaxing-1",0,0)
                    self.commonService:YieldSeconds(0.83)

                    local shuziAni1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_01").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    local shuziAni2 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_02").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    local shuziAni3 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_03").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    local shuziAni4 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_04").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    local shuziAni5 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_05").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    shuziAni1:Play("shuzi_01_jia_1")
                    shuziAni2:Play("shuzi_02_jia_1")
                    shuziAni3:Play("shuzi_03_jia_1")
                    shuziAni4:Play("shuzi_04_jia_1")
                    shuziAni5:Play("shuzi_05")
                    self.audioService:PlayClipOneShot(self.DDJFAudio)
                end)
                self.audioService:PlayClipOneShot(self.JXKCAudio)
                self.audioService:PlayClipOneShot(self.DFJFBGMAudio)
            else
                -- 普通加分
                self.canvasRect = self.shengduanweiPanel.transform:Find("Canvas")
                self.canvas = self.canvasRect.gameObject:GetComponent(typeof(CS.UnityEngine.Canvas))
                self.canvas.sortingOrder = sortOrder

                self.closeBtnRoot = self.canvasRect:Find("duanwei/zhezhao/anjian")
                -- self.closeBtn = self.canvasRect:Find("duanwei/zhezhao/Group 1321315159/Button").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
                -- -- 添加返回按钮事件
                -- self.commonService:AddEventListener(self.closeBtn, "onClick", function()
                --     log("回到ABCZone")
                --     self.shengduanweiPanel:SetActive(false)
                --     App:GameReturn()
                -- end)
                self.closeBtn = self.canvasRect:Find("duanwei/zhezhao/anjian/tuichu")
                self.againBtn = self.canvasRect:Find("duanwei/zhezhao/anjian/zailianyiju")
                if btnCallBack then
                    btnCallBack(self.closeBtn, self.againBtn)
                end

                self.closeBtnRoot.gameObject:SetActive(false)

                self.animatior = self.canvasRect:Find("duanwei").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))

                -- 判断个人赛团队赛
                local diyiming = self.canvasRect:Find("duanwei/zhezhao/mingci_jingyan/mingci/mc/diyiming")
                local huosheng = self.canvasRect:Find("duanwei/zhezhao/mingci_jingyan/mingci/mc/huosheng")
                local shibai = self.canvasRect:Find("duanwei/zhezhao/mingci_jingyan/mingci/mc/shibai")
                local jingyan = self.canvasRect:Find("duanwei/zhezhao/mingci_jingyan/jingyan")
                local jingyan2 = self.canvasRect:Find("duanwei/zhezhao/mingci_jingyan/jingyan2")

                if type and type == 2 then
                    if diyiming and jingyan then
                        diyiming.gameObject:SetActive(false)
                        jingyan.gameObject:SetActive(false)
                        huosheng.gameObject:SetActive(true)
                        jingyan2.gameObject:SetActive(true)
                    end
                    if change_score - protect_score == 0 or isTeamWin == false then
                        shibai.gameObject:SetActive(true)
                        huosheng.gameObject:SetActive(false)
                        local image = jingyan2:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                        if image and self.shibaiditu then
                            image.sprite = self.shibaiditu
                        end
                    end
                    -- 设置第几名
                    local rankText = jingyan2:Find("text/Text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                    if rankText and rank then
                        -- rank 转汉字
                        local numChinese = self:num2Chinese(rank)
                        rankText.text = "第" .. numChinese .. "名"
                    end
                    -- 设置加几分
                    local jingyanText = jingyan2:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                    if jingyanText then
                        if (change_score - protect_score) >= 0 then
                            jingyanText.text = "+" .. (change_score - protect_score)
                            g_Log("设置加分")
                        else
                            jingyanText.text = (change_score - protect_score)
                            g_Log("设置减分")
                        end
                    end
                else
                    if diyiming and jingyan then
                        diyiming.gameObject:SetActive(true)
                        jingyan.gameObject:SetActive(true)
                        huosheng.gameObject:SetActive(false)
                        jingyan2.gameObject:SetActive(false)
                    end

                    if change_score - protect_score == 0 then
                        local image = jingyan:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                        if image and self.shibaiditu then
                            image.sprite = self.shibaiditu
                        end
                    end

                    self.rankImage = diyiming:Find("3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    -- 1.设置第几名
                    if self.rankImage and rank then
                        g_Log("设置名次")
                        self.rankImage.sprite = self.noYellowImageList[rank]
                    end
                    -- 2.设置加几分
                    self.jingyan = jingyan:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                    if self.jingyan then
                        if (change_score - protect_score) >= 0 then
                            self.jingyan.text = "+" .. (change_score - protect_score)
                            g_Log("设置加分")
                        else
                            self.jingyan.text = (change_score - protect_score)
                            g_Log("设置减分")
                        end
                    end
                end

                -- 设置额外加分
                if is_protect and protect_score > 0 then
                    local protectText1 = self.canvasRect:Find("duanwei/zhezhao/shouchangjiaxing/scjx-1/scjx-1-1/Rectangle 34625025/Rectangle 34625025 (1)/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                    if protectText1 then
                        protectText1.text = protect_score
                    end
                    local protectText2 = self.canvasRect:Find("duanwei/zhezhao/shouchangjiaxing/scjx-2/scjx-2-2/Rectangle 34625025/Rectangle 34625025 (1)/shuzi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                    if protectText2 then
                        protectText2.text = protect_score
                    end

                    if type and type == 2 then
                        self.canvasRect:Find("duanwei/zhezhao/shouchangjiaxing/scjx-1").gameObject:SetActive(false)
                        self.canvasRect:Find("duanwei/zhezhao/shouchangjiaxing/scjx-2").gameObject:SetActive(true)
                    else
                        self.canvasRect:Find("duanwei/zhezhao/shouchangjiaxing/scjx-1").gameObject:SetActive(true)
                        self.canvasRect:Find("duanwei/zhezhao/shouchangjiaxing/scjx-2").gameObject:SetActive(false)
                    end
                else
                    self.canvasRect:Find("duanwei/zhezhao/shouchangjiaxing/scjx-1").gameObject:SetActive(false)
                    self.canvasRect:Find("duanwei/zhezhao/shouchangjiaxing/scjx-2").gameObject:SetActive(false)
                end
                -- 3.设置加分前状态 
                -- 控制隐藏节点
                -- 星星
                self.starRoot = self.canvasRect:Find("duanwei/zhezhao/Star")
                self.starRect = self.starRoot.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
                self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_before.section_total_score), self.starRect.anchoredPosition.y)
                for i = 1, 10 do
                    local star = self.canvasRect:Find("duanwei/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                    local imagebefore = star.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local colorbefore = imagebefore.color
                    if i <= ranking_before.section_score then
                        colorbefore.a = 1
                    else
                        g_Log("初始化隐藏第" .. i .. "颗星星")
                        colorbefore.a = 0
                    end
                    imagebefore.color = colorbefore

                    local star1 = self.canvasRect:Find("duanwei/zhezhao/Star/Star_you/Star_you (" .. i ..")")
                    local imagebefore1 = star1.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local colorbefore1 = imagebefore1.color
                    colorbefore1.a = 0
                    imagebefore1.color = colorbefore1

                    local starWu = self.canvasRect:Find("duanwei/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                    local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local colorbeforeWu = imagebeforeWu.color
                    if i <= ranking_before.section_total_score then
                        colorbeforeWu.a = 1
                    else
                        colorbeforeWu.a = 0
                    end
                    imagebeforeWu.color = colorbeforeWu
                end
                -- 段位
                local xiaoduanweiName = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_3/baiyin").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNum = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_3/4").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                xiaoduanweiName.sprite = self.RankNameImageList[ranking_after.level]
                xiaoduanweiNum.sprite = self.SectionImageList[tonumber(ranking_after.section_name)]
                local fakeDW = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_3")
                fakeDW.gameObject:SetActive(false)

                local xiaoduanweiName1 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1/qingtong").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNum2 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1/3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                xiaoduanweiName1.sprite = self.RankNameImageList[ranking_before.level]
                xiaoduanweiNum2.sprite = self.SectionImageList[tonumber(ranking_before.section_name)]
                local xiaoduanweiName3 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_2/baiyin").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNum4 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_2/4").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                xiaoduanweiName3.sprite = self.RankNameImageList[ranking_after.level]
                xiaoduanweiNum4.sprite = self.SectionImageList[tonumber(ranking_after.section_name)]

                -- 勋章
                local daduanweiImagef = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_3/xunzhang_baiyin").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local daduanweiImageff = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_3/xunzhang_baiyin/xunzhang_baiguang (1)").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                daduanweiImagef.sprite = self.RankImageList[ranking_after.level]
                daduanweiImageff.sprite = self.RankImageList[ranking_after.level]
                local fakeXZ = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_3")
                fakeXZ.gameObject:SetActive(false)

                local daduanweiImage1 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1/xunzhang_qingtong").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local daduanweiImage2 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1/xunzhang_qingtong/xunzhang_baiguang").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                daduanweiImage1.sprite = self.RankImageList[ranking_before.level]
                daduanweiImage2.sprite = self.RankImageList[ranking_before.level]
                local daduanweiImage3 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_2/xunzhang_baiyin").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local daduanweiImage4 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_2/xunzhang_baiyin/xunzhang_baiguang (1)").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                daduanweiImage3.sprite = self.RankImageList[ranking_after.level]
                daduanweiImage4.sprite = self.RankImageList[ranking_after.level]
                -- 巅峰段位
                if ranking_after.level == 7 then
                    local xiaoduanweiName = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/dianfeng").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumBai = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/qian").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumShi = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/bai").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumGe = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumGeLast = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/ge").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumGeAdd = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/+").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    xiaoduanweiNumGeLast.gameObject:SetActive(false)
                    xiaoduanweiNumGeAdd.gameObject:SetActive(false)
                    local xiaoduanweiName1 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng1/Mask/dianfeng").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumBai1 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng1/Mask/shuzi/bai").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumShi1 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng1/Mask/shuzi/shi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumGe1 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng1/Mask/shuzi/ge").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    xiaoduanweiName.sprite = self.RankNameImageList[ranking_after.level]
                    xiaoduanweiName1.sprite = self.RankNameImageList[ranking_after.level]
                    local bai = math.floor(ranking_after.section_score / 100)
                    local shi = math.floor((ranking_after.section_score - bai * 100) / 10)
                    local ge = ranking_after.section_score - bai * 100 - shi * 10
                    if bai > 0 then
                        xiaoduanweiNumBai.sprite = self.dfNumImageList[bai]
                        xiaoduanweiNumBai1.sprite = self.dfNumImageList[bai]
                        xiaoduanweiNumShi.sprite = self.dfNumImageList[shi]
                        xiaoduanweiNumShi1.sprite = self.dfNumImageList[shi]
                        xiaoduanweiNumGe.sprite = self.dfNumImageList[ge]
                        xiaoduanweiNumGe1.sprite = self.dfNumImageList[ge]
                    else
                        if shi > 0 then
                            xiaoduanweiNumBai.sprite = self.dfNumImageList[shi]
                            xiaoduanweiNumBai1.sprite = self.dfNumImageList[shi]
                            xiaoduanweiNumShi.sprite = self.dfNumImageList[ge]
                            xiaoduanweiNumShi1.sprite = self.dfNumImageList[ge]
                            xiaoduanweiNumGe.gameObject:SetActive(false)
                            xiaoduanweiNumGe1.gameObject:SetActive(false)
                        else
                            xiaoduanweiNumBai.sprite = self.dfNumImageList[ge]
                            xiaoduanweiNumBai1.sprite = self.dfNumImageList[ge]
                            xiaoduanweiNumShi.gameObject:SetActive(false)
                            xiaoduanweiNumShi1.gameObject:SetActive(false)
                            xiaoduanweiNumGe.gameObject:SetActive(false)
                            xiaoduanweiNumGe1.gameObject:SetActive(false)
                        end
                    end
                end
                local fakeDF = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng1")
                fakeDF.gameObject:SetActive(false)
                
                -- 显示结算页面
                self.shengduanweiPanel:SetActive(true)
                if ranking_after.level == 7 then
                    self.audioService:PlayClipOneShot(self.JSDFBGMAudio)
                else
                    self.audioService:PlayClipOneShot(self.JiaXBGMAudio)
                end
                
                self.audioService:PlayClipOneShot(self.JXKCAudio)
                self.commonService:StartCoroutine(function ()
                    -- 4.执行开篇动画
                    self.commonService:YieldSeconds(2.75)
                    self:HideDaojishi()
                    -- 5.执行加星星动画
                    if change_score > 0 then
                        -- 执行加星星动画
                        local curStarNum = ranking_before.section_score
                        local addStarNum = change_score
                        local hasUpgrade = false
                        while addStarNum > 0 do
                            if not hasUpgrade then
                                curStarNum = curStarNum % ranking_before.section_total_score + 1
                            else
                                curStarNum = curStarNum % ranking_after.section_total_score + 1
                            end
                            
                            -- 添加判断刚开始就先升段
                            if not hasUpgrade then
                                if addStarNum == change_score and curStarNum == 1 then
                                    if ranking_after.level ~= ranking_before.level then
                                        if ranking_after.level < 7 then
                                            -- 普通段位晋升
                                            hasUpgrade = true
                                            curStarNum = 1
                                            addStarNum = ranking_after.section_score
                                            self.animatior:Play("shengdaduanwei",0,0)
                                            self.audioService:PlayClipOneShot(self.JDDWAudio)
                                            self.commonService:YieldSeconds(1.61)
                                            local xiaoduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                            local daduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1")
                                            xiaoduanwei.gameObject:SetActive(false)
                                            daduanwei.gameObject:SetActive(false)
                                            fakeXZ.gameObject:SetActive(true)
                                            fakeDW.gameObject:SetActive(true)
    
                                            -- 升段位后要把星星变为0
                                            self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_after.section_total_score), self.starRect.anchoredPosition.y)
                                            for i = 1, 10 do
                                                local staryou = self.canvasRect:Find("duanwei/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                                                local image = staryou.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                                local color = image.color
                                                color.a = 0
                                                image.color = color
    
                                                local starWu = self.canvasRect:Find("duanwei/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                                                local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                                local colorbeforeWu = imagebeforeWu.color
                                                if i <= ranking_after.section_total_score then
                                                    colorbeforeWu.a = 1
                                                else
                                                    colorbeforeWu.a = 0
                                                end
                                                imagebeforeWu.color = colorbeforeWu
                                            end
                                        else
                                            -- 王者段位晋升
                                            hasUpgrade = true
                                            curStarNum = 1
                                            addStarNum = ranking_after.section_score
                                            self.animatior:Play("jinshengwangzhe",0,0)
                                            self.audioService:PlayClipOneShot(self.JSDFAudio)
                                            self.commonService:YieldSeconds(2.2)
    
                                            local xiaoduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                            local daduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1")
                                            local daduanwei1 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang_touying")
                                            daduanwei1.gameObject:SetActive(false)
                                            xiaoduanwei.gameObject:SetActive(false)
                                            daduanwei.gameObject:SetActive(false)
    
                                            local star = self.canvasRect:Find("duanwei/zhezhao/Star")
                                            star.gameObject:SetActive(false)
                                            -- 修改fakeDF的位置向下偏移57.6
                                            local pos = fakeDF.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition
                                            pos.y = pos.y - 57.6
                                            fakeDF.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition = pos
                                            -- 修改fakeXZ的位置向下偏移57.6
                                            local pos1 = fakeXZ.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition
                                            pos1.y = pos1.y - 57.6
                                            fakeXZ.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition = pos1
                                            fakeDF.gameObject:SetActive(true)
                                            fakeXZ.gameObject:SetActive(true)
                                            break
                                        end
                                    else
                                        -- 判断是否升小段位
                                        if tonumber(ranking_after.section_name) < tonumber(ranking_before.section_name) then
                                            hasUpgrade = true
                                            curStarNum = 1
                                            addStarNum = ranking_after.section_score
                                            self.animatior:Play("shengxiaoduanwei",0,0)
                                            self.audioService:PlayClipOneShot(self.JXDWAudio)
                                            self.commonService:YieldSeconds(1.38)
                                            local xiaoduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                            xiaoduanwei.gameObject:SetActive(false)
                                            fakeDW.gameObject:SetActive(true)
    
                                            -- 升段位后要把星星变为0
                                            self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_after.section_total_score), self.starRect.anchoredPosition.y)
                                            for i = 1, 10 do
                                                local staryou = self.canvasRect:Find("duanwei/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                                                local image = staryou.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                                local color = image.color
                                                color.a = 0
                                                image.color = color
    
                                                local starWu = self.canvasRect:Find("duanwei/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                                                local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                                local colorbeforeWu = imagebeforeWu.color
                                                if i <= ranking_after.section_total_score then
                                                    colorbeforeWu.a = 1
                                                else
                                                    colorbeforeWu.a = 0
                                                end
                                                imagebeforeWu.color = colorbeforeWu
                                            end
                                        end
                                    end
                                end
                            end
                            
                            if is_protect and protect_score > 0 and addStarNum <= protect_score then
                                local totaoStar = ranking_before.section_total_score

                                if hasUpgrade then
                                    totaoStar = ranking_after.section_total_score
                                end

                                if totaoStar % 2 == 1 then
                                    -- 多余
                                    local extraStar = (9 - totaoStar) / 2
                                    self.animatior:Play("scjx-" .. math.floor(curStarNum + extraStar) .. " odd",0,0)
                                else
                                    local extraStar = (10 - totaoStar) / 2
                                    self.animatior:Play("scjx-" .. math.floor(curStarNum + extraStar),0,0)
                                end

                                self.commonService:YieldSeconds(1.22)
                            else
                                if curStarNum < 10 then
                                    self.animatior:Play("star_feiru_0" .. curStarNum,0,0)
                                else
                                    self.animatior:Play("star_feiru_" .. curStarNum,0,0)
                                end
                            end

                            self.audioService:PlayClipOneShot(self.JXAudio)
                            self.commonService:YieldSeconds(1.16)
                            
                            -- 设置播放后星星显示
                            local staryouAfter = self.canvasRect:Find("duanwei/zhezhao/Star/Star_you_fin/Star_you (" .. curStarNum ..")")
                            local imageAfter = staryouAfter.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                            local colorAfter = imageAfter.color
                            colorAfter.a = 1
                            imageAfter.color = colorAfter

                            if not hasUpgrade then
                                -- 星星数量和当前等级星星数一样的时候，需要升段位
                                if curStarNum == ranking_before.section_total_score then
                                    if ranking_after.level ~= ranking_before.level then
                                        if ranking_after.level < 7 then
                                            -- 普通段位晋升
                                            hasUpgrade = true
                                            curStarNum = 0
                                            addStarNum = ranking_after.section_score + 1
                                            self.animatior:Play("shengdaduanwei",0,0)
                                            self.audioService:PlayClipOneShot(self.JDDWAudio)
                                            self.commonService:YieldSeconds(1.61)
                                            local xiaoduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                            local daduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1")
                                            xiaoduanwei.gameObject:SetActive(false)
                                            daduanwei.gameObject:SetActive(false)
                                            fakeXZ.gameObject:SetActive(true)
                                            fakeDW.gameObject:SetActive(true)

                                            -- 升段位后要把星星变为0
                                            self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_after.section_total_score), self.starRect.anchoredPosition.y)
                                            for i = 1, 10 do
                                                local staryou = self.canvasRect:Find("duanwei/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                                                local image = staryou.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                                local color = image.color
                                                color.a = 0
                                                image.color = color

                                                local starWu = self.canvasRect:Find("duanwei/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                                                local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                                local colorbeforeWu = imagebeforeWu.color
                                                if i <= ranking_after.section_total_score then
                                                    colorbeforeWu.a = 1
                                                else
                                                    colorbeforeWu.a = 0
                                                end
                                                imagebeforeWu.color = colorbeforeWu
                                            end
                                        else
                                            -- 王者段位晋升
                                            hasUpgrade = true
                                            curStarNum = 0
                                            addStarNum = ranking_after.section_score + 1
                                            self.animatior:Play("jinshengwangzhe",0,0)
                                            self.audioService:PlayClipOneShot(self.JSDFAudio)
                                            self.commonService:YieldSeconds(2.2)

                                            local xiaoduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                            local daduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1")
                                            local daduanwei1 = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang_touying")
                                            daduanwei1.gameObject:SetActive(false)
                                            xiaoduanwei.gameObject:SetActive(false)
                                            daduanwei.gameObject:SetActive(false)

                                            local star = self.canvasRect:Find("duanwei/zhezhao/Star")
                                            star.gameObject:SetActive(false)
                                            -- 修改fakeDF的位置向下偏移57.6
                                            local pos = fakeDF.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition
                                            pos.y = pos.y - 57.6
                                            fakeDF.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition = pos
                                            -- 修改fakeXZ的位置向下偏移57.6
                                            local pos1 = fakeXZ.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition
                                            pos1.y = pos1.y - 57.6
                                            fakeXZ.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform)).anchoredPosition = pos1
                                            fakeDF.gameObject:SetActive(true)
                                            fakeXZ.gameObject:SetActive(true)
                                            break
                                        end
                                    else
                                        -- 判断是否升小段位
                                        if tonumber(ranking_after.section_name) < tonumber(ranking_before.section_name) then
                                            hasUpgrade = true
                                            curStarNum = 0
                                            addStarNum = ranking_after.section_score + 1
                                            self.animatior:Play("shengxiaoduanwei",0,0)
                                            self.audioService:PlayClipOneShot(self.JXDWAudio)
                                            self.commonService:YieldSeconds(1.38)
                                            local xiaoduanwei = self.canvasRect:Find("duanwei/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                            xiaoduanwei.gameObject:SetActive(false)
                                            fakeDW.gameObject:SetActive(true)

                                            -- 升段位后要把星星变为0
                                            self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_after.section_total_score), self.starRect.anchoredPosition.y)
                                            for i = 1, 10 do
                                                local staryou = self.canvasRect:Find("duanwei/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                                                local image = staryou.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                                local color = image.color
                                                color.a = 0
                                                image.color = color

                                                local starWu = self.canvasRect:Find("duanwei/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                                                local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                                local colorbeforeWu = imagebeforeWu.color
                                                if i <= ranking_after.section_total_score then
                                                    colorbeforeWu.a = 1
                                                else
                                                    colorbeforeWu.a = 0
                                                end
                                                imagebeforeWu.color = colorbeforeWu
                                            end
                                        end
                                    end
                                end
                            end

                            addStarNum = addStarNum - 1
                        end
                    end

                    -- 7.定格出现退出按钮
                    self.closeBtnRoot.gameObject:SetActive(true)
                    self.animatior:Play("jiaxing",0,0)
                    self.commonService:YieldSeconds(1)
                end)
            end
        else
            -- 巅峰减分
            if ranking_before.level == 7 and ranking_after.level == 7 then
                self.canvasRect = self.dianfengjianPanel.transform:Find("Canvas")
                self.canvas = self.canvasRect.gameObject:GetComponent(typeof(CS.UnityEngine.Canvas))
                self.canvas.sortingOrder = sortOrder

                if isFailed == true then
                    local weitongguoObj = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/mingci_jiaxing")
                    weitongguoObj.gameObject:SetActive(false)
                else
                    local weitongguoObj = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/mingci")
                    weitongguoObj.gameObject:SetActive(false)
                end

                -- self.closeBtn = self.canvasRect:Find("dianfeng/zhezhao/Group 1321315159/Button").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
                -- -- 添加返回按钮事件
                -- self.commonService:AddEventListener(self.closeBtn, "onClick", function()
                --     log("回到ABCZone")
                --     self.dianfengjianPanel:SetActive(false)
                --     App:GameReturn()
                -- end)

                self.closeBtn = self.canvasRect:Find("dianfeng/zhezhao/anjian/tuichu")
                self.againBtn = self.canvasRect:Find("dianfeng/zhezhao/anjian/zailianyiju")
                if btnCallBack then
                    btnCallBack(self.closeBtn, self.againBtn)
                end

                -- 判断个人赛团队赛
                local diyiming = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/mingci_jiaxing/mc/diyiming")
                local huosheng = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/mingci_jiaxing/mc/shibai")
                local jingyan = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/jingyan")
                local jingyan2 = self.canvasRect:Find("dianfeng/zhezhao/mingci_jingyan/jingyan2")

                if type and type == 2 then
                    if diyiming and jingyan then
                        diyiming.gameObject:SetActive(false)
                        jingyan.gameObject:SetActive(false)
                        huosheng.gameObject:SetActive(true)
                        jingyan2.gameObject:SetActive(true)
                    end
                    -- 设置第几名
                    local rankText = jingyan2:Find("text/Text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                    if rankText and rank then
                        -- rank 转汉字
                        local numChinese = self:num2Chinese(rank)
                        rankText.text = "第" .. numChinese .. "名"
                    end
                    -- 设置加几分
                    local jingyanText = jingyan2:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                    if jingyanText then
                        if change_score >= 0 then
                            jingyanText.text = "+" .. change_score
                            g_Log("设置加分")
                        else
                            jingyanText.text = change_score
                            g_Log("设置减分")
                        end
                    end
                else
                    if diyiming and jingyan then
                        diyiming.gameObject:SetActive(true)
                        jingyan.gameObject:SetActive(true)
                        huosheng.gameObject:SetActive(false)
                        jingyan2.gameObject:SetActive(false)
                    end

                    self.rankImage = diyiming:Find("3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    -- 1.设置第几名
                    if self.rankImage and rank then
                        g_Log("设置名次")
                        self.rankImage.sprite = self.noYellowImageList[rank]
                    end
                    -- 2.设置加几分
                    self.jingyan = jingyan:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                    if self.jingyan then
                        if change_score >= 0 then
                            self.jingyan.text = "+" .. change_score
                            g_Log("设置加分")
                        else
                            self.jingyan.text = change_score
                            g_Log("设置减分")
                        end
                    end
                end

                -- 3.设置加分前状态 
                -- 巅峰段位
                local xiaoduanweiNumQian = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_01/qian_01").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumBai = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_02/bai_01").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumShi = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_03/shi_01").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumGe = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_04/ge_01").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumAdd = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_05/+").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumQian1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_01/qian_02").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumBai1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_02/bai_02").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumShi1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_03/shi_02").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumGe1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_04/ge_02").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNumAdd1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_05/+").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))

                self:DianfengNum(xiaoduanweiNumQian, xiaoduanweiNumBai, xiaoduanweiNumShi, xiaoduanweiNumGe, xiaoduanweiNumAdd, ranking_before.section_score)
                self:DianfengNum(xiaoduanweiNumQian1, xiaoduanweiNumBai1, xiaoduanweiNumShi1, xiaoduanweiNumGe1, xiaoduanweiNumAdd1, ranking_after.section_score)
                if ranking_before.section_score > 9999 then
                    xiaoduanweiNumAdd1.gameObject:SetActive(true)
                end

                local MaskRect = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask"):GetComponent(typeof(CS.UnityEngine.RectTransform))
                -- 设置锚点
                if ranking_after.section_score > 9999 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(-30, 0)
                elseif ranking_after.section_score > 999 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(-16, 0)
                elseif ranking_after.section_score > 99 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(-1, 0)
                elseif ranking_after.section_score > 9 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(16, 0)
                elseif ranking_after.section_score >= 0 then
                    MaskRect.anchoredPosition = CS.UnityEngine.Vector2(30, 0)
                end

                self.dianfengjianPanel:SetActive(true)
                self.commonService:StartCoroutine(function()
                    self.commonService:YieldSeconds(2.75)
                    self:ShowDaojishi()
                    local shuziAni1 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_01").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    local shuziAni2 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_02").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    local shuziAni3 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_03").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    local shuziAni4 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_04").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    local shuziAni5 = self.canvasRect:Find("dianfeng/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shuzi_jian_05").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))
                    shuziAni1:Play("shuzi_01_jian_1")
                    shuziAni2:Play("shuzi_jian_02")
                    shuziAni3:Play("shuzi_03_jian_1")
                    shuziAni4:Play("shuzi_04_jian_1")
                    if ranking_after.section_score < 10000 then
                        shuziAni5:Play("shuzi_05_jian_1")
                    end

                    self.audioService:PlayClipOneShot(self.DDDFAudio)
                end)
                self.audioService:PlayClipOneShot(self.DXKCAudio)
                self.audioService:PlayClipOneShot(self.DFDFBGMAudio)
            else
                -- 普通段位未通过
                self.canvasRect = self.weitongguoPanel.transform:Find("Canvas")
                self.canvas = self.canvasRect.gameObject:GetComponent(typeof(CS.UnityEngine.Canvas))
                self.canvas.sortingOrder = sortOrder

                if isFailed == true then
                    local weitongguoObj = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan/mingci_jiaxing")
                    weitongguoObj.gameObject:SetActive(false)
                else
                    local weitongguoObj = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan/mingci")
                    weitongguoObj.gameObject:SetActive(false)
                end

                self.closeBtnRoot = self.canvasRect:Find("weitongguo/zhezhao/anjian")
                -- self.closeBtn = self.canvasRect:Find("weitongguo/zhezhao/Group 1321315159/Button").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Button))
                -- -- 添加返回按钮事件
                -- self.commonService:AddEventListener(self.closeBtn, "onClick", function()
                --     log("回到ABCZone")
                --     self.weitongguoPanel:SetActive(false)
                --     App:GameReturn()
                -- end)
                self.closeBtn = self.canvasRect:Find("weitongguo/zhezhao/anjian/tuichu")
                self.againBtn = self.canvasRect:Find("weitongguo/zhezhao/anjian/zailianyiju")
                if btnCallBack then
                    btnCallBack(self.closeBtn, self.againBtn)
                end
                self.closeBtnRoot.gameObject:SetActive(false)

                self.animatior = self.canvasRect:Find("weitongguo").gameObject:GetComponent(typeof(CS.UnityEngine.Animator))


                -- 判断个人赛团队赛
                local diyiming = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan/mingci_jiaxing/mc/diyiming")
                local huosheng = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan/mingci_jiaxing/mc/shibai")
                local jingyan = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan/jingyan")
                local jingyan2 = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan/jingyan2")

                if type and type == 2 then
                    if diyiming and jingyan then
                        diyiming.gameObject:SetActive(false)
                        jingyan.gameObject:SetActive(false)
                        huosheng.gameObject:SetActive(true)
                        jingyan2.gameObject:SetActive(true)
                    end
                    -- 设置第几名
                    local rankText = jingyan2:Find("text/Text").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                    if rankText and rank then
                        -- rank 转汉字
                        local numChinese = self:num2Chinese(rank)
                        rankText.text = "第" .. numChinese .. "名"
                    end
                    -- 设置加几分
                    local jingyanText = jingyan2:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                    if jingyanText then
                        if change_score >= 0 then
                            jingyanText.text = "+" .. change_score
                            g_Log("设置加分")
                        else
                            jingyanText.text = change_score
                            g_Log("设置减分")
                        end
                    end
                else
                    if diyiming and jingyan then
                        diyiming.gameObject:SetActive(true)
                        jingyan.gameObject:SetActive(true)
                        huosheng.gameObject:SetActive(false)
                        jingyan2.gameObject:SetActive(false)
                    end

                    self.rankImage = diyiming:Find("3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    -- 1.设置第几名
                    if self.rankImage and rank then
                        g_Log("设置名次")
                        self.rankImage.sprite = self.noYellowImageList[rank]
                    end
                    -- 2.设置加几分
                    self.jingyan = jingyan:Find("Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                    if self.jingyan then
                        if change_score >= 0 then
                            self.jingyan.text = "+" .. change_score
                            g_Log("设置加分")
                        else
                            self.jingyan.text = change_score
                            g_Log("设置减分")
                        end
                    end
                end
                -- if type and type == 2 then
                --     local personal = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan")
                --     personal.gameObject:SetActive(false)
                --     -- 设置第几名
                --     local rankText = self.canvasRect:Find("mingci_jingyan_team/mingci/rank").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Text))
                --     if rankText and rank then
                --         -- rank 转汉字
                --         local numChinese = self:num2Chinese(rank)
                --         rankText.text = "第" .. numChinese .. "名"
                --     end
                --     -- 设置加几分
                --     local jingyanText = self.canvasRect:Find("mingci_jingyan_team/jingyan/Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                --     if jingyanText then
                --         if change_score >= 0 then
                --             jingyanText.text = "+" .. change_score
                --             g_Log("设置加分")
                --         else
                --             jingyanText.text = change_score
                --             g_Log("设置减分")
                --         end
                --     end
                -- else
                --     local team = self.canvasRect:Find("mingci_jingyan_team")
                --     team.gameObject:SetActive(false)

                --     self.rankImage = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan/mingci_jiaxing/mc/3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                --     -- 1.设置第几名
                --     if self.rankImage and rank then
                --         g_Log("设置名次")
                --         self.rankImage.sprite = self.noYellowImageList[rank]
                --     end

                --     -- 2.设置加几分
                --     self.jingyan = self.canvasRect:Find("weitongguo/zhezhao/mingci_jingyan/jingyan/Rectangle_jy/Rectangle_jy (1)").gameObject:GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
                --     if self.jingyan then
                --         if change_score >= 0 then
                --             self.jingyan.text = "+" .. change_score
                --             g_Log("设置加分")
                --         else
                --             self.jingyan.text = change_score
                --             g_Log("设置减分")
                --         end
                --     end
                -- end

                -- 3.设置减分前状态 
                -- 控制隐藏节点
                -- 星星
                self.starRoot = self.canvasRect:Find("weitongguo/zhezhao/Star")
                self.starRect = self.starRoot.gameObject:GetComponent(typeof(CS.UnityEngine.RectTransform))
                self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_before.section_total_score), self.starRect.anchoredPosition.y)
                for i = 1, 10 do
                    local star = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                    local imagebefore = star.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local colorbefore = imagebefore.color
                    if i <= ranking_before.section_score then
                        colorbefore.a = 1
                    else
                        g_Log("初始化隐藏第" .. i .. "颗星星")
                        colorbefore.a = 0
                    end
                    imagebefore.color = colorbefore

                    local star1 = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_you/Star_you (" .. i ..")")
                    local imagebefore1 = star1.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local colorbefore1 = imagebefore1.color
                    colorbefore1.a = 0
                    imagebefore1.color = colorbefore1

                    local starWu = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                    local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local colorbeforeWu = imagebeforeWu.color
                    if i <= ranking_before.section_total_score then
                        colorbeforeWu.a = 1
                    else
                        colorbeforeWu.a = 0
                    end
                    imagebeforeWu.color = colorbeforeWu
                end
                -- 段位
                local xiaoduanweiName = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_3/qingtong").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNum = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_3/3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                xiaoduanweiName.sprite = self.RankNameImageList[ranking_after.level]
                xiaoduanweiNum.sprite = self.SectionImageList[tonumber(ranking_after.section_name)]
                local fakeDW = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_3")
                fakeDW.gameObject:SetActive(false)

                local xiaoduanweiName1 = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1/baiyin").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNum2 = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1/4").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                xiaoduanweiName1.sprite = self.RankNameImageList[ranking_before.level]
                xiaoduanweiNum2.sprite = self.SectionImageList[tonumber(ranking_before.section_name)]
                local xiaoduanweiName3 = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_2/qingtong").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                local xiaoduanweiNum4 = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_2/3").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                xiaoduanweiName3.sprite = self.RankNameImageList[ranking_after.level]
                xiaoduanweiNum4.sprite = self.SectionImageList[tonumber(ranking_after.section_name)]

                -- 勋章
                local daduanweiImagef = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_3/xunzhang_qingtong").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                daduanweiImagef.sprite = self.RankImageList[ranking_after.level]
                local fakeXZ = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_3")
                fakeXZ.gameObject:SetActive(false)

                local daduanweiImage1 = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1/xunzhang_baiyin").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                daduanweiImage1.sprite = self.RankImageList[ranking_before.level]
                local daduanweiImage3 = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_2/xunzhang_qingtong").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                daduanweiImage3.sprite = self.RankImageList[ranking_after.level]
                -- 巅峰段位
                if ranking_before.level == 7 then
                    -- 将巅峰段位显示出来，普通段位信息隐藏
                    local normalduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei")
                    normalduanwei.gameObject:GetComponent(typeof(CS.UnityEngine.CanvasGroup)).alpha = 0

                    local dianfengduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng")
                    dianfengduanwei.gameObject:GetComponent(typeof(CS.UnityEngine.CanvasGroup)).alpha = 1
                    local xiaoduanweiName = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/dianfeng").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumBai = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/bai").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumShi = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/shi").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    local xiaoduanweiNumGe = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei_dianfeng/Mask/shuzi/ge").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                    xiaoduanweiName.sprite = self.RankNameImageList[ranking_before.level]
                    local bai = math.floor(ranking_before.section_score / 100)
                    local shi = math.floor((ranking_before.section_score - bai * 100) / 10)
                    local ge = ranking_before.section_score - bai * 100 - shi * 10
                    if bai > 0 then
                        xiaoduanweiNumBai.sprite = self.dfNumImageList[bai]
                        xiaoduanweiNumShi.sprite = self.dfNumImageList[shi]
                        xiaoduanweiNumGe.sprite = self.dfNumImageList[ge]
                    else
                        if shi > 0 then
                            xiaoduanweiNumBai.sprite = self.dfNumImageList[shi]
                            xiaoduanweiNumShi.sprite = self.dfNumImageList[ge]
                            xiaoduanweiNumGe.gameObject:SetActive(false)
                        else
                            xiaoduanweiNumBai.sprite = self.dfNumImageList[ge]
                            xiaoduanweiNumShi.gameObject:SetActive(false)
                            xiaoduanweiNumGe.gameObject:SetActive(false)
                        end
                    end
                    if ranking_after.level < 7 then
                        for i = 1, 10 do
                            local star = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_you/Star_you (" .. i ..")")
                            local imagebefore = star.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                            local colorbefore = imagebefore.color
                            if i <= ranking_after.section_score then
                                colorbefore.a = 1
                            else
                                colorbefore.a = 0
                            end
                            imagebefore.color = colorbefore
                        end
                        local xiaoduanweiName1 = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1/baiyin").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                        local xiaoduanweiNum2 = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1/4").gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                        xiaoduanweiName1.sprite = self.RankNameImageList[ranking_after.level]
                        xiaoduanweiNum2.sprite = self.SectionImageList[tonumber(ranking_after.section_name)]
                    end

                    self.starYouRoot = self.canvasRect:Find("weitongguo/zhezhao/Star")
                    self.starYouRoot.gameObject:SetActive(false)
                end
                
                -- 显示结算页面
                self.weitongguoPanel:SetActive(true)
                self.audioService:PlayClipOneShot(self.DXKCAudio)
                if ranking_after.level < 7 then
                    self.audioService:PlayClipOneShot(self.DFDLBGMAudio)
                else
                    self.audioService:PlayClipOneShot(self.JianXBGMAudio)
                end
                
                self.commonService:StartCoroutine(function ()
                    -- 4.执行开篇动画
                    if ranking_before.level == 7 and ranking_after.level < 7 then
                        self.animatior:Play("weitongguo_02",0,0)
                    end
                    
                    self.commonService:YieldSeconds(2.75)
                    self:ShowDaojishi()
                    -- 5.执行加星星动画
                    if change_score < 0 then
                        -- 执行加星星动画
                        local curStarNum = ranking_before.section_score
                        local addStarNum = change_score
                        local isDFDL = false
                        -- 执行巅峰掉落
                        if ranking_after.level ~= ranking_before.level then
                            if ranking_before.level ==  7 then
                                g_Log("从巅峰掉落")
                                isDFDL = true
                                local starXS = self.canvasRect:Find("weitongguo/zhezhao/Star/star_xiaoshi")
                                starXS.gameObject:SetActive(false)
                                -- 王者段位掉落
                                self.animatior:Play("dianfengdiaoluo",0,0)
                                self.audioService:PlayClipOneShot(self.DDDLAudio)
                                self.commonService:YieldSeconds(3)
                                self.starYouRoot.gameObject:SetActive(true)
                                local xiaoduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                local daduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1")
                                xiaoduanwei.gameObject:SetActive(false)
                                daduanwei.gameObject:SetActive(false)

                                fakeXZ.gameObject:SetActive(true)
                                fakeDW.gameObject:SetActive(true)
                                self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_after.section_total_score), self.starRect.anchoredPosition.y)
                                for i = 1, 10 do
                                    local star = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                                    local imagebefore = star.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                    local colorbefore = imagebefore.color
                                    if i <= ranking_after.section_score then
                                        colorbefore.a = 1
                                    else
                                        colorbefore.a = 0
                                    end
                                    imagebefore.color = colorbefore

                                    local starWu = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                                    local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                    local colorbeforeWu = imagebeforeWu.color
                                    if i <= ranking_after.section_total_score then
                                        colorbeforeWu.a = 1
                                    else
                                        colorbeforeWu.a = 0
                                    end
                                    imagebeforeWu.color = colorbeforeWu
                                end
                            end
                        end

                        while addStarNum < 0 and isDFDL == false do
                            -- 设置播放后星星显示
                            for i = 1, 10 do
                                local staryouAfter = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                                local imageAfter = staryouAfter.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                local colorAfter = imageAfter.color
                                if i < curStarNum then
                                    colorAfter.a = 1
                                else
                                    colorAfter.a = 0
                                end
                                imageAfter.color = colorAfter
                            end

                            local starXS = self.canvasRect:Find("weitongguo/zhezhao/Star/star_xiaoshi")
                            starXS.gameObject:SetActive(true)
                            if curStarNum == 0 then
                            else
                                if curStarNum < 10 then
                                    self.animatior:Play("jianxing_0" .. curStarNum,0,0)
                                else
                                    self.animatior:Play("jianxing_" .. curStarNum,0,0)
                                end
                                self.audioService:PlayClipOneShot(self.DXAudio)
                                self.commonService:YieldSeconds(0.5)
                            end
                            starXS.gameObject:SetActive(false)
                            -- 1颗星星的时候，去掉需要掉落段位
                            if curStarNum == 1 then
                                if ranking_after.level ~= ranking_before.level then
                                    -- -- 普通段位掉落
                                    self.animatior:Play("diaodaduanwei",0,0)
                                    self.audioService:PlayClipOneShot(self.DDDWAudio)
                                    self.commonService:YieldSeconds(1.5)
                                    local xiaoduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                    local daduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1")
                                    xiaoduanwei.gameObject:SetActive(false)
                                    daduanwei.gameObject:SetActive(false)
                                    fakeXZ.gameObject:SetActive(true)
                                    fakeDW.gameObject:SetActive(true)
                                else
                                    -- 判断是否掉落小段位
                                    if tonumber(ranking_after.section_name) > tonumber(ranking_before.section_name) then
                                        self.animatior:Play("diaoxiaoduanwei",0,0)
                                        self.audioService:PlayClipOneShot(self.DXDWAudio)
                                        self.commonService:YieldSeconds(1)
                                        local xiaoduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                        xiaoduanwei.gameObject:SetActive(false)
                                        fakeDW.gameObject:SetActive(true)
                                    end
                                end
                                -- 掉段位后要把星星变为10
                                self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_after.section_total_score), self.starRect.anchoredPosition.y)
                                for i = 1, 10 do
                                    local star = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                                    local imagebefore = star.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                    local colorbefore = imagebefore.color
                                    if i <= ranking_after.section_score then
                                        colorbefore.a = 1
                                    else
                                        colorbefore.a = 0
                                    end
                                    imagebefore.color = colorbefore

                                    local starWu = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                                    local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                    local colorbeforeWu = imagebeforeWu.color
                                    if i <= ranking_after.section_total_score then
                                        colorbeforeWu.a = 1
                                    else
                                        colorbeforeWu.a = 0
                                    end
                                    imagebeforeWu.color = colorbeforeWu
                                end

                                curStarNum = ranking_after.section_total_score
                                addStarNum = addStarNum + 1
                            elseif curStarNum == 0 then
                                if ranking_after.level ~= ranking_before.level then
                                    -- -- 普通段位掉落
                                    self.animatior:Play("diaodaduanwei",0,0)
                                    self.audioService:PlayClipOneShot(self.DDDWAudio)
                                    self.commonService:YieldSeconds(1.5)
                                    local xiaoduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                    local daduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/xunzhang/xunzhang_1")
                                    xiaoduanwei.gameObject:SetActive(false)
                                    daduanwei.gameObject:SetActive(false)
                                    fakeXZ.gameObject:SetActive(true)
                                    fakeDW.gameObject:SetActive(true)
                                else
                                    -- 判断是否掉落小段位
                                    if tonumber(ranking_after.section_name) > tonumber(ranking_before.section_name) then
                                        self.animatior:Play("diaoxiaoduanwei",0,0)
                                        self.audioService:PlayClipOneShot(self.DXDWAudio)
                                        self.commonService:YieldSeconds(1)
                                        local xiaoduanwei = self.canvasRect:Find("weitongguo/zhezhao/duanwei+shengji/xunzhang+duanwei/duanwei/Mask/duanwei_1")
                                        xiaoduanwei.gameObject:SetActive(false)
                                        fakeDW.gameObject:SetActive(true)
                                    end
                                end
                                -- 掉段位后要把星星变为10
                                self.starRect.anchoredPosition = CS.UnityEngine.Vector2(30 * (10 - ranking_after.section_total_score), self.starRect.anchoredPosition.y)
                                for i = 1, 10 do
                                    local star = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_you_fin/Star_you (" .. i ..")")
                                    local imagebefore = star.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                    local colorbefore = imagebefore.color
                                    if i <= ranking_after.section_total_score then
                                        colorbefore.a = 1
                                    else
                                        colorbefore.a = 0
                                    end
                                    imagebefore.color = colorbefore

                                    local starWu = self.canvasRect:Find("weitongguo/zhezhao/Star/Star_wu/Star_wu (" .. i ..")")
                                    local imagebeforeWu = starWu.gameObject:GetComponent(typeof(CS.UnityEngine.UI.Image))
                                    local colorbeforeWu = imagebeforeWu.color
                                    if i <= ranking_after.section_total_score then
                                        colorbeforeWu.a = 1
                                    else
                                        colorbeforeWu.a = 0
                                    end
                                    imagebeforeWu.color = colorbeforeWu
                                end

                                curStarNum = ranking_after.section_total_score
                                addStarNum = addStarNum
                            else
                                addStarNum = addStarNum + 1
                                curStarNum = curStarNum - 1
                            end
                        end
                    end

                    -- 7.定格出现退出按钮
                    local starXS = self.canvasRect:Find("weitongguo/zhezhao/Star/star_xiaoshi")
                    starXS.gameObject:SetActive(false)
                    self.closeBtnRoot.gameObject:SetActive(true)
                    self.animatior:Play("diaoxing",0,0)
                    self.commonService:YieldSeconds(1)
                end)
                self.weitongguoPanel:SetActive(true)
            end
        end
    end)

    -- 新增隐藏界面
    self.BusEventService:Watch("HIDE_GAME_RANK_RESULT_PANEL", function(key, args) 
        self.shengduanweiPanel.gameObject:SetActive(false)
    end)
end

-- 数字转汉字
function GameRank:num2Chinese(num)
    local rankStr = ""
    if num then
        if num == 1 then
            rankStr = "一"
        elseif num == 2 then
            rankStr = "二"
        elseif num == 3 then
            rankStr = "三"
        elseif num == 4 then
            rankStr = "四"
        elseif num == 5 then
            rankStr = "五"
        elseif num == 6 then
            rankStr = "六"
        elseif num == 7 then
            rankStr = "七"
        elseif num == 8 then
            rankStr = "八"
        elseif num == 9 then
            rankStr = "九"
        elseif num == 10 then
            rankStr = "十"
        end
        
    end
    return rankStr
end

function GameRank:DianfengNum(imageQian,imageBai,imageShi,imageGe,imageAdd,num)
    -- 计算
    local qian = math.floor(num / 1000)
    local bai = math.floor(num / 100 - qian * 10)
    local shi = math.floor(num / 10 - qian * 100 - bai * 10)
    local ge = num % 10
    
    if num > 9999 then
        imageAdd.gameObject:SetActive(true)
        imageQian.sprite = self.dfNumImageList[9]
        imageBai.sprite = self.dfNumImageList[9]
        imageShi.sprite = self.dfNumImageList[9]
        imageGe.sprite = self.dfNumImageList[9]
    elseif num > 999 then
        imageAdd.gameObject:SetActive(false)
        imageQian.sprite = self.dfNumImageList[qian]
        imageBai.sprite = self.dfNumImageList[bai]
        imageShi.sprite = self.dfNumImageList[shi]
        imageGe.sprite = self.dfNumImageList[ge]
    elseif num > 99 then
        imageAdd.gameObject:SetActive(false)
        imageGe.gameObject:SetActive(false)
        imageQian.sprite = self.dfNumImageList[bai]
        imageBai.sprite = self.dfNumImageList[shi]
        imageShi.sprite = self.dfNumImageList[ge]
    elseif num > 9 then
        imageAdd.gameObject:SetActive(false)
        imageGe.gameObject:SetActive(false)
        imageShi.gameObject:SetActive(false)
        imageQian.sprite = self.dfNumImageList[shi]
        imageBai.sprite = self.dfNumImageList[ge]
    elseif num >= 0 then
        imageAdd.gameObject:SetActive(false)
        imageGe.gameObject:SetActive(false)
        imageShi.gameObject:SetActive(false)
        imageBai.gameObject:SetActive(false)
        imageQian.sprite = self.dfNumImageList[ge]
    end
end

--显示倒计时
function GameRank:ShowDaojishi()
    if self.ishowDaojishi == nil or self.ishowDaojishi == false then  
        return
    end
    self.nextTxt = self.daojishiPanel.transform:Find("right/nextTxt"):GetComponent(typeof(CS.UnityEngine.UI.Text))
    self.nextTxt.text = "下一步  (" .. 5 .. "s)"
    self:StartCountDownTime()
    self.daojishiCanvas = self.daojishiPanel.transform:GetComponent(typeof(CS.UnityEngine.Canvas))
    self.daojishiCanvas.sortingOrder = 1210
    self.nextBtn = self.daojishiPanel.transform:Find("right/nextBtn"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    self.commonService:AddEventListener(self.nextBtn, "onClick", function()
        self:CloseAllPanels()
    end)

    self.daojishiPanel:SetActive(true)
end
--隐藏倒计时
function GameRank:HideDaojishi()
    if self.ishowDaojishi == nil or self.ishowDaojishi == false then  
        return
    end
    self:StopCountDownTime()
    self.daojishiPanel:SetActive(false)
end
---开始倒计时
function GameRank:StartCountDownTime()
    self.countDownTime = 5
    self.countDownCoroutine = self.commonService:StartCoroutine(function()
        while self.countDownTime > 0 do
            self.commonService:YieldSeconds(1)
            self.countDownTime = self.countDownTime - 1
            if self.nextTxt then
                self.nextTxt.text = "下一步  (" .. self.countDownTime .. "s)"
            end
        end
        -- 倒计时结束，自动执行下一步
        if self.countDownTime <= 0 then
            self:Print("倒计时结束，自动执行下一步")
            self:CloseAllPanels()
        end
    end)
end
---停止倒计时
function GameRank:StopCountDownTime()
    if self.countDownCoroutine then
        self:StopCoroutineSafely(self.countDownCoroutine)
        self.countDownCoroutine = nil
    end
end
-- 添加一个统一的关闭方法
function GameRank:CloseAllPanels()
    -- 停止倒计时
    self:HideDaojishi()
    self.canvasRect.gameObject:SetActive(false)
    -- 隐藏所有面板
    if self.shengduanweiPanel then self.shengduanweiPanel:SetActive(false) end
    if self.weitongguoPanel then self.weitongguoPanel:SetActive(false) end
    if self.dianfengaddPanel then self.dianfengaddPanel:SetActive(false) end
    if self.dianfengjianPanel then self.dianfengjianPanel:SetActive(false) end
    if self.daojishiPanel then self.daojishiPanel:SetActive(false) end
    -- 触发关闭事件（如果其他系统需要知道）
    self.BusEventService:Fire("GAME_RANK_RESULT_PANEL_CLOSE_BTN_CLICK")
end


-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function GameRank:ReceiveMessage(key, value, isResume)

end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function GameRank:SendCustomMessage(key, body)
    self:SendMessage(key,body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function GameRank:SelfAvatarCreated(avatar)
end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function GameRank:SelfAvatarPrefabLoaded(avatar)
    
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function GameRank:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function GameRank:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function GameRank:LogicMapStartRecover()
    GameRank.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function GameRank:LogicMapEndRecover()
    GameRank.super:LogicMapEndRecover(self)
end
--所有的组件恢复完成
function GameRank:LogicMapAllComponentRecoverComplete()
    
end

--收到Trigger事件
function GameRank : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function GameRank : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function GameRank:Exit()
    GameRank.super.Exit(self)
end

return GameRank
 

