---
---  Author: 【author】
---  AuthorID: 【authorID】
---  CreateTime: 【createTime】
--- 【FSync】
--- 【排行榜】
---
local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")
local json = require("nextjson")
local FsyncElement = class("minirank", WBElement)

local idx = 0
function FsyncElement:Tick()

    local count = 10
    if App:IsLowDevice() then
        count = 20
    end

    if self.rankData and idx % count == 0 then
        self:RefreshUI(self.rankData)
        self.rankData = nil
        idx = 0
    end
    idx = idx + 1
end
function FsyncElement:FetchRealTimeInMS(str)

    -- if App.IsStudioClient then
    --     if str == nil then
    --         self.logTime = os.clock() * 1000;
    --     else
    --         g_LogError(str .. ":" .. (os.clock() * 1000 - self.logTime))
    --     end
    -- end

end
function FsyncElement:RefreshUI(data)
    -- g_Log("客户端:收到刷新排行榜UI信息", table.dump(data))

    -- 清理上次的排行榜内容
    local baseObje = self.baseObje
    local slider = self.slider
    local tmp = {}
    for i = 0, slider.childCount - 1, 1 do
        local go = slider:GetChild(i).gameObject
        go.gameObject:SetActive(false)
    end

    -- 排序
    local index = 1
    local i = 0;
    for k, v in pairs(data) do
        self:FetchRealTimeInMS()

        local value = data[k]
        local rankObj = nil

        local reUsed = false
        if slider.childCount >= i + 1 then
            reUsed = true
            rankObj = slider:GetChild(i).gameObject
        else
            rankObj = CS.UnityEngine.GameObject.Instantiate(baseObje.gameObject, slider.transform)

            rankObj.transform:SetParent(slider.transform)
            rankObj.transform.name = "排行榜名次(拷贝)"
        end
        rankObj.gameObject:SetActive(true)

        i = i + 1
        local content = nil
        local showHighlight = false
        -- 前三名
        if index < 4 then
            if value.highlight then
                showHighlight = true
            end
        end

        if showHighlight then
            rankObj.transform:Find("highlight").gameObject:SetActive(true)
            rankObj.transform:Find("normal").gameObject:SetActive(false)

            rankObj.transform:Find("highlight/图标1").gameObject:SetActive(false)
            rankObj.transform:Find("highlight/图标2").gameObject:SetActive(false)
            rankObj.transform:Find("highlight/图标3").gameObject:SetActive(false)
            rankObj.transform:Find("highlight/图标" .. tostring(index)).gameObject:SetActive(true)
        else

            rankObj.transform:Find("highlight").gameObject:SetActive(false)
            rankObj.transform:Find("normal").gameObject:SetActive(true)

            local rankText = tostring(index)
            if index == 1 then
                rankText = "<color=#FFE81F>" .. rankText .. "</color>"
            elseif index == 2 then
                rankText = "<color=#29B6F5>" .. rankText .. "</color>"
            elseif index == 3 then
                rankText = "<color=#DF8F4C>" .. rankText .. "</color>"
            else
                rankText = "<color=#FFFFFF>" .. rankText .. "</color>"
            end
            local rankTextIdx = rankObj.transform:Find("normal/idx"):GetComponent(typeof(CS.TMPro.TextMeshProUGUI))

            rankTextIdx.text = rankText
            local rect = rankTextIdx:GetComponent(typeof(CS.UnityEngine.RectTransform))
            rect.anchoredPosition = CS.UnityEngine.Vector2(5, rect.anchoredPosition.y)
            rankTextIdx.alignment = CS.TMPro.TextAlignmentOptions.Center
        end

        if showHighlight then
            content = rankObj.transform:Find("highlight/content")
        else
            content = rankObj.transform:Find("normal/content")
        end
        --节点名称
        local section = {"磐石", "钢铁", "青铜", "白银", "黄金", "钻石"}

        if value.showRankLevel and value.rankInfo ~= nil and self.isRank == true then
            for i, v in ipairs(section) do
                content:Find(v).gameObject:SetActive(false)
            end
            content:Find("巅峰").gameObject:SetActive(false)
            local currentSection = 0

            for i, v in ipairs(section) do

                if i == value.rankInfo.level then
                    local _sub = value.rankInfo.section_name

                    if _sub == "1" then
                        _sub = "I"
                    elseif _sub == "2" then
                        _sub = "II"
                    elseif _sub == "3" then
                        _sub = "III"
                    elseif _sub == "4" then
                        _sub = "IV"
                    elseif _sub == "5" then
                        _sub = "V"
                    elseif _sub == "6" then
                        _sub = "VI"
                    elseif _sub == "7" then
                        _sub = "VII"
                    elseif _sub == "8" then
                        _sub = "VIII"
                    elseif _sub == "9" then
                        _sub = "IX"
                    end

                    content:Find(v).gameObject:SetActive(true)
                    content:Find(v):GetComponentInChildren(typeof(CS.TMPro.TextMeshProUGUI)).text = "<color=#000000>" ..
                                                                                                        self:getRankName(v) .. _sub ..
                                                                                                        "</color>"
                    currentSection = i
                    break
                end

            end

            if currentSection == 0 then
                content:Find("巅峰").gameObject:SetActive(true)
                content:Find("巅峰"):GetComponentInChildren(typeof(CS.TMPro.TextMeshProUGUI)).text =
                    "<color=#000000>" .. self:getRankName("巅峰") .. self:GetMaxNumStr(value.rankInfo.level_score) .. "</color>"
            end

        else
            for i, v in ipairs(section) do
                content:Find(v).gameObject:SetActive(false)
            end
            content:Find("巅峰").gameObject:SetActive(false)
            -- 隐藏段位
        end

        local nameText_tmp = content:Find("名字"):GetComponentInChildren(typeof(CS.TMPro.TMP_Text))

        self:FetchRealTimeInMS("1")
        self:FetchRealTimeInMS()

        if self.nameLengthMap == nil then
            self.nameLengthMap = {}
        end

        local nameStr = self.nameLengthMap[v.avatarName]
        if nameStr == nil then
            nameStr = ""
            local nameText = content:Find("Text"):GetComponentInChildren(typeof(CS.UnityEngine.UI.Text))
            nameText.gameObject:SetActive(true)
            local _t = self:StringToTable(v.avatarName)
            for k, v in pairs(_t) do
                nameStr = nameStr .. v
                nameText.text = nameStr
                -- 计算宽度
                local _width = nameText.preferredWidth;
                if _width > 100 then
                    nameStr = self:Truncate(nameStr, k - 1) .. "..."
                    break
                end
            end

            nameText.gameObject:SetActive(false)
            self.nameLengthMap[v.avatarName] = nameStr
        end

        if value.uuid == App.Uuid then
            nameStr = "<color=#FFE81F>" .. nameStr .. "</color>"
        else
            nameStr = "<color=#FFFFFF>" .. nameStr .. "</color>"
        end

        nameText_tmp.text = nameStr

        local rankText = rankObj.transform:Find("答题数"):GetComponentInChildren(typeof(CS.TMPro.TextMeshProUGUI))
        if value.text == nil then
            rankText.text = value.score .. "分"
        else
            rankText.text = value.text
        end

        self.title.text = value.title

        index = index + 1
        self:FetchRealTimeInMS("2")

    end

    local rectTransform = self.slider.transform:GetComponent(typeof(CS.UnityEngine.RectTransform))
    rectTransform.sizeDelta = CS.UnityEngine.Vector2(0, 52 * (index - 1) + 40)

    -- 设置宽高
    local imageTransform = self.sv.transform:GetComponent(typeof(CS.UnityEngine.RectTransform))
    local height = 48 * (index - 1) + 84
    height = height <= 275 and height or 275
    imageTransform.sizeDelta = CS.UnityEngine.Vector2(imageTransform.sizeDelta.x, height)
end
function FsyncElement:getRankName(key)

    if key == "磐石" then
        return "学童"
    elseif key == "钢铁" then
        return "学生"
    elseif key == "青铜" then
        return "学者"
    elseif key == "白银" then
        return "学士"
    elseif key == "黄金" then
        return "学霸"
    elseif key == "钻石" then
        return "学圣"
    elseif key == "巅峰" then
        return "学神"
    end
end
---@param worldElement CS.Tal.framesync.WorldElement
function FsyncElement:initialize(worldElement)
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    FsyncElement.super.initialize(self, worldElement)
    self.miniRankInfoKey = "miniRankInfo"
    self.miniRankListKey = "miniRankList"
    self.miniRankList = {}
    self:SubscribeMsgKey(self.miniRankListKey)
    self:SubscribeMsgKey("activateRoom")

end
function FsyncElement:setVisElement(VisElement)
    self.VisElement = VisElement

    local func = function()
        self.commonService = App:GetService("CommonService")
        self.VisElement.transform:Find("minirank/Asset"):GetComponent(typeof(CS.UnityEngine.Canvas)).sortingOrder = 100
        self.root = self.VisElement.transform:Find("minirank/Asset")
        self.baseObje = self.VisElement.transform:Find("minirank/Asset/排行榜名次")
        self.baseObje.gameObject:SetActive(false)
        self.slider = self.VisElement.transform:Find("minirank/Asset/滚动视图/滚动区域/滚动内容")

        self.sv = self.VisElement.transform:Find("minirank/Asset/滚动视图")
        self.title = self.sv:Find("标题"):GetComponentInChildren(typeof(CS.TMPro.TextMeshProUGUI))
        -- 设置排行榜右上对齐
        local svRectTransform = self.sv:GetComponent(typeof(CS.UnityEngine.RectTransform))
        local newLayoutTagGo = GameObject.Find("底部答题视频面板")
        if newLayoutTagGo then
            svRectTransform.anchorMin = Vector2(1, 1)
            svRectTransform.anchorMax = Vector2(1, 1)
            svRectTransform.pivot = Vector2(1, 1)
            svRectTransform.anchoredPosition = Vector2(-20, -150)
        else
            local rect = self.sv:GetComponent(typeof(CS.UnityEngine.RectTransform))
            rect.anchoredPosition = Vector2(85.27368, -120);
        end

        -- 订阅刷新排行榜消息

        self.pool = {}

        self.observerService:Watch("RefleshRankUI", function(key, args)
            local data = args[0]

            self.rankData = data
        end)
        self.configService = CourseEnv.ServicesManager:GetConfigService()
        self.isStartShow = self.configService:GetConfigValueByConfigKey(self.VisElement, "isStartShow")

        if self.isStartShow ~= "True" then
            self:Hide()
        end

        -- 是否显示rank信息
        local isRank = self.configService:GetConfigValueByConfigKey(self.VisElement, "isRank")

        if isRank ~= "True" then
            self.isRank = false
            self:SendRankInfo(nil)
        else
            self.isRank = true
        end
    end

    local assetPath = "modules/" .. RESOURCE_LOC .. "/assets/prefabs/business/minirank/assets/Prefabs/Canvas.prefab"
    ResourceManager:LoadGameObjectWithExName(assetPath, function(asset)

        local go = GameObject.Instantiate(asset)
        local p = GameObject("minirank")
        go.name = "Asset"
        p.transform:SetParent(self.VisElement.transform)
        go.transform:SetParent(p.transform)
        func()
    end)

end
function FsyncElement:Show()
    self.root.gameObject:SetActive(true)
end
function FsyncElement:GetMaxNumStr(number)
    local str = tostring(number) -- 把数字转换成字符串
    if #str > 3 then -- 如果字符串长度超过3
        return "999+" -- 就返回“999+”
    else -- 否则
        return str -- 就返回原字符串
    end
end
function FsyncElement:Hide()
    self.root.gameObject:SetActive(false)

end
-- 截取字符串，按字符截取
-- str:         要截取的字符串
-- startChar:   开始字符下标,从1开始
-- numChars:    要截取的字符长度
function FsyncElement.utf8sub(str, startChar, numChars)
    local startIndex = 1
    while startChar > 1 do
        local char = string.byte(str, startIndex)
        startIndex = startIndex + FsyncElement.chsize(char)
        startChar = startChar - 1
    end

    local currentIndex = startIndex

    while numChars > 0 and currentIndex <= #str do
        local char = string.byte(str, currentIndex)
        currentIndex = currentIndex + FsyncElement.chsize(char)
        numChars = numChars - 1
    end
    return str:sub(startIndex, currentIndex - 1)
end

function FsyncElement.utf8Insert(str, i, subStr)
    return FsyncElement.utf8sub(str, 1, i) .. subStr .. FsyncElement.utf8sub(str, i + 1, FsyncElement.utf8len(str) - 1)
end

-- 计算utf8字符串字符数, 各种字符都按一个字符计算
function FsyncElement.utf8len(str)
    local len = 0
    local currentIndex = 1
    while currentIndex <= #str do
        local char = string.byte(str, currentIndex)
        currentIndex = currentIndex + FsyncElement.chsize(char)
        len = len + 1
    end
    return len
end
-- 判断utf8字符byte长度
function FsyncElement.chsize(char)
    if not char then
        return 0
    elseif char > 240 then
        return 4
    elseif char > 225 then
        return 3
    elseif char > 192 then
        return 2
    else
        return 1
    end
end
function FsyncElement:StringToTable(str)
    local tbl = {}

    for _, code in utf8.codes(str) do
        tbl[#tbl + 1] = utf8.char(code)
    end
    return tbl
end

function FsyncElement:Truncate(str, max)

    local t = self:StringToTable(str)
    local result = {}

    for i = 1, max do
        if t[i] == nil then
            break
        end
        table.insert(result, t[i])
    end
    return table.concat(result, "")
end
function FsyncElement:GetStrLength(str)
    return #self:StringToTable(str)
end
-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function FsyncElement:ReceiveMessage(key, value, isResume)
    -- TODO:
    if key == self.miniRankListKey then
        self.miniRankList = json.decode(value[#value]);
        self:UpdateRankList(self.miniRankList)
    elseif key == "activateRoom" then
        local _d = json.decode(value[#value]);
        -- g_Log("请求rank数据 game_id" .. _d.game_id)

        local game_type = tonumber(_d.game_type)
        self:UpdateList(game_type)
    end
end
function FsyncElement:UpdateRankList(data)
    self.observerService:Fire("RefleshRankUI", data)
end
-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function FsyncElement:SendCustomMessage(key, body)
    self:SendMessage(key, body)
end
function FsyncElement:UpdateList(gameId)

    if self.isRank == false then
        self:SendRankInfo(nil)
        return
    end

    local host = "app.chuangjing.com"
    local domain = "https://" .. host .. "/next-api"
    local url = domain .. "/v3/game/user/get-ranking"
    local ranking = {
        level = 1,
        level_name = "磐石",
        section_num = 1,
        section_name = "5",
        level_score = 0
    }
    ---请求排位等级，并发送给remote
    if App.IsStudioClient then
        self:SendRankInfo(ranking)
    else
        APIBridge.RequestAsync('api.httpclient.request', {
            ["url"] = url,
            ["headers"] = {
                ["Content-Type"] = "application/json"
            },
            ["data"] = {
                type_id = gameId
            }
        }, function(res)
            if res ~= nil and res.responseString ~= nil and res.isSuccessed then
                local resp = res.responseString
                local data = json.decode(resp)
                -- g_Log("rank获取积分成功 " .. resp)
                if data then
                    if data.code == 0 then
                        -- 成功
                        self:SendRankInfo(data.data.ranking)
                    else
                        -- g_LogError("rank获取积分失败 " .. resp)
                        -- 失败
                        self:SendRankInfo(ranking)
                    end
                else
                    -- 失败
                    -- g_LogError("rank获取积分失败 " .. resp)
                    self:SendRankInfo(ranking)
                end
            else

            end
        end)
    end
end
-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarCreated(avatar)
    if App.IsStudioClient then
        self:UpdateList(1)
    end

end
function FsyncElement:SendRankInfo(info)
    if self.rankInfoSended == true then
        return
    end
    local _d = {
        rankInfo = info,
        avatarName = App.Properties.AvatarName,
        uuid = App.Uuid, -- 玩家id
        score = 0, -- 分数
        alive = true, -- 存活标记
        highlight = false, -- 是否高亮，只有前三名有高亮
        showRankLevel = true, -- 是否显示rank等级
        title = "排行榜", -- 标题
        unit = "分", -- 单位
        text = "0分" -- 显示文本,优先级更高
    }
    -- g_Log("发送rank信息")
    -- g_Log(table.dump(_d, nil, 3))

    self.commonService:StartCoroutine(function()

        self.commonService:Yield(self.commonService:WaitUntil(function()
            return self.selfAvatarLoaded == true
        end))
        self.rankInfoSended = true
        self:SendCustomMessage(self.miniRankInfoKey, _d)
    end)

end
-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarPrefabLoaded(avatar)
    self.selfAvatarLoaded = true
end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
-- 是否是异步恢复如果是需要改成true
function FsyncElement:LogicMapIsAsyncRecorver()
    return false
end
-- 开始恢复方法（断线重连的时候用）
function FsyncElement:LogicMapStartRecover()
    FsyncElement.super:LogicMapStartRecover()
    -- TODO
end
-- 结束恢复方法 (断线重连的时候用)
function FsyncElement:LogicMapEndRecover()
    FsyncElement.super:LogicMapEndRecover(self)
    -- TODO
end
-- 所有的组件恢复完成
function FsyncElement:LogicMapAllComponentRecoverComplete()
end

-- 收到Trigger事件
function FsyncElement:OnReceiveTriggerEvent(interfaceId, args)
    if interfaceId == "data" then
        -- g_Log("更新排行榜数据：" .. table.dump(args))
        self.observerService:Fire("RefleshRankUI", args)
    elseif interfaceId == "show" then
        self:Show()
    end
end
-- 收到GetData事件
function FsyncElement:OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

-- 脚本释放
function FsyncElement:Exit()
    FsyncElement.super.Exit(self)
end

return FsyncElement

