---
---  Author: 【杨浩】
---  AuthorID: 【149456】
---  CreateTime: 【2023-7-26 15:29:57】
--- 【FSync】
--- 【注册选皮肤】
---

local class = require("middleclass")
local WBElement = require("mworld/worldBaseElement")

---@class fsync_2f2f7c0a_af6a_4286_a653_5c5527d5c708 : WorldBaseElement
local FsyncElement = class("fsync_2f2f7c0a-af6a-4286-a653-5c5527d5c708", WBElement)



---@param worldElement CS.Tal.framesync.WorldElement
function FsyncElement:initialize(worldElement)
    FsyncElement.super.initialize(self, worldElement)

    ---@type CommonService
    self.commonService = App:GetService("CommonService")
    ---@type HttpService
    self.httpService = CourseEnv.ServicesManager:GetHttpService()
    ---@type ObserverService
    self.observerService = CourseEnv.ServicesManager:GetObserverService()
    ---@type AvatarService
    self.avatarService = CourseEnv.ServicesManager:GetAvatarService()
    ---@type DecorateService
    self.decorateService = CourseEnv.ServicesManager:GetDecorateService()
    ---@type JsonService
    self.jsonService = CourseEnv.ServicesManager:GetJsonService()
    ---@type LightService
    self.lightService = CourseEnv.ServicesManager:GetLightService()

    self.currentColorIndex = -1
    self:_initView()
    self:RegisterNativeEvent()
end

function FsyncElement:RegisterNativeEvent()
    
    --注册native点击换肤
    APIBridge.CreateService("unity.login.changeSkin", {}, function(res)
        g_Log("注册换肤 --- 点击换肤",table.dump(res))
        local info = {
            ["url"] = res.url,
            ["bodyPartType"] = res.bodyPartType,
            ["gender"] = "1",
            ["cutType"] = res.cutType,
            ["decorateType"] = res.decorateType ,
            ["isDefault"] = res.isDefault,
            ["uAddress"] = res.uAddress
        }
        local skinInfoList = {}
        table.insert(skinInfoList,info)
        self.decorateService:ChangeSkinOnly(true, self.avatarGO, function(isSuccess, info)
            if isSuccess then
                g_Log("模型换装成功 SUCCEED")
                
            else
                g_LogError("换装失败 FAILED")
            end
        end, skinInfoList)

    end)

    

    --注册native点击换脸型
    APIBridge.CreateService("unity.login.changeFace", {}, function(res)
        g_Log("注册换脸 --- 点击换脸",table.dump(res))
        if res.faceType and res.index then
            local faceType = res.faceType
            local index = res.index
            if faceType == 1 then
                -- face
                self.decorateService:ChangeEmote(true,self.avatarGO,index)
            else
                -- color
                self.currentColorIndex = index
                self.decorateService:ChangeFaceColor(true,self.avatarGO,index)
            end
        end
    end)


    APIBridge.CreateService("unity.login.completion", {}, function(res)
        g_Log("注册换头发 --- 完成注册",table.dump(res))

        self:CompleteRegister(res.name)
    end)

    -- CourseEnv.ServicesManager:GetUIService().PickBtnClick:connect(function()
        
    --     self:CompleteRegister("哈哈哈哈")
    -- end)

    APIBridge.CreateService("app.login.show.sex", {}, function(res)
        g_Log("切换预设角色",table.dump(res))
        local sexValue = res.sex
        if sexValue then
            self:ChangeSex(tonumber(sexValue), function ()
                --给端上一个回调
                APIBridge.RequestAsync("app.login.show.loadModelFinish", {})
                if self.currentColorIndex ~= -1 then
                    self.decorateService:ChangeFaceColor(true,self.avatarGO,self.currentColorIndex)
                end
            end)
        end
    end)

    -- self.commonService:DispatchAfter(5,function ()
    --     print("===== 换表情")
    --     self.decorateService:ChangeEmote(true,self.avatarGO,29)
        -- self.commonService:DispatchAfter(3,function ()
        --     print("===== 换肤色")
        --     self.decorateService:ChangeEmote(true,self.avatarGO,26)
        -- end)
    -- end)
end

function FsyncElement:ChangeSex(sexValue, callback)
    ---加载对应的 模型皮肤
    self:LoadModel({}, sexValue, callback)
end

function FsyncElement:ChangeSkin()

end

function FsyncElement:CompleteRegister(name)

    
end

function FsyncElement:_initView() 

    self.root = self.VisElement.gameObject
    -- self.root:SetActive(false)
    self.rootTrans = self.VisElement.transform
    self.ui = self.rootTrans:FindChildWithName("模型")
    self.canvasTrans = self.ui:FindChildWithName("Canvas")
    ---@type CS.UnityEngine.Canvas
    self.canvas = self.canvasTrans:GetComponent(typeof(CS.UnityEngine.Canvas))
    self.canvas.sortingOrder = 1500


    self.idol = self.canvasTrans:FindChildWithName("idol").gameObject
    ---@type CS.UnityEngine.UI.RawImage 
    self.idolImage = self.idol:GetComponent(typeof(CS.UnityEngine.UI.RawImage))

    -- local genderChangedNode = self.canvasTrans:FindChildWithName("genderChange")
    -- if genderChangedNode then
    --     genderChangedNode.gameObject:SetActive(true)
    --     local boyButton = genderChangedNode:FindChildWithName("Boy"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    --     local boySelectedTf = genderChangedNode:Find("Boy/Selected")
    --     local girlButton = genderChangedNode:FindChildWithName("Girl"):GetComponent(typeof(CS.UnityEngine.UI.Button))
    --     local girlSelectedTf = genderChangedNode:Find("Girl/Selected")
    --     self.commonService:AddEventListener(boyButton, "onClick", function() 
    --         print("选择 男")
    --         self:ChangeSex(1)
    --         boySelectedTf.gameObject:SetActive(true)
    --         girlSelectedTf.gameObject:SetActive(false)
    --     end)
    --     self.commonService:AddEventListener(girlButton, "onClick", function() 
    --         print("选择 女")
    --         self:ChangeSex(2)
    --         boySelectedTf.gameObject:SetActive(false)
    --         girlSelectedTf.gameObject:SetActive(true)
    --     end)
    -- end
    
    self.container = self.ui:FindChildWithName("container")
    ---@type CS.UnityEngine.Transform
    self.idolNode = self.ui:FindChildWithName("idolNode")

    self.cameraGO = self.idolNode:FindChildWithName("CameraGO").gameObject

    ---@type CS.UnityEngine.Camera
    self.camera = self.cameraGO:AddComponent(typeof(CS.UnityEngine.Camera))

    

    self.camera.clearFlags = CS.UnityEngine.CameraClearFlags.SolidColor
    self.camera.backgroundColor = CS.UnityEngine.Color(0, 0, 0, 0)
    self.camera.targetTexture = self.idolImage.texture
    self.camera.fieldOfView = 40

    local lightTrans = self.lightService.light.transform
    
    self.idolNode.eulerAngles = Vector3(-1 * lightTrans.eulerAngles.x, lightTrans.eulerAngles.y - 180, -1 * lightTrans.eulerAngles.z)

    self:LoadModel({},1, function ()
        --模型加载完成 通知native把列表显示出来
        print("模型加载完成 通知native把列表显示出来")
        APIBridge.RequestAsync("app.login.show.skinList", {})
    end)

    self:AddRawImageEvent()

    if App.IsStudioClient then
        self.canvas.sortingOrder = 50
        local testCanvas = self.VisElement.transform:Find("屏幕画布")
        local buttons = testCanvas:GetComponentsInChildren(typeof(CS.UnityEngine.UI.Button),true)
        if buttons then
            for i = 0, buttons.Length - 1 do
                local button = buttons[i]
                self.commonService:AddEventListener(button, "onClick", function ()
                    self:ButtonClick(button)
                end)
            end
        end
    end

end

function FsyncElement:ButtonClick(button)
    print("button.gameObject.name:",button.gameObject.name)
    local index = tonumber(button.gameObject.name)
    if index > 1000 and index < 2000 then
        --表情切换
        self.decorateService:ChangeEmote(true,self.avatarGO,index)
    else
        ---肤色切换
        self.decorateService:ChangeFaceColor(true,self.avatarGO,index)
    end
    
end

--添加Raw Image触摸旋转事件
function FsyncElement:AddRawImageEvent()
    self.listTouchPosition = Vector2()
    local width = CS.UnityEngine.Screen.width
    local referWidth = 1624

    ---@type CS.Com.Tal.Unity.UI.EventTriggerHandler
    self.triggerEvent = self.idol:GetComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
    if self.triggerEvent == nil then
        self.triggerEvent = self.idol:AddComponent(typeof(EventTriggerNameSpace.EventTriggerHandler))
        self.triggerEvent:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.BeginDrag, function(data)
            self.listTouchPosition = Input.mousePosition
        end)
        self.triggerEvent:AddEvent(EventTriggerTypeNameSpace.EventTriggerType.Drag, function(data)
            local offset = Input.mousePosition - self.listTouchPosition

            self.container.localEulerAngles = self.container.localEulerAngles + Vector3(0, -0.95 * offset.x * referWidth / width, 0)

            self.listTouchPosition = Input.mousePosition
        end)
    end
end

function FsyncElement:LoadModel(skinInfo, gender, callback)
    
    print("gyz === LoadModel ===")
    if self.avatarGO then
        CS.UnityEngine.GameObject.Destroy(self.avatarGO)
        self.avatarGO = nil
    end
    
    self.decorateService:LoadAndChangeSkin(gender, true, function(avatarGO)
        -- if self.avatarGO then
        --     return
        -- end
        ---@type CS.UnityEngine.GameObject
        self.avatarGO = avatarGO
        avatarGO.transform:SetParent(self.container)
        avatarGO.transform.localPosition = Vector3.zero
        avatarGO.transform.localScale = Vector3.one
        avatarGO.transform.localRotation = CS.UnityEngine.Quaternion.identity
        self:CancelShadows(self.avatarGO)
        -- self.Animator = avatarGO:GetComponentInChildren(typeof(CS.UnityEngine.Animator))
        -- self.Animator:SetFloat("speed", 0)
        if callback then
            callback()
        end
    end, skinInfo)
end

function FsyncElement:CancelShadows(model)
    local renderers = model:GetComponentsInChildren(typeof(CS.UnityEngine.Renderer))
    for i = 0, renderers.Length - 1 do
        local renderer = renderers[i]
        renderer.shadowCastingMode = CS.UnityEngine.Rendering.ShadowCastingMode.Off
        renderer.receiveShadows = false
    end
end

-- 收到/恢复IRC消息
-- @param key  订阅的消息key
-- @param value  消息集合体
-- @param isResume  是否为恢复消息
function FsyncElement:ReceiveMessage(key, value, isResume)
    -- TODO:
end

-- 发送KEY-VALUE 消息 
-- @param key 自定义/协议key
-- @param body  table 消息体
function FsyncElement:SendCustomMessage(key, body)
    self:SendMessage(key,body)
end

-- 自己avatar对象创建完成
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarCreated(avatar)

end

-- 自己avatar对象人物模型加载完成ba
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:SelfAvatarPrefabLoaded(avatar)

end

-- avatar对象创建完成，包含他人和自己
-- @param avatar 对应自己的Fsync_avatar对象
function FsyncElement:AvatarCreated(avatar)

end

------------------------蓝图组件相应方法---------------------------------------------
--是否是异步恢复如果是需要改成true
function FsyncElement:LogicMapIsAsyncRecorver()
    return false
end
--开始恢复方法（断线重连的时候用）
function FsyncElement:LogicMapStartRecover()
    FsyncElement.super:LogicMapStartRecover()
    --TODO
end
--结束恢复方法 (断线重连的时候用)
function FsyncElement:LogicMapEndRecover()
    FsyncElement.super:LogicMapEndRecover(self)
    --TODO
end
--所有的组件恢复完成
function FsyncElement:LogicMapAllComponentRecoverComplete()
end

--收到Trigger事件
function FsyncElement : OnReceiveTriggerEvent(interfaceId)
end
--收到GetData事件
function FsyncElement : OnReceiveGetDataEvent(interfaceId)
    return nil
end

------------------------蓝图组件相应方法End---------------------------------------------

--- 脚本释放
function FsyncElement:Exit()
    FsyncElement.super.Exit(self)
    if self.triggerEvent then
        self.triggerEvent:ClearAll()
    end
end

return FsyncElement
 

